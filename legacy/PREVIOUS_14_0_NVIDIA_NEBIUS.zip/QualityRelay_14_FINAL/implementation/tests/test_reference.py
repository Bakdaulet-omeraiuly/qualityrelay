from fastapi.testclient import TestClient
from qualityrelay14.api import app
from qualityrelay14.core import pair_assessment, numeric_mm
from qualityrelay14.ocr import parse_mm, stable_lcd
from qualityrelay14.ledger import DemoLedger
from qualityrelay14.vision import golden_difference,decode_data_image
import numpy as np
import cv2,base64
import pytest,uuid

client=TestClient(app)

def test_pair_rejects_clearance_not_parts():
    a=pair_assessment('20.6','20.3',False,True)
    assert a['slot_locally_accepted'] and a['tab_locally_accepted']
    assert a['status']=='HOLD' and a['clearance_mm']=='0.3'

def test_pair_good_is_review_not_actual_pass():
    assert pair_assessment('21.0','20.0',False,True)['status']=='PASS_REVIEW'

def test_visual_dissent_holds():
    assert pair_assessment('21.0','20.0',True,True)['status']=='HOLD'

def test_missing_caliper_holds():
    assert pair_assessment('21.0','20.0',False,False)['status']=='HOLD'

def test_missing_peer_holds():
    assert pair_assessment('21.0','20.0',False,True,peer_fresh=False)['status']=='HOLD'

def test_invalid_measurement():
    with pytest.raises(ValueError):numeric_mm('nan')

def test_ocr_requires_unit():
    assert parse_mm('20.34') is None
    assert parse_mm('20.34 mm') is not None

def test_ocr_ambiguous_decimal_holds():
    assert not stable_lcd(['20.34 mm','20.34 mm','203.4 mm'])['ok']

def test_ocr_stable_text_needs_manual_confirm():
    d=stable_lcd(['20.34 mm']*3)
    assert d['ok'] and 'manual_confirmation' in d['reason']

def test_ocr_not_enough_frames():
    assert not stable_lcd(['20.34 mm'])['ok']

def test_vision_same_equals_zero_difference():
    im=np.ones((128,128,3),dtype=np.uint8)*220
    assert golden_difference(im,im)['image_difference_fraction']==0

def test_vision_large_defect_candidate():
    a=np.full((128,128,3),220,dtype=np.uint8); b=a.copy(); b[40:80,40:80]=5
    assert golden_difference(a,b)['anomaly_candidate']

def test_vision_pose_requires_registration():
    with pytest.raises(ValueError):golden_difference(np.zeros((100,100,3),np.uint8),np.zeros((120,120,3),np.uint8))

def test_ledger_double_ack_not_double_counted():
    l=DemoLedger();l.disposition('x','P1','CONFIRMED_REJECT',True)
    l.route_ack('ack','P1','CONFIRMED_REJECT','sensor_confirmed')
    l.route_ack('ack','P1','CONFIRMED_REJECT','sensor_confirmed')
    assert l.counters()['physically_rejected_count_sensor_confirmed']==1

def test_ledger_human_report_not_sensor():
    l=DemoLedger();l.disposition('x','P1','CONFIRMED_REJECT',True)
    l.route_ack('ack','P1','CONFIRMED_REJECT','human_observed')
    assert l.counters()['physically_rejected_count_sensor_confirmed']==0
    assert l.counters()['human_reported_reject_routes']==1

def test_ledger_disallows_unauthorized_disposition():
    with pytest.raises(PermissionError):DemoLedger().disposition('x','P1','PASS',False)

def test_ledger_disallows_wrong_route():
    l=DemoLedger();l.disposition('x','P1','PASS',True)
    with pytest.raises(ValueError):l.route_ack('ack','P1','CONFIRMED_REJECT','sensor_confirmed')

def test_health_reports_real_limitations():
    s=client.get('/api/demo/health').json()
    assert not s['full_peer_network_implemented'] and not s['physical_sorter_connected']

def test_endpoint_holds_bad_clearance():
    s=client.post('/api/demo/inspection',json={'specimen_slot_id':'A1','specimen_tab_id':'B1','slot_mm':'20.6','tab_mm':'20.3','measurement_manually_confirmed':True}).json()
    assert s['status']=='HOLD' and s['next_inspection']=='repeat_or_confirm_caliper'

def test_endpoint_caliper():
    assert client.post('/api/demo/caliper',json={'sample_id':'A1','frame_ocr_text':['20.30 mm']*3}).json()['ok']

def test_endpoint_vision():
    a=np.full((128,128,3),200,dtype=np.uint8); b=a.copy();b[:80,:80]=0
    _,aa=cv2.imencode('.png',a);_,bb=cv2.imencode('.png',b)
    x=client.post('/api/demo/vision',json={'sample_id':'A1','golden_image_b64':base64.b64encode(aa).decode(),'sample_image_b64':base64.b64encode(bb).decode()})
    assert x.status_code==200 and x.json()['anomaly_candidate']

def test_endpoint_bad_image_422():
    x=client.post('/api/demo/vision',json={'sample_id':'A1','golden_image_b64':'blah','sample_image_b64':'blah'})
    assert x.status_code==422

def test_ocr_image_false_positive_never_automatically_verifies():
    from qualityrelay14.ocr_image import caliper_image_ocr
    x=caliper_image_ocr(np.ones((60,120,3),dtype=np.uint8)*255)
    assert not x['instrument_verified']

def test_endpoint_caliper_image_bad_input():
    x=client.post('/api/demo/caliper/image',json={'sample_id':'T1','image_b64':'!bad'})
    assert x.status_code==422

def test_site_served():
    x=client.get('/')
    assert x.status_code==200 and 'QualityRelay' in x.text
