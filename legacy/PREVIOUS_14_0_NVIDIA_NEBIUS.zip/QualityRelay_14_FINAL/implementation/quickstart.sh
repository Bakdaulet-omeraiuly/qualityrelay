#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pytest -q
printf '\nStart at http://127.0.0.1:8000/ (Mac only); for phone use trusted HTTPS URL.\n'
exec uvicorn qualityrelay14.api:app --host 127.0.0.1 --port 8000
