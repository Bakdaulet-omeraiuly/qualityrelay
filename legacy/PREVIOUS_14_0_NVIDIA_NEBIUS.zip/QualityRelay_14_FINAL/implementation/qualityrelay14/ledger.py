"""In-memory traceable idempotent demo ledger (NOT production secure storage)."""
from dataclasses import dataclass
from collections import defaultdict


class DemoLedger:
    def __init__(self):
        self.events = {}
        self.dispositions = {}
        self.route_acks = {}

    def disposition(self, event_id: str, specimen_id: str, status: str, approved: bool):
        if event_id in self.events:
            return self.events[event_id]
        if status not in {'PASS', 'HOLD', 'CONFIRMED_REJECT'}:
            raise ValueError('unknown disposition')
        if not approved and status != 'HOLD':
            raise PermissionError('human approval required')
        # Mutable current state version is demo-only; real persistence uses versioned CAS.
        if specimen_id in self.dispositions and self.dispositions[specimen_id]['status'] != status:
            raise ValueError('conflicting disposition; formal supersession needed')
        event = {'event_id':event_id, 'specimen_id':specimen_id,
                 'status':status, 'approved':approved}
        self.events[event_id] = event
        self.dispositions[specimen_id] = event
        return event

    def route_ack(self, event_id: str, specimen_id: str, actual_bin: str, source: str):
        if event_id in self.events:
            return self.events[event_id]
        disposition = self.dispositions.get(specimen_id)
        if disposition is None or not disposition['approved']:
            raise PermissionError('no approved disposition')
        if disposition['status'] != actual_bin:
            raise ValueError('unexpected bin; manual investigation')
        if source not in {'human_observed', 'sensor_confirmed'}:
            raise ValueError('invalid acknowledgement source')
        if specimen_id in self.route_acks:
            raise ValueError('one confirmed routing per specimen')
        event = {'event_id':event_id,'specimen_id':specimen_id,
                 'actual_bin':actual_bin,'source':source}
        self.events[event_id] = event
        self.route_acks[specimen_id] = event
        return event

    def counters(self):
        statuses = {id:ev['status'] for id,ev in self.dispositions.items()}
        inspected = len(statuses)
        defect = sum(st=='CONFIRMED_REJECT' for st in statuses.values())
        physical_reject = sum(ack['actual_bin']=='CONFIRMED_REJECT' and ack['source']=='sensor_confirmed'
                              for ack in self.route_acks.values())
        operator_ack_reject = sum(ack['actual_bin']=='CONFIRMED_REJECT' and ack['source']=='human_observed'
                              for ack in self.route_acks.values())
        return {'inspected_count':inspected,'confirmed_defective_count':defect,
                'physically_rejected_count_sensor_confirmed':physical_reject,
                'human_reported_reject_routes':operator_ack_reject,
                'pending_reject_route_count':defect-physical_reject-operator_ack_reject,
                'held_count':sum(st=='HOLD' for st in statuses.values())}
