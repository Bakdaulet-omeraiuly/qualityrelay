"""Review-only, deterministic dimensional and evidence decision core.

IMPORTANT: does not supply a calibrated risk probability, certified QC decision,
or a real autonomous machine controller.
"""
from dataclasses import dataclass, asdict
from decimal import Decimal, InvalidOperation
from typing import Optional

SLOT_LOCAL = (Decimal('20.5'), Decimal('21.5'))
TAB_LOCAL = (Decimal('19.5'), Decimal('20.5'))
MIN_CLEARANCE = Decimal('0.5')


def numeric_mm(x) -> Decimal:
    try:
        d = Decimal(str(x))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise ValueError('invalid numeric measurement') from exc
    if not d.is_finite() or not (Decimal('0') < d < Decimal('1000')):
        raise ValueError('invalid physical size')
    return d


def pair_assessment(slot_mm, tab_mm, visual_suspicion: bool, metrology_confirmed: bool,
                    visual_evidence_usable: bool = True, peer_fresh: bool = True) -> dict:
    w, t = numeric_mm(slot_mm), numeric_mm(tab_mm)
    clearance = w - t
    in_slot_spec = SLOT_LOCAL[0] <= w <= SLOT_LOCAL[1]
    in_tab_spec = TAB_LOCAL[0] <= t <= TAB_LOCAL[1]
    adequate_clearance = clearance >= MIN_CLEARANCE
    reasons = []
    if not metrology_confirmed:
        reasons.append('caliper result needs operator confirmation')
    if not visual_evidence_usable:
        reasons.append('visual evidence missing, stale or low-quality')
    if not peer_fresh:
        reasons.append('remote peer evidence unavailable or stale')
    if visual_suspicion:
        reasons.append('possible visible defect; professional review required')
    if not in_slot_spec or not in_tab_spec:
        reasons.append('one or more dimensions fail the local acceptance interval')
    if not adequate_clearance:
        reasons.append('insufficient pairwise clearance')
    # Candidate review status; NEVER a final PASS/REJECT without authority and proof.
    status = 'HOLD' if reasons else 'PASS_REVIEW'
    return dict(status=status, slot_mm=str(w), tab_mm=str(t), clearance_mm=str(clearance),
                min_clearance_mm=str(MIN_CLEARANCE), slot_locally_accepted=in_slot_spec,
                tab_locally_accepted=in_tab_spec, clearance_sufficient=adequate_clearance,
                reasons=reasons, human_approval_required=True,
                evidence_level='DEMO_ONLY_UNCALIBRATED',
                calibrated_failure_probability=None)


def next_inspection(decision: dict) -> str:
    # Transparent fixed fallback; actual EVSI requires validated observation models.
    reasons = ' '.join(decision['reasons']).lower()
    if 'caliper' in reasons or 'clearance' in reasons:
        return 'repeat_or_confirm_caliper'
    if 'visible defect' in reasons or 'visual evidence' in reasons:
        return 'capture_new_side_view_or_human_inspection'
    if 'peer' in reasons:
        return 'request_authorized_fresh_peer_evidence'
    return 'no_additional_inspection_suggested'
