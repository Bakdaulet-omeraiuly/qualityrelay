"""Simple image-difference baseline; strict acquisition assumptions apply.

Not NVIDIA TAO, not a defect-calibrated classifier. This does not infer mm.
"""
import base64
import binascii
import numpy as np
import cv2


def decode_data_image(data: str, max_bytes=5_000_000):
    if data.startswith('data:'):
        data = data.split(',', 1)[-1]
    if len(data) > int(max_bytes * 4 / 3) + 20:
        raise ValueError('image too large')
    try:
        raw = base64.b64decode(data, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise ValueError('invalid base64 image') from exc
    if len(raw) > max_bytes:
        raise ValueError('image too large')
    img = cv2.imdecode(np.frombuffer(raw, np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError('unsupported image data')
    return img


def golden_difference(reference, observed, diff_threshold=28):
    """Return a visualization-level difference candidate in matching, registered views.
    Need background/pose control; percent is NOT defect probability.
    """
    if reference is None or observed is None:
        raise ValueError('reference and sample required')
    if min(*reference.shape[:2], *observed.shape[:2]) < 48:
        raise ValueError('image too small')
    if reference.shape != observed.shape:
        raise ValueError('image dimensions must match (register pose first)')
    a = cv2.GaussianBlur(cv2.cvtColor(reference, cv2.COLOR_BGR2GRAY), (5, 5), 0)
    b = cv2.GaussianBlur(cv2.cvtColor(observed, cv2.COLOR_BGR2GRAY), (5, 5), 0)
    diff = cv2.absdiff(a, b)
    ratio = float(np.count_nonzero(diff > diff_threshold)) / diff.size
    return dict(image_difference_fraction=round(ratio, 5),
                model='opencv_difference_baseline_v0',
                anomaly_candidate=ratio > 0.04,
                threshold_illustrative_only=True, calibrated_confidence=None,
                limitation='Requires same pose/lighting and sample-specific validation; not a mm measurement')
