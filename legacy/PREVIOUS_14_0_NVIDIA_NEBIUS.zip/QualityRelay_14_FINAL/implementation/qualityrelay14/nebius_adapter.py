"""OPTIONAL Nebius Token Factory bounded reasoning adapter.

The API key and model are mandatory via environment; model must be returned by
live model discovery; output is a proposal, NEVER an action or measurement.
"""
import os


def request_evidence_review(scoped_evidence: str) -> dict:
    from openai import OpenAI  # optional dependency, do not install for P0
    key = os.environ['NEBIUS_API_KEY']
    name = os.environ['NEBIUS_MODEL']
    client = OpenAI(base_url='https://api.tokenfactory.nebius.com/v1/',
                    api_key=key, timeout=30, max_retries=0)
    available = {x.id for x in client.models.list().data}
    if name not in available:
        raise ValueError('Selected model is not in this key\'s current model catalog')
    # Caller must redact sensitive input and independently validate response.
    r = client.chat.completions.create(model=name, temperature=0,
        messages=[{'role':'system','content':
           'You are a manufacturing QA reviewer. Make no measurement claims beyond supplied evidence. Never direct an actuator. Return a short provisional review with cited event IDs; when information is missing, say HOLD.'},
          {'role':'user','content':scoped_evidence}])
    return {'model':name,'provisional_review':r.choices[0].message.content,
            'is_verified':False,'may_actuate':False}
