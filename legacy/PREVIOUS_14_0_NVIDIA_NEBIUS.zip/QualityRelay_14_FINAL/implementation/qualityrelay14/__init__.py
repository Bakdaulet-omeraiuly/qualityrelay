"""QualityRelay 14 prototype: deliberately non-industrial reference code."""
__version__ = "0.1.0-demo"
