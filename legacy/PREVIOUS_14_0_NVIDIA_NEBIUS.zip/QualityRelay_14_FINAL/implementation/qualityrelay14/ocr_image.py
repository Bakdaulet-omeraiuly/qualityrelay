"""OPTIONAL real caliper-image OCR. Demonstration candidates only, not gauge truth.

Requires Tesseract binary and Python package pytesseract on local backend.
Never silently infers mm from an absent unit.
"""
import cv2
import numpy as np
from .ocr import parse_mm


def caliper_image_ocr(image):
    try:
        import pytesseract
    except ImportError:
        return {'ok':False,'candidates':[],'reason':'pytesseract_not_installed'}
    if image is None or image.ndim != 3 or min(image.shape[:2]) < 48:
        return {'ok':False,'candidates':[],'reason':'invalid_image'}
    gray = cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
    gray = cv2.resize(gray,None,fx=2,fy=2,interpolation=cv2.INTER_CUBIC)
    gray = cv2.GaussianBlur(gray,(3,3),0)
    variants = [gray]
    _,thr = cv2.threshold(gray,0,255,cv2.THRESH_OTSU+cv2.THRESH_BINARY)
    variants += [thr,255-thr]
    texts=[]; values=[]
    for im in variants:
        try:
            txt=pytesseract.image_to_string(im,config='--psm 7 -c tessedit_char_whitelist=0123456789.-mM ')
        except (pytesseract.TesseractNotFoundError, RuntimeError):
            return {'ok':False,'candidates':[],'reason':'tesseract_unavailable'}
        texts.append(txt.strip())
        v=parse_mm(txt)
        if v is not None:
            values.append(str(v))
    uniq=sorted(set(values))
    return {'ok':len(uniq)==1,'candidates':uniq,'raw_ocr_texts':texts,
            'reason':'candidate_needs_manual_confirmation' if len(uniq)==1 else 'unreadable_or_conflicting',
            'instrument_verified':False,'unit_verified':len(uniq)>0}
