"""A runnable web/demo API, not implemented fully decentralized manufacturing system.

Start: uvicorn qualityrelay14.api:app --reload
"""
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from pathlib import Path
from .core import pair_assessment, next_inspection
from .ocr import stable_lcd
from .vision import decode_data_image, golden_difference
from .ocr_image import caliper_image_ocr
from .ledger import DemoLedger

app = FastAPI(title='QualityRelay 14 Reference Demo', version='0.1.0')
ledger = DemoLedger()

class InspectionRequest(BaseModel):
    specimen_slot_id: str = Field(min_length=1, max_length=100)
    specimen_tab_id: str = Field(min_length=1, max_length=100)
    slot_mm: str
    tab_mm: str
    measurement_manually_confirmed: bool = False
    suspected_visual_defect: bool = False
    visual_evidence_usable: bool = False
    peer_fresh: bool = True

class OCRRequest(BaseModel):
    sample_id: str = Field(min_length=1)
    frame_ocr_text: list[str] = Field(min_length=1)

class CaliperImageRequest(BaseModel):
    sample_id: str
    image_b64: str

class VisionRequest(BaseModel):
    sample_id: str
    golden_image_b64: str
    sample_image_b64: str

class DispositionRequest(BaseModel):
    event_id: str
    specimen_id: str
    status: str
    approved_by_human: bool = False

class AckRequest(BaseModel):
    event_id: str
    specimen_id: str
    actual_bin: str
    evidence_source: str

@app.get('/api/demo/health')
def health():
    return {'app':'QualityRelay 14.0', 'status':'reference-only',
            'nebius_inference_connected':False,'nvidia_tao_model_loaded':False,
            'full_peer_network_implemented':False,'physical_sorter_connected':False}

@app.post('/api/demo/inspection')
def inspect(r:InspectionRequest):
    try:
        ans = pair_assessment(r.slot_mm, r.tab_mm, r.suspected_visual_defect,
                              r.measurement_manually_confirmed,
                              r.visual_evidence_usable, r.peer_fresh)
        ans['next_inspection'] = next_inspection(ans)
        ans['specimen_ids'] = [r.specimen_slot_id, r.specimen_tab_id]
        return ans
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc

@app.post('/api/demo/caliper')
def caliper(r:OCRRequest):
    return dict(sample_id=r.sample_id, **stable_lcd(r.frame_ocr_text))

@app.post('/api/demo/caliper/image')
def caliper_image(r:CaliperImageRequest):
    try:
        return dict(sample_id=r.sample_id, **caliper_image_ocr(decode_data_image(r.image_b64)))
    except ValueError as exc:
        raise HTTPException(422,str(exc)) from exc

@app.post('/api/demo/vision')
def vision(r:VisionRequest):
    try:
        return dict(sample_id=r.sample_id, **golden_difference(
            decode_data_image(r.golden_image_b64),decode_data_image(r.sample_image_b64)))
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc

@app.post('/api/demo/disposition')
def disposition(r:DispositionRequest):
    try:return ledger.disposition(r.event_id,r.specimen_id,r.status,r.approved_by_human)
    except PermissionError as exc:raise HTTPException(403,str(exc)) from exc
    except ValueError as exc:raise HTTPException(409,str(exc)) from exc

@app.post('/api/demo/sorter/ack')
def ack(r:AckRequest):
    try:return ledger.route_ack(r.event_id,r.specimen_id,r.actual_bin,r.evidence_source)
    except PermissionError as exc:raise HTTPException(403,str(exc)) from exc
    except ValueError as exc:raise HTTPException(409,str(exc)) from exc

@app.get('/api/demo/counters')
def counters():
    return ledger.counters()

@app.get('/')
def website():
    return FileResponse(Path(__file__).resolve().parents[2]/'web'/'index.html')
