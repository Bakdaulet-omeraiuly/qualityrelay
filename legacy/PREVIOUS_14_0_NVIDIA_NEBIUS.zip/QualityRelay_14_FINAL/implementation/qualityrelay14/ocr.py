"""Caliper OCR guard: text parsing and frame stability; not instrument calibration."""
import re
from decimal import Decimal, InvalidOperation

# Require explicitly recognized unit, never assume pixels/screen values are mm.
LCD = re.compile(r'(?<![\d.])(-?\d{1,3}\.\d{1,3})\s*(mm)\b', re.IGNORECASE)


def parse_mm(text: str):
    txt = text.replace(',', '.')
    m = LCD.search(txt)
    if not m:
        return None
    try:
        v = Decimal(m.group(1))
    except InvalidOperation:
        return None
    if not v.is_finite() or v <= 0 or v > 500:
        return None
    return v


def stable_lcd(readings: list[str], min_frames=3, tolerance_mm='0.02') -> dict:
    """Requires consistent OCR text from >=3 frames, not proof of correct gauge contact."""
    if len(readings) < min_frames:
        return dict(ok=False, value_mm=None, reason='not_enough_frames')
    parsed = [parse_mm(r) for r in readings[-min_frames:]]
    if any(v is None for v in parsed):
        return dict(ok=False, value_mm=None, reason='invalid_or_missing_mm')
    vals = [v for v in parsed if v is not None]
    if max(vals) - min(vals) > Decimal(tolerance_mm):
        return dict(ok=False, value_mm=None, reason='unstable_or_conflicting_digits')
    return dict(ok=True, value_mm=str(vals[-1]), reason='candidate_only_needs_manual_confirmation')
