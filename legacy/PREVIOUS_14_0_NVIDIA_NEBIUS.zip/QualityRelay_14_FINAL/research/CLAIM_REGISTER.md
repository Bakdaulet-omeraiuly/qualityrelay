# Claim register (freeze alongside final slides)

| Claim | Allowed today? | Evidence needed before approval |
|---|---|---|
| "Phone photo can be submitted for review via website" | YES (reference code/API) | show actual upload from own phone HTTPS |
| "A deterministic clearance check and conservative HOLD logic run" | YES (25 unit/API tests run) | reproduce tests in `results/REFERENCE_TEST_RESULTS.txt` |
| "LCD photo OCR produces candidate" | YES with available pytesseract/tesseract, NOT verified on user caliper | actual device test + exact reading confirmation rate |
| "NVIDIA detects our 3D-printed defects" | NOT YET | labeled train/held-out data, actual TAO/model run ID, confusion matrix |
| "Nebius supplies our 21 autonomous AI agents" | NOT YET | live authenticated API, selective role tool calls, model IDs, source validation |
| "21 specialist agents fully implemented" | NO | contract+runtime test for all roles; currently retained architecture |
| "Genuinely distributed station peers work independently" | NOT YET IN V14 REFERENCE | separately running peers and outage/inbox replay demonstration |
| "Servo sorter physically sorts parts" | NOT YET | hardware assembled, bench-tested, route confirmation video/event |
| "We invented a scientifically new superior decision algorithm" | NO | prior art audit and reproducible fair benchmark showing meaningful effect |
| "We have surveyed 10,000 research papers" | NO | validated corpus + dedup + inclusion/exclusion counts; primary-paper reading audit |
| "Factory validated or certified" | NO | independent pilot + operator signoff + governance/security and measurement evidence |
