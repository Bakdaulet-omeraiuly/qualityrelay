# QUALITYRELAY 14.0 — VISION-GOVERNED EVIDENCE MESH

**Final scientific, architecture, physical-demo, NVIDIA/Nebius, and team implementation blueprint**  
**Freeze date:** 2026-10-30 · **Track:** ScienceClaw / Manufacturing & Materials  
**Owners:** Bakdaulet-omeraiuly, adilnurgg, HyorinmaruK; optional fourth contributor  
**Primary mode:** independently authorized decentralized station peers  
**What is ready in THIS release:** a Python reference decision service and tests, local vision baseline code, a browser camera capture interface, provider integration adapters and documented experimental protocols. This is a prototype package, **not** a validated production AI/robotic system. All unrun experiments are explicitly `NOT_RUN`.

> **One-sentence product:** QualityRelay connects a phone-based visual inspection, a human-operated digital caliper, four independent manufacturing stations, and a bounded network of specialist agents to identify unsafe assembly combinations, request decision-relevant evidence, and authorize traceable PASS / HOLD / CONFIRMED REJECT actions, with optional physical sorter verification.

> **Scientific claim (proposal, not result):** Evidence lineage, calibrated uncertainty, and decision-aware inspection may allow a decentralized manufacturing team to approach centralized decision quality with lower cross-station raw-data exposure and better continuity during network partitions, while avoiding unnecessary inspection. We will compare this against strong baselines, including ones that may win.

---

## 0. CHANGE CONTROL — all previous work retained

| Source | Mandatory retained decision | Status in this blueprint |
|---|---|---|
| 5.0 | Independent Slot/Tab/Assembly station ownership; local raw data; trusted scoped evidence; clearance risk, truncated accepted-part distributions, EWMA, Bayesian hypotheses, information gain, outages, exactly-once reconciliation | **Required unchanged**; original 5.0 source is appended verbatim and archived |
| 6–7 | Role-specific Design, Quality, Process, Assembly engineer agents; optional Chief Engineer coordinates but cannot bypass authority | 21-role registry retained, Chief as **comparison/hybrid**, not a secret central decisionmaker |
| 8.0 | Evidence Mesh, missing-evidence debt, protection of valid minority evidence, controlled agent-to-agent communication | Core research protocol |
| 9.0 | V-DER / decision-value hypothesis, literature-corpus collection program | Registered baseline and treatment; no unverified novelty statement |
| 10.0 | Narrow runnable backend, permissions, replay, partial evidence | Legacy reference baseline; new reference implementation is independent and smaller |
| 11–12 | **Fully decentralized primary deployment**, 21 specialists, Sorter 4th station, 50 Slot + 50 Tab target, PASS/HOLD/CONFIRMED REJECT, verified counting | Four-peer topology and sorter protocol required |
| 13.0 | PACE safety guard, lineage/de-duplication and counterexample studies | Hard gate and research checks |
| 13.1 | Visual Evidence Agent, geometry, ArUco calibration, CAIR, abstention | Phone camera **required** |
| **14.0** | NVIDIA TAO Visual ChangeNet / optional EfficientAD/PatchCore, NVIDIA Brev GPU, optional Nebius GPU, Nebius Token Factory and scientific tools where relevant, phone-based caliper LCD OCR and visible defect capture | **New integration**; provider access depends on actual credits and credentials |

**Scope correction:** The user chose their **own phone**, not an additional physical camera. The phone is the *default for both LCD OCR and appearance inspection*, sequentially. A teammate's webcam can substitute for LCD OCR; event hardware (ESP32/Raspberry Pi/servo) is **OPTIONAL P1**, never a required camera purchase. When sorter hardware is available, **servo moves only the sorting gate, never caliper jaws**.

**Do not lose sources:** The deliverable ZIP includes immutable copies of the 5.0 original, 10.0 reference package, 12.0 sorting package, and 13.1 camera research package. Older inner versions remain inside those packages. The new master is independent and does not force teams to open nested ZIPs for core build instructions.

## 1. Product and buyer

**First target:** small precision manufacturers and additive prototyping labs that operate separated metrology, machine/print, assembly and disposition workflows, where individually accepted parts may fail when paired. **First buyer/persona:** manufacturing quality engineer with authority to request reinspection, **not** a plant manager approving autonomous releases.

**Problem:** one station can only see its own verified observations; an apparently acceptable Slot and an apparently acceptable Tab can yield inadequate clearance. Camera evidence and dimensional evidence can disagree for legitimate reasons; an LLM majority vote is not a certified measurement. Repeated inspection and unjustified scrap cost labor and parts.

**Product workflows:** register lot and specimen IDs; capture phone images; read caliper display with OCR + confirmation; run local fit-risk / defect analysis; exchange scoped evidence; display contradictory assessments and missing evidence; request the next best inspection; select feasible pairings; require human approval; route/verify disposition, with measured actual results linked to the original claim.

**Non-goals:** unattended factory robot autonomy, auto-certification, industrial safety guarantee, inferring 0.1 mm tolerances from a casual phone shot, claiming unique prior-art ownership, treating 10,000 searched abstracts as read full texts, or presenting synthetic accuracy as industrial validation.

## 2. Judge-readable demo: 1 phone, 1 caliper, 3D prints

**Specimen kit:** 50 printed Slots and 50 printed Tabs is the v12 **target**; if printing capacity/time is insufficient, execute a smaller 3–10-pair demonstrator and clearly mark `DEMO_SAMPLE_SIZE`, while preserving the 100-part scientific protocol as `NOT_RUN` until complete. Print nominal, narrow-slot, thick-tab, visible print failure, and ambiguous appearance specimens. Assign unique QR/label or typed ID; keep raw geometry and final CAD revision. Include 3D fixture for stable phone height/light.

1. Operator chooses `Slot A-07`, taps `Capture caliper` on the phone website, physically measures the opening with the caliper, and aims the same phone at LCD. OCR yields *candidate*, not ground truth. Unit, stable frames, decimal point and association with ID are checked; uncertain readings go `HOLD_PENDING_CONFIRMATION`. Operator confirms or corrects reading. Caliper instrument + operator remain responsible for reading.
2. Operator chooses `Tab B-12`, repeats. Source events are append-only and marked `physical/manual_verified` (not `calibrated` unless calibration is actually documented).
3. Operator taps `Inspect surface`, points **same phone** at both components, gets guided alignment/photo quality, optional golden-reference image difference and model anomaly regions. A vision defect is *suspected*, not proven, until validated.
4. The Slot peer, Tab peer, Vision peer (as **additional independent evidence owner/worker**), Assembly peer, and Sorter peer (if activated) issue bounded event messages. The 21 *specialist roles* are invoked selectively based on evidence, not 21 expensive model calls per part.
5. Example discrepancy 1: Tab is within local tolerance but image shows suspected crack → **HOLD** pending inspection, not automatic PASS. Discrepancy 2: image appears normal but caliper shows insufficient pair clearance → **HOLD** and suggest higher information-value remeasure/pair change.
6. The decision engine computes evidence-scoped compatibility, hypotheses and best *next action*. It may say `MORE_EVIDENCE_REQUIRED` instead of inventing certainty.
7. On human-authorized `PASS`, `HOLD` or `CONFIRMED_REJECT`, the operator sorts by hand in P0. In P1, an ESP32 sends the servo to the appropriate **gate** position; an IR/beam-break or second phone view verifies physical arrival. Unverified route does not increment `physically_sorted`.
8. UI separately reports `inspected_count`, `confirmed_defective_count`, `physically_rejected_count`. An outage simulator severs one station; other services continue local measurements and mark peer data stale. Reconnect exactly once, show event hashes and audit log.
9. Side-by-side exact same specimen stream: isolated QC, centralized oracle, one general AI, decentralized peers without evidence governance, **QualityRelay**, optional hybrid Chief; compare matched accuracy, time, number and cost of inspections, raw bytes shared, unsafe-release rate, false reject, over-hold rate and outage behavior.

### 2.1 Correct count semantics

| Metric | Increment exactly when | NOT when |
|---|---|---|
| `inspected_count` | unique specimen ID has complete inspection record | frame processed, duplicate upload, incomplete inspection |
| `confirmed_defective_count` | distinct specimen disposition event is authorized and defect status validated | vision model flags anomaly, same event replay |
| `physically_rejected_count` | unique specimen routing to REJECT physically acknowledged | gate command sent, visual defect suspected, duplicate sensor pulse |
| `held_count` | unique specimen has active HOLD disposition | repeated OCR failures on same specimen |
| `unverified_sorting_count` | authorized route lacking ack or unexpected bin | successful ack |

**Counters must be derivable from immutable unique events, not incremented by video frames or arbitrary model outputs.** A REJECT disposition differs from actual physical sorting; investigate count discrepancies.

## 3. Diagram — unified website, decentralized runtime

```mermaid
flowchart TB
  Phone[Own iPhone/Android • HTTPS camera • caliper LCD OCR + defect photo] --> Capture[Phone Capture Gateway • ID and quality validation]
  Capture -->|scoped measurement/photo events| Slot[(Slot Peer • own DB)]
  Capture -->|scoped measurement/photo events| Tab[(Tab Peer • own DB)]
  Capture -->|scoped frames / derived detections| Vision[(Visual Evidence Peer • independent data authority)]
  Slot <-->|signed filtered events| Assembly[(Assembly Peer • own DB)]
  Tab <-->|signed filtered events| Assembly
  Vision <-->|verified image evidence| Assembly
  Assembly <-->|authorized disposition + ack| Sorter[(Sorter Peer • own DB)]
  Assembly <-->|relevant task only| Roles[21 bounded AI specialists + metrology, design, process, audit]
  Roles --> Decision[Deterministic stats + PACE + V-DER/CAIR]
  Decision --> Assembly
  Sorter --> Gate[Optional ESP32 servo gate + sensor / manual route]
  Slot --> Browser[One website Dashboard / Evidence / Experiments / Audit]
  Tab --> Browser
  Vision --> Browser
  Assembly --> Browser
  Sorter --> Browser
  Chief[Optional centralized Chief Engineer • comparison mode ONLY] -.-> Roles
```

**Independence test:** disable Assembly peer or any provider key; local Slot, Tab and Visual peers can continue local captures and queue approved records. A single web front door is UX, **not** evidence of decentralized authority. If every role reads a shared global DB and copies one global posterior, the primary decentralization claim fails.

## 4. Evidence contract v3 — truth before fluency

All messages are schema validated, content-addressed and scoped. Use ISO timestamps with timezone. `SHA256` validates accidental tampering, **not identity**; use properly authenticated peer identity, TLS/mTLS or signatures backed by managed secrets when appropriate. Never claim that a self-reported image hash proves its camera origin.

```json
{
  "schema_version":"3.0.0-draft",
  "event_id":"uuid-v4",
  "specimen_id":"tab-B12",
  "lot_id":"B",
  "station_id":"vision-peer-1",
  "observation_kind":"visual_anomaly_candidate",
  "origin_kind":"physical",
  "measurement":null,
  "unit":null,
  "model_score":0.82,
  "score_calibration_status":"NOT_CALIBRATED",
  "image_sha256":"hex_sha256_of_image_bytes",
  "source_event_ids":["uuid-source-camera-1"],
  "acquisition":{"device":"own_phone","view":"top","lighting":"diffuse","quality_gate":"pass"},
  "algorithm":{"id":"golden_image_v1","version":"0.1"},
  "evidence_status":"CANDIDATE",
  "observed_at":"2026-10-30T18:01:22-04:00",
  "expires_at":"2026-10-30T18:11:22-04:00"
}
```

**No majority vote on copies:** evidence graph nodes are original measurement events; agent interpretations are children of those nodes and **cannot independently multiply likelihoods**. Two agents citing the same photo are correlated testimony, not two independent sensors. A strong dissent must be preserved until its source is checked. On missing calibration / stale evidence / image-pose mismatch / low OCR confidence, system can only recommend `HOLD`, remeasurement or human review.

### 4.1 Authority table

| Actor | Reads | Allowed effect | Forbidden |
|---|---|---|---|
| Slot / Tab peers | own lot and measurement records | sign bounded summaries and queue events | read each other's raw tables |
| Visual peer | scoped image + capture metadata | flag candidate defect, request view | label unverified candidate as certified scrap |
| Assembly peer | scoped lot evidence and confirmed disposition | risk, next inspection, suggested pairing | direct factory actuator command |
| Sorter peer | authorized disposition + specimen ID | gate proposal and ack tracking | route until authorized; treat servo movement as arrival |
| Specialist agents | role-authorized sources and tools | bounded proposal + source IDs | fabricate raw measurements, override policy |
| Chief (optional) | allowed summaries only | request other agents, synthesize review | supersede peer authority or safety veto |
| Human reviewer | reviewed evidence and policy | approve/reject physical actions | rewrite audit events or counterfeit source origin |

### 4.2 PACE gate and dispositions

Safety checks are deterministic policy code, **not** LLM instructions. The *mechanical* clearance gate alone cannot guarantee absence of cracks; vision also cannot prove a submillimeter dimension from one uncalibrated image.

- `PASS_CANDIDATE` when all required evidence complete, acceptance criteria and uncertainty guards met, no unresolved critical disagreement; still needs approval for industrial disposition.
- `HOLD` when critical uncertainty, disputed defect, missing peer, stale evidence, OCR ambiguity, or unknown physical route.
- `CONFIRMED_REJECT` requires verified failure against documented rule and reviewer confirmation (not a model score alone).
- `ABSTAIN/NO_AUTOMATION` when evidence/authorization is insufficient.
- **Never automatically release a safety-critical component or scrap costly production material** based on LLM narrative.

## 5. Phone camera subsystem: two capture modes, one device

### 5.1 A — caliper LCD OCR (metrology)

**Manual reading is the measurement source; OCR only removes manual typing.** On iPhone use web `getUserMedia({ video: { facingMode: 'environment' } })` over HTTPS with explicit camera permission; fallback `<input type=file accept=image/* capture=environment>`. If the phone is taking the LCD image, it is not simultaneously acting as a fixed part camera unless there is a second camera. Guides for operator place ID label **before** photographing.

Pipeline: crop the instrument screen → perspective warp if needed → grayscale/CLAHE → threshold, invert as appropriate → OCR candidate(s) with Tesseract if available; **LCD seven-segment digit template/CV may outperform general-purpose OCR** under glare; perform camera focus + glare quality gate → normalize decimal and minus sign → validate valid numerical range, explicit `mm` unit/ instrument mode → require repeated **stable** reading over at least three frames or operator acceptance → link to selected specimen and gauge ID → review UI → store signed event with `physical/manual_confirmed`, plus OCR candidate and evidence image hashes.

If unit cannot be observed, require user to confirm `mm`, never silently assume. If two OCR candidates disagree, `HOLD/OCR_RECAPTURE`. Do not present OCR text as a micrometer-accurate measurement or claim OCR confidence is metrological uncertainty. For static screenshot upload stable-frame test is *not applicable*; one-shot requires manual confirmation. **OCR decimal digit swaps are a designed negative test**.

### 5.2 B — post-print external defect detection (visual)

Capture top/side images in stable diffuse lighting, a contrasting non-reflective mat, approximately fixed height and same camera orientation for normal and defective sample. Name image by specimen_id + view + timestamp; retain image hash, crop transform, camera model, quality gate outcome and operator label. ArUco/known reference can calibrate scale in a *planar region* only; account for lens, perspective, pose, edge selection and repeatability before asserting millimeter measurement. Avoid pretending that NIST's dedicated metrology instrumentation accuracy is achievable with a phone.

Defect taxonomy: layer shift, large visible crack, incomplete print/missing tab, excessive stringing, gross warping, large edge deformation. Exclude internal voids, latent stress, and microscopic defects invisible in the photo. A normal appearance **does not override** caliper fit failure.

**Model ladder:**

| Level | Method | Need | Claim boundary |
|---|---|---|---|
| V0 | alignment + background segmentation + golden-image pixel/contour difference (OpenCV) | nominal reference images, reproducible setup | a baseline anomaly **candidate**, not trained AI |
| V1 | pretrained feature embedding / PatchCore (CVPR'22) | varied good images, frozen benchmark split | anomaly map; validate on own parts |
| V1b | EfficientAD (WACV'24) | nominal images, GPU training if needed | low-latency baseline; not guaranteed on phone parts |
| V2 | NVIDIA TAO Visual ChangeNet classify/segment | labeled golden/test pairs, TAO environment and appropriate GPU | **excellent candidate for golden-reference comparison**; NVIDIA's PCB performance is not our performance |
| V3 | calibrated metric optical inspection | lens calibration target, rigid fixture, repeated independent gauge validation | only report uncertainty-supported dimensional measurements |

A VLM (Nebius / NVIDIA text-vision model where supported) may *explain* a marked anomaly or propose another viewpoint; it must not independently declare a precise width or raw safety disposition.

### 5.3 CAIR: choose next useful sensor action

Candidates: `repeat_lcd_photo`, `manual_caliper`, `top_photo`, `side_photo`, `change_light`, `reprint_sample`, `hold_for_engineer`. Score by **expected reduction in downstream decision loss** subject to measured action cost and measurement validity. Compare mathematically with traditional entropy information gain (`IG`) at matched cost. When observation/outcome likelihood models are not validated, use a fixed safe triage rule rather than pretending utility predictions are calibrated.

## 6. Scientific mathematical core inherited from 5.0 / 9.0 / 13.0

Slot width `W`, Tab thickness `T`, clearance `C = W - T`; functional minimum `c_min`. For independent Gaussian *untruncated* raw-process distributions, mean and variance of C follow the familiar difference rules; for accepted parts **condition** on each local spec before computing functional failure risk. Use deterministic seeded Monte Carlo from truncated distributions (or numeric integration), record uncertainty and assumption sensitivity. Do **not** calculate risk from only one measurement and call it lot-level probability.

Reference educational specs from original 5.0: Slot 20.5–21.5 mm, Tab 19.5–20.5 mm, minimum clearance 0.5 mm; actual samples must use measured dimensions and actual fit labels. A pair `20.6 - 20.3 = 0.3 mm` is locally accepted but functionally short of 0.5 mm, subject to uncertainty and the true assembly test. This is an **illustrative configuration**, not factory tolerance data.

- **Local drift:** EWMA on properly calibrated baseline, predeclared limits, no fake alarms from only five samples.
- **Hypotheses:** H0 normal baseline, H1 narrow slot shift, H2 thick tab shift, H4 both; H3 misalignment only with a credible physical likelihood model. Report posterior only on authorized fresh evidence with sensitivity checks.
- **IG:** `IG(a) = H[p(H|E)] - E_y H[p(H|E,y)]`; inspection priority could be IG / time if ground truth independent.
- **Decision-aware value:** `EVSI(a) = min_d E[L(d,H)|E] - E_y min_d E[L(d,H)|E,y,a]`; possible net benefit `EVSI - action cost`, with risk/abstain constraints. If both methods choose the same action, record a tie; do not manufacture an improvement.
- **Provenance:** de-duplicate common source events before combining evidence; separate physical labels, synthetic labels, and classifier guesses.
- **Safety:** Decision rule considers not only posterior point estimate but confidence/coverage, asymmetric false PASS cost, and missing evidence. `HOLD` is a valid outcome with an explicit cost.
- **Sorting:** optimize matching among available accepted parts only after consent/constraints; a part that fails one pair can fit another without itself being rejected.

### 6.1 Registered research questions and falsifiers

**RQ1** At fixed sensor budget, do separate vision + metrology + engineering agents decrease *unsafe releases* or inspection effort relative to one agent and simple threshold QC? Falsify if matched differences show no gain or worse unsafe release.

**RQ2** Does evidence lineage reduce posterior overconfidence from duplicated photos? Falsify if duplicates never change confidence under all conditions or if graph introduces worse calibration; simulate correlated duplicates and track ECE/Brier when sample size supports.

**RQ3** Does decision-aware CAIR improve net decision loss vs IG under asymmetric defect costs? **Previous toy tests were near ties**; primary test uses prespecified asymmetric costs and blinded held-out scenarios, not cherry-picked illustrative traps.

**RQ4** Does decentralized peer mesh preserve local utility with interrupted connectivity vs centralized? Compare availability, freshness, accuracy, unauthorized reads, replay idempotency. Do not claim decentralized beats central omniscient upper bound.

**RQ5** What additional gain do V1 PatchCore/EfficientAD or NVIDIA TAO models provide beyond V0 OpenCV on OUR 3D printed defects? Pair by same image/camera/light; report recall and false alarm separately. More AI may not be better.

**RQ6** Does specialist count (1/4/8/21 enabled) improve decision quality after controlling for **unique tool data, token budget, latency and cost**? Extra persona agreement is *not* independent evidence. Explicitly test degradation.

### 6.2 Strong experimental matrix

| Arm | Vision | Data access | Decision | Sorter | Scientific purpose |
|---|---|---|---|---|---|
| B0 | none | local only | deterministic threshold QC | manual | physical baseline |
| B1 | phone V0 | single combined | centralized deterministic | manual | benefit of image baseline |
| B2 | phone V1 | single combined | centralized, same calibrated core | manual | vision model benefit |
| B3 | phone V1 | split peer evidence | isolated decisions | manual | isolated lower bound |
| B4 | phone V1 | scoped peer messages | peer + IG + PACE | manual | decentralization, without CAIR |
| B5 | phone V1 | scoped peer messages | **peer + V-DER/CAIR + PACE** | manual | principal scientific treatment |
| B6 | same exact evidence | global raw visibility | centralized chief + same core | manual | controlled upper reference |
| B7 | same as B5 | scoped peer + outage | peer continues locally | manual | resilience |
| B8 | same as B5 | scoped peer | lineage de-dup disabled | manual | evidence de-dup ablation |
| B9 | same as B5 | scoped peer | minority evidence gate disabled | manual | overconfident consensus ablation |
| B10 | same as B5 | scoped peer | optional servo + verified ack | physical | closure of physical loop |

**Fair design:** same frozen specimen/photo streams and accepted-part inclusion, random seeds, calibration and train/test split by **specimen or print batch**, equivalent information budgets, human-in-the-loop assumptions and cost. Do not leak multiple views of the same physical sample across train/test. Hold out a new print day, lighting condition and phone orientation. Report randomization, failures, dropout, confidence intervals, exploratory nature if underpowered. Synthetic decision studies and physical validation appear in **separate tables**.

### 6.3 Physical measurement uncertainty

HyorinmaruK measures one stable artifact at least ten repeated trials, plus two operators if feasible. Define reference/supposed gauge resolution, repeated reading standard deviation, instrument uncertainty if known, and image OCR *transcription accuracy separately*. A simple repeatability check is **not** a calibrated gauge R&R certification. Physical assembly fit needs standardized insertion force/protocol to avoid subjective judgement; log operator, repeated fit attempts, orientation, environmental effects. Misclassification from camera must be measured on manually labeled held-out images. Aim for conservative performance not invented 95% accuracy.

## 7. NVIDIA integration — targeted, not sponsor decoration

### 7.1 NVIDIA Brev credits vs shared Nebius H100

Official ScienceClaw Compute handout says **$150 NVIDIA Brev compute credits per registered member** (3 people = $450 if each individually eligible and redeemed); Brev offers by-the-hour GPUs e.g. L4/L40S/A100/H100 and others, availability and prices vary. The **16 NVIDIA H100 GPUs from Nebius are shared across the event**; do NOT budget as 16 dedicated GPUs for the team. Nebius recommends roughly **one GPU per team/job** out of fairness; queued jobs can fail if not scheduled within 30 min. These resources have separate sign-up/authorization workflows; do not assume Brev credits can be spent as unrestricted Nebius cloud credit.

**P0: 0 GPUs needed.** Phone capture + OpenCV and classical stats run CPU. If available, use **one GPU and one short job** for TAO visual comparison, EfficientAD training or embedding extraction; export trained weights + checksums and stop GPU when complete. Do not rely on GPU availability during the final live demo; local V0 and deterministic engine are mandatory fallbacks.

### 7.2 Exact NVIDIA tools

1. **NVIDIA TAO 2026 skill-based toolkit / Visual ChangeNet** — train/evaluate/classify/segment input vs golden reference; verify current license, runtime, weights, support and model card; requires correct paired labels and consistent camera poses. See official [TAO getting started](https://docs.nvidia.com/tao/tao-toolkit/latest/text/getting_started.html), [TAO overview](https://docs.nvidia.com/tao/tao-toolkit/latest/text/overview.html) and [Visual ChangeNet docs](https://docs.nvidia.com/tao/tao-toolkit/latest/text/cv_finetuning/pytorch/visual_changenet/visual_changenet_classify.html).
2. **NVIDIA NIM** — optional standardized GPU inference server, but expensive/heavy; only deploy if model, NGC authorization, GPU VRAM and Docker runtime confirmed. [Brev NIM guide](https://docs.nvidia.com/brev/guides/inference-deployment/deploying-nims).
3. **NeMo Relay** — optional agent trace/policy/observability, not required for P0. **Do NOT start new work on deprecated NeMo Agent Toolkit:** NVIDIA docs mark it deprecated as of October 2026; migration to Relay/Helix/Fabric recommended. [Relay overview](https://docs.nvidia.com/nemo/relay/latest/about-nemo-relay/overview) and [deprecation notice](https://docs.nvidia.com/nemo/agent-toolkit/latest/).
4. **Nemotron** — optional reasoning model if available through your entitled provider/API, but no role may replace deterministic measurement or final disposition safety.
5. **Isaac Sim / Omniverse** — post-hackathon optional; no physical sorter digital twin required for a useful scientific demo.

### 7.3 GPU work definition and success gate

- Export image training manifest with `specimen_id, view, golden_image, test_image, label, split, acquisition_id`, no overlap of specimen IDs across train/val/test.
- Run V0 OpenCV baseline first and log per-sample outputs.
- If labels sufficient, run TAO Visual ChangeNet classify/segment **only on a subset appropriate to model and use case**. If labels insufficient, prefer few-shot PatchCore or stay with V0 and record that fact.
- Compute **ROC-AUC/PR-AUC only when both classes and enough samples exist**; at demo scale report confusion matrix and per-class sensitivity/specificity with exact numerator/denominator; don't present overly precise estimates.
- Export `model.pt`/ONNX if supported, labels, config, seed, version, hash, GPU type, run duration, model card. Backend loads optional adapter only if artifact exists; otherwise explicit `vision_backend=opencv_reference`.
- **Do not train on MVTec AD for commercial purposes without observing dataset's CC BY-NC-SA license**. MVTec AD is educational benchmark; use **our own printed parts** for our product-oriented experiments. [Dataset/license](https://www.mvtec.com/research-teaching/datasets/mvtec-ad).

## 8. Nebius — use the right resource for the right question

### 8.1 Three distinct Nebius offerings

| Resource | ScienceClaw allocation | Intended QualityRelay task | Access caution |
|---|---|---|---|
| **Nebius Scientific AI Platform (closed beta)** | one credential set **per team**, 65 domain-specific models/skills, 10GB S3 bucket, agentic notebook + MCP (per event PDF) | optional physically meaningful scientific checks (materials hypotheses/robotics where model is verified); store experiment artifacts | biology/protein models are **not** manufacturing defect classifiers; do not call them merely because they're free |
| **Nebius Cloud AI H100** | shared 16 GPUs across hackathon | training/inference benchmarks for vision or simulation | invitation must be accepted, tenant `Nebius-Academy-8dj`; no guaranteed immediate slot |
| **Nebius Token Factory API** | API availability depends on assigned key/entitlement, not automatically same as H100 quota | language-based specialist agents, citation/explanation, schema-constrained action proposals | no credential or model => deterministic bounded fallback; query `/v1/models` for allowed model names |

Official Token Factory uses `https://api.tokenfactory.nebius.com/v1/` and OpenAI-compatible `/chat/completions`, `/models`, `/responses` with entitlement-dependent model lists. [Official OpenAPI](https://api.tokenfactory.nebius.com/docs), [Nebius cookbook](https://github.com/nebius/token-factory-cookbook), [service](https://nebius.com/services/token-factory/inference-service).

**Illustrative integration (not executed here, requires registered key and a supported model):**

```python
from openai import OpenAI
import os
client = OpenAI(base_url="https://api.tokenfactory.nebius.com/v1/", api_key=os.environ["NEBIUS_API_KEY"])
allowed = [m.id for m in client.models.list().data]
model = os.environ["NEBIUS_MODEL"]  # must be present in allowed
assert model in allowed
response = client.chat.completions.create(
    model=model, temperature=0,
    messages=[
      {"role":"system","content":"You are a bounded manufacturing QA agent. Only cite supplied evidence IDs; output proposals, never final measurements or actuator commands."},
      {"role":"user","content":"Incident: tab-B12. Scoped evidence: ..."}
    ]
)
# Treat text as UNTRUSTED until schema validation and independent tool checks.
```

**Security:** server-side credentials only (`NEBIUS_API_KEY`, no `.env` in Git, no JS keys), short context, redact supplier identity/person data, rate and spend caps, exact model/version logging, backoff on 429/5xx. The server never trusts an LLM's invented specimen IDs. For a Scientific AI Platform MCP integration verify **which tools are actually exposed** and call only relevant validated skills; each team's key is not a general model license.

### 8.2 Provider decision tree

- Need to read phone photos / caliper OCR? → **local CV first**, no Nebius scientific platform required.
- Need to train a defect detector? → **NVIDIA Brev or Nebius H100 (one GPU), only if data and entitlement are ready**.
- Need specialist natural-language explanation? → **Nebius Token Factory**, provider adapter, deterministic numerical core.
- Need molecular dynamics / robotics/materials simulation? → Nebius Scientific AI **only** if a concrete qualified skill exists; do not fabricate physics.
- Need a robust offline demonstration? → all critical decisions stay local when GPU/API unavailable.

## 9. Sorter: separate policy, command, gate movement and arrival

**v12 Sorter Peer is independent**; optional ESP32 controls just gate motor, never caliper jaws. `SortingRequested` requires specimen ID, disposition ID, human approval (or explicitly scoped lab-demo policy), TTL, nonce and idempotency key. Hardware driver accepts only whitelist `PASS|HOLD|CONFIRMED_REJECT`, and only within low-energy guarded demonstration. Do not physically actuate if authorization or current sensor state unknown.

```text
Disposition proposed -> authorized -> routing requested -> gate moved
   -> confirmation sensor/second visual record -> physically_sorted
   OR timeout / mismatch -> SORT_FAILED + HOLD + operator inspection
```

Manual route mode implements the same ack event schema but ack is human-reported, **not equivalent** to verified IR sensor presence. One component seen in 30 video frames counts once; event ID and specimen ID de-dup at backend. Counter mismatches are visible, never silently reconciled.

### 9.1 P0 phone-only; P1 servo optional

- **P0 required:** 3D prints, phone browser camera, digital caliper, peer evidence, visual baseline, HOLD, manual sorting, audit and benchmark.
- **P1 optional:** 1 ESP32-S3, 1 low-voltage servo+gate (if in ELEGOO bundle), one break-beam/IR detector (verify it is actually supplied), breadboard and jumpers. Camera board/Pi/Hailo are *not* required; optional second independent vision peer if hardware available.
- Physical sorter cannot be presented as built if it isn't. Include `hardware_sorter_status=NOT_BUILT` in run manifest until bench tested.

## 10. Team ownership — parallelizable without ambiguous handoffs

| GitHub | Owner | Primary components | Measurable acceptance |
|---|---|---|---|
| `Bakdaulet-omeraiuly` | **Scientific/Data Science lead** | risk engine, Bayesian/IG/EVSI and CAIR, V0/V1/TAO model trials, preregistration, experiment/metrics and research citation table | fixed seeds, held-out specimens, reproducible metrics; no unsupported claim |
| `adilnurgg` | **Backend, decentralized security lead** | station peer services, event envelope auth + replay, storage and API; Nebius Token Factory adapter; provider failures; integration/deployment | unauth raw read 403, outage resilience, exactly-once event application, API spec and tests |
| `HyorinmaruK` | **Mechanical engineering, physical validation AND final presentation owner** | CAD revisions, 3D printing, caliper fixture + phone alignment, measurement uncertainty log, photo ground truth, assembly trials, sorter gate if hardware, UI demo UX, scientific slides/pitch | physical specimen IDs, held-out labels, reproducible inspection protocol, evidence-linked pitch |
| fourth (optional) | Frontend/integration/independent QA | mobile-responsive website, camera controls, CI, smoke tests, external engineer outreach, independent test review | HTTPS phone upload from 2 devices; trace end-to-end and negative tests |

**Three-person default:** frontend implementation split: adilnurgg owns API & basic website wiring, HyorinmaruK owns camera UX, physical workflow and presentation; Bakdaulet owns report/plots. Fourth, if added, takes frontend and independent QA without duplicating core decision engine. **No person** may silently change another owner's data contract; OpenAPI/JSON Schema freeze first.

### 10.1 Work branches and integration

- `main` protected/tagged, no secret commits.
- `feat/science-engine` (Bakdaulet); `feat/peer-backend-nebius` (adilnurgg); `feat/mechanical-phone-demo` (HyorinmaruK); `feat/mobile-web-qa` (optional).
- `contracts/v3` freezes field names before parallel work; each PR includes test + one representative sample event and a consumer smoke test.
- Cross-team daily integration: `git pull --rebase`, `pytest`, demo run; snapshots include model weights SHA, camera photo SHA and exact specimen inventory. Have prerecorded demo as fallback but mark clip as recorded.

## 11. One website — minimal information architecture

| Screen | Operator action | Exactly what it shows |
|---|---|---|
| `/dashboard` | pick incident, lot-pair | station live/stale status, evidence coverage, predicted risk vs uncertainty |
| `/capture` | scan QR/type specimen, select **Caliper OCR** or **Surface Vision**, use own phone camera | source photo, candidate result, approve/recapture, no fake numeric confidence |
| `/agents` | inspect specialist tasks/evidence | real tool invocation status and actual source IDs; contract-only roles clearly labelled |
| `/evidence` | provenance graph, conflicting claims | original events vs derived opinions and evidence debt |
| `/decisions` | review HOLD/PASS/REJECT or suggested extra measurement | reason, missing proof, human approval and expiry |
| `/sorter` | manual routing confirmation / ESP32 gate command if available | per-specimen state + `inspected`, `confirmed_defective`, `physically_rejected` counts |
| `/experiments` | B0–B10 run and paired comparisons | physical vs synthetic separated, baseline, CIs, seeds and limitations |
| `/audit` | export record and event source | append-only log, hashes and model version |

**Phone browser:** must be served over HTTPS (or localhost during local laptop development); use `getUserMedia` or file-capture fallback, user consent, visible stop camera button, no automatic upload of continuous video. In Chrome/Safari camera web APIs require a secure context, [MDN](https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia).

## 12. Interface freeze: API and idempotency

**Core endpoints (target contracts; this package contains a smaller reference subset):**

| Method | Route | Behavior |
|---|---|---|
| POST | `/api/specimens` | register ID, lot, class, CAD rev; deny duplicates |
| POST | `/api/capture/caliper` | photograph candidate with specimen, unit, gauge and confirmation |
| POST | `/api/capture/vision` | photo + golden reference; returns candidate and model identifier |
| POST | `/api/evidence` | schema/authority validation, idempotent source events |
| GET | `/api/peers` | scoped station liveness; no raw cross-table disclosure |
| POST | `/api/incidents` | register pair and set evidence snapshot |
| GET | `/api/incidents/{id}/risk` | clearance analysis and coverage |
| POST | `/api/incidents/{id}/next-inspection` | ranked candidate, cost and evidence basis |
| POST | `/api/dispositions` | policy-controlled proposal + human authorization |
| POST | `/api/sorter/route` | whitelist and non-expired signed authorization |
| POST | `/api/sorter/ack` | physical/manual confirmation with source type; idempotent |
| GET | `/api/counters` | derive unique verified counts and discrepancy |
| POST | `/api/experiments/run` | immutable reproducible manifest of baseline comparison |
| GET | `/api/audit/export` | replayable provenance records |

**Reference code in ZIP:** optional `/api/demo/inspection` calculates dimensional fit advisory + image-difference candidate and outputs `HOLD/PASS_REVIEW` with explicit `NOT_CALIBRATED` limitations, plus `/api/demo/sorter` and `/api/demo/counters` to demonstrate event idempotence. It **does not** yet implement fully independent networked station services, real TAO training or ESP32 hardware. Use these endpoints as test scaffolding, not factory validation.

## 13. 21 specialists (retained v12 registry, plus Visual as station)

Each of these is an *available role* with permissions, tool and denial tests, **not** 21 autonomous inference models currently running:

| # | Specialist | Real evidence/tool and abstention |
|---:|---|---|
| 1 | Design Geometry | CAD rev + datums; unknown revision → abstain |
| 2 | Tolerance Analyst | accepted-part distributions; missing model → no risk claim |
| 3 | Materials Engineer | certified material data; no certificate → hypothesis only |
| 4 | Process Engineer | process graph and time series; missing log → partial |
| 5 | CNC Expert | machining logs if actual CNC; else not applicable |
| 6 | Additive Manufacturing Expert | slicer/filament/print settings and visible failure |
| 7 | Metrology Engineer | gauge ID, repeatability, operator, physical measurement |
| 8 | SPC Agent | calibrated EWMA/CUSUM baseline |
| 9 | Quality Inspector | acceptance + evidence/hold rules |
| 10 | Assembly Engineer | pair-level clearance and assembly-test plan |
| 11 | Causal Diagnosis | DAG hypotheses, discriminator measurement |
| 12 | Bayesian Statistician | frozen priors/likelihoods and sensitivity |
| 13 | Inspection Planner | IG/EVSI/CAIR, predeclared candidate IDs |
| 14 | Operations Research | feasible lot pairing constraints, reject unsafe matches |
| 15 | Maintenance Engineer | real maintenance evidence or N/A |
| 16 | Supplier Boundary | approval for cross-factory scoped summaries |
| 17 | Safety/Governance | policy veto + human approval gate |
| 18 | Privacy/Security | verified auth, data leak report |
| 19 | Reliability/Network | stale/offline/replay/coverage metrics |
| 20 | Scientific Auditor | signed run manifest, origin labels, reproduction |
| 21 | Kaizen / PDCA | controlled improvement hypothesis, no fake causal claim |

**Vision evidence owner** is an independently authorized **fifth observation peer** or integrated bounded sensor of QA peer; **Sorter remains the fourth physical station** following Slot, Tab and Assembly as in v12. Do not renumber 21 specialists because adding a camera device is not equivalent to adding a 22nd independent engineering role. Primary peer count: four station services (Slot/Tab/Assembly/Sorter), **plus a visual evidence service when deployed independently**.

## 14. Anti-hype experimental validity gates

1. Baselines run against the *same* frozen specimens and photographic observations; match wall-clock and inspection costs where possible.
2. Physically distinct photo views of same object are **not** independently sampled held-out objects. Group split by specimen_id and print batch.
3. Print simulation vs physical evidence in separate tables. Every `origin.kind` is visible; same model cannot use a test photo to set its own threshold.
4. Model score ≠ calibrated probability. Calibrate on held-out data only with enough cases; otherwise report ranking and uncertainty qualitatively.
5. OCR error rate measured as exact full-reading match vs independent transcription, especially decimals and minus sign; gross measurement error from bad caliper contact is a separate phenomenon.
6. Count confidence and sorter route confirmations independently; no results invented for planned servo.
7. Publish **negative results**; old V-DER pilot nearly tied IG. A single illustrative counterexample does not prove superiority.
8. Freeze primary outcome before experiment: `unsafe_PASS_rate` under a target or compare difference at fixed refusal/hold rate; secondaries: inspection cost/time, AUPRC, false reject, calibration, event bytes, fault delays, graceful degradation.
9. Time, provider spend and token use are experimental variables. A 21-agent system that improves one metric but doubles risk/cost may fail product usefulness.
10. No approval of industrial safety-critical use until separate domain controls, external validation, security and legal compliance.

### 14.1 Technical acceptance (P0)

- [ ] A phone photo is actually captured and linked to specimen ID, not stock footage.
- [ ] Original unmodified 5.0 package verifiably archived.
- [ ] A caliper decimal digit conflict yields explicit HOLD; no blind OCR acceptance.
- [ ] A visibly suspicious but dimensionally acceptable part yields HOLD, not PASS.
- [ ] A visually normal but dimensionally incompatible pair yields HOLD even if camera says normal.
- [ ] Duplicate evidence does not multiply independent likelihood; duplicate sorter ack does not increment counts.
- [ ] Offline peer does not silently contribute stale likelihood; local peers continue.
- [ ] A disposition requires documented policy + reviewer prior to sorting.
- [ ] P0 demo works with zero NVIDIA/Nebius connectivity.
- [ ] GPU jobs/logs are linked only if actually run; otherwise model states `NOT_RUN`.
- [ ] Physically rejected count increments only after event-level confirmation.
- [ ] Real physical measurements are visibly separated from synthetic samples.

## 15. Deployment & cost-first architecture

- **Frontend:** React/Next.js or minimal phone-first HTML, HTTPS, indexed specimen forms, no credentials in browser.
- **Local science:** Python/OpenCV/Pydantic/FastAPI with NumPy/SciPy if needed; model weight optional.
- **Independent services:** eventually Slot, Tab, Assembly, Sorter and optional Vision peer own DBs; event transfer via authenticated queue/router with zero diagnostic authority; failure injection.
- **Cloud providers:** NVIDIA Brev/Nebius H100 are **temporary model training resources**, not mandatory production API host; Nebius Token Factory is optional interpretation tool. All providers behind adapters so no sponsor lock-in.
- **Hosting:** site on Vercel/Cloud Run if entitlement; avoid assuming Google event account persists (PDF warns auto-delete Sunday). Export code/model/logs before termination.
- **Data:** raw phone images retained only with explicit consent; encrypt in transit/rest, minimize visibility, implement TTL and delete process; training data licensing checked.
- **Budget controls:** cap image uploads, downsample for nonmetrological vision only, model invocation maximum, GPU time and total cloud spending, error fallback; do not run 21 reasoning calls per specimen.

## 16. Schedule / cut lines for three-person hackathon

| Phase | Scientific lead (Bakdaulet) | Backend (adilnurgg) | Mechanical/pitch (HyorinmaruK) | Deliverable |
|---|---|---|---|---|
| H0–H3 | freeze specs, scenario set, CSV schema | freeze API + station permissions | print fixtures & choose failure specimens | reproducible P0 scope |
| H3–H8 | clearance/IG baseline + openCV sanity | phone capture + event provenance | caliper repeatability and photo fixture | one real physical event through dashboard |
| H8–H14 | golden-image model and evaluation | 4-peer separation and outage simulator | test both contradictory evidence cases | HOLD decisions with provenance |
| H14–H20 | initial matched baseline trials | sorter event idempotence; optional Nebius API adapter | printed pairs/assembly labels; optional servo gate | demo full loop, physical counters |
| H20–H24 | freeze run manifest, honest plots | harden error/security and manual fallback | pitch, judge rehearsal, photo evidence | two full rehearsals |
| H24+ | no new core features | no new core features | submit/rehearse | stable and evidence-linked |

These are *active-hour milestones*, not promises about remaining event time. Follow the current official hackathon schedule and submission instructions, especially earlier slide deadlines. **If work slips: drop GPU training, then borrowed hardware servo, then fancy vision model, then extra roles; never drop original peer evidencing, HOLD, real measurements, fair baseline or demo stability.**

## 17. Exact sources: primary literature, official docs, and ScienceClaw constraints

### Research (known methods: do not present as original discoveries)

1. Roth et al. (2022), **PatchCore / Towards Total Recall**, CVPR: https://openaccess.thecvf.com/content/CVPR2022/html/Roth_Towards_Total_Recall_in_Industrial_Anomaly_Detection_CVPR_2022_paper.html
2. Batzner, Heckler, König (2024), **EfficientAD**, WACV: https://openaccess.thecvf.com/content/WACV2024/html/Batzner_EfficientAD_Accurate_Visual_Anomaly_Detection_at_Millisecond-Level_Latencies_WACV_2024_paper.html
3. **MVTec AD datasets/license**, educational reference only; CC BY-NC-SA: https://www.mvtec.com/research-teaching/datasets/mvtec-ad
4. **Value of information and conditional risk:** decision-theoretic basis from original 5.0/13.0 research; see their complete citations in archived materials, verify DOI before citing in slides.
5. NIST (Praniewicz et al., Oct 2026), machine vision uncertainty **with dedicated laboratory metrology system**, *not a phone benchmark*: https://www.nist.gov/publications/validation-upgrades-nist-m48-vision-measurement-system

### Official provider implementation references

6. NVIDIA TAO overview: https://docs.nvidia.com/tao/tao-toolkit/latest/text/overview.html
7. NVIDIA TAO 2026 skill-based getting started + Visual ChangeNet: https://docs.nvidia.com/tao/tao-toolkit/latest/text/getting_started.html
8. NVIDIA Visual ChangeNet classify: https://docs.nvidia.com/tao/tao-toolkit/latest/text/cv_finetuning/pytorch/visual_changenet/visual_changenet_classify.html
9. NVIDIA NeMo Relay: https://docs.nvidia.com/nemo/relay/latest/about-nemo-relay/overview
10. NVIDIA NeMo Agent Toolkit **deprecation**: https://docs.nvidia.com/nemo/agent-toolkit/latest/
11. NVIDIA Brev NIM optional: https://docs.nvidia.com/brev/guides/inference-deployment/deploying-nims
12. Nebius Token Factory API: https://api.tokenfactory.nebius.com/docs
13. Nebius Token Factory examples: https://github.com/nebius/token-factory-cookbook
14. MDN HTTPS secure-context camera: https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia
15. **ScienceClaw compute PDF supplied by team** — NVIDIA $150/member; Claude $100/member; Nebius shared 16 H100; Nebius team Scientific AI credentials and 10GB S3; Google temporary cloud max two accounts; OpenAI $50 API credits.
16. **ScienceClaw hardware PDF supplied by team** — limited shared ESP32, camera boards, Pi/Hailo, components and printers; no guarantee of hardware access.

### Novelty register — four honest levels

- `L0 established`: Bayesian inspection, information gain, anomaly detection, OCR, multi-agent role orchestration, source provenance all exist.
- `L1 integration proposal`: mobile optical evidence + manual gauge measurements + decentralized role contracts + safe sorting + decision-aware inspection and physical ack in one auditable workflow.
- `L2 reproducible result`: only after fixed runs reveal a measured delta with interval vs strong baselines; no L2 claim here without run artifact.
- `L3 industrial validation / publishable novelty`: independent plant-specific study, broad negative/positive cases, repeated batches, external review and prior-art search. **No L3 claim made.**

---

## APPENDIX A — Original QualityRelay 5.0 master blueprint (verbatim, separately archived)

# QualityRelay 5.0 master blueprint

## 1. Executive definition

QualityRelay is a decentralized quality-coordination system for assemblies whose fit depends on measurements owned by different manufacturing stations. A slot can pass its local specification and a tab can pass its local specification while their pairing still has insufficient clearance. Each station continues to own its raw data and local decisions. Agents exchange scoped, provenance-linked evidence only when an assembly-risk query or anomaly makes collaboration useful.

The hackathon demonstration answers one narrow scientific question:

> With the same statistical core and inspection budget, what capability is gained or retained when quality evidence is coordinated across independently authorized station agents, especially when communication is intermittent?

It does **not** attempt to prove that multi-agent systems are universally better than centralized quality systems.

## 2. The manufacturing problem

Three logical stations are modeled:

1. **Slot station** produces a slot and measures slot width `W`.
2. **Tab station** produces a tab and measures tab thickness `T`.
3. **Assembly station** selects lots, observes fit outcomes, and evaluates clearance `C = W - T` against a functional minimum `c_min`.

Local part specifications are deliberately not equivalent to the assembly requirement. In the demonstration reference design:

- Slot specification: 20.5–21.5 mm.
- Tab specification: 19.5–20.5 mm.
- Functional minimum clearance: 0.5 mm.
- Nominal means: slot 21.0 mm, tab 20.0 mm.

Worst-case individually accepted parts can produce `20.5 - 20.5 = 0.0 mm`, below the functional requirement. The exact risk depends on the process distributions and the acceptance conditioning. These values are configuration assumptions for a teaching demonstration, not measured factory parameters.

## 3. User story

Before assembly, an operator selects slot lot A-07 and tab lot B-12. The assembly agent cannot calculate a current risk until it obtains sufficient, authorized summaries from both stations. It sends evidence requests. Each station returns a signed summary referencing local measurement event IDs, not its entire raw table. The assembly agent calls the deterministic compatibility engine, receives a provenance-linked risk estimate, and either:

- permits the planned pairing with its uncertainty and evidence coverage;
- recommends a server-provided alternative lot with lower estimated risk; or
- asks for the physical measurement with highest expected information gain per second.

If the slot link is taken offline, the slot station continues local measurements and queues outbound events. Peers stop receiving new slot evidence; the UI marks the current diagnosis as partial and omits the stale station likelihood from the live posterior. The audit history remains intact. On reconnection, event IDs make replay idempotent.

## 4. Why decentralized agents are justified

The system models real organizational and technical boundaries:

- Different equipment or suppliers own different raw records.
- A station has authority to measure and summarize its own process, not to read another station’s database.
- Assembly owns the relational decision: whether two lots should be paired.
- Communication can be intermittent while local production and monitoring continue.
- An append-only router moves messages but cannot fabricate a measurement, compute a diagnosis, or override a station.

If every actor reads one shared database and one global posterior, the project fails its own decentralization claim.

## 5. P0 end-to-end behavior

1. Record or seed at least five recent measurements per relevant lot and station.
2. Create a `BatchRiskQuery` for an upcoming slot–tab lot pairing.
3. Show `pending_insufficient_evidence` until authorized evidence responses arrive.
4. Calculate clearance risk with the shared deterministic engine.
5. Link every estimate to the exact evidence event IDs, code version, assumptions, and origin labels.
6. Rank server-provided physical inspection candidates by expected information gain divided by time cost.
7. Accept a real caliper entry and update the diagnosis.
8. Toggle one station link offline and show partial-evidence behavior.
9. Reconnect and reconcile queued events exactly once.
10. Export a replayable run manifest and result record.

## 6. Architecture at a glance

```text
Slot UI/tool -> Slot service + local DB ----\
                                         signed evidence events
Tab UI/tool  -> Tab service + local DB ----- event router/log ---> Assembly service + local DB -> Dashboard
                                             |                         |
                                             |                         +-> risk/diagnosis/inspection core
                                             +-> no diagnostic authority

Optional LLM adapters sit above each station's approved tools.
All numeric truth is rendered from deterministic service responses.
```

The statistical core is one versioned library reused in isolated, centralized, and decentralized conditions. This prevents a strawman baseline. Deployment and evidence access change; the mathematics does not.

## 7. Scientific core

### 7.1 Clearance risk

For independent normal slot and tab distributions before acceptance truncation:

`mu_C = mu_W - mu_T`

`sigma_C^2 = sigma_W^2 + sigma_T^2 - 2*rho*sigma_W*sigma_T`

`P(C < c_min) = Phi((c_min - mu_C) / sigma_C)`

The benchmark must condition on both parts passing their local specifications. Use deterministic Monte Carlo from truncated distributions or numerical integration. The random seed is derived from the run ID, lot pair, evidence snapshot hash, and algorithm version so identical inputs return identical outputs.

### 7.2 Local process monitoring

Each station maintains an EWMA:

`z_t = lambda*x_t + (1-lambda)*z_(t-1)`

Control limits use the standard time-varying EWMA form. `lambda = 0.2` and `L = 3` are starting configuration values, not optimized claims. Baseline process mean and sigma come from the calibration dataset; they are not estimated from only five live points.

### 7.3 Evidence-scoped diagnosis

The minimum hypothesis set is:

- `H0`: stable process; assembly failures occur at the nonzero design baseline.
- `H1`: slot mean shifted downward.
- `H2`: tab mean shifted upward.
- `H4`: both means shifted toward reduced clearance.

Optional `H3` fixture/misalignment is P3 because a credible physical mechanism and likelihood model are not available in the core sprint.

Posterior updates are performed only over evidence the calling actor has locally observed or received through authorized responses. When a station is unavailable or evidence is outside the freshness window, its likelihood term is omitted and the posterior is renormalized. The UI must show evidence coverage, such as “computed from 2 of 3 stations.”

### 7.4 Targeted inspection

For candidate action `a` and possible outcomes `y`:

`IG(a) = H[p(H|E)] - sum_y p(y|a,E) * H[p(H|E,y)]`

`score(a) = IG(a) / expected_seconds(a)`

Candidate specimen IDs come from the server. An LLM may choose among them or request no action, but cannot invent an ID. The method is an application of established Bayesian experimental design, not a new information-theory algorithm.

## 8. Requested combined demonstration scenario

`configs/scenario_combined_0p100mm.yaml` specifies:

- scenario: `combined`;
- slot mean shift: `-0.100 mm`;
- tab mean shift: `+0.100 mm`;
- slot communication: `online` at the start;
- data source: `simulated`;
- pairing policy: uniform random pairing among locally accepted parts;
- outcome status: `NOT_RUN`.

Expected qualitative observations, not claimed results:

- both local EWMAs should move toward reduced clearance, though the exact alarm timing is unknown until run;
- the joint clearance-risk estimate should tend upward relative to the frozen nominal baseline;
- evidence requests and responses should complete while the slot link is online;
- the combined hypothesis should gain support if the generated evidence matches the configured shifts;
- a targeted inspection may be proposed if expected information gain exceeds the configured threshold;
- all dashboard values must be labeled simulated and tied to the seed.

Do not promise that the collaborative system beats the isolated condition at this shift magnitude. Pilot candidate shifts first because 0.100 mm may be locally detectable depending on sigma, EWMA parameters, and run length.

## 9. Validation design

### Experiment A: collective capability under full connectivity

Compare:

- isolated station actors with peer requests disabled;
- centralized system with all raw evidence;
- QualityRelay peer evidence exchange.

Use the same core, scenario streams, inspection budget, and seeds. Primary interpretation: QualityRelay may recover much of centralized performance with less raw-data access and a traceable communication budget. Do not claim it should beat the centralized upper bound.

### Experiment B: resilience to information topology

A 2×2 design:

| Topology | Always on | Intermittent link |
|---|---|---|
| Centralized hub | upper-bound reference | hub/link degradation |
| Decentralized peer mesh | normal QualityRelay | local continuity + partial evidence + reconciliation |

The hub’s coordinator-failure test is deliberately asymmetric: a peer mesh has no single coordinator to fail. State this rather than pretending the cells are identical.

### Metrics

- fault-hypothesis accuracy on simulated ground truth;
- detection delay in units after injected change;
- assembly-risk Brier score on simulated runs only;
- number and time cost of physical/simulated inspections;
- raw records exposed across station boundaries;
- message count and bytes;
- evidence coverage at decision time;
- duplicate-event count after reconnect;
- unauthorized access attempts denied;
- physical loop completion reported descriptively, never as a calibrated percentage.

## 10. Physical evidence plan

Use a small U-slot coupon and flat tab coupon printed in white PLA. Print a safe pair, a nominal pair, and a tight-risk pair plus backups. Do not rely on CAD dimensions as ground truth. First measure one stable coupon ten times, compute repeatability standard deviation `s_r`, then choose a demonstrated clearance difference comfortably larger than measurement noise. A 3–5× `s_r` rule is a screening heuristic, not a full gauge R&R study.

Two or three physical pairings close the loop; they do not validate the predicted probability. Simulation supplies repeated, seeded ground truth. Physical and simulated metrics must be shown in separate panels.

Do not attempt a live print-redesign-reprint-refit loop. Show any corrected CAD as a next-step artifact.

## 11. Success criteria

P0 is complete only when all are true:

- one command resets the demo to a known state;
- a risk query remains pending before evidence arrives;
- unauthorized cross-station raw reads return 403 and are logged;
- the same input snapshot produces the same risk output;
- all numeric UI statements are server-rendered from structured results;
- candidate IDs are whitelisted;
- link loss changes evidence coverage visibly without deleting history;
- reconnect produces zero duplicate events;
- a physical caliper entry is stored with `origin.kind = physical`;
- a simulated benchmark record includes seed and generator version;
- no chart combines physical and simulated observations into one unlabeled metric;
- the deterministic fallback performs the complete demo without an LLM.

## 12. Milestones and cut lines

| Milestone | Active-hour deadline | Acceptance condition | Cut if missed |
|---|---:|---|---|
| M0 scope/interface freeze | H1 | schemas, role boundaries, scenario IDs fixed | remove alternative-lot and disagreement branches |
| M1 deterministic core | H6 | clearance, EWMA, diagnosis, inspection tests pass | remove Bayesian extras; keep risk + fixed inspection |
| M2 minimum viable demo | H12 | reset → query → evidence → risk → inspection → update | LLM removed from critical path |
| M3 decentralized proof | H18 | 403 test, scoped posterior, offline queue, idempotent replay | use recorded outage clip; keep live evidence exchange |
| M4 experiment freeze | H23 | pilot selects shift rule; matrix and seeds frozen | reduce to 3 seeds and label exploratory |
| M5 feature freeze | H25 | full run completes twice | no new features |
| M6 submission ready | H29 | slides, repository, manifest, backup clip, 2 rehearsals | polish only |

## 13. ScienceClaw rubric alignment

| Rubric | Evidence to show |
|---|---|
| Problem significance, 20% | relational tolerance-stack failure across data silos; preventable scrap/rework risk |
| Scientific/technical impact, 25% | prospective lot-pair risk, targeted inspection, traceable decision; results shown only after execution |
| Decentralized agency, 20% | station-local data/authority, explicit evidence requests, no decision-making router, offline local continuity |
| Collective capability, 25% | same-core comparison against isolated and centralized conditions; link-fault experiment |
| Execution/validation, 10% | functioning vertical loop, seeded experiments, physical caliper input, negative permission test, replay manifest |
| Optional collaboration bonus | another team actually reuses the event schema, replay dataset, or tool; usage is documented |

## 14. Honest closing claim template

Fill brackets only after measured runs:

> Using the same statistical core and inspection budget, QualityRelay’s independently authorized station agents evaluated an upcoming compatibility risk through selective evidence exchange, requested a targeted inspection, and retained local operation during a communication interruption. In seeded simulation, the collaborative condition [measured result with uncertainty]. In the physical demonstration, [descriptive observed loop outcome]. These results demonstrate a hackathon prototype, not industrial validation.



---

**END — source 5.0 appendix above included byte-for-byte as text; the original file is separately preserved for exact-byte verification.**
