# QualityRelay 14 — START HERE

**This is an implementation-oriented scientific research package, not an already factory-validated platform.** It preserves the 5.0 original and prior 8/9/10/12/13.1 work, adds the v14 phone camera + NVIDIA/Nebius integration blueprint, and provides a minimal executable reference site.

## Download and launch on Mac

```bash
unzip QualityRelay_14_NVIDIA_NEBIUS_PHONE_COMPLETE.zip
cd QualityRelay_14_FINAL/implementation
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m pytest -q
uvicorn qualityrelay14.api:app --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000/` on **the Mac**. For your own phone to access the camera flow over the network, serve the site through a trusted **HTTPS** URL (e.g. via a securely configured dev tunnel or deployed HTTPS host), not `http://<Mac LAN IP>:8000`: browser camera APIs require a secure context. Keep your test images non-confidential. An `input capture` photo flow may be available even without streaming, depending on mobile browser.

The first response is an honest health status showing:

- `nebius_inference_connected=false`
- `nvidia_tao_model_loaded=false`
- `full_peer_network_implemented=false`
- `physical_sorter_connected=false`

These remain false until real integrations are performed. The website *does* exercise phone file capture, actual baseline OpenCV image comparison, optional Tesseract LCD-photo OCR, caliper text guard, assembly clearance evaluation and idempotent sorter-ack simulation.

## What to implement next (in order)

1. Photograph and manually verify actual 3D-printed specimen dimensions; print IDs; get two contradictory (vision vs metrology) evidence examples.
2. Freeze the event schema and split 4 independent station services (Slot/Tab/Assembly/Sorter) into separate databases/processes and authenticated message exchange; prove outage behavior and negative permission tests.
3. Build reliable phone capture fixture, golden-reference photo dataset, blind labels and held-out sample split.
4. Run V0 OpenCV **before** using GPU. If results justify it, fine-tune NVIDIA TAO Visual ChangeNet or test EfficientAD/PatchCore using **one** event-available GPU, compare same photographs.
5. Optional Nebius Token Factory adapter for specialist proposal language; never allow it to change numeric truth or actuate a motor.
6. If borrowed hardware available, attach servo **sorting gate only** + physical confirmation sensor; otherwise use manually recorded routing.
7. Run matched baseline experiments and freeze the actual result tables for slides; no invented accuracy or latency.

## Important boundaries

- No separate camera hardware is necessary; **own phone default** for caliper LCD photo and later surface photo, taken sequentially.
- Physical caliper measures; OCR reads its display **provisionally**; operator confirms.
- A camera may detect a visible defect, not safely claim arbitrary 0.1mm precision or internal quality.
- A `PASS_REVIEW` is not an authorization for production use.
- The Nebius Scientific AI Platform team credential is **not** an H100 GPU allocation and is **not** automatically a Token Factory commercial credit.
- Do not commit private ScienceClaw event links or API keys to GitHub.

## Ownership

- **Bakdaulet-omeraiuly:** scientific core, CV model metrics, randomized benchmark, design and paired experiments.
- **adilnurgg:** event/API/backend distributed services, secrets, Nebius adapter, secure deployment.
- **HyorinmaruK:** all physical/mechanical validation, 3D fixtures, photo/caliper acquisition, sorter demo if available, **slides and final pitch**.
- **Optional #4:** frontend ownership, QA independent reproduction and integration.

## Files

- `QUALITYRELAY_14_FINAL_MASTER_BLUEPRINT.md`: principal end-to-end plan including original 5.0 blueprint verbatim.
- `implementation/`: executable limited scientific reference with tests and one web screen.
- `research/`: source-to-feature table with links and scientific safeguards.
- `configs/`: demo-only acceptance specs and experiment preregistration.
- `legacy/`: earlier archives unchanged. No code is silently represented as integrated solely by being archived.
- `MANIFEST_SHA256.txt`: check integrity after downloading.
