# QualityRelay 15.0 — Start Here

**Release:** 15.0 Dual-Vision Evidence Mesh (30 Oct 2026)

## What changed from 14.2?

**YES**: smartphone + **physically separate Raspberry Pi camera** become two station-owned Vision evidence sources. A vision conflict requires `HOLD`, preserves both source IDs, and triggers an inspection request. A third-party webcam may be used only as a clearly labeled substitute. Phone OCR remains optional, digital caliper remains the physical instrument. Hailo-8L acceleration is optional and **not yet integrated**. ESP32/servo is an optional **sorting gate**, not a caliper motor.

## What is in this ZIP?

- `QUALITYRELAY_15_FINAL_MASTER_BLUEPRINT.md`: one full scientific+engineering blueprint, including unchanged text from the prior v14.2 master appendix and original 5.0 design lineage.
- `src/dualvision/`: working, bounded Python station + reviewer reference, independent SQLite stores and source-specific HMAC, no physical actuation.
- `tests/`: 23 current automated tests, all rerun when package was built.
- `docs/PHYSICAL_VALIDATION_PROTOCOL.md`: actual physical experimental plan, specimen labels, false-pass/hold metrics.
- `docs/TEAM_HANDOFF.md`: responsibilities for Bakdaulet / adilnurgg / HyorinmaruK (+ optional 4th). **Only latter two handle Google Cloud.**
- `docs/SCIENTIFIC_EVIDENCE_REGISTER.md`: scientific novelty limits, verified external references and claims.
- `web/dual_camera.html`: static operator reference page; two node endpoints require same-origin proxy/CORS and real secrets in local dev; NOT a public production web app.
- `archive/QualityRelay_14_2_AGENT_INTELLIGENCE_COMPLETE_ORIGINAL.zip`: original, byte-unchanged 14.2 ZIP with older code/research nested inside.
- `archive/QualityRelay_Hackathon_Package_2026-10-28_ORIGINAL_5_0.zip`: original 5.0 archive (33 files).
- `MANIFEST_SHA256.txt`: checksums of package files (except the manifest itself).

## The quick test

```bash
cd QualityRelay_15_FINAL
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
PYTHONPATH=src python -m pytest -q tests
```

**Expected as packaged: 23 tests passed**, no private keys/GPU/Pi/Internet required. An additional **65 inherited v14.2 tests** passed in the packaging environment (stored original archive; rerun them separately after extracting it). Together these are software checks, not an industrial certification.

## Real camera path

1. Reserve Pi5+Hailo8L+Pi Camera from limited event pool. Build and photograph actual Slot/Tab pieces.
2. Run two independent node processes on different devices, with separate SQLite and station keys. Detailed commands in Master §10.
3. Submit a phone camera photo under its specimen ID; `rpicam-still` + `python -m dualvision.pi_capture` records independent Pi photo.
4. Retrieve signed source summaries and run the strict deterministic reducer.
5. On conflict or missing Pi, status is HOLD. No physical actuation is wired in this reference.
6. Run physical acceptance measurements and blinded labels; only then evaluate camera performance, scientific novelty and sponsor model benefit.

## Honest readiness summary

**Built and locally tested:** source-specific API/DBs, image comparison baseline, signing, deduplication, conservative decision reduction, 14.2 agent bridge. **Not built/validated:** deployed Hailo neural model, trained NVIDIA defect classifier, live Nebius LLM, secure production gateway, physical sorter, external factory trial, 10,000-article empirical review.

**Never post event-only redemption links, account credentials, signed camera raw photos or personal/factory secrets to public GitHub.**
