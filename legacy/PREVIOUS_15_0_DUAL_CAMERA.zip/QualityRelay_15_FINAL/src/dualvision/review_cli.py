"""Manually fetch independently signed node evidence, print REVIEW only.
The operator input flags are not independent metrology validation; the final
human signature/certified authorization is a separate future integration.
"""
import argparse,os,httpx
from .reconcile import decide

def main():
    p=argparse.ArgumentParser();p.add_argument('--specimen',required=True)
    p.add_argument('--metrology-verified',action='store_true');p.add_argument('--assembly-verified',action='store_true')
    inp=p.parse_args()
    cfg=[('phone_vision',os.getenv('QR_PHONE_NODE_URL','http://127.0.0.1:8101'),os.getenv('QR_PHONE_OPERATOR_TOKEN','')),
         ('pi_edge_vision',os.getenv('QR_PI_NODE_URL','http://127.0.0.1:8102'),os.getenv('QR_PI_OPERATOR_TOKEN',''))]
    events=[]
    for station,addr,token in cfg:
        if not token:print(station,'missing operator token');continue
        try:
            r=httpx.get(addr.rstrip('/')+'/v1/report/'+inp.specimen,
                headers={'X-Operator-Token':token},timeout=3.0)
            r.raise_for_status()
            data=r.json()
            if data.get('events'):events.append(data['events'][0])
        except (httpx.HTTPError,ValueError) as err:print(station,'OFFLINE or unavailable:',type(err).__name__)
    result=decide(events,{'phone_vision':os.getenv('QR_PHONE_STATION_SECRET',''),
        'pi_edge_vision':os.getenv('QR_PI_STATION_SECRET','')},
        metrology_verified=inp.metrology_verified,
        assembly_verified=inp.assembly_verified)
    print(result)
if __name__=='__main__':main()
