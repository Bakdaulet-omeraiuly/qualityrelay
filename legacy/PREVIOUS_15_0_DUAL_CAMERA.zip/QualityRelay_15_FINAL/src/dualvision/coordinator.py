"""Optional READ-ONLY review service; it does not own node databases.

For a real demo, make node applications independently available, retrieve their
signed summaries via /v1/report (operator or service identity), then POST both
reports to /api/dual-vision/reconcile. No machine control is exposed.
"""
import os
from fastapi import FastAPI,HTTPException,Header
from pydantic import BaseModel
from .reconcile import decide

app=FastAPI(title='QualityRelay 15: two-camera evidence reviewer')

class Review(BaseModel):
    events:list[dict]
    metrology_verified:bool=False
    assembly_verified:bool=False

@app.post('/api/dual-vision/reconcile')
def reconcile(r:Review,x_review_token:str|None=Header(default=None)):
    import secrets
    tok=os.getenv('QR_REVIEW_TOKEN','')
    if len(tok)<16 or x_review_token is None or not secrets.compare_digest(x_review_token,tok):
        raise HTTPException(403,'private operator review required')
    keys={'phone_vision':os.getenv('QR_PHONE_STATION_SECRET',''),
          'pi_edge_vision':os.getenv('QR_PI_STATION_SECRET','')}
    if any(len(k)<16 for k in keys.values()):raise HTTPException(503,'station verification secrets unavailable')
    return decide(r.events,keys,metrology_verified=r.metrology_verified,
                  assembly_verified=r.assembly_verified)

@app.get('/api/dual-vision/health')
def health():
    return {'status':'reference','physical_sorter_connected':False,
            'hailo_model_loaded':False,'nvidia_model_loaded':False,
            'nebius_connected':False,'nodes_must_run_as_separate_processes':True}
