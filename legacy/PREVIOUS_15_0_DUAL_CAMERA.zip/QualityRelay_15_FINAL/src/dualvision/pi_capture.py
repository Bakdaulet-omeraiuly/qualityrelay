"""Submit a Pi-camera photo already captured with rpicam-still.
This does not claim a deployed Hailo neural net; inference is OpenCV demo.
No key is placed in command-line arguments or in the repository.
"""
import argparse,base64,os,pathlib,uuid
import httpx

def main():
    p=argparse.ArgumentParser()
    for key in ('sample','golden','specimen'):
        p.add_argument('--'+key,required=True)
    args=p.parse_args()
    addr=os.getenv('QR_PI_NODE_URL','http://127.0.0.1:8102').rstrip('/')
    token=os.getenv('QR_PI_OPERATOR_TOKEN','')
    if not token:raise SystemExit('Missing QR_PI_OPERATOR_TOKEN')
    def data(path):return base64.b64encode(pathlib.Path(path).read_bytes()).decode()
    item={'specimen_id':args.specimen,'capture_id':uuid.uuid4().hex,
          'sample_b64':data(args.sample),'golden_b64':data(args.golden)}
    r=httpx.post(addr+'/v1/capture',json=item,headers={'X-Operator-Token':token},timeout=30.0)
    r.raise_for_status()
    e=r.json()
    print('station:',e['station_id'],'specimen:',e['specimen_id'],
          'visual candidate:',e['candidate'],'event_id:',e['event_id'])
if __name__=='__main__':main()
