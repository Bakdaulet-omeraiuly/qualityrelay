"""Offline proof of the decision logic. Results are constructed, NOT camera output."""
from datetime import datetime,timezone
from .evidence import new_event,sign_event
from .reconcile import decide

KEYS={'phone_vision':'PHONE_KEY_FOR_TEST_ONLY_12345678',
      'pi_edge_vision':'PI_KEY_FOR_TEST_ONLY_12345678'}

def fake_event(station,kind,digest_character):
    ev=new_event(station_id=station,specimen_id='tab-B12',
      image_digest=digest_character*64,reference_digest='f'*64,
      candidate=kind,quality_ok=True,method='SCRIPTED_SYNTHETIC_EXAMPLE',
      capture_id=station+'-'+kind)
    ev['origin']='physical_capture' # Synthetic demo only: DO NOT present as physical.
    return sign_event(ev,KEYS[station])

def main():
    for label,kinds in [('agreement_clear',('NO_ANOMALY','NO_ANOMALY')),
                        ('contradiction',('NO_ANOMALY','SUSPECT')),
                        ('both_suspect',('SUSPECT','SUSPECT'))]:
        events=[fake_event('phone_vision',kinds[0],'a'),fake_event('pi_edge_vision',kinds[1],'b')]
        ans=decide(events,KEYS,metrology_verified=True,assembly_verified=True)
        print(label,ans['review_status'],ans['reasons'])
if __name__=='__main__':main()
