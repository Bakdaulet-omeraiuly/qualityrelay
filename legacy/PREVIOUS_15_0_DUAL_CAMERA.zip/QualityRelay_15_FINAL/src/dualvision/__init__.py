"""Two independent vision evidence nodes + deterministic reconciliation reference."""
