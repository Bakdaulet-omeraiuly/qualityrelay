"""Run one station in its own OS process and SQLite path.
Example:
 QR_STATION_ID=phone_vision QR_STATION_DB=data/phone.sqlite ... \
 python -m dualvision.run_station --port 8101
"""
import argparse,os,uvicorn
from .station import app_from_env

def main():
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,required=True)
    p.add_argument('--host',default='127.0.0.1')
    args=p.parse_args()
    uvicorn.run(app_from_env(),host=args.host,port=args.port,log_level='info')
if __name__=='__main__':main()
