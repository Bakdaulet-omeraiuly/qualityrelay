"""One station = one process + one independent local SQLite database.

Run two processes from this same code with distinct station IDs, secrets,
operator tokens, and sqlite files. For trusted local demo only: NOT hardened for
public internet. Do not commit secrets, camera images, or factory data.
"""
import os, sqlite3, json, secrets
from pathlib import Path
from fastapi import FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel,Field
from .evidence import new_event,sign_event
from .vision_baseline import evaluate_pair

class Capture(BaseModel):
    specimen_id:str=Field(min_length=1,max_length=100)
    capture_id:str=Field(min_length=1,max_length=128)
    sample_b64:str
    golden_b64:str


def create_station_app(station_id: str, *, db_path: str, station_secret: str,
                       operator_token: str) -> FastAPI:
    if station_id not in ('phone_vision','pi_edge_vision'):raise ValueError('invalid station id')
    if len(station_secret)<16 or len(operator_token)<16:
        raise ValueError('set 16+ character unique secret/token for each station')
    Path(db_path).parent.mkdir(parents=True,exist_ok=True)
    app=FastAPI(title=f'QualityRelay 15 local station: {station_id}')
    allowed_origin=os.environ.get('QR_UI_ALLOWED_ORIGIN','').strip()
    if allowed_origin:
        # Exact origin allowlist, not wildcard CORS; for restricted operator demo.
        app.add_middleware(CORSMiddleware,allow_origins=[allowed_origin],
                           allow_credentials=False,allow_methods=['GET','POST'],
                           allow_headers=['Content-Type','X-Operator-Token'])
    with sqlite3.connect(db_path) as conn:
        conn.execute('CREATE TABLE IF NOT EXISTS evidence(event_id TEXT PRIMARY KEY, specimen_id TEXT NOT NULL, payload TEXT NOT NULL)')
        conn.commit()

    @app.get('/health')
    def health():
        return {'station_id':station_id,'online':True,'inference':'OpenCV demo, not Hailo/NVIDIA',
                'independent_sqlite':True,'supports_hardware_actuation':False}

    @app.post('/v1/capture')
    def capture(inp:Capture,x_operator_token: str | None=Header(default=None)):
        if not x_operator_token or not secrets.compare_digest(x_operator_token,operator_token):
            raise HTTPException(403,'operator token required')
        try:
            result=evaluate_pair(inp.golden_b64,inp.sample_b64)
            event=sign_event(new_event(station_id=station_id,specimen_id=inp.specimen_id,
                capture_id=inp.capture_id,image_digest=result['image_sha256'],
                reference_digest=result['reference_sha256'],candidate=result['candidate'],
                quality_ok=result['image_quality_usable'],
                method=result['method'], score=result['score_illustrative_not_probability']),station_secret)
        except (ValueError,TypeError) as exc:raise HTTPException(422,str(exc)) from exc
        packed=json.dumps(event,sort_keys=True)
        with sqlite3.connect(db_path) as conn:
            old=conn.execute('SELECT payload FROM evidence WHERE event_id=?',(event['event_id'],)).fetchone()
            if old:
                old_event=json.loads(old[0])
                # Timestamp/attestation may differ across retries. Only the saved
                # first attested observation is returned, never re-counted.
                if (old_event['image_sha256']!=event['image_sha256'] or
                    old_event['reference_sha256']!=event['reference_sha256'] or
                    old_event['specimen_id']!=event['specimen_id']):
                    raise HTTPException(409,'duplicate capture ID with altered image or specimen')
                return old_event
            conn.execute('INSERT INTO evidence VALUES (?,?,?)',(event['event_id'],inp.specimen_id,packed))
            conn.commit()
        return event

    @app.get('/v1/report/{specimen_id}')
    def report(specimen_id:str,x_operator_token: str | None=Header(default=None)):
        if not x_operator_token or not secrets.compare_digest(x_operator_token,operator_token):
            raise HTTPException(403,'operator token required')
        with sqlite3.connect(db_path) as conn:
            rows=conn.execute('SELECT payload FROM evidence WHERE specimen_id=? ORDER BY rowid DESC LIMIT 5',(specimen_id,)).fetchall()
        return {'station_id':station_id,'specimen_id':specimen_id,'events':[json.loads(r[0]) for r in rows]}

    return app


def app_from_env():
    station=os.environ.get('QR_STATION_ID','')
    return create_station_app(station,db_path=os.environ.get('QR_STATION_DB',''),
             station_secret=os.environ.get('QR_STATION_SECRET',''),
             operator_token=os.environ.get('QR_STATION_OPERATOR_TOKEN',''))
