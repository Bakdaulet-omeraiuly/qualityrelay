"""Translation of verified dual camera events into v14.2's bounded VISION tool view.

The model never receives raw images, HMAC secrets, or speculative mm dimensions.
The final disposition always comes from the stricter dual-vision deterministic
reducer, NOT from v14.2 single-vision evidence_gate or LLM prose.
"""
from .evidence import STATIONS,verify_event


def to_agent_view(events:list[dict], secrets:dict[str,str]) -> dict[str,dict]:
    view={}
    for e in events:
        station=e.get('station_id')
        if station not in STATIONS or not verify_event(e,secrets.get(station,'')):
            raise PermissionError('unverified vision event')
        if e.get('candidate') not in ('NO_ANOMALY','SUSPECT','ABSTAIN'):
            raise ValueError('invalid visual candidate')
        view[e['event_id']]={
            'event_id':e['event_id'],'specimen_id':e['specimen_id'],
            'kind':'VISION','origin_station':station,
            'observed_at':e['observed_at'],'origin':'physical',
            'payload':{'visual_usable':bool(e.get('image_quality_usable')),
                       'defect_suspected':True if e['candidate']=='SUSPECT' else (
                           False if e['candidate']=='NO_ANOMALY' else None)},
            'source_event_ids':list(e.get('source_event_ids',[])),
            'source_is_signature_verified':True,
            'source_model':e.get('method'),
        }
    return view
