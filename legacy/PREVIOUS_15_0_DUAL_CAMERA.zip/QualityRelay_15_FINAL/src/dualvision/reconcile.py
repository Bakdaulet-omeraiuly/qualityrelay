"""Safety-oriented decision support; not release or scrap authorization.

A single camera's 'clear' label cannot justify PASS. Agreement may still be
correlated, uncalibrated, or wrong. This reducer only emits review statuses.
"""
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from .evidence import STATIONS,verify_event


def decide(evidence:list[dict],station_secrets:dict[str,str],*,
           metrology_verified:bool=False,assembly_verified:bool=False,
           now:datetime|None=None,max_age_s=600) -> dict:
    now=now or datetime.now(timezone.utc)
    reasons=[]
    seen={}
    unique=[]
    for ev in evidence:
        if not isinstance(ev,dict):reasons.append('malformed_event');continue
        eid=ev.get('event_id')
        if not isinstance(eid,str) or not eid:reasons.append('missing_event_id');continue
        if eid in seen:
            if seen[eid]!=ev:reasons.append('event_id_collision')
            continue
        seen[eid]=ev
        station=ev.get('station_id')
        if station not in STATIONS:
            reasons.append('unknown_station');continue
        if not verify_event(ev,station_secrets.get(station,'')):
            reasons.append('invalid_attestation');continue
        if ev.get('schema_version')!='qr-vision-1' or ev.get('origin')!='physical_capture':
            reasons.append('invalid_evidence_origin');continue
        if ev.get('may_authorize_hardware') is not False:
            reasons.append('unsafe_event_claim');continue
        try:
            t=datetime.fromisoformat(ev['observed_at'].replace('Z','+00:00'))
            age=(now-t).total_seconds()
            if not t.tzinfo or age<0 or age>max_age_s:raise ValueError()
        except (ValueError, KeyError, TypeError):
            reasons.append('stale_or_invalid_timestamp');continue
        if ev.get('source_event_ids'):
            reasons.append('derived_evidence_not_independent');continue
        if ev.get('candidate') not in ('NO_ANOMALY','SUSPECT','ABSTAIN'):
            reasons.append('invalid_candidate');continue
        if not ev.get('image_quality_usable') or ev['candidate']=='ABSTAIN':
            reasons.append('visual_quality_or_abstention');continue
        unique.append(ev)
    specimens={e['specimen_id'] for e in unique}
    if len(specimens)!=1:reasons.append('missing_or_mismatched_specimen')
    bystation={}
    for e in unique:bystation.setdefault(e['station_id'],[]).append(e)
    for station in STATIONS:
        if station not in bystation:reasons.append(f'missing_{station}_evidence')
        elif len(bystation[station])>1:reasons.append(f'multiple_{station}_candidates_need_selection')
    if len(bystation)==2 and all(len(v)==1 for v in bystation.values()):
        a,b=(bystation[k][0] for k in STATIONS)
        if a['image_sha256']==b['image_sha256']:
            reasons.append('identical_camera_image_not_independent')
        if a['candidate']!=b['candidate']:
            reasons.append('camera_disagreement')
        if any(e['candidate']=='SUSPECT' for e in (a,b)):
            reasons.append('suspected_visual_defect')
    if not metrology_verified:reasons.append('unverified_dimensional_measurement')
    if not assembly_verified:reasons.append('unverified_assembly_compatibility')
    action='repeat_visual_capture_or_caliper' if any(x in reasons for x in (
        'camera_disagreement','visual_quality_or_abstention','suspected_visual_defect')) else 'request_missing_evidence'
    return {'review_status':'HOLD' if reasons else 'PASS_REVIEW',
            'reasons':sorted(set(reasons)),
            'suggested_next_action':action if reasons else 'human_engineer_review',
            'human_approval_required':True,'physical_sorter_command':None,
            'verified_node_count':len(bystation),'unique_event_count':len(seen),
            'model_confidence_calibrated':False,'physical_validation_completed':False}
