"""Versioned, tamper-evident evidence envelope for dual-camera research demo.

HMAC is for node-to-node integrity using pre-shared secrets. It is NOT a public
key signature, not a factory-grade identity solution, and does not make a
malicious/corrupted camera trustworthy. Independent observations are required.
"""
from __future__ import annotations
from datetime import datetime, timezone
import hashlib, hmac, json, uuid

STATIONS = ('phone_vision', 'pi_edge_vision')
CANDIDATES = ('NO_ANOMALY', 'SUSPECT', 'ABSTAIN')


def canonical(event: dict) -> bytes:
    # Exclude attestation from signed body.
    return json.dumps({k:v for k,v in event.items() if k != 'attestation'},
                      sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                      allow_nan=False).encode('utf-8')


def sign_event(event: dict, secret: str) -> dict:
    if len(secret)<16: raise ValueError('station secret too short')
    doc = dict(event)
    doc.pop('attestation', None)
    doc['attestation'] = hmac.new(secret.encode(), canonical(doc), 'sha256').hexdigest()
    return doc


def verify_event(event: dict, secret: str) -> bool:
    if not isinstance(event, dict) or not isinstance(event.get('attestation'), str):return False
    if len(secret)<16:return False
    exp=hmac.new(secret.encode(),canonical(event),'sha256').hexdigest()
    return hmac.compare_digest(exp,event['attestation'])


def iso_now():
    return datetime.now(timezone.utc).isoformat()


def new_event(*, station_id: str, specimen_id: str, image_digest: str,
              reference_digest: str, candidate: str, capture_id: str,
              quality_ok: bool, method: str, score: float | None = None,
              observed_at: str | None = None, source_event_ids: list[str] | None = None) -> dict:
    if station_id not in STATIONS:raise ValueError('invalid station')
    if candidate not in CANDIDATES:raise ValueError('invalid candidate')
    if not specimen_id or len(specimen_id)>100:raise ValueError('invalid specimen')
    if not capture_id or len(capture_id)>128:raise ValueError('invalid capture')
    if not isinstance(image_digest,str) or len(image_digest)!=64:raise ValueError('invalid digest')
    # A repeated camera capture is one event; retry is idempotent. Different
    # image under the same capture_id is an audit collision, not an overwrite.
    event_id=str(uuid.uuid5(uuid.NAMESPACE_URL, f'{station_id}/{specimen_id}/{capture_id}'))
    return {
       'schema_version':'qr-vision-1', 'event_id':event_id,
       'station_id':station_id, 'specimen_id':specimen_id, 'capture_id':capture_id,
       'observed_at':observed_at or iso_now(), 'origin':'physical_capture',
       'image_sha256':image_digest, 'reference_sha256':reference_digest,
       'candidate':candidate, 'image_quality_usable':bool(quality_ok),
       'method':method, 'score_illustrative_not_probability':score,
       'source_event_ids':source_event_ids or [],
       'may_authorize_hardware':False,
    }
