"""OpenCV image comparison baseline. Not an NVIDIA/Hailo AI model.

Reference and sample must be same registered view. Difference score is NOT a
calibrated defect probability and must NOT be interpreted as dimensional mm.
"""
import base64, binascii, hashlib
import cv2
import numpy as np

MAX_IMAGE_BYTES=4_000_000


def decode_image(b64: str):
    if b64.startswith('data:'):b64=b64.split(',',1)[1]
    if not isinstance(b64,str) or len(b64)>int(MAX_IMAGE_BYTES*4/3)+32:
        raise ValueError('image payload exceeds limit')
    try: raw=base64.b64decode(b64,validate=True)
    except (binascii.Error,ValueError):raise ValueError('invalid base64')
    if len(raw)>MAX_IMAGE_BYTES:raise ValueError('image payload exceeds limit')
    image=cv2.imdecode(np.frombuffer(raw,dtype=np.uint8),cv2.IMREAD_COLOR)
    if image is None or min(image.shape[:2])<80: raise ValueError('invalid or undersized image')
    return image,hashlib.sha256(raw).hexdigest()


def evaluate_pair(golden_b64: str, sample_b64: str):
    reference,refhash=decode_image(golden_b64)
    sample,samplehash=decode_image(sample_b64)
    if reference.shape!=sample.shape:raise ValueError('images must be registered to same dimensions')
    gray0=cv2.cvtColor(reference,cv2.COLOR_BGR2GRAY)
    gray1=cv2.cvtColor(sample,cv2.COLOR_BGR2GRAY)
    blur0=cv2.GaussianBlur(gray0,(5,5),0)
    blur1=cv2.GaussianBlur(gray1,(5,5),0)
    contrast=float(gray1.std())
    # Intentional conservative acquisition gate, still heuristic—not a calibrated
    # defect acceptance threshold.
    quality_ok=contrast>=6 and float(gray1.mean())>=15 and float(gray1.mean())<=240
    ratio=float(np.mean(cv2.absdiff(blur0,blur1)>28))
    score=round(ratio,5)
    candidate='ABSTAIN' if not quality_ok else ('SUSPECT' if ratio>0.04 else 'NO_ANOMALY')
    return {'image_sha256':samplehash,'reference_sha256':refhash,
            'candidate':candidate,'image_quality_usable':quality_ok,
            'score_illustrative_not_probability':score,
            'method':'opencv_registered_golden_difference_demo_v0',
            'limitation':'Change fraction is not a defect probability; pose and illumination effects require validation'}
