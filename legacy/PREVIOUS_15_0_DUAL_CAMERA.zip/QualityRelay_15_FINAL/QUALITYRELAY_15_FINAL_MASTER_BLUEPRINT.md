# QUALITYRELAY 15.0 — DUAL-VISION EVIDENCE MESH

**Final Scientific + Implementation Master Blueprint**  
**ScienceClaw manufacturing / materials research prototype | 30 October 2026**  
**Primary architecture:** fully decentralized evidence ownership; optional read-only aggregation and centralized Chief Engineer used as experimental baselines.  
**Core configuration:** smartphone camera + Raspberry Pi 5 camera/Hailo-8L (if borrowed) + manual digital caliper + 3D printed Slot/Tab + 21 bounded engineering-specialist roles + peer evidence exchange + NVIDIA GPU experiments + Nebius LLM tool calling + optional ESP32 sorter.  
**Core promise:** decision-support research, **not** a commercially validated autonomous machine or an already discovered new scientific law.

> **Read this section first.** Your requested change is **YES: two separate camera sources are used as two separately accountable vision evidence stations**. The phone and Raspberry Pi must each capture their own images, run or request their own vision analysis, keep their own events, and report them with immutable IDs. Their conflicting conclusions must not be resolved by LLM majority voting. If either camera reports a possible defect, is offline, provides unusable evidence, or conflicts with the other, the independent deterministic review policy returns `HOLD` until further verification. A servo, if available, moves the **sorting gate**, never caliper jaws. A caliper remains the physical dimensional instrument.

---

## 0. Source of truth, status and preservation policy

**What is actually implemented in this ZIP**

1. A runnable, bounded **two-station reference** using **two separate Python processes and two separate SQLite databases**. Both camera stations use an OpenCV golden-image difference **baseline** (not NVIDIA inference), and produce per-capture attested provenance envelopes. The Pi process can run on a laptop for interface testing, but may be called a *physical Pi station* only once deployed on that device and connected to its own camera.
2. A deterministic `HOLD` / `PASS_REVIEW` gate that validates station-specific HMAC attestations, event freshness, same specimen, duplicate IDs, distinct image digests, contradictory outcomes, usable visual evidence and the existence of separately verified metrology/assembly evidence. `PASS_REVIEW` is **not** PASS and cannot actuate hardware.
3. A narrow translation layer feeding verified visual summaries to the **original QualityRelay 14.2 specialist-agent contracts** without making LLM prose authoritative.
4. A small static dashboard reference, Pi photo submission CLI, station APIs, coordinator API, test scripts, 23 reference unit/integration tests and configuration instructions.
5. The **unchanged original QualityRelay 14.2 ZIP** is preserved inside `archive/` and retains the earlier nested 14.0 and research archive lineage. The original 5.0 33-file ZIP is also provided directly for easy access.

**Not implemented / not demonstrated**

- Actual access to a borrowed Raspberry Pi 5, Hailo-8L, camera, servo, or physical sorter.
- Camera-specific trained NVIDIA Visual ChangeNet / PatchCore / EfficientAD inference or a compiled Hailo `.hef` for our Slot/Tab parts.
- A live Nebius account/LLM session or production peer-to-peer infrastructure.
- Real-camera classification accuracy, metrology uncertainty, time savings, industrial pilot, or manufacturer acceptance.
- Any scientific superiority of V-DER, CAIR or the 21-agent architecture. Earlier toy/synthetic results **did not establish** significant improvement over classical information gain.
- 10,000 individually downloaded or analyzed scientific papers: earlier packages contain a bibliographic retrieval program, not that completed corpus.

**Evidence labeling:** `TEST_FIXTURE`, `SIMULATED`, `PHYSICAL_CAPTURE`, `INDEPENDENT_VERIFIED_MEASUREMENT` are distinct labels in experiments; NEVER merge their metrics without explicit subgroup labeling. HMAC authenticates a station's message under a shared secret; it does not independently prove that a real camera took a photo or that the algorithm is accurate.

---

## 1. What the audience sees — a complete 2-camera scientific demonstration

**Physical demo story.** Three printed components are registered: a dimensionally conforming tab, a tab with a visibly missing corner/crack, and a visually normal tab whose thickness violates an assembly clearance limit. The team prepares a safe slot and alternative tab pairings. All geometry and dimensions in this Master are *teaching configuration values* taken from 5.0, not factory tolerances.

1. The **Metrology Station** operator measures the tab or slot with a **digital caliper**. The phone optionally OCR-reads the LCD into a *candidate* value. The operator checks units, specimen ID and stable measurement before confirming. An OCR reading alone is never accepted as metrology truth.
2. **Phone Vision Station** captures a surface image through the web app with a known pose and reference image. It records visual suspicion, image quality, source timestamp, image hash, model version and signed event ID. It is a physically separate sensor source from the Pi.
3. **Pi Edge Vision Station** independently captures the same **specimen**, from its own camera and (preferably) complementary controlled view. When a Hailo-compatible *validated* model is available, the Hailo-8L can perform edge inference. Initially use the OpenCV CPU fallback; clearly label which backend is active.
4. The **Station Evidence-Mesh** retrieves *allowlisted, signed summaries*, not unrestricted raw photos, and makes both records visible to Quality, Design, Process, Assembly and Inspection agents as permitted.
5. **Evidence router and policy** compare source IDs, snapshots, image provenance, conflicting interpretations, assembly clearance, metrology quality and calibration. They either recommend further acquisition or return `PASS_REVIEW` (pending human signoff). Neither an LLM nor the UI can silently promote `HOLD` to PASS.
6. **Inspection Planner** uses pre-registered V-DER/CAIR hypotheses to rank recapturing at a second angle, changing illumination, re-reading the caliper, or human engineering review based on expected *decision loss* and cost. Early-stage implementation may use a fixed safe request rather than pretend that the information-theory algorithm is calibrated.
7. **Optional Sorter** (borrowed ESP32 and servo) receives only an authenticated, operator-approved routing request in a future hardware driver. Confirm arrival using a beam-break or camera *independently*; do not count every video frame. Without hardware, show the disposition and route as a **non-actuating simulation**.
8. Dashboard shows the two camera results side by side, why they agree/disagree, actual measurement evidence, selective inspection recommendation, source provenance and the **physically confirmed** count only when a physical sensor has acknowledged arrival.

### 1.1 How disagreement makes decentralization visible

| Phone station | Pi edge station | Metrology / assembly | Deterministic outcome | Reason |
|---|---|---|---|---|
| clear | clear | verified | `PASS_REVIEW` | Two usable visual observations; still requires human authorization |
| clear | suspect | verified | `HOLD` | Minority dissent may be important |
| suspect | clear | verified | `HOLD` | A second camera cannot vote away a possible defect |
| suspect | suspect | verified | `HOLD` | Suspect is *not* a verified reject |
| unavailable | clear | verified | `HOLD` | Partial evidence and an explicit offline alarm |
| clear | unavailable | verified | `HOLD` | Independent Pi evidence missing |
| clear | clear | caliper not confirmed | `HOLD` | Visual normality is not dimensional conformance |
| clear | clear | assembly incompatibility | `HOLD` | Even good individual parts may not fit together |
| unusable lighting or pose | any | any | `HOLD` | Do not assign fake image certainty |
| same exact image reused | clear | verified | `HOLD` | Not independent capture evidence |

`PASS_REVIEW` != final physical PASS. `HOLD` != confirmed scrap. Only a separate operator authorization policy could eventually decide final routing.

### 1.2 The hypothesis QualityRelay should test

> **H1 (benefit):** Under *controlled distribution shift and partial sensor coverage*, provenance-aware, dissent-preserving, decision-aware two-camera coordination lowers **unsafe false-PASS rate at a fixed inspection budget** relative to phone-only, Pi-only, naive voting and a central single-model baseline.

> **H0 (falsifier):** Under the same controlled conditions, the proposed method delivers no reduction in false passes, or any reduction is fully explained by a more conservative HOLD policy that also could be implemented in a conventional rule-based system.

The comparison must include a **conservative rules-only fusion baseline**. Otherwise, a benefit caused by simple OR/HOLD logic could be wrongly credited to 21 LLM agents. We must not claim that extra sensors or more HOLDs automatically make the system superior.

---

## 2. What is the novel research candidate — and what is NOT novel?

**Proposed research contribution:** *Provenance-Constrained, Decision-Aware Dual-Vision Evidence Routing (PC-DAVER)*.

The design investigates whether the combination of (a) evidence provenance and independence constraints, (b) expert minority dissent protection, (c) cost-sensitive next-inspection selection, (d) fail-closed local continuation when a station drops and (e) separate instrument/visual/assembly verification yields useful operational gains in a decentralized factory topology.

**Not novel individually:** two-camera inspection, disagreement/HOLD, calibration, anomaly detection, Bayesian value of information, digital threads, agent orchestration and evidence signing all have substantial prior art. Our proposed integration and especially *empirical performance under constrained collaboration* are research hypotheses, not established inventions. A patentability/novelty search is separate from academic prior-art review.

**Research honesty:** an experiment where the proposed approach performs worse is an informative result. An LLM's confident explanation is not evidence of a discovered physical law. Registered decisions and numeric outputs come from deterministic, versioned scientific tools; LLMs are question-asking and interpretation agents.

### 2.1 Formal decision objective (conceptual)

Let `E` be independently verified current evidence; `a` the proposed inspection action; `y` a possible observation; `d` the final disposition decision; `L(d,H)` an asymmetric loss against the true state `H` (unsafe PASS cost >> unnecessary HOLD cost); and `cost(a)` the measurement, compute and delay expense.

\[
 a^* = \arg\min_{a\in A} \left[cost(a) + \mathbb E_{y\mid E,a}\left(\min_d \mathbb E_{H\mid E,y,a}[L(d,H)]\right)\right].
\]

- Include the no-action alternative in `A`, and enforce inspection/time budgets.
- Evaluate **Bayesian risk reduction, not only entropy reduction**. Since these are existing decision-theory ideas, scientific novelty requires controlled evidence that the provenance/decentralization constraints matter.
- Dependency warning: two camera results may be correlated because of identical lighting, shared 3D geometry, training datasets or domain shift. **Never multiply their probabilities under a naive independence assumption.** Fit/test a dependence-aware likelihood, or use distribution-free conservative HOLD until reliable calibration data exist.
- A sensor that predicts a binary classification must not create a precise dimensional measurement from pixels unless the camera has been calibrated and independent gauge R&R / measurement-system tests support that resolution.

---

## 3. Physical camera setup and accuracy constraints

### 3.1 Phone camera (owned hardware)

- Modern iPhone/Android camera, used through HTTPS web capture (`<input type=file accept=image/* capture=environment>` for basic capture; `getUserMedia()` only under a secure context and explicit permission).
- **Two modes:** (A) caliper LCD OCR *candidate* and (B) independent surface defect image capture.
- Stabilize on stand; use a marked specimen ID and fixed controlled lighting. Golden comparison only when orientation, distance, perspective and background match.
- Photograph at least one *top* and one *side* view only when the experiment needs it; distinguish multiple photos from **one** source from photos made by an independent second source.
- No hard promises of detecting 0.100 mm shifts by ordinary smartphone photos. Use the caliper as dimensional ground truth, subject to actual gauge uncertainty.

### 3.2 Borrowed Raspberry Pi + Hailo camera

- Request **1 Raspberry Pi 5 + Hailo-8L AI HAT**, **1 Pi camera**, optional adjustable mount/lighting from the shared ScienceClaw hardware pool. Quantities are limited and first-come, first-served; do not assume availability.
- Separate `pi_edge_vision` process, device key and local SQLite store. Distinct camera and capture ID; independent timestamps and model version; source-specific quality gate.
- Start with CPU OpenCV reference difference/contour detection on the Pi. This can run without a working neural accelerator and lets you validate the peer evidence protocol.
- **Only if available:** install a Hailo-8L-compatible `.hef` model and verify a real inference on the Pi. Hailo-8L's supported vision-model compilation workflow is not interchangeable with NVIDIA GPU/TensorRT binaries. Hailo Model Zoo currently directs Hailo-8/8L to a compatible **v2.x branch**, not its default master for newer chips.
- Report exact `backend=opencv_cpu_demo` or `backend=hailo8l_<model>_<version>`; do not silently substitute model names.
- The Hailo-8L is a vision inference accelerator; it does **not** turn into 21 local LLM models. Nebius can host reasoning models separately.

### 3.3 What is the *camera defect label*?

Initial label taxonomy with **image-level and specimen-level labels kept separate**:

| Defect label | Can ordinary RGB cameras see it? | Ground-truth method |
|---|---|---|
| `missing_corner` / `missing_feature` | If visible at acquired pose | Manual expert inspection + controlled print design |
| `layer_shift` | Often, if external geometry shows it | Print-log scenario + expert label |
| `stringing` / excess plastic | Often visible | Expert and reference photography |
| `surface_crack_visible` | Only if visible at resolution | Human close-up / additional optical inspection |
| `warping_visible` | Sometimes, with reference/side view | Flatness measurement/fixture + expert label |
| `undersized_slot` / `oversized_tab` | Not reliably from uncalibrated photo | Caliper dimensions and uncertainty analysis |
| `internal_void` / structural strength | Not reliably | Beyond RGB scope; require suitable non-destructive/mechanical test |

For the hackathon freeze, emphasize **missing feature, visible layer shift and obvious surface defect** rather than pretending to detect every 3D-print failure.

---

## 4. NVIDIA, Nebius, Hailo — exact non-overlapping responsibilities

### 4.1 NVIDIA (training/research GPU, not the second camera's hardware manufacturer)

**NVIDIA Brev $150 per registered participant** according to *ScienceClaw Compute*, page 4. Three correctly registered team members may each claim a separate one-time coupon; don't treat these as transferable cash or assume a single shared billing account. Track burn rate and shut down GPU instances after experiments.

Research track options, prioritized:

1. **P0 — no-GPU baseline:** OpenCV golden-image difference to establish full image capture/provenance/reconciliation behavior and a weakness baseline.
2. **P1 — NVIDIA Visual ChangeNet via TAO**: aligned golden vs test paired-image difference model; train/evaluate only when real labeled pairs exist. Capture viewpoint/lighting split to measure generalization. Use class predictions and calibrated uncertainty, not “millimeter dimensions”. The NVIDIA documentation describes classify and segmentation pathways; actual backbone, data schema and weights should be checked against the installed version.
3. **P1/P2 — PatchCore or EfficientAD** as external research baselines. PatchCore (CVPR 2022) and EfficientAD (WACV 2024) are published prior work, not our claimed discoveries.
4. **P2 — domain-shift and calibration tests**: train on one illumination/camera/background, test on another; measure image-level sensitivity, false positives, calibration and latency.

**If Hailo model transfer fails:** keep Pi OpenCV/compatible lightweight model and report heterogeneous models; it is not necessary or scientifically honest to force the same NVIDIA model to execute on Hailo.

### 4.2 Nebius (three different things; separate credentials)

- **Nebius Token Factory / hosted inference:** engineering LLM “brains” for Quality/Process/Assembly/Metrology agents. API is OpenAI-compatible (`/v1/chat/completions`, model listing). Choose a current model ID from your actual account. Use bounded tool calling; server-side authorization, evidence allowlists and deterministic gates are mandatory.
- **Nebius Scientific AI Platform:** the ScienceClaw document page 8 describes a team-specific closed-beta access, an agentic notebook, a scientific API/MCP and 65 scientific models/skills. Mostly useful if a *specific* solver matches a test; protein-folding models do **not** belong in our machining/inspection demo by default. Only **one request per team**.
- **Nebius shared H100 cloud pool:** ScienceClaw page 9 says **16 shared H100 GPUs across the event**, NOT 16 dedicated for QualityRelay. Individual jobs can be queued/fail on contention. One GPU per job is the considerate default; use only if a GPU experiment clearly improves the research question.

**Model grounding pipeline:** LLM sees server-filtered event IDs, invokes approved tools, returns hypothesis + citations to those IDs; deterministic policy validates citations, timeliness and peer provenance. Tools never give unrestricted shell, cross-station raw-table access or hardware commands to the model. An LLM can recommend HOLD/inspection but cannot directly release or scrap a part.

### 4.3 Other ScienceClaw credits and infrastructure

- Claude Console **$100 per registered member**, OpenAI API **$50 credit**, and Google AI Studio preconfigured API access according to *ScienceClaw Compute* pages 6, 13 and 11. They are **optional baselines**, not reasons to call multiple expensive LLMs on every specimen.
- Google Cloud accounts have a **maximum of two per team**, and may be automatically deleted Sunday night. Export code/results before expiry. **Bakdaulet does not work on Google Cloud**; adilnurgg and HyorinmaruK own Google Cloud infrastructure and deployment tasks.
- Event-specific credit links are protected; don't repost them in GitHub, ZIPs or public docs. Nebius credentials, NVIDIA keys and Google secrets stay in `.env`/secrets manager, never checked into source.
- Hardware pool (*Hardware Summary*, page 1): 15 ESP32-S3, 10 ESP32-S3 Camera boards, 5 Raspberry Pi 5 + Hailo-8L, 5 ELEGOO bundles, 5 Raspberry Pi cameras, breadboards and jumpers; all **shared, limited**.

### 4.4 Source / software compatibility matrix

| Workload | Location | Minimum workable model | Sponsor resource | Demonstration condition |
|---|---|---|---|---|
| Caliper OCR candidate | phone photo → local/backend | Tesseract OCR + manual confirm | none required | `caliper_verified` by operator, stable unit mm |
| Phone surface detection | phone photo → server | OpenCV, then NVIDIA-trained model | Brev GPU optional | real held-out images and camera metadata |
| Pi visual detection | Raspberry Pi device | OpenCV CPU first, then supported Hailo HEF | borrowed Pi/Hailo | genuine independent capture, local run documented |
| LLM engineering collaboration | local services → Nebius API | bounded model tool-calling | Nebius Token Factory | live model, tool result and logged source IDs |
| PACE/V-DER/CAIR scientific decision | local deterministic Python | cost matrix and evidence gate | CPU enough | baseline comparison, provenance audit |
| optional physical sorter | ESP32/servo | authenticated driver, interlock, arrival ack | borrowed ELEGOO/ESP32 | never driven directly by LLM |
| unified website | frontend & read-only gateway | HTTPS browser interface | Google Cloud optional | node DBs still separate; shared web URL != shared ownership |

---

## 5. Distributed architecture: one web site, real independent data authority

```mermaid
flowchart TB
  U[Unified HTTPS dashboard / operator] -->|Capture image| P[Phone Vision Node + local DB]
  PI[Raspberry Pi Camera + Hailo-8L or CPU] --> E[Pi Edge Vision Node + local DB]
  M[Metrology caliper + operator confirmation] --> MET[Metrology Station + local DB]
  P -->|signed scoped summary| R[Peer Evidence Exchange]
  E -->|signed scoped summary| R
  MET -->|signed verified dimensions| R
  R --> A[Assembly Station / deterministic clearance & evidence gate]
  R --> Q[Specialist Agent Tool Views: Quality, Vision, Process, Design, Inspection]
  Q -->|hypotheses + event IDs| A
  A -->|non-actuating proposal| H[Human engineer authorization]
  H -->|future authenticated policy command| S[Optional ESP32 sorter + independent arrival sensor]
  C[Chief Engineer coordinator] -.->|optional baseline only| Q
```

**Distributed truth requirements**:

1. Phone and Pi do not share a mutable evidence database, even if read on one screen.
2. A node may be taken offline; local capture should persist and the system must visibly mark partial coverage. Online peer decisions are conservative while a node is offline.
3. Each event has station ID, specimen ID, capture ID, timestamp, `image_sha256`, reference hash, model version, origin and signature. Raw imagery stays local by default and must be transferred only under permitted scope and retention policy.
4. Exactly-once **effect** with event-ID deduplication; the network may still deliver at-least-once messages. A different image under a reused capture ID is a collision, not a new count.
5. Two photos shot by the *same* phone are repeated measurements, not two independent physical camera stations. Phone/Pi observations can still be statistically correlated; this is a different notion from organizational/system autonomy.
6. Reconnecting a station must not duplicate dispositions, counts or physical gate moves. Queue/replay behavior must be validated before making resilience claims.
7. A central API gateway, CDN or dashboard is permitted for user convenience; it must never become the only source of process truth. The optional centralized Chief Engineer must be switched off in the default decentralized study arm.
8. HMAC is a prototype integrity mechanism; production requires stronger authentication, key rotation, TLS, authorization review, expiry/revocation, data minimization and audit.

### 5.1 Evidence envelope (prototype)

```json
{
  "schema_version": "qr-vision-1",
  "event_id": "uuid5(station/specimen/capture)",
  "station_id": "phone_vision",
  "specimen_id": "tab-B12",
  "capture_id": "unique-camera-capture-id",
  "observed_at": "2026-10-30T18:00:00+00:00",
  "origin": "physical_capture",
  "image_sha256": "64 lowercase hex chars",
  "reference_sha256": "64 lowercase hex chars",
  "candidate": "SUSPECT",
  "image_quality_usable": true,
  "method": "opencv_registered_golden_difference_demo_v0",
  "score_illustrative_not_probability": 0.07,
  "source_event_ids": [],
  "may_authorize_hardware": false,
  "attestation": "HMAC-SHA256-of-canonical-fields"
}
```

This is a **schema example**, not a recorded actual specimen. The raw image bytes are deliberately not embedded in the peer-summary envelope.

### 5.2 `PASS_REVIEW` is not a sorter command

The code returns `{'review_status': 'HOLD' | 'PASS_REVIEW', 'physical_sorter_command': None}`. A real actuator requires an entirely separate, access-controlled, human-authorized state transition and a physical confirmation. A suspect image cannot by itself justify `CONFIRMED_REJECT`.

### 5.3 Current code boundaries

`src/dualvision/station.py` instantiates two independently configured FastAPI apps with separate SQLite paths. `src/dualvision/reconcile.py` checks signed summaries, timestamp freshness and dissent; `src/dualvision/agent_bridge.py` translates verified events to source-limited v14.2 role views. `web/dual_camera.html` is an operator **reference UI**; it does not bypass secure cross-origin browser rules, cannot itself verify HMAC secrets, and does not claim factory deployment. For a restricted development dashboard, set `QR_UI_ALLOWED_ORIGIN` on both station processes to the *exact* dashboard origin and run the static dashboard with `python -m http.server 8000 --directory web`; browser requests across origins otherwise fail. A real phone needs resolvable node addresses and HTTPS. For a production-quality single domain, use an authenticated server-side gateway or reverse proxy with allowlisted CORS/TLS and station identity; do **not** embed persistent secrets in public JavaScript.

---

## 6. The 21 specialist agents and their real intelligence contract

**The 21 roles are retained from QualityRelay 12/14.2 exactly**. Do not confuse a registry of role contracts with 21 independently trained neural models. They may share one Nebius LLM endpoint but have separate system prompts, allowed tools, privileges, context/evidence scopes and budgets.

| Role | Essential responsibility | Trusted tools/inputs | Can it command hardware? |
|---|---|---|---|
| 1 Design Geometry | CAD geometry and constraints | approved CAD summary | No |
| 2 Tolerance Analyst | tolerance stack-up | approved CAD + verified dimensions | No |
| 3 Materials Engineer | material certificate review | verified certificates | No |
| 4 Process Engineer | process shift hypotheses | process stats / print logs | No |
| 5 CNC Expert | manufacturing process diagnosis | machining records if present | No |
| 6 Additive Manufacturing Expert | 3D-print defect causes | print logs + vision summaries | No |
| 7 Metrology Engineer | repeatability, instruments, caliper uncertainty | verified gauge events | No |
| 8 SPC Agent | EWMA/SPC process signal | calibration data / SPC output | No |
| 9 Quality Inspector | suspected defects and audit | dual vision + dimensions | No |
| 10 Assembly Engineer | clearance and fit | deterministic geometry tool | No |
| 11 Causal Diagnosis | alternative root causes | scoped process evidence | No |
| 12 Bayesian Statistician | posterior and confidence | calibrated statistical model | No |
| 13 Inspection Planner | choose next physical check | V-DER, CAIR, time costs | No |
| 14 Operations Research | part pairing and allocation | approved dimensions + constraints | No |
| 15 Maintenance Engineer | instrument/process health | maintenance records | No |
| 16 Supplier Boundary | cross-company evidence sharing | signed supplier summaries | No |
| 17 Safety Governance | safety-critical HOLD veto | policy + provenance ledger | No |
| 18 Privacy/Security | verify access boundaries | auth audit only | No |
| 19 Reliability/Network | disconnected nodes and replay | connection health / event IDs | No |
| 20 Scientific Auditor | preregistration and metrics | run manifests / test outputs | No |
| 21 Kaizen/PDCA | postmortem improvement plan | approved improvement records | No |

**Camera/Edge Vision Agents** are station services and tools, not an undocumented increase to the 21 specialist count. Likewise Slot, Tab, Assembly and optional Sorter are **station ownership roles**, not 21 more LLMs. The default run invokes only the minimum 2–7 relevant specialists per case.

**LLM thought process contract:**

```
Authorized source events → scoped tool calls → validated results → bounded specialist proposal
→ independent cross-specialist dissent check → deterministic evidence / policy gate
→ next measurement or operator review → audit + replay manifest
```

- Every numeric measurement is produced by a calibrated measurement service or a deterministic tool, **never invented by an LLM**.
- Every material claim must cite IDs that the agent actually obtained through a permitted tool. Unsupported or conflicting claims become `ABSTAIN`/`HOLD`.
- A role cannot read arbitrary other station databases, issue shell commands, rewrite permissions, direct a servo or invent a unique specimen ID.
- Request denial and provider failure are explicit; models have max rounds, tool-call budgets, timeout and token/cost limits.
- A Chief Engineer orchestrator is available as a **centralized comparative baseline**, not the final decentralized authority.
- The dataset split and comparison must reveal whether LLM specialists help at all beyond a deterministic baseline and explain added latency/cost.

---

## 7. 3D print, caliper, camera, physical sorting — one test bench

### 7.1 Mechanical configuration from original QualityRelay 5.0

- Slot width `W` with educational local limits 20.5–21.5 mm; Tab thickness `T` with local limits 19.5–20.5 mm.
- Functional clearance `C = W - T`; educational minimum `C_min = 0.5 mm`.
- **Counterexample:** W=20.5 mm, T=20.5 mm gives 0.0 mm clearance even though both components individually pass their local specifications. Geometric numbers are assumptions for the print demo, not factory certification.
- Manufacturing mean shifts (e.g. -0.100/+0.100 mm) are proposed simulation scenarios and may be below the reliable detection ability of the physical setup; calibrate gauge repeatability before selecting physical targets.

### 7.2 Proposed specimen batch

**Minimum practical:** 3–6 marked Slot/Tab pairs, with safe nominal, tight/assembly-risk and obvious visible defect examples. Print backups. **Stretch:** 50 Slot + 50 Tab from v12 for a meaningful matching/inspection benchmark, *only if print and validation capacity allow*. Quantity alone is not research quality.

Prepare part ID labels, print batch, intended CAD dimension and revision, manual caliper record, top/side phone photo, independent Pi photo and a blinded defect label. Keep physical/printed values separate from model-predicted values. Ensure the same specimen retains the same ID across all sources.

### 7.3 Physical sorting acceptance

States and counts MUST be separate:

- `inspected_unique`: unique parts with completed inspection review;
- `confirmed_defective`: unique parts with manually verified defect disposition;
- `physically_rejected`: unique parts whose arrival in a REJECT tray was verified by an independent sensor;
- `held_for_review`: unique parts waiting for evidence, not scrap.

Only physical arrival acknowledgement increments a physical tray count. The servo's motion itself does not prove successful delivery. The SORTER is P1/stretch; the two-camera scientific experiment is P0.

---

## 8. Scientific experimental design — stronger than a two-camera sales demo

### 8.1 Preregister the questions before seeing final labels

- **RQ1 — visual complementarity:** Which visible defect classes are detected by phone-only vs Pi-only, across controlled lighting, pose and part batches?
- **RQ2 — dissent:** Does preserving an outvoted station's `SUSPECT` evidence reduce false PASS versus majority or confidence-weighted voting, and at what HOLD cost?
- **RQ3 — real decision value:** Can V-DER/CAIR lower *measured expected misclassification cost + inspection delay* versus classical information gain or fixed inspection order? Report null results honestly.
- **RQ4 — independence:** Is any performance gain from better camera viewpoint, stronger model, more evidence, or truly decentralized coordination? Use ablations that keep sensors and inference fixed.
- **RQ5 — resilience:** Does a Pi disconnect cause visible partial coverage and safe continuity, while reconnect replay produces zero duplicate counters?
- **RQ6 — specialists:** Does routing to 2–7 specialist tool-users improve validated fault identification over the exact same deterministic statistical core and a single LLM, accounting for extra token/latency cost?

### 8.2 Fair benchmark arms

| ID | Measurement and sensor policy | Agent/comms policy | Main ablation |
|---|---|---|---|
| B0 | digital caliper + deterministic assembly threshold | no AI | physical truth/standard QC |
| B1 | phone visual only | same fixed rules | phone contribution |
| B2 | Pi visual only | same fixed rules | Pi contribution |
| B3 | phone + Pi | naive average/vote | naive fusion risk |
| B4 | phone + Pi | **conservative rules-only HOLD** | isolate benefit from simple fail-safe rules |
| B5 | phone + Pi + verified caliper | single LLM + same tools | single-model baseline |
| B6 | same evidence and tools | central Chief Engineer multi-agent | orchestration baseline |
| B7 | same evidence and tools | decentralized specialist peers | collective benefit |
| B8 | same as B7 | decentralized + V-DER/CAIR | decision-aware routing gain |
| B9 | same as B8 | dropout/reconnect experiment | resilience |
| B10 | same as B8 | provenance/dissent protection ablated | source integrity contribution |

**Core fairness rules:** same defect scenarios, part IDs, model weights where the ablation is about topology, seeds, inspection budget, action costs, latency accounting, image capture setting and labeling procedure. Centralized raw-data baseline should be treated as an information-access upper-bound where it has more permissible evidence; do not manufacture an unfair disadvantage for it.

### 8.3 Primary and secondary metrics

**Primary (choose one before running):**

- `Unsafe false-PASS rate = unsafe physically verified cases with automated PASS recommendation / all unsafe labeled cases`, with confidence interval. When there are zero unsafe cases, this rate is undefined—not 0%.
- Or `expected cost per inspected case` using a **predeclared** false PASS / false HOLD / measurement / delay cost matrix. Estimate paired differences with bootstrap clustered by specimen/print batch.

**Secondary:** sensitivity/recall per defect, specificity, precision (report class base rate), balanced accuracy, false-HOLD rate, selective coverage vs risk curves, Brier score/ECE *only after calibrated probabilities exist*, camera agreement/Cohen κ, number of additional measurements, latency p50/p95, byte/message overhead, denied reads, replay duplicates, fraction of cases with independent peer coverage, physical bin counting mismatch.

A visually suspicious image **must not be labeled ground truth by its own model**. Use independently measured/mechanically designed defect labels, blinded manual inspectors and adjudication. Report number of specimens vs number of independent defect mechanisms; 100 photos from five parts are not 100 independent units. Avoid data leakage by splitting by **part/batch/design and acquisition session**, not random frames.

### 8.4 Negative tests every reviewer should see

1. Phone says clear, Pi says suspect ⇒ HOLD and dissent preserved.
2. Phone says suspect, Pi says clear ⇒ HOLD.
3. Both say clear, caliper shows bad clearance ⇒ HOLD.
4. Pi goes offline ⇒ phone measurement saved locally, joint review HOLD, no fake Pi event.
5. One photo copied into both sources ⇒ independence violation.
6. A forged/modified event HMAC ⇒ rejected.
7. Same `capture_id` retried ⇒ no double count; changed photo under same ID ⇒ 409 collision.
8. OCR uncertain decimal or unit ⇒ manual re-read required.
9. Poor lighting/pose ⇒ ABSTAIN + capture again; not false clear.
10. LLM asks to move servo or read ungranted source ⇒ denied and logged.
11. Two sources use correlated artifacts from same scene ⇒ quantify sensitivity to correlation, do not overstate certainty.
12. Human-approved sorter command without arrival acknowledgement ⇒ not counted as physically sorted.

### 8.5 Before the team claims scientific success

- Freeze hypothesis, dataset version, image/model IDs, weights, experimental conditions and costs before evaluation.
- Run each registered comparison and export all runs, including failures and abstentions.
- Compute confidence intervals on a held-out physical sample and distinguish from synthetic runs.
- Record baseline improvements in absolute terms with uncertainty (and adverse changes) rather than cherry-picking the largest percent.
- Do not claim factory-ready use from an independent machine-shop measurement report alone. Real pilot requires site-specific validation, change management and operator acceptance.

---

## 9. Full team allocation — 3 people + optional 4th

| Owner | GitHub | Scope and deliverable | Explicit exclusion |
|---|---|---|---|
| **Bakdaulet** | `Bakdaulet-omeraiuly` | Scientific lead; physical/synthetic dataset protocol; Data Science, V-DER/CAIR/Calibration studies, Nvidia GPU experiments for visual models, statistical baseline tables, reproducing test results | **NO Google Cloud setup or administration** |
| **adilnurgg** | `adilnurgg` | Platform/backend lead; Nebius LLM tool calling; separate station FastAPI services, signed evidence, node auth, peer exchange, sorter approval policy, CI, **Google Cloud backend hosting/security** | Does not certify physical metrology |
| **HyorinmaruK** | `HyorinmaruK` | **Mechanical engineer + physical validation and final presentation**; CAD/3D printing, caliper gauge protocol, two camera stands/lighting and Pi hardware setup, physical sorter if feasible, camera ground-truth labeling, UX, **Google Cloud site/deployment**, all pitch slides and demo choreography | Must not claim validation absent measured results |
| **4th person if added** | TBD | Independent QA; blind labeling, adversarial tests, Hailo compatibility, documentation, reproducibility and real-world integration | Cannot replace three owners' P0 delivery |

### 9.1 Concrete branches, PR ownership and acceptance

- Bakdaulet: `feature/science-vision-benchmark` → `experiments/`, model evaluation report, visual dataset registry, uncertainty report and preregistered comparison plots. Tests: same input/seed/revision reproduces core results; data leakage checks; physical/synthetic strata separated.
- adilnurgg: `feature/dual-vision-backend` → `/src/dualvision/`, integration with `/agent_runtime/`, network ACL, event validation, secure connection plan, Nebius adapter, **GCP backend**. Tests: stale/forged/duplicate event cannot PASS, offline is safe, no LLM servo command.
- HyorinmaruK: `feature/physical-validation-and-ui` → `/web/`, CAD/STL/mounting, calibration sheet, physical dataset and presentation; Raspberry Pi Hailo integration; **GCP frontend deployment**. Tests: real camera uploads, stable specimen IDs, gauge repeatability documented, validation report and slide screenshots evidence-grounded.
- Optional 4th: `feature/qa-peer-review` → tests, independent blind labels, system/camera calibration challenge, manifest/hardware checklist.

**Review ownership:** one owner writes, another approves code, the third verifies the live demo. Scientific metrics require a peer signoff from somebody other than their author; physical claims need HyorinmaruK's written measurement report.

### 9.2 Freeze order (P0/P1/P2)

- **P0 must work:** one phone photo, one independent Pi photo (or clearly labeled emulator while awaiting hardware); own SQLite stores and IDs; caliper dimensions; joint HOLD on disagreement/offline; 21 role registry/selected tools; dashboard with traceable audit; 3D physical safe vs risky case.
- **P1 only after P0:** Hailo-8L actual inference, NVIDIA-trained vision model on held-out photos, Nebius live API, optional servo sorter and arrival sensor, CAIR/V-DER measured routing improvements.
- **P2 future:** real supplier integration, CMM industrial connector, federated training, industrial safety certification, machine-control actuation and large-scale datasets.

**Cut scope, not honesty:** if Pi unavailable, stage two independently captured camera devices *if available* and identify them accurately. If only one phone exists, demo a one-camera case plus simulated/offline Pi and explicitly state that hardware decentralization was not demonstrated. If physical sorter not built, demonstrate an advisory dashboard, not a fake moving servo.

---

## 10. Start and test the runnable reference files

**Prerequisites:** Python 3.10+, separate environment, OpenCV, FastAPI, NumPy. Existing prior v14.2 package remains archived and has a different start command. Current 15.0 API is a **standalone dual-camera reference**, not a full built/hosted production site.

```bash
unzip QualityRelay_15_DUAL_CAMERA_COMPLETE.zip
cd QualityRelay_15_FINAL
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
PYTHONPATH=src python -m pytest -q tests
```

Generate **three unique secrets and two operator tokens**. Save them in a private `.env` (not GitHub). For each OS terminal, export just the relevant variables; the examples below use placeholders and must be replaced:

```bash
# Terminal A: PHONE node (standalone process and phone.sqlite)
export PYTHONPATH=src QR_STATION_ID=phone_vision QR_STATION_DB=./data/phone.sqlite
export QR_STATION_SECRET='<unique-phone-HMAC-secret>'
export QR_STATION_OPERATOR_TOKEN='<unique-phone-operator-token>'
python -m dualvision.run_station --port 8101

# Terminal B: PI node (normally a separate Raspberry Pi, with pi.sqlite)
export PYTHONPATH=src QR_STATION_ID=pi_edge_vision QR_STATION_DB=./data/pi.sqlite
export QR_STATION_SECRET='<unique-Pi-HMAC-secret>'
export QR_STATION_OPERATOR_TOKEN='<unique-Pi-operator-token>'
python -m dualvision.run_station --port 8102
```

From the Pi after producing a camera picture with `rpicam-still` (actual command/driver may vary with installed OS):

```bash
rpicam-still -o part_sample.jpg
export PYTHONPATH=src QR_PI_NODE_URL='http://127.0.0.1:8102'
export QR_PI_OPERATOR_TOKEN='<unique-Pi-operator-token>'
python -m dualvision.pi_capture --sample part_sample.jpg --golden golden.jpg --specimen tab-B12
```

For a manual signed peer review (read-only):

```bash
export PYTHONPATH=src
export QR_PHONE_NODE_URL='http://127.0.0.1:8101'
export QR_PI_NODE_URL='http://127.0.0.1:8102'
export QR_PHONE_OPERATOR_TOKEN='<phone-operator-token>'
export QR_PI_OPERATOR_TOKEN='<Pi-operator-token>'
export QR_PHONE_STATION_SECRET='<phone-HMAC-secret>'
export QR_PI_STATION_SECRET='<Pi-HMAC-secret>'
python -m dualvision.review_cli --specimen tab-B12
# Will HOLD unless additional separately verified metrology and assembly evidence exists.
```

For a **fixture-only** reducer illustration:

```bash
PYTHONPATH=src python -m dualvision.demo
```

**Do not call fixture results physical observations.** The fixture code uses constructed signed events to exercise policy branches. The separate station test in pytest verifies actual image data decoding and independent database behavior, but not camera optics or Hailo inference.

The optional `web/dual_camera.html` is for a restricted operator demo, not a public app. Live phone webcam `getUserMedia` needs HTTPS or localhost secure context. `file` capture input may permit direct photo selection on mobile, but cross-origin calls to two independent local stations need a secured same-origin proxy/CORS setup and operator authorization. Never embed production operator tokens or HMAC secrets in web JavaScript. A production unified site is a future P1/GCP deployment task owned by adilnurgg and HyorinmaruK.

### 10.1 How this connects to original 14.2 agent runtime

Install the original 14.2 code in its preserved folder; call `dualvision.agent_bridge.to_agent_view()` **only after each source has passed signature checks**. It creates ordinary `VISION` source objects for v14.2 `run_agent()` tools. It does not grant new raw-image or database access. After the LLM produces candidate hypotheses, the final independent reducer is **`dualvision.reconcile.decide()`**, not a majority vote or the older single-camera gate.

Every integration PR must test the full chain:

`station event → signature verification → authorized evidence bridge → specialist tool calls → PACE review → deterministic dual-camera decision → human review → append-only audit.`

**Never allow an older `PASS_REVIEW` result to short-circuit newer two-camera checks.**

---

## 11. Sponsor access / expiration / security checklist

Sources from the two **user-provided official ScienceClaw PDFs**:

- *ScienceClaw Compute*, page 4: Brev $150 per member, 5 onsite Dell GB10 units, supported NVIDIA frameworks, Brev coupon unique to registered email.
- Page 6: Claude Console $100/member; one-time event link is restricted; do not leak it.
- Page 8: Nebius Scientific AI Platform, one team request, hosted scientific skills and 10GB S3; team API key secret.
- Page 9: **16 H100 GPUs shared** across hackathon teams, possible queue / no per-team reservation; be considerate.
- Page 11: Google AI Studio plus GCP two temporary accounts **maximum per team** and Sunday auto-delete; only adilnurgg and HyorinmaruK own GCP work.
- Page 13: OpenAI API $50 credit tied to event registration, not a personal ChatGPT subscription.
- *Hardware Summary*, page 1: limited Pi + Hailo, Pi cameras, ESP32-S3 (including camera boards), ELEGOO, breadboard/jumper pool; first-come first-served.

**External documentation and scientific source checks** (official URLs; verify exact versions during installation):

1. Raspberry Pi AI / Hailo setup: https://www.raspberrypi.com/documentation/computers/ai.html
2. Raspberry Pi AI HAT / model limitations: https://www.raspberrypi.com/documentation/accessories/ai-hat-plus.html
3. Hailo Model Zoo (v2 branch for Hailo-8/8L): https://github.com/hailo-ai/hailo_model_zoo
4. NVIDIA TAO Visual ChangeNet: https://docs.nvidia.com/tao/tao-toolkit/latest/text/getting_started.html
5. NVIDIA Brev quickstart: https://docs.nvidia.com/brev/getting-started/quickstart
6. Nebius Token Factory API: https://api.tokenfactory.nebius.com/docs
7. MDN getUserMedia security: https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia
8. Roth et al., CVPR 2022, PatchCore: https://openaccess.thecvf.com/content/CVPR2022/html/Roth_Towards_Total_Recall_in_Industrial_Anomaly_Detection_CVPR_2022_paper.html
9. Batzner et al., WACV 2024, EfficientAD: https://openaccess.thecvf.com/content/WACV2024/html/Batzner_EfficientAD_Accurate_Visual_Anomaly_Detection_at_Millisecond-Level_Latencies_WACV_2024_paper.html
10. MVTec AD dataset, research-only/CC BY-NC-SA: https://www.mvtec.com/research-teaching/datasets/mvtec-ad

The official source information above supports **platform capabilities, model research, resource restrictions and broad method choice**, not proof of performance on our printed parts. Do not redistribute copyrighted research PDFs or non-commercial datasets as if they were ours.

---

## 12. Acceptance gates — objective, falsifiable, reviewer-ready

**P0 (must all hold):**

- [ ] 3D printed Slot/Tab specimens have unique physical labels, physical caliper records and a known design revision.
- [ ] Phone and physical Pi each capture **their own** part photo with timestamps; the second station is not a simulated duplicate when claiming dual camera validation.
- [ ] Two independent station databases and node-specific keys exist; raw images do not need to be shared centrally.
- [ ] Under disagreement, offline, stale, poor lighting or copied image, joint status is HOLD.
- [ ] `PASS_REVIEW` is never shown as automatically released PASS.
- [ ] Video-frame duplication does not inflate physical counts; an actual arrival sensor is required for any claimed physical routing.
- [ ] 21 role contracts remain, but only invoked roles and actual tools are represented as active.
- [ ] No raw unapproved CAD/supplier images leave their authorized station boundary.
- [ ] Demo UI displays clear `NVIDIA model loaded / not loaded`, `Pi Hailo inference / CPU baseline`, `Nebius live / mock`, `physical / simulated` flags.
- [ ] Fair baseline run with at least one clear, one visual-only suspect and one dimension-only failure; save failure cases.
- [ ] Team runs full current test suite and the archived 14.2 suite from their own environment. A test pass is not an industrial validation certificate.
- [ ] HyorinmaruK's mechanical signoff, Bakdaulet's scientific verification, and adilnurgg's integration review are explicitly recorded.

**P1 (only if P0 stable):** validated NVIDIA model, real Hailo HEF inference, real Nebius tool-calling session, physically verified sorter and seeded controlled benchmark with confidence intervals.

**P2:** manufacturer pilot, controlled data agreements, external safety review, regulatory/process approval where applicable, secure multi-node monitoring, privacy impact and model drift monitoring.

### 12.1 Pitch claim to use only after a successful physical test

> “We built a prototype where a phone and a separate Raspberry Pi inspect the same 3D-printed component from their own camera sources. Their independently logged evidence is reconciled with verified caliper/assembly data and with bounded specialist AI tool calls. When they disagree, the platform preserves the dissent and requests another inspection instead of inventing a confident release decision. We compare this against phone-only, Pi-only, conservative fixed-rule and centralized baselines on preregistered scenarios.”

Fill measured results only after experiment and include uncertainty, abstentions, and observed failure cases. No “world-first”, “scientific discovery confirmed” or “factory ready” claim without new evidence.

---

## 13. Historical scientific continuity and source preservation

| Version | Preserved research/engineering theme | How 15.0 uses it |
|---|---|---|
| 5.0 | Slot/Tab/Assembly agents; clearance, truncated Monte Carlo, EWMA, Bayesian hypotheses, information gain, secure station scopes | physical problem and deterministic measurement/science core |
| 6.0–7.1 | Design/Process/Quality/Assembly specialists, Chief Engineer experimental coordinator | bounded 21-role registry, centralized comparison arm |
| 8.0 | EVIDENCE-MESH, dissent/minority protection, evidence debt | immutable two-camera source IDs; strict disagreement HOLD |
| 9.0 | V-DER, up-to-10,000-paper retrieval **program**, synthetic comparison | decision-aware inspection hypothesis; not a proven new law |
| 10.0 | reference API/tools and scientific platform blueprint | integration baseline |
| 11.0 | independence of authority and discontinuous connectivity | separate station apps/databases, offline test |
| 12.0 | 21 specialists, optional Sorter and physically confirmed counters | non-actuating PASS/HOLD/reject-review and future servo pathway |
| 13.0 | PACE, provenance, conflict/abstention safety | independent deterministic decision checks |
| 13.1 | CAIR, Vision + calibrated metrology | second-camera acquisition and follow-up inspection questions |
| 14.0 | owned smartphone, NVIDIA vision, Nebius reasoning | provider responsibilities + phone capture |
| 14.2 | 21 bounded LLM role contracts, tool-calling, 65 inherited reference tests | archived original package + verified visual agent bridge |
| **15.0** | **separate phone and Hailo-8L Pi cameras; two signed node evidence streams; cross-modal disagreements** | new code, tests and scientific protocol |

The ZIP retains the original 14.2 source package **byte-for-byte** and directly retains the original QualityRelay 5.0 ZIP, with SHA-256 manifest. The full 14.2 Master Blueprint is appended below to this document for convenient reading, but the historical Python files remain unchanged under `archive/`.

---

# APPENDIX A — ORIGINAL QUALITYRELAY 14.2 MASTER BLUEPRINT (UNCHANGED TEXT)

The following archival section is copied from the previous team's Master Blueprint. In conflicts, **the v15.0 P0 dual-camera constraints and stricter safety gate take precedence**. The earlier architecture and scientific rationale are preserved for traceability.

# QUALITYRELAY 14.2 — EVIDENCE-GROUNDED ENGINEERING AGENTS

**Master Implementation Blueprint | ScienceClaw / Manufacturing & Materials | 2026-10-30**

> **Project thesis.** A useful manufacturing AI agent is not a talking persona. It is a scoped decision-support actor that can request authenticated evidence, call verified engineering tools, identify when it cannot establish a fact, preserve dissent across sensor modalities, and provide an auditable recommendation. Physical PASS/REJECT and sorter actuation remain outside model authority.

**Change policy:** QualityRelay 14.2 is an additive agent-intelligence upgrade to QualityRelay 14.0. The exact 14.0 ZIP is preserved in `reference_14/QualityRelay_14_COMPLETE_ORIGINAL.zip`; original 5.0/8.0/9.0/10.0/12.0/13.1 materials remain inside that original archive. The 21 specialist roles and the primary decentralized four-station topology remain. No prior scientific claims are retroactively upgraded to validated findings.

## Executive verdict: what is and is not built

| Component | This package contains | Not yet established |
|---|---|---|
| 21 specialist roles | Server-side capability/role registry with source restrictions and tool grants | 21 separately trained model weights, 21 validated engineering experts |
| Model brain | Nebius Token Factory OpenAI-compatible model adapter; complete bounded function-call loop; scripted offline substitute | Successful paid live Nebius call, actual model benchmark, tokens/prices under this team's credential |
| Engineering tools | `read_evidence`, `check_clearance`, `check_visual`, `request_inspection` with strict argument schemas, evidence IDs and permission checks | CAD/FEA/CMM/MES connectors for real plants |
| Evidence mesh | HMAC-authenticated, scoped summaries between isolated in-memory station objects; de-duplication and offline negative tests | Distributed cloud machines, production PKI, mTLS, durable message broker |
| Safety decision | Independent deterministic `HOLD / PASS_REVIEW` gate and physical/simulated distinction; **no** LLM actuation | Autonomous factory certification, calibrated failure probabilities |
| One web UI | Phone Vision + Caliper OCR + source-aware agent test on same FastAPI app | Finished UX, tested mobile deployment, production camera calibration |
| Scientific evaluation | Protocol, baselines, ablations, challenge sets, 38 passing offline reference tests | Comparative result showing specialist collaboration improves quality on physical factory samples |

**Important:** The package strengthens the architecture and implements a working reference agent loop; it **does not** claim a peer-to-peer plant deployment or scientific breakthrough has already been demonstrated.

---

## 1. Exact product demonstration

Factory example: print a U-slot and flat tab in several size variants. Assign unique specimen IDs and record the CAD revision. One team's phone has two modes: **Caliper LCD OCR** and **Surface defect photo**. The digital caliper is still the dimensional measuring instrument. An OCR reading must be operator-confirmed and bound to an immutable event ID. An NVIDIA-trained or classical CV model may classify **visible** defects; it cannot infer 0.1 mm feature accuracy or internal flaws from an uncalibrated photo.

1. **Slot local node** owns Slot width measurements and the associated gauge/source metadata.
2. **Tab local node** owns Tab thickness, actual 3D-print metadata and measurements.
3. **Visual evidence node** owns phone image observations and model/version/threshold metadata (can be separated from the quality node to prove agency).
4. **Assembly node** requests *approved summaries*, never SQL access to every upstream database.
5. **Sorter node** receives an authorized instruction from the deterministic controller **after** human approval; it never accepts arbitrary model text or raw LLM commands.
6. **Specialist agents** are selectively spawned. Metrology looks at verification status, Quality Inspector checks multi-sensor risk, Additive Manufacturing assesses plausible print failure, Assembly checks pair clearance, Inspection Planner proposes another test, Audit records integrity.

**Illustrative conflict:** width 21.0 mm and thickness 20.0 mm clear the 0.5 mm educational assembly threshold, but the Vision Agent notices a possible visible crack. Result is `HOLD` until an independent test resolves the concern. Caliper passing does not silence Vision; camera passing does not override insufficient clearance. A model's majority vote cannot release the specimen.

This is the demonstration **target**; only the offline script with *simulated* evidence is runnable from this package without live hardware.

## 2. Architecture — one website, decentralized authority

```mermaid
flowchart TB
    Phone[Phone camera: LCD OCR / defect photo]
    Slot[(Slot Station + own data)]
    Tab[(Tab Station + own data)]
    Vision[(Visual Evidence Station + own data)]
    Assembly[(Assembly Station + own data)]
    Sorter[(Sorter Station: proposed route, optional servo)]
    UI[One QualityRelay HTTPS web application]
    Role[21 specialized role contracts / selective routing]
    LLM[Nebius Token Factory model API]
    Math[Deterministic Bayesian / tolerance / CAIR / policy tools]
    Human[Engineer sign-off]
    Phone --> Vision
    Phone --> Slot
    Phone --> Tab
    Slot <-->|Scoped signed summary| Assembly
    Tab <-->|Scoped signed summary| Assembly
    Vision <-->|Scoped signed summary| Assembly
    Assembly <-->|Evidence requests / opinions| Role
    Role <-->|Tool-calling| LLM
    Role --> Math
    Assembly --> UI
    UI --> Human
    Human -->|Authorized action only| Sorter
```

**Clarification:** one web application is an operator UI. It does not need to be the central source of raw production truth. A single shared inference API is not automatically a centralized decision authority. Conversely, running four Python classes in one process is **not** proof of operational decentralization. The reference code models separate station stores and permissions locally; separate deployments, fault injection and network tests are required before claiming a true peer system.

### 2.1 Default collective mechanism: selective and accountable

- The **router** picks a small subset of the 21 roles by incident type and available evidence; its choices and token budget are logged.
- **Roles are not independent votes.** Several role outputs citing the same sensor event constitute ONE evidence root.
- A role may request additional evidence from a different station only if the station server grants the requested kind/scope.
- LLM may propose an action from an allowlist and must attach an ID for every cited observation.
- A deterministic policy decides `HOLD` or `PASS_REVIEW`. Only a human authorizer can enact a physical disposition.
- **Chief Engineer** is preserved as an optional baseline: router and reasoning coordinator only, without superuser raw-data access. If the coordinator fails, local stations retain their own monitoring and the primary peer evidence exchange remains possible.

### 2.2 Limits that are not negotiable

Never grant an LLM: unrestricted shell/SQL, direct motor control, arbitrary network fetch, cross-supplier database reads, manufacturing release or certified safety authority. Protect model keys on the backend. Do not equate free-form model confidence with a calibrated probability. Deny unverified evidence or ambiguous visual observations; report uncertainties explicitly.

---

## 3. How the LLM "brain" actually works

The same actual LLM endpoint may serve multiple roles, but each is a **separate model session** with a verified role identity, domain-specific prompt, approved source IDs, and backend-enforced tool grants.

```text
Incident created
    ↓
Role Router chooses Metrology + Quality + Assembly (+ Vision-related expert)
    ↓
Per-role LLM sees only exact authorized event IDs (not every raw station file)
    ↓
LLM returns: tool_call(name='read_evidence', args={'event_id':'...'})
    ↓
Tool Gateway checks: role, source scope, specimen ID, allowed tool,
                     schema, call budget, freshness & event origin
    ↓
Local tool returns the authenticated summary / numeric result, with source IDs
    ↓
LLM returns strictly structured preliminary proposal + real evidence IDs
    ↓
Provenance & conflict checks reject invented citations and duplicated opinions
    ↓
Separate deterministic Safety Gate recomputes relevant facts
    ↓
PASS_REVIEW (human must approve), or HOLD + recommended inspection
```

**Key implementation files:**

- `agent_runtime/roles.py` — exactly 21 historical specialist names, explicit domain and tool grants, selective role routing.
- `agent_runtime/evidence.py` — distinct station-local stores, signed authorization-scoped summaries, idempotent event receipts, explicit offline behavior.
- `agent_runtime/tools.py` — allowlisted tool gateway and deterministic clearance evaluation; never runs a shell or motor.
- `agent_runtime/brain.py` — `NebiusBrain` real API adapter and `ScriptedBrain` deterministic test model.
- `agent_runtime/runtime.py` — real tool-call iteration and validated structured proposals; independent policy gate.
- `agent_runtime/reconcile.py` — source-root de-duplication and cross-modality dissent preservation.
- `agent_runtime/demo.py` — synthetic case, replayable source ids; intentionally not presented as physical data.
- `agent_runtime/api.py` — structured demo endpoints.
- `agent_runtime/unified_app.py` — same app serves existing QualityRelay 14 camera demo and new agent demonstration.
- `tests/test_agents.py` — deny tests for tool escalation, fake sources, provider outages, duplicates and unsafe release.

### 3.1 Supported tool contract (current code)

| Tool | Request | Verified output | Authority |
|---|---|---|---|
| `read_evidence` | exact event ID | redacted, station-scoped summary | read only |
| `check_clearance` | Slot + Tab metrology event IDs | deterministic nominal demo clearance + threshold | read only; **not** lot-level predicted probability |
| `check_visual` | visual event ID | image-model suspicion + `visual_usable` as stored | read only; **not** image inference itself |
| `request_inspection` | allowlisted action + known specimen ID | proposed manual check / another photo | no actuation |

**Near-term tools to add with real instrument/CAD integrations** (not implemented here): `get_cad_revision`, `read_gauge_calibration`, `summarize_print_settings`, `run_probabilistic_lot_fit`, `propose_next_measurement_evsi`, `fetch_authorized_peer_summary`, `compare_change_net_defects`, `get_signed_inspection_approval`, `request_sorter_route_after_approval`. Each must have typed request/response, provenance, specific node owner, unit tests and a security-deny test.

### 3.2 A real model is NOT required for the fail-safe demo

`ScriptedBrain` is a deterministic **fake** model that returns a function call then an evidence-grounded JSON review. It enables integration and security tests without spending sponsor credits. It should never be called a functioning neural model. Real Nebius only runs after a key/model entitlement is confirmed and a human explicitly enables it.

### 3.3 Exact live Nebius integration

Nebius Token Factory official compatible chat API is `https://api.tokenfactory.nebius.com/v1/`, with `GET /v1/models` and `POST /v1/chat/completions`. The `tools` parameter is model-dependent. The code checks the live model catalog and **never invents a model ID**. It follows the function-call sequence (`assistant` tool calls, per-call tool-result message, next inference) with a hard ceiling on rounds and tool requests.

Run on an internet-connected developer Mac only after checking allowed credits and pricing:

```bash
cd QualityRelay_14_2_AGENT_INTELLIGENCE
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
# export NEBIUS_API_KEY from the team's authorized console (never commit)
export NEBIUS_MODEL='<exact model id from your team key /v1/models>'
export ALLOW_LIVE_NEBIUS_REVIEW=YES
python -m agent_runtime.live_review
```

**No real credentials or paid calls were exercised while creating this package.** Nebius Scientific AI Platform, the event-wide shared H100 allocation, and Token Factory are distinct resources. Access to one does not guarantee entitlement to the others. Only team-authorized credentials can establish actual availability.

### 3.4 NVIDIA: model *eyes*, not engineering arithmetic

NVIDIA Brev or Nebius H100 can be used to train/fine-tune/freeze Visual ChangeNet or a suitable anomaly detector **after** labeled photos and a specimen-grouped split exist. Use a simple OpenCV reference baseline and optionally PatchCore/EfficientAD first. A NVIDIA or Nebius vision model creates a *visual evidence event*; it does not update a caliper measurement or command the servo. Save exact model version/hash, thresholds, camera geometry, lighting, training set, photo hash and uncertainty label.

**Credit-efficient routing:** On incidents with no relevant imagery, do not run a vision model; on simple numeric checks, use the deterministic tool before paying for an LLM; request two or four specialist reviews by default and only expand to eight or 21 for pre-registered research ablations.

---

## 4. Every specialist is a real contract, not an imaginary trained worker

The role list below is the historical 21-role registry kept from QualityRelay 12/14. Each role has a clear **stop/abstention condition**. The implemented role-specific tool subsets are defined in `roles.py`, and the final physical action remains restricted.

| Role | Engineering responsibility | Mandatory grounding / when to abstain |
|---|---|---|
| Design Geometry | tolerance features, datum and revision mapping | CAD revision unknown → ABSTAIN |
| Tolerance Analyst | dimensional stack-ups | unknown distributions/covariances → no lot probability |
| Materials Engineer | polymer/material properties | no certificates/tests → hypothesis only |
| Process Engineer | link process excursions to outcomes | no process timestamps → not established |
| CNC Expert | machining-specific faults | no actual CNC process → N/A |
| Additive Manufacturing Expert | print layer, nozzle, warp and failure modes | image alone ≠ confirmed process cause |
| Metrology Engineer | gauge verification, uncertainty, units | OCR unconfirmed or gauge uncalibrated → HOLD |
| SPC Agent | EWMA/CUSUM on established baseline | underpowered or absent control history → ABSTAIN |
| Quality Inspector | acceptance and visual alarm reconciliation | insufficient verified evidence → HOLD |
| Assembly Engineer | functional pair clearance and candidate pairing | unknown geometry/lot link → HOLD |
| Causal Diagnosis | propose differentiating tests | correlation alone ≠ causality |
| Bayesian Statistician | prior/likelihood/posterior and sensitivity | no calibrated prior → no numeric posterior |
| Inspection Planner | IG/EVSI/CAIR candidates | no observation model → safe heuristic with label |
| Operations Research | feasible pairing under constraints | unclear feasible set → do not suggest release |
| Maintenance Engineer | machine maintenance / wear | no maintenance logs → N/A |
| Supplier Boundary | supplier-scoped summary and consent | missing agreements/authorization → deny |
| Safety/Governance | veto and approve policy *recommendations* | cannot self-authorize irreversible action |
| Privacy/Security | privilege violations, data leakage | never silently share raw supplier records |
| Reliability/Network | stale messages, offline/replay metrics | missing station → partial evidence, not PASS |
| Scientific Auditor | run manifest, result provenance and bias checks | no independent data → no performance claim |
| Kaizen/PDCA | controlled improvement experiments | no before/after control → proposal only |

**Capability maturity:** All 21 now have enforceable registry scopes and may run through the common tool-call loop, but many will **abstain** because their specialized live tools and data do not yet exist. They are not 21 trained or validated autonomous engineers. The scientific advantage comes from unique evidence and tools, not artificially varying the prompt of a single model.

---

## 5. Source-aware decision protocol: V-DER × CAIR × PACE × EVIDENCE-MESH

### 5.1 Provenance representation

Every sensor observation must have:

```json
{
  "event_id":"slot-evt-001", "specimen_id":"SLOT-A03",
  "kind":"METROLOGY", "origin_station":"slot",
  "observed_at":"2026-10-30T18:00:00+00:00",
  "origin":"physical", "source_event_ids":[],
  "payload":{"width_mm":"20.6","unit":"mm","caliper_verified":true,"gauge_id":"G-01"}
}
```

Fields in `payload` are measurement statements only if the instrument/operator actually supplied them. `origin="simulated"` is required for generated examples. Peer messages contain HMAC-authenticated **redacted summaries**; demonstration HMAC keys are not substitutes for factory PKI/mTLS. A derived result must cite root `source_event_ids`; copies cannot be counted as independent evidence.

### 5.2 Evidence debt and dissent

**Evidence debt** records which conditions of a decision remain unsupported: `missing_gauge_confirmation`, `missing_visual_observation`, `expired_peer_summary`, `unverified_CAD_revision`, `missing_route_ack` etc. A certified action cannot be inferred merely because models agree.

**Dissent preservation** means one actual camera observation of a possible crack is not voted down by four persona agents citing the same nominal caliper event. Reliability weights should be grounded in sensor calibration, validation and source lineage, **not arbitrary LLM self-confidence**. The reference `independence_report` counts citation roots and flags cross-modal conflicts; it is not yet a calibrated Bayesian causal fusion model.

### 5.3 Decision-aware next measurement

The scientific target is **expected reduction of downstream decision loss per cost**, constrained by valid measurement models and policy. Let hypotheses be H, evidence E, available actions a and feasible dispositions d. Prefer next observation a that minimizes expected loss after the observation plus its acquisition cost:

\[
 a^* = \arg\min_a \left[c(a) + \mathbb{E}_{y \sim p(y\mid a,E)} \min_d \mathbb{E}_{H \sim p(H\mid E,y,a)} L(d,H)\right].
\]

Compare against conventional expected information gain (entropy reduction), random inspection, fixed inspection schedules and a full-information central benchmark. This is **a research synthesis of established VOI/decision-theory methods**. No claim of a universally novel mathematical theorem or superiority is made. Compute numeric utility ONLY when observation likelihoods and costs have been pre-specified and checked; otherwise use a transparently labeled fixed safe triage rule.

### 5.4 Current deterministic PACE review gate

`HOLD` whenever calibrated facts are missing, evidence is stale or simulated, camera indicates possible visible defect, dimensional pair clearance is insufficient, local demo dimensions fail, evidence ID is conflicting, or a model claims final release authority. `PASS_REVIEW` only means *eligible for an engineer's independent approval*, not machine authorization. Servo physically routes parts only after a separately authenticated, nonce+TTL-protected approval and arrival sensor acknowledgment (optional future hardware milestone).

---

## 6. Scientific questions with falsifiable tests

A **good research result can be negative**. Do not optimize a benchmark only to force multi-agent victory.

| ID | Hypothesis | Intervention / control | Primary outcome | Scientific failure that must be reported |
|---|---|---|---|---|
| H1 | Evidence-grounded specialist collaboration reduces unsupported conclusions | same provider & tokens: 1 generalist vs 4 specialists with same unique sources | unsupported claim rate; correct fault-source accuracy | no change or more hallucination |
| H2 | Different *sensor* evidence improves defect decisions | dimensions-only vs vision-only vs fused | unsafe release/false negative rate at matched hold cost | vision adds noise and worsens decisions |
| H3 | A dissent-preserving ledger prevents incorrect override by repetitive agents | no provenance dedup vs root dedup + minority hold | critical evidence suppression frequency | no improvement or increased false alarms |
| H4 | Decision-aware inspection reduces cost | IG vs decision VOI vs fixed vs random with same validated observation model | total measured inspection cost and expected decision loss | no improvement to IG (as earlier toy tests suggested) |
| H5 | Decentralized nodes tolerate partial outage | all-online, slot-offline, vision-offline, coordinator-offline | local continuity, fail-closed rate, event reconciliation | data lost or stale accepted |
| H6 | Many personas are not automatically better | 1, 4, 8, 21 roles at *equal total inference budget* | loss, latency, USD per case, evidence roots actually used | 21 agents cost more or perform worse |
| H7 | Camera OCR can be used as a bounded reading assistant | operator transcription vs OCR+confirmation vs OCR unconfirmed | exact full-reading accuracy including decimal/unit; operator time | unit/decimal mistakes exceed the threshold |

### 6.1 Experiment controls

1. Freeze specimen-ID grouped photo dataset and manufacturing batch splits before tuning. Repeated views of the same physical part must stay in the same train/test group.
2. Preregister costs, priors, camera thresholds, physical tolerances, risk weights, sample sizes and numeric success criteria. Do not derive a confidence interval from unpaired samples when tests share identical cases.
3. Run at least 3 seeds for smoke tests; statistical claims require an a priori power or precision target and enough independent cases to meet it.
4. Include **known-bad** and **known-good** parts from independent physical labels, not the AI's own score. Label ground truth by fit tests and verified optical/mechanical inspection; document ambiguity and disagreement.
5. Keep **physical vs simulation** in separate tables and never use physically unconfirmed measurements as ground truth.
6. Report risk-coverage curve: unsafe PASS among cases released vs HOLD fraction; do not maximize accuracy by holding every sample. Report latency, cost, raw data shared, provenance coverage and failed/rejected tool calls.
7. Freeze agent prompts, model IDs, temperatures, schemas, provider responses (redacted), method versions, data hashes, seed, and hardware/camera setup in `run_manifest.json`.
8. Use a matched **centralized upper-bound** with the same statistical core; central availability advantages and outage test asymmetries must be explicitly disclosed.
9. Run adversarial tests: malicious text in photo metadata, false sensor event, replay IDs, removed camera, wrong decimal OCR, wrong unit, schema overreach, invented specimen ID, raw supplier data request, LLM attempting to command servo.

### 6.2 What prior QualityRelay results actually show

The earlier V-DER experiment (3000 synthetic trials) produced near-equal conditional costs for decision-aware and IG policies; it did **not** establish a superiority claim. Our code tests are **engineering correctness tests**, not scientific validation. The new protocol is intended to find the specific conditions where combination of heterogeneous independent sensors and evidence debt changes decisions, or to report that it fails to improve them.

### 6.3 Innovation claim register

- **Known:** Bayesian value of information, entropy IG, process monitoring, visual anomaly detection, role/tool-calling, HMAC, human approval, calibrated metrology.
- **Our engineering contribution:** an implementation of provenance-grounded specialist calls + per-role permissions + dissent and cost-aware triage in a physical-demo workflow.
- **Our research hypothesis:** the integrated policy improves bounded-risk assembly decisions under distributed evidence and partial communication failures at equal budget.
- **NOT shown:** new theorem, universally better multi-agent intelligence, industrial certification, production ROI, or having read 10,000 research papers.

---

## 7. Team ownership and merge plan (3 + optional 4)

| Owner | Branch | Exact deliverables | Acceptance |
|---|---|---|---|
| **Bakdaulet-omeraiuly** | `feat/evidence-science` | scientist-owned decision loss/CAIR simulation, Bayesian baselines, actual cost estimates, experiment registration, calibration, held-out evaluations, GPU vision comparisons | all claims matched to data & CIs; model ablations run on same splits; negative results documented |
| **adilnurgg** | `feat/agent-runtime-nebius` | typed agent gateway, backend auth, real model sessions, per-station state, policy gate, HMAC now and TLS/mTLS later, unified API, event replay and cost caps | unauthorized access denied, no model-controlled hardware, deterministic replay, authenticated event logs, real API smoke test when credited |
| **HyorinmaruK (mechanical engineer)** | `feat/physical-vision-pitch` | physical 3D CAD+prints, caliper repeatability, phone fixture+lighting, defect taxonomy, independent ground truth, sorter if time, final presentation/pitch | clear IDs on all parts, repeatable real measurements, photos and uncertainty report; honest demo results |
| **4th person if added** | `feat/mobile-frontend-qa` | phone-responsive UX, camera capture, independent QA, screenshot/CI tests, observability, external test data adapter | one-site integrated smoke test and cross-browser phone checks |

**Merge rules:** contracts freeze first; one source owner per station; any API or schema change needs a sample event and two reviewers; evidence and model credentials never committed; CI runs all 14.0 and 14.2 tests. Freeze and tag a tested demo candidate, have a prerecorded labeled fallback, and keep hardware steps separate from cloud demos.

### 7.1 Working order (P0 to P2)

**P0 mandatory:** tool-call loop using `ScriptedBrain`, verified evidence summaries, role permissions, deterministic safety, original phone capture, core incident displayed on one page, tests/trace export. **P1 high value:** one live Nebius tool-using specialist with team-entitled model, second specialist using *different real evidence*, actual 3D prints and calibrated/confirmed caliper plus visible defect photo. **P2 optional:** trained NVIDIA Visual ChangeNet, multi-node cloud deployment, probabilistic EVSI calibration, ESP32 servo and independent arrival counter, 21-role equal-budget ablations.

If deadlines threaten: **cut role count and optional servo before cutting scientific provenance and physical measurement verification**.

---

## 8. How to execute the package

The safe default is the scripted *mock* brain; running it requires no GPU, credentials, network or connected servo.

```bash
cd QualityRelay_14_2_AGENT_INTELLIGENCE
python -m pytest -q tests/test_agents.py
python -m agent_runtime.demo > results/demo_run.json
```

Full combined website (uses existing v14 dependencies):

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install -r implementation/requirements.txt
PYTHONPATH=.:implementation uvicorn agent_runtime.unified_app:app --reload
# open http://127.0.0.1:8000 on the laptop
# production phone use needs HTTPS; see browser security requirements
```

The website retains `Caliper OCR`, `Surface Vision`, `Assembly Review`, `Sorter Trace (simulation)`, and adds `Engineering Agents (simulated tool-calling)`. Its role-select control does NOT silently invoke a paid provider. To run a **genuinely live** Nebius review, follow section 3.3 explicitly on the server.

Reference tests do not make manufacturing/medical/aviation safety claims. The review gate is intentionally conservative, uses educational 5.0 dimensions, and is not for production automatic reject actions.

---

## 9. Resource map — NVIDIA / Nebius / supplied ScienceClaw PDFs

The event's **ScienceClaw Compute PDF** advertises $150 NVIDIA Brev per registered participant, $100 Claude API per registered participant, one Nebius Scientific AI Platform credential set per team, shared 16× H100 Nebius GPUs with possible queues, up to two temporary Google Cloud accounts per team, plus $50 OpenAI API credit. Eligibility, availability and actual keys are **not** verified here. Use the registered email and do not share event-specific redemption links outside the event.

- **NVIDIA Brev** — use if held-out vision data exists and the group has a validated training objective (one GPU job; report billable hours).
- **Nebius Token Factory** — use for language/tool reasoning with exact model ID from the credential's `/v1/models`, bounded number of specialist calls and spend cap.
- **Nebius shared H100** — optional vision training, not a hard dependency of the physical demonstration.
- **Scientific AI Platform** — do not assume protein/chemistry models are appropriate for slot-tab QA; use only demonstrably relevant validated skills.
- **Phone camera** — sufficient for first vision evidence and LCD OCR; no separate camera hardware required. Control lighting and rigid viewpoint; do not claim unmeasured submillimeter precision.

### Primary implementation and reliability sources

- [Nebius Token Factory OpenAPI](https://api.tokenfactory.nebius.com/docs) — Chat Completions, Responses, model discovery, fine-tuning.
- [Nebius Token Factory cookbook](https://github.com/nebius/token-factory-cookbook) — current compatible client examples.
- [Nebius Beam reflection model example, October 2026](https://dev.nebius.com/cookbook/beam-reflection-token-factory) — note model-specific continuation requirements and no assumed entitlement.
- [NVIDIA NIM tool calling guide](https://docs.nvidia.com/nim/large-language-models/2.0.10/advanced-use-cases/tool-calling-and-mcp.html) — deployment-specific support and schema caution.
- [OWASP AI Agent Security](https://cheatsheetseries.owasp.org/cheatsheets/AI_Agent_Security_Cheat_Sheet.html) and [OWASP Agent and MCP security guidance](https://owasp.github.io/DevSecOpsGuideline/2-Process/2-2-Develop/2-2-5-AI-Agent-and-MCP-Security/) — strict tool authorization and human approval.
- [NIST AI RMF Generative AI Profile](https://www.nist.gov/publications/artificial-intelligence-risk-management-framework-generative-artificial-intelligence) — risk-management framework, not a certification.
- Scientific methods, historical blueprints and detailed vision references retained verbatim in the original 14.0 archive; see its own claim register and sources.

---

## 10. Acceptance gate — evidence before winning claims

- [ ] End-to-end phone image and operator-confirmed measurement bound to same specimen ID in web UI.
- [ ] Role-ACL tests block unauthorized event types, raw reads and unlisted tools.
- [ ] Real team Nebius model returned at least one *actual* structured tool call and properly handled its returned evidence (current package: **not tested live**).
- [ ] If Nebius is down the engine abstains safely and the rest of the demo remains usable.
- [ ] Original 14.0 OCR/vision/fit/sorter-demo tests remain green after changes.
- [ ] Missing/old/contradictory evidence, unknown CAD, visual anomaly → `HOLD`.
- [ ] Final disposition requires separately recorded human approval; no prompt can bypass this.
- [ ] Each agent cites actual source event IDs; duplicated derived agent opinions do not change evidence root count.
- [ ] 3D specimens have independent mechanical ground truth, print process IDs and calibrated instrument notes.
- [ ] Camera algorithm evaluated with a specimen-grouped held-out set; no test leakage.
- [ ] Baselines (single LLM, deterministic QC, central full-data, decentralized agents) use matched data, budgets and costs.
- [ ] App performs useful work if NVIDIA GPU or Nebius endpoints are unavailable.
- [ ] Any sorter run clearly distinguishes operator observation from sensor-confirmed physical routing.
- [ ] Physical and simulated results, as well as pass/hold/reject numbers, are labeled correctly.

**Deliverable threshold:** A role registry and clean diagrams are necessary but **not sufficient**. The scientific claim becomes credible only when actual diverse physical evidence improves measured decision quality or reduces validated inspection cost against pre-registered baselines; equally important, report failure to improve.

---

## APPENDIX A — Original QualityRelay 14.0 full Master Blueprint (archival text)

The full previous document is reproduced below **verbatim** for concept and scientific-history continuity; it is also preserved as a byte-unchanged original ZIP. If an old section conflicts with a newer implementation contract, the **14.2 change notes** above control the new agent module; the old source remains unchanged as evidence of design evolution.

# QUALITYRELAY 14.0 — VISION-GOVERNED EVIDENCE MESH

**Final scientific, architecture, physical-demo, NVIDIA/Nebius, and team implementation blueprint**  
**Freeze date:** 2026-10-30 · **Track:** ScienceClaw / Manufacturing & Materials  
**Owners:** Bakdaulet-omeraiuly, adilnurgg, HyorinmaruK; optional fourth contributor  
**Primary mode:** independently authorized decentralized station peers  
**What is ready in THIS release:** a Python reference decision service and tests, local vision baseline code, a browser camera capture interface, provider integration adapters and documented experimental protocols. This is a prototype package, **not** a validated production AI/robotic system. All unrun experiments are explicitly `NOT_RUN`.

> **One-sentence product:** QualityRelay connects a phone-based visual inspection, a human-operated digital caliper, four independent manufacturing stations, and a bounded network of specialist agents to identify unsafe assembly combinations, request decision-relevant evidence, and authorize traceable PASS / HOLD / CONFIRMED REJECT actions, with optional physical sorter verification.

> **Scientific claim (proposal, not result):** Evidence lineage, calibrated uncertainty, and decision-aware inspection may allow a decentralized manufacturing team to approach centralized decision quality with lower cross-station raw-data exposure and better continuity during network partitions, while avoiding unnecessary inspection. We will compare this against strong baselines, including ones that may win.

---

## 0. CHANGE CONTROL — all previous work retained

| Source | Mandatory retained decision | Status in this blueprint |
|---|---|---|
| 5.0 | Independent Slot/Tab/Assembly station ownership; local raw data; trusted scoped evidence; clearance risk, truncated accepted-part distributions, EWMA, Bayesian hypotheses, information gain, outages, exactly-once reconciliation | **Required unchanged**; original 5.0 source is appended verbatim and archived |
| 6–7 | Role-specific Design, Quality, Process, Assembly engineer agents; optional Chief Engineer coordinates but cannot bypass authority | 21-role registry retained, Chief as **comparison/hybrid**, not a secret central decisionmaker |
| 8.0 | Evidence Mesh, missing-evidence debt, protection of valid minority evidence, controlled agent-to-agent communication | Core research protocol |
| 9.0 | V-DER / decision-value hypothesis, literature-corpus collection program | Registered baseline and treatment; no unverified novelty statement |
| 10.0 | Narrow runnable backend, permissions, replay, partial evidence | Legacy reference baseline; new reference implementation is independent and smaller |
| 11–12 | **Fully decentralized primary deployment**, 21 specialists, Sorter 4th station, 50 Slot + 50 Tab target, PASS/HOLD/CONFIRMED REJECT, verified counting | Four-peer topology and sorter protocol required |
| 13.0 | PACE safety guard, lineage/de-duplication and counterexample studies | Hard gate and research checks |
| 13.1 | Visual Evidence Agent, geometry, ArUco calibration, CAIR, abstention | Phone camera **required** |
| **14.0** | NVIDIA TAO Visual ChangeNet / optional EfficientAD/PatchCore, NVIDIA Brev GPU, optional Nebius GPU, Nebius Token Factory and scientific tools where relevant, phone-based caliper LCD OCR and visible defect capture | **New integration**; provider access depends on actual credits and credentials |

**Scope correction:** The user chose their **own phone**, not an additional physical camera. The phone is the *default for both LCD OCR and appearance inspection*, sequentially. A teammate's webcam can substitute for LCD OCR; event hardware (ESP32/Raspberry Pi/servo) is **OPTIONAL P1**, never a required camera purchase. When sorter hardware is available, **servo moves only the sorting gate, never caliper jaws**.

**Do not lose sources:** The deliverable ZIP includes immutable copies of the 5.0 original, 10.0 reference package, 12.0 sorting package, and 13.1 camera research package. Older inner versions remain inside those packages. The new master is independent and does not force teams to open nested ZIPs for core build instructions.

## 1. Product and buyer

**First target:** small precision manufacturers and additive prototyping labs that operate separated metrology, machine/print, assembly and disposition workflows, where individually accepted parts may fail when paired. **First buyer/persona:** manufacturing quality engineer with authority to request reinspection, **not** a plant manager approving autonomous releases.

**Problem:** one station can only see its own verified observations; an apparently acceptable Slot and an apparently acceptable Tab can yield inadequate clearance. Camera evidence and dimensional evidence can disagree for legitimate reasons; an LLM majority vote is not a certified measurement. Repeated inspection and unjustified scrap cost labor and parts.

**Product workflows:** register lot and specimen IDs; capture phone images; read caliper display with OCR + confirmation; run local fit-risk / defect analysis; exchange scoped evidence; display contradictory assessments and missing evidence; request the next best inspection; select feasible pairings; require human approval; route/verify disposition, with measured actual results linked to the original claim.

**Non-goals:** unattended factory robot autonomy, auto-certification, industrial safety guarantee, inferring 0.1 mm tolerances from a casual phone shot, claiming unique prior-art ownership, treating 10,000 searched abstracts as read full texts, or presenting synthetic accuracy as industrial validation.

## 2. Judge-readable demo: 1 phone, 1 caliper, 3D prints

**Specimen kit:** 50 printed Slots and 50 printed Tabs is the v12 **target**; if printing capacity/time is insufficient, execute a smaller 3–10-pair demonstrator and clearly mark `DEMO_SAMPLE_SIZE`, while preserving the 100-part scientific protocol as `NOT_RUN` until complete. Print nominal, narrow-slot, thick-tab, visible print failure, and ambiguous appearance specimens. Assign unique QR/label or typed ID; keep raw geometry and final CAD revision. Include 3D fixture for stable phone height/light.

1. Operator chooses `Slot A-07`, taps `Capture caliper` on the phone website, physically measures the opening with the caliper, and aims the same phone at LCD. OCR yields *candidate*, not ground truth. Unit, stable frames, decimal point and association with ID are checked; uncertain readings go `HOLD_PENDING_CONFIRMATION`. Operator confirms or corrects reading. Caliper instrument + operator remain responsible for reading.
2. Operator chooses `Tab B-12`, repeats. Source events are append-only and marked `physical/manual_verified` (not `calibrated` unless calibration is actually documented).
3. Operator taps `Inspect surface`, points **same phone** at both components, gets guided alignment/photo quality, optional golden-reference image difference and model anomaly regions. A vision defect is *suspected*, not proven, until validated.
4. The Slot peer, Tab peer, Vision peer (as **additional independent evidence owner/worker**), Assembly peer, and Sorter peer (if activated) issue bounded event messages. The 21 *specialist roles* are invoked selectively based on evidence, not 21 expensive model calls per part.
5. Example discrepancy 1: Tab is within local tolerance but image shows suspected crack → **HOLD** pending inspection, not automatic PASS. Discrepancy 2: image appears normal but caliper shows insufficient pair clearance → **HOLD** and suggest higher information-value remeasure/pair change.
6. The decision engine computes evidence-scoped compatibility, hypotheses and best *next action*. It may say `MORE_EVIDENCE_REQUIRED` instead of inventing certainty.
7. On human-authorized `PASS`, `HOLD` or `CONFIRMED_REJECT`, the operator sorts by hand in P0. In P1, an ESP32 sends the servo to the appropriate **gate** position; an IR/beam-break or second phone view verifies physical arrival. Unverified route does not increment `physically_sorted`.
8. UI separately reports `inspected_count`, `confirmed_defective_count`, `physically_rejected_count`. An outage simulator severs one station; other services continue local measurements and mark peer data stale. Reconnect exactly once, show event hashes and audit log.
9. Side-by-side exact same specimen stream: isolated QC, centralized oracle, one general AI, decentralized peers without evidence governance, **QualityRelay**, optional hybrid Chief; compare matched accuracy, time, number and cost of inspections, raw bytes shared, unsafe-release rate, false reject, over-hold rate and outage behavior.

### 2.1 Correct count semantics

| Metric | Increment exactly when | NOT when |
|---|---|---|
| `inspected_count` | unique specimen ID has complete inspection record | frame processed, duplicate upload, incomplete inspection |
| `confirmed_defective_count` | distinct specimen disposition event is authorized and defect status validated | vision model flags anomaly, same event replay |
| `physically_rejected_count` | unique specimen routing to REJECT physically acknowledged | gate command sent, visual defect suspected, duplicate sensor pulse |
| `held_count` | unique specimen has active HOLD disposition | repeated OCR failures on same specimen |
| `unverified_sorting_count` | authorized route lacking ack or unexpected bin | successful ack |

**Counters must be derivable from immutable unique events, not incremented by video frames or arbitrary model outputs.** A REJECT disposition differs from actual physical sorting; investigate count discrepancies.

## 3. Diagram — unified website, decentralized runtime

```mermaid
flowchart TB
  Phone[Own iPhone/Android • HTTPS camera • caliper LCD OCR + defect photo] --> Capture[Phone Capture Gateway • ID and quality validation]
  Capture -->|scoped measurement/photo events| Slot[(Slot Peer • own DB)]
  Capture -->|scoped measurement/photo events| Tab[(Tab Peer • own DB)]
  Capture -->|scoped frames / derived detections| Vision[(Visual Evidence Peer • independent data authority)]
  Slot <-->|signed filtered events| Assembly[(Assembly Peer • own DB)]
  Tab <-->|signed filtered events| Assembly
  Vision <-->|verified image evidence| Assembly
  Assembly <-->|authorized disposition + ack| Sorter[(Sorter Peer • own DB)]
  Assembly <-->|relevant task only| Roles[21 bounded AI specialists + metrology, design, process, audit]
  Roles --> Decision[Deterministic stats + PACE + V-DER/CAIR]
  Decision --> Assembly
  Sorter --> Gate[Optional ESP32 servo gate + sensor / manual route]
  Slot --> Browser[One website Dashboard / Evidence / Experiments / Audit]
  Tab --> Browser
  Vision --> Browser
  Assembly --> Browser
  Sorter --> Browser
  Chief[Optional centralized Chief Engineer • comparison mode ONLY] -.-> Roles
```

**Independence test:** disable Assembly peer or any provider key; local Slot, Tab and Visual peers can continue local captures and queue approved records. A single web front door is UX, **not** evidence of decentralized authority. If every role reads a shared global DB and copies one global posterior, the primary decentralization claim fails.

## 4. Evidence contract v3 — truth before fluency

All messages are schema validated, content-addressed and scoped. Use ISO timestamps with timezone. `SHA256` validates accidental tampering, **not identity**; use properly authenticated peer identity, TLS/mTLS or signatures backed by managed secrets when appropriate. Never claim that a self-reported image hash proves its camera origin.

```json
{
  "schema_version":"3.0.0-draft",
  "event_id":"uuid-v4",
  "specimen_id":"tab-B12",
  "lot_id":"B",
  "station_id":"vision-peer-1",
  "observation_kind":"visual_anomaly_candidate",
  "origin_kind":"physical",
  "measurement":null,
  "unit":null,
  "model_score":0.82,
  "score_calibration_status":"NOT_CALIBRATED",
  "image_sha256":"hex_sha256_of_image_bytes",
  "source_event_ids":["uuid-source-camera-1"],
  "acquisition":{"device":"own_phone","view":"top","lighting":"diffuse","quality_gate":"pass"},
  "algorithm":{"id":"golden_image_v1","version":"0.1"},
  "evidence_status":"CANDIDATE",
  "observed_at":"2026-10-30T18:01:22-04:00",
  "expires_at":"2026-10-30T18:11:22-04:00"
}
```

**No majority vote on copies:** evidence graph nodes are original measurement events; agent interpretations are children of those nodes and **cannot independently multiply likelihoods**. Two agents citing the same photo are correlated testimony, not two independent sensors. A strong dissent must be preserved until its source is checked. On missing calibration / stale evidence / image-pose mismatch / low OCR confidence, system can only recommend `HOLD`, remeasurement or human review.

### 4.1 Authority table

| Actor | Reads | Allowed effect | Forbidden |
|---|---|---|---|
| Slot / Tab peers | own lot and measurement records | sign bounded summaries and queue events | read each other's raw tables |
| Visual peer | scoped image + capture metadata | flag candidate defect, request view | label unverified candidate as certified scrap |
| Assembly peer | scoped lot evidence and confirmed disposition | risk, next inspection, suggested pairing | direct factory actuator command |
| Sorter peer | authorized disposition + specimen ID | gate proposal and ack tracking | route until authorized; treat servo movement as arrival |
| Specialist agents | role-authorized sources and tools | bounded proposal + source IDs | fabricate raw measurements, override policy |
| Chief (optional) | allowed summaries only | request other agents, synthesize review | supersede peer authority or safety veto |
| Human reviewer | reviewed evidence and policy | approve/reject physical actions | rewrite audit events or counterfeit source origin |

### 4.2 PACE gate and dispositions

Safety checks are deterministic policy code, **not** LLM instructions. The *mechanical* clearance gate alone cannot guarantee absence of cracks; vision also cannot prove a submillimeter dimension from one uncalibrated image.

- `PASS_CANDIDATE` when all required evidence complete, acceptance criteria and uncertainty guards met, no unresolved critical disagreement; still needs approval for industrial disposition.
- `HOLD` when critical uncertainty, disputed defect, missing peer, stale evidence, OCR ambiguity, or unknown physical route.
- `CONFIRMED_REJECT` requires verified failure against documented rule and reviewer confirmation (not a model score alone).
- `ABSTAIN/NO_AUTOMATION` when evidence/authorization is insufficient.
- **Never automatically release a safety-critical component or scrap costly production material** based on LLM narrative.

## 5. Phone camera subsystem: two capture modes, one device

### 5.1 A — caliper LCD OCR (metrology)

**Manual reading is the measurement source; OCR only removes manual typing.** On iPhone use web `getUserMedia({ video: { facingMode: 'environment' } })` over HTTPS with explicit camera permission; fallback `<input type=file accept=image/* capture=environment>`. If the phone is taking the LCD image, it is not simultaneously acting as a fixed part camera unless there is a second camera. Guides for operator place ID label **before** photographing.

Pipeline: crop the instrument screen → perspective warp if needed → grayscale/CLAHE → threshold, invert as appropriate → OCR candidate(s) with Tesseract if available; **LCD seven-segment digit template/CV may outperform general-purpose OCR** under glare; perform camera focus + glare quality gate → normalize decimal and minus sign → validate valid numerical range, explicit `mm` unit/ instrument mode → require repeated **stable** reading over at least three frames or operator acceptance → link to selected specimen and gauge ID → review UI → store signed event with `physical/manual_confirmed`, plus OCR candidate and evidence image hashes.

If unit cannot be observed, require user to confirm `mm`, never silently assume. If two OCR candidates disagree, `HOLD/OCR_RECAPTURE`. Do not present OCR text as a micrometer-accurate measurement or claim OCR confidence is metrological uncertainty. For static screenshot upload stable-frame test is *not applicable*; one-shot requires manual confirmation. **OCR decimal digit swaps are a designed negative test**.

### 5.2 B — post-print external defect detection (visual)

Capture top/side images in stable diffuse lighting, a contrasting non-reflective mat, approximately fixed height and same camera orientation for normal and defective sample. Name image by specimen_id + view + timestamp; retain image hash, crop transform, camera model, quality gate outcome and operator label. ArUco/known reference can calibrate scale in a *planar region* only; account for lens, perspective, pose, edge selection and repeatability before asserting millimeter measurement. Avoid pretending that NIST's dedicated metrology instrumentation accuracy is achievable with a phone.

Defect taxonomy: layer shift, large visible crack, incomplete print/missing tab, excessive stringing, gross warping, large edge deformation. Exclude internal voids, latent stress, and microscopic defects invisible in the photo. A normal appearance **does not override** caliper fit failure.

**Model ladder:**

| Level | Method | Need | Claim boundary |
|---|---|---|---|
| V0 | alignment + background segmentation + golden-image pixel/contour difference (OpenCV) | nominal reference images, reproducible setup | a baseline anomaly **candidate**, not trained AI |
| V1 | pretrained feature embedding / PatchCore (CVPR'22) | varied good images, frozen benchmark split | anomaly map; validate on own parts |
| V1b | EfficientAD (WACV'24) | nominal images, GPU training if needed | low-latency baseline; not guaranteed on phone parts |
| V2 | NVIDIA TAO Visual ChangeNet classify/segment | labeled golden/test pairs, TAO environment and appropriate GPU | **excellent candidate for golden-reference comparison**; NVIDIA's PCB performance is not our performance |
| V3 | calibrated metric optical inspection | lens calibration target, rigid fixture, repeated independent gauge validation | only report uncertainty-supported dimensional measurements |

A VLM (Nebius / NVIDIA text-vision model where supported) may *explain* a marked anomaly or propose another viewpoint; it must not independently declare a precise width or raw safety disposition.

### 5.3 CAIR: choose next useful sensor action

Candidates: `repeat_lcd_photo`, `manual_caliper`, `top_photo`, `side_photo`, `change_light`, `reprint_sample`, `hold_for_engineer`. Score by **expected reduction in downstream decision loss** subject to measured action cost and measurement validity. Compare mathematically with traditional entropy information gain (`IG`) at matched cost. When observation/outcome likelihood models are not validated, use a fixed safe triage rule rather than pretending utility predictions are calibrated.

## 6. Scientific mathematical core inherited from 5.0 / 9.0 / 13.0

Slot width `W`, Tab thickness `T`, clearance `C = W - T`; functional minimum `c_min`. For independent Gaussian *untruncated* raw-process distributions, mean and variance of C follow the familiar difference rules; for accepted parts **condition** on each local spec before computing functional failure risk. Use deterministic seeded Monte Carlo from truncated distributions (or numeric integration), record uncertainty and assumption sensitivity. Do **not** calculate risk from only one measurement and call it lot-level probability.

Reference educational specs from original 5.0: Slot 20.5–21.5 mm, Tab 19.5–20.5 mm, minimum clearance 0.5 mm; actual samples must use measured dimensions and actual fit labels. A pair `20.6 - 20.3 = 0.3 mm` is locally accepted but functionally short of 0.5 mm, subject to uncertainty and the true assembly test. This is an **illustrative configuration**, not factory tolerance data.

- **Local drift:** EWMA on properly calibrated baseline, predeclared limits, no fake alarms from only five samples.
- **Hypotheses:** H0 normal baseline, H1 narrow slot shift, H2 thick tab shift, H4 both; H3 misalignment only with a credible physical likelihood model. Report posterior only on authorized fresh evidence with sensitivity checks.
- **IG:** `IG(a) = H[p(H|E)] - E_y H[p(H|E,y)]`; inspection priority could be IG / time if ground truth independent.
- **Decision-aware value:** `EVSI(a) = min_d E[L(d,H)|E] - E_y min_d E[L(d,H)|E,y,a]`; possible net benefit `EVSI - action cost`, with risk/abstain constraints. If both methods choose the same action, record a tie; do not manufacture an improvement.
- **Provenance:** de-duplicate common source events before combining evidence; separate physical labels, synthetic labels, and classifier guesses.
- **Safety:** Decision rule considers not only posterior point estimate but confidence/coverage, asymmetric false PASS cost, and missing evidence. `HOLD` is a valid outcome with an explicit cost.
- **Sorting:** optimize matching among available accepted parts only after consent/constraints; a part that fails one pair can fit another without itself being rejected.

### 6.1 Registered research questions and falsifiers

**RQ1** At fixed sensor budget, do separate vision + metrology + engineering agents decrease *unsafe releases* or inspection effort relative to one agent and simple threshold QC? Falsify if matched differences show no gain or worse unsafe release.

**RQ2** Does evidence lineage reduce posterior overconfidence from duplicated photos? Falsify if duplicates never change confidence under all conditions or if graph introduces worse calibration; simulate correlated duplicates and track ECE/Brier when sample size supports.

**RQ3** Does decision-aware CAIR improve net decision loss vs IG under asymmetric defect costs? **Previous toy tests were near ties**; primary test uses prespecified asymmetric costs and blinded held-out scenarios, not cherry-picked illustrative traps.

**RQ4** Does decentralized peer mesh preserve local utility with interrupted connectivity vs centralized? Compare availability, freshness, accuracy, unauthorized reads, replay idempotency. Do not claim decentralized beats central omniscient upper bound.

**RQ5** What additional gain do V1 PatchCore/EfficientAD or NVIDIA TAO models provide beyond V0 OpenCV on OUR 3D printed defects? Pair by same image/camera/light; report recall and false alarm separately. More AI may not be better.

**RQ6** Does specialist count (1/4/8/21 enabled) improve decision quality after controlling for **unique tool data, token budget, latency and cost**? Extra persona agreement is *not* independent evidence. Explicitly test degradation.

### 6.2 Strong experimental matrix

| Arm | Vision | Data access | Decision | Sorter | Scientific purpose |
|---|---|---|---|---|---|
| B0 | none | local only | deterministic threshold QC | manual | physical baseline |
| B1 | phone V0 | single combined | centralized deterministic | manual | benefit of image baseline |
| B2 | phone V1 | single combined | centralized, same calibrated core | manual | vision model benefit |
| B3 | phone V1 | split peer evidence | isolated decisions | manual | isolated lower bound |
| B4 | phone V1 | scoped peer messages | peer + IG + PACE | manual | decentralization, without CAIR |
| B5 | phone V1 | scoped peer messages | **peer + V-DER/CAIR + PACE** | manual | principal scientific treatment |
| B6 | same exact evidence | global raw visibility | centralized chief + same core | manual | controlled upper reference |
| B7 | same as B5 | scoped peer + outage | peer continues locally | manual | resilience |
| B8 | same as B5 | scoped peer | lineage de-dup disabled | manual | evidence de-dup ablation |
| B9 | same as B5 | scoped peer | minority evidence gate disabled | manual | overconfident consensus ablation |
| B10 | same as B5 | scoped peer | optional servo + verified ack | physical | closure of physical loop |

**Fair design:** same frozen specimen/photo streams and accepted-part inclusion, random seeds, calibration and train/test split by **specimen or print batch**, equivalent information budgets, human-in-the-loop assumptions and cost. Do not leak multiple views of the same physical sample across train/test. Hold out a new print day, lighting condition and phone orientation. Report randomization, failures, dropout, confidence intervals, exploratory nature if underpowered. Synthetic decision studies and physical validation appear in **separate tables**.

### 6.3 Physical measurement uncertainty

HyorinmaruK measures one stable artifact at least ten repeated trials, plus two operators if feasible. Define reference/supposed gauge resolution, repeated reading standard deviation, instrument uncertainty if known, and image OCR *transcription accuracy separately*. A simple repeatability check is **not** a calibrated gauge R&R certification. Physical assembly fit needs standardized insertion force/protocol to avoid subjective judgement; log operator, repeated fit attempts, orientation, environmental effects. Misclassification from camera must be measured on manually labeled held-out images. Aim for conservative performance not invented 95% accuracy.

## 7. NVIDIA integration — targeted, not sponsor decoration

### 7.1 NVIDIA Brev credits vs shared Nebius H100

Official ScienceClaw Compute handout says **$150 NVIDIA Brev compute credits per registered member** (3 people = $450 if each individually eligible and redeemed); Brev offers by-the-hour GPUs e.g. L4/L40S/A100/H100 and others, availability and prices vary. The **16 NVIDIA H100 GPUs from Nebius are shared across the event**; do NOT budget as 16 dedicated GPUs for the team. Nebius recommends roughly **one GPU per team/job** out of fairness; queued jobs can fail if not scheduled within 30 min. These resources have separate sign-up/authorization workflows; do not assume Brev credits can be spent as unrestricted Nebius cloud credit.

**P0: 0 GPUs needed.** Phone capture + OpenCV and classical stats run CPU. If available, use **one GPU and one short job** for TAO visual comparison, EfficientAD training or embedding extraction; export trained weights + checksums and stop GPU when complete. Do not rely on GPU availability during the final live demo; local V0 and deterministic engine are mandatory fallbacks.

### 7.2 Exact NVIDIA tools

1. **NVIDIA TAO 2026 skill-based toolkit / Visual ChangeNet** — train/evaluate/classify/segment input vs golden reference; verify current license, runtime, weights, support and model card; requires correct paired labels and consistent camera poses. See official [TAO getting started](https://docs.nvidia.com/tao/tao-toolkit/latest/text/getting_started.html), [TAO overview](https://docs.nvidia.com/tao/tao-toolkit/latest/text/overview.html) and [Visual ChangeNet docs](https://docs.nvidia.com/tao/tao-toolkit/latest/text/cv_finetuning/pytorch/visual_changenet/visual_changenet_classify.html).
2. **NVIDIA NIM** — optional standardized GPU inference server, but expensive/heavy; only deploy if model, NGC authorization, GPU VRAM and Docker runtime confirmed. [Brev NIM guide](https://docs.nvidia.com/brev/guides/inference-deployment/deploying-nims).
3. **NeMo Relay** — optional agent trace/policy/observability, not required for P0. **Do NOT start new work on deprecated NeMo Agent Toolkit:** NVIDIA docs mark it deprecated as of October 2026; migration to Relay/Helix/Fabric recommended. [Relay overview](https://docs.nvidia.com/nemo/relay/latest/about-nemo-relay/overview) and [deprecation notice](https://docs.nvidia.com/nemo/agent-toolkit/latest/).
4. **Nemotron** — optional reasoning model if available through your entitled provider/API, but no role may replace deterministic measurement or final disposition safety.
5. **Isaac Sim / Omniverse** — post-hackathon optional; no physical sorter digital twin required for a useful scientific demo.

### 7.3 GPU work definition and success gate

- Export image training manifest with `specimen_id, view, golden_image, test_image, label, split, acquisition_id`, no overlap of specimen IDs across train/val/test.
- Run V0 OpenCV baseline first and log per-sample outputs.
- If labels sufficient, run TAO Visual ChangeNet classify/segment **only on a subset appropriate to model and use case**. If labels insufficient, prefer few-shot PatchCore or stay with V0 and record that fact.
- Compute **ROC-AUC/PR-AUC only when both classes and enough samples exist**; at demo scale report confusion matrix and per-class sensitivity/specificity with exact numerator/denominator; don't present overly precise estimates.
- Export `model.pt`/ONNX if supported, labels, config, seed, version, hash, GPU type, run duration, model card. Backend loads optional adapter only if artifact exists; otherwise explicit `vision_backend=opencv_reference`.
- **Do not train on MVTec AD for commercial purposes without observing dataset's CC BY-NC-SA license**. MVTec AD is educational benchmark; use **our own printed parts** for our product-oriented experiments. [Dataset/license](https://www.mvtec.com/research-teaching/datasets/mvtec-ad).

## 8. Nebius — use the right resource for the right question

### 8.1 Three distinct Nebius offerings

| Resource | ScienceClaw allocation | Intended QualityRelay task | Access caution |
|---|---|---|---|
| **Nebius Scientific AI Platform (closed beta)** | one credential set **per team**, 65 domain-specific models/skills, 10GB S3 bucket, agentic notebook + MCP (per event PDF) | optional physically meaningful scientific checks (materials hypotheses/robotics where model is verified); store experiment artifacts | biology/protein models are **not** manufacturing defect classifiers; do not call them merely because they're free |
| **Nebius Cloud AI H100** | shared 16 GPUs across hackathon | training/inference benchmarks for vision or simulation | invitation must be accepted, tenant `Nebius-Academy-8dj`; no guaranteed immediate slot |
| **Nebius Token Factory API** | API availability depends on assigned key/entitlement, not automatically same as H100 quota | language-based specialist agents, citation/explanation, schema-constrained action proposals | no credential or model => deterministic bounded fallback; query `/v1/models` for allowed model names |

Official Token Factory uses `https://api.tokenfactory.nebius.com/v1/` and OpenAI-compatible `/chat/completions`, `/models`, `/responses` with entitlement-dependent model lists. [Official OpenAPI](https://api.tokenfactory.nebius.com/docs), [Nebius cookbook](https://github.com/nebius/token-factory-cookbook), [service](https://nebius.com/services/token-factory/inference-service).

**Illustrative integration (not executed here, requires registered key and a supported model):**

```python
from openai import OpenAI
import os
client = OpenAI(base_url="https://api.tokenfactory.nebius.com/v1/", api_key=os.environ["NEBIUS_API_KEY"])
allowed = [m.id for m in client.models.list().data]
model = os.environ["NEBIUS_MODEL"]  # must be present in allowed
assert model in allowed
response = client.chat.completions.create(
    model=model, temperature=0,
    messages=[
      {"role":"system","content":"You are a bounded manufacturing QA agent. Only cite supplied evidence IDs; output proposals, never final measurements or actuator commands."},
      {"role":"user","content":"Incident: tab-B12. Scoped evidence: ..."}
    ]
)
# Treat text as UNTRUSTED until schema validation and independent tool checks.
```

**Security:** server-side credentials only (`NEBIUS_API_KEY`, no `.env` in Git, no JS keys), short context, redact supplier identity/person data, rate and spend caps, exact model/version logging, backoff on 429/5xx. The server never trusts an LLM's invented specimen IDs. For a Scientific AI Platform MCP integration verify **which tools are actually exposed** and call only relevant validated skills; each team's key is not a general model license.

### 8.2 Provider decision tree

- Need to read phone photos / caliper OCR? → **local CV first**, no Nebius scientific platform required.
- Need to train a defect detector? → **NVIDIA Brev or Nebius H100 (one GPU), only if data and entitlement are ready**.
- Need specialist natural-language explanation? → **Nebius Token Factory**, provider adapter, deterministic numerical core.
- Need molecular dynamics / robotics/materials simulation? → Nebius Scientific AI **only** if a concrete qualified skill exists; do not fabricate physics.
- Need a robust offline demonstration? → all critical decisions stay local when GPU/API unavailable.

## 9. Sorter: separate policy, command, gate movement and arrival

**v12 Sorter Peer is independent**; optional ESP32 controls just gate motor, never caliper jaws. `SortingRequested` requires specimen ID, disposition ID, human approval (or explicitly scoped lab-demo policy), TTL, nonce and idempotency key. Hardware driver accepts only whitelist `PASS|HOLD|CONFIRMED_REJECT`, and only within low-energy guarded demonstration. Do not physically actuate if authorization or current sensor state unknown.

```text
Disposition proposed -> authorized -> routing requested -> gate moved
   -> confirmation sensor/second visual record -> physically_sorted
   OR timeout / mismatch -> SORT_FAILED + HOLD + operator inspection
```

Manual route mode implements the same ack event schema but ack is human-reported, **not equivalent** to verified IR sensor presence. One component seen in 30 video frames counts once; event ID and specimen ID de-dup at backend. Counter mismatches are visible, never silently reconciled.

### 9.1 P0 phone-only; P1 servo optional

- **P0 required:** 3D prints, phone browser camera, digital caliper, peer evidence, visual baseline, HOLD, manual sorting, audit and benchmark.
- **P1 optional:** 1 ESP32-S3, 1 low-voltage servo+gate (if in ELEGOO bundle), one break-beam/IR detector (verify it is actually supplied), breadboard and jumpers. Camera board/Pi/Hailo are *not* required; optional second independent vision peer if hardware available.
- Physical sorter cannot be presented as built if it isn't. Include `hardware_sorter_status=NOT_BUILT` in run manifest until bench tested.

## 10. Team ownership — parallelizable without ambiguous handoffs

| GitHub | Owner | Primary components | Measurable acceptance |
|---|---|---|---|
| `Bakdaulet-omeraiuly` | **Scientific/Data Science lead** | risk engine, Bayesian/IG/EVSI and CAIR, V0/V1/TAO model trials, preregistration, experiment/metrics and research citation table | fixed seeds, held-out specimens, reproducible metrics; no unsupported claim |
| `adilnurgg` | **Backend, decentralized security lead** | station peer services, event envelope auth + replay, storage and API; Nebius Token Factory adapter; provider failures; integration/deployment | unauth raw read 403, outage resilience, exactly-once event application, API spec and tests |
| `HyorinmaruK` | **Mechanical engineering, physical validation AND final presentation owner** | CAD revisions, 3D printing, caliper fixture + phone alignment, measurement uncertainty log, photo ground truth, assembly trials, sorter gate if hardware, UI demo UX, scientific slides/pitch | physical specimen IDs, held-out labels, reproducible inspection protocol, evidence-linked pitch |
| fourth (optional) | Frontend/integration/independent QA | mobile-responsive website, camera controls, CI, smoke tests, external engineer outreach, independent test review | HTTPS phone upload from 2 devices; trace end-to-end and negative tests |

**Three-person default:** frontend implementation split: adilnurgg owns API & basic website wiring, HyorinmaruK owns camera UX, physical workflow and presentation; Bakdaulet owns report/plots. Fourth, if added, takes frontend and independent QA without duplicating core decision engine. **No person** may silently change another owner's data contract; OpenAPI/JSON Schema freeze first.

### 10.1 Work branches and integration

- `main` protected/tagged, no secret commits.
- `feat/science-engine` (Bakdaulet); `feat/peer-backend-nebius` (adilnurgg); `feat/mechanical-phone-demo` (HyorinmaruK); `feat/mobile-web-qa` (optional).
- `contracts/v3` freezes field names before parallel work; each PR includes test + one representative sample event and a consumer smoke test.
- Cross-team daily integration: `git pull --rebase`, `pytest`, demo run; snapshots include model weights SHA, camera photo SHA and exact specimen inventory. Have prerecorded demo as fallback but mark clip as recorded.

## 11. One website — minimal information architecture

| Screen | Operator action | Exactly what it shows |
|---|---|---|
| `/dashboard` | pick incident, lot-pair | station live/stale status, evidence coverage, predicted risk vs uncertainty |
| `/capture` | scan QR/type specimen, select **Caliper OCR** or **Surface Vision**, use own phone camera | source photo, candidate result, approve/recapture, no fake numeric confidence |
| `/agents` | inspect specialist tasks/evidence | real tool invocation status and actual source IDs; contract-only roles clearly labelled |
| `/evidence` | provenance graph, conflicting claims | original events vs derived opinions and evidence debt |
| `/decisions` | review HOLD/PASS/REJECT or suggested extra measurement | reason, missing proof, human approval and expiry |
| `/sorter` | manual routing confirmation / ESP32 gate command if available | per-specimen state + `inspected`, `confirmed_defective`, `physically_rejected` counts |
| `/experiments` | B0–B10 run and paired comparisons | physical vs synthetic separated, baseline, CIs, seeds and limitations |
| `/audit` | export record and event source | append-only log, hashes and model version |

**Phone browser:** must be served over HTTPS (or localhost during local laptop development); use `getUserMedia` or file-capture fallback, user consent, visible stop camera button, no automatic upload of continuous video. In Chrome/Safari camera web APIs require a secure context, [MDN](https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia).

## 12. Interface freeze: API and idempotency

**Core endpoints (target contracts; this package contains a smaller reference subset):**

| Method | Route | Behavior |
|---|---|---|
| POST | `/api/specimens` | register ID, lot, class, CAD rev; deny duplicates |
| POST | `/api/capture/caliper` | photograph candidate with specimen, unit, gauge and confirmation |
| POST | `/api/capture/vision` | photo + golden reference; returns candidate and model identifier |
| POST | `/api/evidence` | schema/authority validation, idempotent source events |
| GET | `/api/peers` | scoped station liveness; no raw cross-table disclosure |
| POST | `/api/incidents` | register pair and set evidence snapshot |
| GET | `/api/incidents/{id}/risk` | clearance analysis and coverage |
| POST | `/api/incidents/{id}/next-inspection` | ranked candidate, cost and evidence basis |
| POST | `/api/dispositions` | policy-controlled proposal + human authorization |
| POST | `/api/sorter/route` | whitelist and non-expired signed authorization |
| POST | `/api/sorter/ack` | physical/manual confirmation with source type; idempotent |
| GET | `/api/counters` | derive unique verified counts and discrepancy |
| POST | `/api/experiments/run` | immutable reproducible manifest of baseline comparison |
| GET | `/api/audit/export` | replayable provenance records |

**Reference code in ZIP:** optional `/api/demo/inspection` calculates dimensional fit advisory + image-difference candidate and outputs `HOLD/PASS_REVIEW` with explicit `NOT_CALIBRATED` limitations, plus `/api/demo/sorter` and `/api/demo/counters` to demonstrate event idempotence. It **does not** yet implement fully independent networked station services, real TAO training or ESP32 hardware. Use these endpoints as test scaffolding, not factory validation.

## 13. 21 specialists (retained v12 registry, plus Visual as station)

Each of these is an *available role* with permissions, tool and denial tests, **not** 21 autonomous inference models currently running:

| # | Specialist | Real evidence/tool and abstention |
|---:|---|---|
| 1 | Design Geometry | CAD rev + datums; unknown revision → abstain |
| 2 | Tolerance Analyst | accepted-part distributions; missing model → no risk claim |
| 3 | Materials Engineer | certified material data; no certificate → hypothesis only |
| 4 | Process Engineer | process graph and time series; missing log → partial |
| 5 | CNC Expert | machining logs if actual CNC; else not applicable |
| 6 | Additive Manufacturing Expert | slicer/filament/print settings and visible failure |
| 7 | Metrology Engineer | gauge ID, repeatability, operator, physical measurement |
| 8 | SPC Agent | calibrated EWMA/CUSUM baseline |
| 9 | Quality Inspector | acceptance + evidence/hold rules |
| 10 | Assembly Engineer | pair-level clearance and assembly-test plan |
| 11 | Causal Diagnosis | DAG hypotheses, discriminator measurement |
| 12 | Bayesian Statistician | frozen priors/likelihoods and sensitivity |
| 13 | Inspection Planner | IG/EVSI/CAIR, predeclared candidate IDs |
| 14 | Operations Research | feasible lot pairing constraints, reject unsafe matches |
| 15 | Maintenance Engineer | real maintenance evidence or N/A |
| 16 | Supplier Boundary | approval for cross-factory scoped summaries |
| 17 | Safety/Governance | policy veto + human approval gate |
| 18 | Privacy/Security | verified auth, data leak report |
| 19 | Reliability/Network | stale/offline/replay/coverage metrics |
| 20 | Scientific Auditor | signed run manifest, origin labels, reproduction |
| 21 | Kaizen / PDCA | controlled improvement hypothesis, no fake causal claim |

**Vision evidence owner** is an independently authorized **fifth observation peer** or integrated bounded sensor of QA peer; **Sorter remains the fourth physical station** following Slot, Tab and Assembly as in v12. Do not renumber 21 specialists because adding a camera device is not equivalent to adding a 22nd independent engineering role. Primary peer count: four station services (Slot/Tab/Assembly/Sorter), **plus a visual evidence service when deployed independently**.

## 14. Anti-hype experimental validity gates

1. Baselines run against the *same* frozen specimens and photographic observations; match wall-clock and inspection costs where possible.
2. Physically distinct photo views of same object are **not** independently sampled held-out objects. Group split by specimen_id and print batch.
3. Print simulation vs physical evidence in separate tables. Every `origin.kind` is visible; same model cannot use a test photo to set its own threshold.
4. Model score ≠ calibrated probability. Calibrate on held-out data only with enough cases; otherwise report ranking and uncertainty qualitatively.
5. OCR error rate measured as exact full-reading match vs independent transcription, especially decimals and minus sign; gross measurement error from bad caliper contact is a separate phenomenon.
6. Count confidence and sorter route confirmations independently; no results invented for planned servo.
7. Publish **negative results**; old V-DER pilot nearly tied IG. A single illustrative counterexample does not prove superiority.
8. Freeze primary outcome before experiment: `unsafe_PASS_rate` under a target or compare difference at fixed refusal/hold rate; secondaries: inspection cost/time, AUPRC, false reject, calibration, event bytes, fault delays, graceful degradation.
9. Time, provider spend and token use are experimental variables. A 21-agent system that improves one metric but doubles risk/cost may fail product usefulness.
10. No approval of industrial safety-critical use until separate domain controls, external validation, security and legal compliance.

### 14.1 Technical acceptance (P0)

- [ ] A phone photo is actually captured and linked to specimen ID, not stock footage.
- [ ] Original unmodified 5.0 package verifiably archived.
- [ ] A caliper decimal digit conflict yields explicit HOLD; no blind OCR acceptance.
- [ ] A visibly suspicious but dimensionally acceptable part yields HOLD, not PASS.
- [ ] A visually normal but dimensionally incompatible pair yields HOLD even if camera says normal.
- [ ] Duplicate evidence does not multiply independent likelihood; duplicate sorter ack does not increment counts.
- [ ] Offline peer does not silently contribute stale likelihood; local peers continue.
- [ ] A disposition requires documented policy + reviewer prior to sorting.
- [ ] P0 demo works with zero NVIDIA/Nebius connectivity.
- [ ] GPU jobs/logs are linked only if actually run; otherwise model states `NOT_RUN`.
- [ ] Physically rejected count increments only after event-level confirmation.
- [ ] Real physical measurements are visibly separated from synthetic samples.

## 15. Deployment & cost-first architecture

- **Frontend:** React/Next.js or minimal phone-first HTML, HTTPS, indexed specimen forms, no credentials in browser.
- **Local science:** Python/OpenCV/Pydantic/FastAPI with NumPy/SciPy if needed; model weight optional.
- **Independent services:** eventually Slot, Tab, Assembly, Sorter and optional Vision peer own DBs; event transfer via authenticated queue/router with zero diagnostic authority; failure injection.
- **Cloud providers:** NVIDIA Brev/Nebius H100 are **temporary model training resources**, not mandatory production API host; Nebius Token Factory is optional interpretation tool. All providers behind adapters so no sponsor lock-in.
- **Hosting:** site on Vercel/Cloud Run if entitlement; avoid assuming Google event account persists (PDF warns auto-delete Sunday). Export code/model/logs before termination.
- **Data:** raw phone images retained only with explicit consent; encrypt in transit/rest, minimize visibility, implement TTL and delete process; training data licensing checked.
- **Budget controls:** cap image uploads, downsample for nonmetrological vision only, model invocation maximum, GPU time and total cloud spending, error fallback; do not run 21 reasoning calls per specimen.

## 16. Schedule / cut lines for three-person hackathon

| Phase | Scientific lead (Bakdaulet) | Backend (adilnurgg) | Mechanical/pitch (HyorinmaruK) | Deliverable |
|---|---|---|---|---|
| H0–H3 | freeze specs, scenario set, CSV schema | freeze API + station permissions | print fixtures & choose failure specimens | reproducible P0 scope |
| H3–H8 | clearance/IG baseline + openCV sanity | phone capture + event provenance | caliper repeatability and photo fixture | one real physical event through dashboard |
| H8–H14 | golden-image model and evaluation | 4-peer separation and outage simulator | test both contradictory evidence cases | HOLD decisions with provenance |
| H14–H20 | initial matched baseline trials | sorter event idempotence; optional Nebius API adapter | printed pairs/assembly labels; optional servo gate | demo full loop, physical counters |
| H20–H24 | freeze run manifest, honest plots | harden error/security and manual fallback | pitch, judge rehearsal, photo evidence | two full rehearsals |
| H24+ | no new core features | no new core features | submit/rehearse | stable and evidence-linked |

These are *active-hour milestones*, not promises about remaining event time. Follow the current official hackathon schedule and submission instructions, especially earlier slide deadlines. **If work slips: drop GPU training, then borrowed hardware servo, then fancy vision model, then extra roles; never drop original peer evidencing, HOLD, real measurements, fair baseline or demo stability.**

## 17. Exact sources: primary literature, official docs, and ScienceClaw constraints

### Research (known methods: do not present as original discoveries)

1. Roth et al. (2022), **PatchCore / Towards Total Recall**, CVPR: https://openaccess.thecvf.com/content/CVPR2022/html/Roth_Towards_Total_Recall_in_Industrial_Anomaly_Detection_CVPR_2022_paper.html
2. Batzner, Heckler, König (2024), **EfficientAD**, WACV: https://openaccess.thecvf.com/content/WACV2024/html/Batzner_EfficientAD_Accurate_Visual_Anomaly_Detection_at_Millisecond-Level_Latencies_WACV_2024_paper.html
3. **MVTec AD datasets/license**, educational reference only; CC BY-NC-SA: https://www.mvtec.com/research-teaching/datasets/mvtec-ad
4. **Value of information and conditional risk:** decision-theoretic basis from original 5.0/13.0 research; see their complete citations in archived materials, verify DOI before citing in slides.
5. NIST (Praniewicz et al., Oct 2026), machine vision uncertainty **with dedicated laboratory metrology system**, *not a phone benchmark*: https://www.nist.gov/publications/validation-upgrades-nist-m48-vision-measurement-system

### Official provider implementation references

6. NVIDIA TAO overview: https://docs.nvidia.com/tao/tao-toolkit/latest/text/overview.html
7. NVIDIA TAO 2026 skill-based getting started + Visual ChangeNet: https://docs.nvidia.com/tao/tao-toolkit/latest/text/getting_started.html
8. NVIDIA Visual ChangeNet classify: https://docs.nvidia.com/tao/tao-toolkit/latest/text/cv_finetuning/pytorch/visual_changenet/visual_changenet_classify.html
9. NVIDIA NeMo Relay: https://docs.nvidia.com/nemo/relay/latest/about-nemo-relay/overview
10. NVIDIA NeMo Agent Toolkit **deprecation**: https://docs.nvidia.com/nemo/agent-toolkit/latest/
11. NVIDIA Brev NIM optional: https://docs.nvidia.com/brev/guides/inference-deployment/deploying-nims
12. Nebius Token Factory API: https://api.tokenfactory.nebius.com/docs
13. Nebius Token Factory examples: https://github.com/nebius/token-factory-cookbook
14. MDN HTTPS secure-context camera: https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia
15. **ScienceClaw compute PDF supplied by team** — NVIDIA $150/member; Claude $100/member; Nebius shared 16 H100; Nebius team Scientific AI credentials and 10GB S3; Google temporary cloud max two accounts; OpenAI $50 API credits.
16. **ScienceClaw hardware PDF supplied by team** — limited shared ESP32, camera boards, Pi/Hailo, components and printers; no guarantee of hardware access.

### Novelty register — four honest levels

- `L0 established`: Bayesian inspection, information gain, anomaly detection, OCR, multi-agent role orchestration, source provenance all exist.
- `L1 integration proposal`: mobile optical evidence + manual gauge measurements + decentralized role contracts + safe sorting + decision-aware inspection and physical ack in one auditable workflow.
- `L2 reproducible result`: only after fixed runs reveal a measured delta with interval vs strong baselines; no L2 claim here without run artifact.
- `L3 industrial validation / publishable novelty`: independent plant-specific study, broad negative/positive cases, repeated batches, external review and prior-art search. **No L3 claim made.**

---

## APPENDIX A — Original QualityRelay 5.0 master blueprint (verbatim, separately archived)

# QualityRelay 5.0 master blueprint

## 1. Executive definition

QualityRelay is a decentralized quality-coordination system for assemblies whose fit depends on measurements owned by different manufacturing stations. A slot can pass its local specification and a tab can pass its local specification while their pairing still has insufficient clearance. Each station continues to own its raw data and local decisions. Agents exchange scoped, provenance-linked evidence only when an assembly-risk query or anomaly makes collaboration useful.

The hackathon demonstration answers one narrow scientific question:

> With the same statistical core and inspection budget, what capability is gained or retained when quality evidence is coordinated across independently authorized station agents, especially when communication is intermittent?

It does **not** attempt to prove that multi-agent systems are universally better than centralized quality systems.

## 2. The manufacturing problem

Three logical stations are modeled:

1. **Slot station** produces a slot and measures slot width `W`.
2. **Tab station** produces a tab and measures tab thickness `T`.
3. **Assembly station** selects lots, observes fit outcomes, and evaluates clearance `C = W - T` against a functional minimum `c_min`.

Local part specifications are deliberately not equivalent to the assembly requirement. In the demonstration reference design:

- Slot specification: 20.5–21.5 mm.
- Tab specification: 19.5–20.5 mm.
- Functional minimum clearance: 0.5 mm.
- Nominal means: slot 21.0 mm, tab 20.0 mm.

Worst-case individually accepted parts can produce `20.5 - 20.5 = 0.0 mm`, below the functional requirement. The exact risk depends on the process distributions and the acceptance conditioning. These values are configuration assumptions for a teaching demonstration, not measured factory parameters.

## 3. User story

Before assembly, an operator selects slot lot A-07 and tab lot B-12. The assembly agent cannot calculate a current risk until it obtains sufficient, authorized summaries from both stations. It sends evidence requests. Each station returns a signed summary referencing local measurement event IDs, not its entire raw table. The assembly agent calls the deterministic compatibility engine, receives a provenance-linked risk estimate, and either:

- permits the planned pairing with its uncertainty and evidence coverage;
- recommends a server-provided alternative lot with lower estimated risk; or
- asks for the physical measurement with highest expected information gain per second.

If the slot link is taken offline, the slot station continues local measurements and queues outbound events. Peers stop receiving new slot evidence; the UI marks the current diagnosis as partial and omits the stale station likelihood from the live posterior. The audit history remains intact. On reconnection, event IDs make replay idempotent.

## 4. Why decentralized agents are justified

The system models real organizational and technical boundaries:

- Different equipment or suppliers own different raw records.
- A station has authority to measure and summarize its own process, not to read another station’s database.
- Assembly owns the relational decision: whether two lots should be paired.
- Communication can be intermittent while local production and monitoring continue.
- An append-only router moves messages but cannot fabricate a measurement, compute a diagnosis, or override a station.

If every actor reads one shared database and one global posterior, the project fails its own decentralization claim.

## 5. P0 end-to-end behavior

1. Record or seed at least five recent measurements per relevant lot and station.
2. Create a `BatchRiskQuery` for an upcoming slot–tab lot pairing.
3. Show `pending_insufficient_evidence` until authorized evidence responses arrive.
4. Calculate clearance risk with the shared deterministic engine.
5. Link every estimate to the exact evidence event IDs, code version, assumptions, and origin labels.
6. Rank server-provided physical inspection candidates by expected information gain divided by time cost.
7. Accept a real caliper entry and update the diagnosis.
8. Toggle one station link offline and show partial-evidence behavior.
9. Reconnect and reconcile queued events exactly once.
10. Export a replayable run manifest and result record.

## 6. Architecture at a glance

```text
Slot UI/tool -> Slot service + local DB ----\
                                         signed evidence events
Tab UI/tool  -> Tab service + local DB ----- event router/log ---> Assembly service + local DB -> Dashboard
                                             |                         |
                                             |                         +-> risk/diagnosis/inspection core
                                             +-> no diagnostic authority

Optional LLM adapters sit above each station's approved tools.
All numeric truth is rendered from deterministic service responses.
```

The statistical core is one versioned library reused in isolated, centralized, and decentralized conditions. This prevents a strawman baseline. Deployment and evidence access change; the mathematics does not.

## 7. Scientific core

### 7.1 Clearance risk

For independent normal slot and tab distributions before acceptance truncation:

`mu_C = mu_W - mu_T`

`sigma_C^2 = sigma_W^2 + sigma_T^2 - 2*rho*sigma_W*sigma_T`

`P(C < c_min) = Phi((c_min - mu_C) / sigma_C)`

The benchmark must condition on both parts passing their local specifications. Use deterministic Monte Carlo from truncated distributions or numerical integration. The random seed is derived from the run ID, lot pair, evidence snapshot hash, and algorithm version so identical inputs return identical outputs.

### 7.2 Local process monitoring

Each station maintains an EWMA:

`z_t = lambda*x_t + (1-lambda)*z_(t-1)`

Control limits use the standard time-varying EWMA form. `lambda = 0.2` and `L = 3` are starting configuration values, not optimized claims. Baseline process mean and sigma come from the calibration dataset; they are not estimated from only five live points.

### 7.3 Evidence-scoped diagnosis

The minimum hypothesis set is:

- `H0`: stable process; assembly failures occur at the nonzero design baseline.
- `H1`: slot mean shifted downward.
- `H2`: tab mean shifted upward.
- `H4`: both means shifted toward reduced clearance.

Optional `H3` fixture/misalignment is P3 because a credible physical mechanism and likelihood model are not available in the core sprint.

Posterior updates are performed only over evidence the calling actor has locally observed or received through authorized responses. When a station is unavailable or evidence is outside the freshness window, its likelihood term is omitted and the posterior is renormalized. The UI must show evidence coverage, such as “computed from 2 of 3 stations.”

### 7.4 Targeted inspection

For candidate action `a` and possible outcomes `y`:

`IG(a) = H[p(H|E)] - sum_y p(y|a,E) * H[p(H|E,y)]`

`score(a) = IG(a) / expected_seconds(a)`

Candidate specimen IDs come from the server. An LLM may choose among them or request no action, but cannot invent an ID. The method is an application of established Bayesian experimental design, not a new information-theory algorithm.

## 8. Requested combined demonstration scenario

`configs/scenario_combined_0p100mm.yaml` specifies:

- scenario: `combined`;
- slot mean shift: `-0.100 mm`;
- tab mean shift: `+0.100 mm`;
- slot communication: `online` at the start;
- data source: `simulated`;
- pairing policy: uniform random pairing among locally accepted parts;
- outcome status: `NOT_RUN`.

Expected qualitative observations, not claimed results:

- both local EWMAs should move toward reduced clearance, though the exact alarm timing is unknown until run;
- the joint clearance-risk estimate should tend upward relative to the frozen nominal baseline;
- evidence requests and responses should complete while the slot link is online;
- the combined hypothesis should gain support if the generated evidence matches the configured shifts;
- a targeted inspection may be proposed if expected information gain exceeds the configured threshold;
- all dashboard values must be labeled simulated and tied to the seed.

Do not promise that the collaborative system beats the isolated condition at this shift magnitude. Pilot candidate shifts first because 0.100 mm may be locally detectable depending on sigma, EWMA parameters, and run length.

## 9. Validation design

### Experiment A: collective capability under full connectivity

Compare:

- isolated station actors with peer requests disabled;
- centralized system with all raw evidence;
- QualityRelay peer evidence exchange.

Use the same core, scenario streams, inspection budget, and seeds. Primary interpretation: QualityRelay may recover much of centralized performance with less raw-data access and a traceable communication budget. Do not claim it should beat the centralized upper bound.

### Experiment B: resilience to information topology

A 2×2 design:

| Topology | Always on | Intermittent link |
|---|---|---|
| Centralized hub | upper-bound reference | hub/link degradation |
| Decentralized peer mesh | normal QualityRelay | local continuity + partial evidence + reconciliation |

The hub’s coordinator-failure test is deliberately asymmetric: a peer mesh has no single coordinator to fail. State this rather than pretending the cells are identical.

### Metrics

- fault-hypothesis accuracy on simulated ground truth;
- detection delay in units after injected change;
- assembly-risk Brier score on simulated runs only;
- number and time cost of physical/simulated inspections;
- raw records exposed across station boundaries;
- message count and bytes;
- evidence coverage at decision time;
- duplicate-event count after reconnect;
- unauthorized access attempts denied;
- physical loop completion reported descriptively, never as a calibrated percentage.

## 10. Physical evidence plan

Use a small U-slot coupon and flat tab coupon printed in white PLA. Print a safe pair, a nominal pair, and a tight-risk pair plus backups. Do not rely on CAD dimensions as ground truth. First measure one stable coupon ten times, compute repeatability standard deviation `s_r`, then choose a demonstrated clearance difference comfortably larger than measurement noise. A 3–5× `s_r` rule is a screening heuristic, not a full gauge R&R study.

Two or three physical pairings close the loop; they do not validate the predicted probability. Simulation supplies repeated, seeded ground truth. Physical and simulated metrics must be shown in separate panels.

Do not attempt a live print-redesign-reprint-refit loop. Show any corrected CAD as a next-step artifact.

## 11. Success criteria

P0 is complete only when all are true:

- one command resets the demo to a known state;
- a risk query remains pending before evidence arrives;
- unauthorized cross-station raw reads return 403 and are logged;
- the same input snapshot produces the same risk output;
- all numeric UI statements are server-rendered from structured results;
- candidate IDs are whitelisted;
- link loss changes evidence coverage visibly without deleting history;
- reconnect produces zero duplicate events;
- a physical caliper entry is stored with `origin.kind = physical`;
- a simulated benchmark record includes seed and generator version;
- no chart combines physical and simulated observations into one unlabeled metric;
- the deterministic fallback performs the complete demo without an LLM.

## 12. Milestones and cut lines

| Milestone | Active-hour deadline | Acceptance condition | Cut if missed |
|---|---:|---|---|
| M0 scope/interface freeze | H1 | schemas, role boundaries, scenario IDs fixed | remove alternative-lot and disagreement branches |
| M1 deterministic core | H6 | clearance, EWMA, diagnosis, inspection tests pass | remove Bayesian extras; keep risk + fixed inspection |
| M2 minimum viable demo | H12 | reset → query → evidence → risk → inspection → update | LLM removed from critical path |
| M3 decentralized proof | H18 | 403 test, scoped posterior, offline queue, idempotent replay | use recorded outage clip; keep live evidence exchange |
| M4 experiment freeze | H23 | pilot selects shift rule; matrix and seeds frozen | reduce to 3 seeds and label exploratory |
| M5 feature freeze | H25 | full run completes twice | no new features |
| M6 submission ready | H29 | slides, repository, manifest, backup clip, 2 rehearsals | polish only |

## 13. ScienceClaw rubric alignment

| Rubric | Evidence to show |
|---|---|
| Problem significance, 20% | relational tolerance-stack failure across data silos; preventable scrap/rework risk |
| Scientific/technical impact, 25% | prospective lot-pair risk, targeted inspection, traceable decision; results shown only after execution |
| Decentralized agency, 20% | station-local data/authority, explicit evidence requests, no decision-making router, offline local continuity |
| Collective capability, 25% | same-core comparison against isolated and centralized conditions; link-fault experiment |
| Execution/validation, 10% | functioning vertical loop, seeded experiments, physical caliper input, negative permission test, replay manifest |
| Optional collaboration bonus | another team actually reuses the event schema, replay dataset, or tool; usage is documented |

## 14. Honest closing claim template

Fill brackets only after measured runs:

> Using the same statistical core and inspection budget, QualityRelay’s independently authorized station agents evaluated an upcoming compatibility risk through selective evidence exchange, requested a targeted inspection, and retained local operation during a communication interruption. In seeded simulation, the collaborative condition [measured result with uncertainty]. In the physical demonstration, [descriptive observed loop outcome]. These results demonstrate a hackathon prototype, not industrial validation.



---

**END — source 5.0 appendix above included byte-for-byte as text; the original file is separately preserved for exact-byte verification.**

