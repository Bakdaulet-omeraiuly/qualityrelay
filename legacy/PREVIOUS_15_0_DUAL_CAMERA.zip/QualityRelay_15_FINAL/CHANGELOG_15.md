# QualityRelay 15.0 delta from 14.2

- Two physical vision acquisition paths proposed: personal phone + borrowed Raspberry Pi 5 camera/Hailo-8L, each with independent station identity and local database.
- Added practical station API with distinct station HMAC key, image digest, capture ID, source timestamp, camera quality gate and replay/collision handling.
- Added deterministic cross-camera reducer, safe HOLD on dissent, missing/stale event, identical image reuse, forged record, unverified metrology/assembly.
- Added strict LLM agent evidence bridge, preserving original 21 specialist roles and no model-led hardware control.
- NVIDIA Brev model-training plan, Nebius hosted LLM bounded tool plan, local Hailo model limitations and grant budget rules documented.
- Added physical validation checklist, scientific ablation matrix with conservative rule-only baseline and preregistration guidance.
- Updated team split so Bakdaulet DOES NOT manage Google Cloud; adilnurgg and HyorinmaruK are the only GCP owners.
- Explicitly preserved original v14.2 complete ZIP and v5.0 ZIP without byte changes.
- New 23 reference tests; previous 65 v14.2 tests re-run.
- Work is a *research reference*, not trained NVIDIA/Hailo network or live Nebius/factory integration.
