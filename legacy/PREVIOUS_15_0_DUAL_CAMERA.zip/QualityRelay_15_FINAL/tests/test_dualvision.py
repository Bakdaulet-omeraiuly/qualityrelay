import base64, io, os
from datetime import datetime,timezone,timedelta
import cv2,numpy as np, pytest
from fastapi.testclient import TestClient
from dualvision.evidence import new_event,sign_event,verify_event
from dualvision.reconcile import decide
from dualvision.station import create_station_app
from dualvision.vision_baseline import evaluate_pair

KEYS={'phone_vision':'phone_test_shared_secret_123456',
      'pi_edge_vision':'pi_test_shared_secret_123456'}

def ev(station,kind='NO_ANOMALY', capture='1',digest='a',quality=True, when=None):
    return sign_event(new_event(station_id=station,specimen_id='tab-B12',
      image_digest=digest*64,reference_digest='f'*64,candidate=kind,
      capture_id=capture,quality_ok=quality,
      observed_at=when,method='TEST_FIXTURE_NOT_REAL_CAMERA'),KEYS[station])

def both(a='NO_ANOMALY',b='NO_ANOMALY'):
    return [ev('phone_vision',a,digest='a'),ev('pi_edge_vision',b,digest='b')]

def decision(events,**kwargs):return decide(events,KEYS,metrology_verified=True,assembly_verified=True,**kwargs)

def test_two_clear_review_only():
    x=decision(both())
    assert x['review_status']=='PASS_REVIEW' and x['physical_sorter_command'] is None
    assert x['human_approval_required']

def test_disagreement_hold():
    x=decision(both('NO_ANOMALY','SUSPECT'))
    assert 'camera_disagreement' in x['reasons'] and x['review_status']=='HOLD'

def test_both_suspect_still_hold():
    x=decision(both('SUSPECT','SUSPECT'))
    assert x['review_status']=='HOLD'

def test_absent_pi_is_hold():
    assert 'missing_pi_edge_vision_evidence' in decision(both()[:1])['reasons']

def test_absent_phone_is_hold():
    assert 'missing_phone_vision_evidence' in decision(both()[1:])['reasons']

def test_metrology_missing_hold():
    x=decide(both(),KEYS,metrology_verified=False,assembly_verified=True)
    assert 'unverified_dimensional_measurement' in x['reasons']

def test_assembly_missing_hold():
    x=decide(both(),KEYS,metrology_verified=True,assembly_verified=False)
    assert 'unverified_assembly_compatibility' in x['reasons']

def test_tamper_detected():
    e=both();e[1]['candidate']='NO_ANOMALY';e[1]['image_sha256']='c'*64
    assert 'invalid_attestation' in decision(e)['reasons']

def test_identical_image_not_independent():
    e=[ev('phone_vision',digest='a'),ev('pi_edge_vision',digest='a')]
    assert 'identical_camera_image_not_independent' in decision(e)['reasons']

def test_duplicate_replay_not_counted():
    e=both();x=decision(e+[e[1]])
    assert x['unique_event_count']==2 and x['review_status']=='PASS_REVIEW'

def test_evidence_collision_hold():
    e=both();c=dict(e[0]);c['candidate']='SUSPECT'
    assert 'event_id_collision' in decision(e+[c])['reasons']

def test_stale_event_hold():
    old=(datetime.now(timezone.utc)-timedelta(hours=1)).isoformat()
    e=[ev('phone_vision',when=old,digest='a'),ev('pi_edge_vision',digest='b')]
    assert 'stale_or_invalid_timestamp' in decision(e)['reasons']

def test_future_event_hold():
    future=(datetime.now(timezone.utc)+timedelta(minutes=20)).isoformat()
    e=[ev('phone_vision',when=future,digest='a'),ev('pi_edge_vision',digest='b')]
    assert 'stale_or_invalid_timestamp' in decision(e)['reasons']

def test_poor_quality_hold():
    e=[ev('phone_vision',quality=False,digest='a'),ev('pi_edge_vision',digest='b')]
    assert 'visual_quality_or_abstention' in decision(e)['reasons']

def test_derived_evidence_not_independent():
    e=both();e[0]['source_event_ids']=['old'];e[0]=sign_event(e[0],KEYS['phone_vision'])
    assert 'derived_evidence_not_independent' in decision(e)['reasons']

def test_wrong_specimen_hold():
    e=both();e[1]['specimen_id']='tab-B13';e[1]=sign_event(e[1],KEYS['pi_edge_vision'])
    assert 'missing_or_mismatched_specimen' in decision(e)['reasons']

def test_unknown_station_hold():
    e=both();e[1]['station_id']='fake'
    assert 'unknown_station' in decision(e)['reasons']

def test_bad_signature():
    e=ev('phone_vision');assert verify_event(e,KEYS['phone_vision'])
    assert not verify_event(e,KEYS['pi_edge_vision'])

def make_img(change=False):
    img=np.zeros((120,160,3),dtype=np.uint8);img[:]=(80,100,125)
    cv2.rectangle(img,(30,30),(130,95),(220,220,220),-1)
    if change: cv2.rectangle(img,(50,50),(110,80),(0,0,0),-1)
    ok,enc=cv2.imencode('.png',img);assert ok
    return base64.b64encode(enc.tobytes()).decode()

def test_image_baseline():
    a=make_img();b=make_img(change=True)
    clear=evaluate_pair(a,a);diff=evaluate_pair(a,b)
    assert clear['candidate']=='NO_ANOMALY'
    assert diff['candidate']=='SUSPECT'
    assert diff['score_illustrative_not_probability']>clear['score_illustrative_not_probability']

def test_station_auth_and_idempotency(tmp_path):
    station=create_station_app('phone_vision',db_path=str(tmp_path/'phone.db'),station_secret=KEYS['phone_vision'],operator_token='operator_secret_long_123456')
    client=TestClient(station)
    inp={'specimen_id':'tab-B12','capture_id':'cam-capture-7','golden_b64':make_img(),'sample_b64':make_img(change=True)}
    assert client.post('/v1/capture',json=inp).status_code==403
    header={'x-operator-token':'operator_secret_long_123456'}
    r=client.post('/v1/capture',json=inp,headers=header);assert r.status_code==200
    assert r.json()['candidate']=='SUSPECT'
    r2=client.post('/v1/capture',json=inp,headers=header);assert r2.json()==r.json()
    rr=client.get('/v1/report/tab-B12',headers=header).json();assert len(rr['events'])==1
    inp['sample_b64']=make_img()
    assert client.post('/v1/capture',json=inp,headers=header).status_code==409

def test_camera_nodes_isolated_databases(tmp_path):
    phone=create_station_app('phone_vision',db_path=str(tmp_path/'phone.db'),station_secret=KEYS['phone_vision'],operator_token='operator_secret_long_123456')
    pi=create_station_app('pi_edge_vision',db_path=str(tmp_path/'pi.db'),station_secret=KEYS['pi_edge_vision'],operator_token='operator_secret_long_123456')
    c1,c2=TestClient(phone),TestClient(pi)
    headers={'x-operator-token':'operator_secret_long_123456'}
    inp={'specimen_id':'tab-B12','capture_id':'p7','golden_b64':make_img(),'sample_b64':make_img()}
    assert c1.post('/v1/capture',json=inp,headers=headers).status_code==200
    assert len(c2.get('/v1/report/tab-B12',headers=headers).json()['events'])==0

def test_agent_bridge_v14_2_evidence_contract():
    from dualvision.agent_bridge import to_agent_view
    records=both('NO_ANOMALY','SUSPECT')
    view=to_agent_view(records,KEYS)
    assert len(view)==2
    assert {x['kind'] for x in view.values()}=={'VISION'}
    assert all('image_sha256' not in x['payload'] for x in view.values())

def test_agent_bridge_rejects_forged():
    from dualvision.agent_bridge import to_agent_view
    records=both();records[0]['candidate']='SUSPECT'
    with pytest.raises(PermissionError):to_agent_view(records,KEYS)
