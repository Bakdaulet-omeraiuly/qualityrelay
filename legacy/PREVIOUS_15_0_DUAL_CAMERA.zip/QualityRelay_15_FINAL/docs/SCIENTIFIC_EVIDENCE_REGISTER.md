# Scientific evidence and novelty register — QualityRelay 15.0

**Read alongside `QUALITYRELAY_15_FINAL_MASTER_BLUEPRINT.md`.** This register is intentionally conservative.

## Established prior art

- CVPR 2022, Roth et al., *Towards Total Recall in Industrial Anomaly Detection* (PatchCore): https://openaccess.thecvf.com/content/CVPR2022/html/Roth_Towards_Total_Recall_in_Industrial_Anomaly_Detection_CVPR_2022_paper.html — representative patch memory-bank anomaly detection on industrial datasets. Not our algorithm.
- WACV 2024, Batzner et al., *EfficientAD*: https://openaccess.thecvf.com/content/WACV2024/html/Batzner_EfficientAD_Accurate_Visual_Anomaly_Detection_at_Millisecond-Level_Latencies_WACV_2024_paper.html — student/teacher visual anomaly detection and latency evaluation. Not our algorithm.
- MVTec AD: https://www.mvtec.com/research-teaching/datasets/mvtec-ad — widely used industrial visual benchmark; dataset is **non-commercial CC BY-NC-SA**, not a dataset to redistribute in our ZIP or treat as factory labels.
- NVIDIA TAO Visual ChangeNet reference: https://docs.nvidia.com/tao/tao-toolkit/latest/text/getting_started.html — paired visual change models are established; must reproduce on our parts before claiming any accuracy.
- Raspberry Pi Hailo documentation: https://www.raspberrypi.com/documentation/computers/ai.html and https://github.com/hailo-ai/hailo_model_zoo — hardware inference capability, Hailo-8L version compatibility and custom model export constraints.
- Nebius Token Factory docs: https://api.tokenfactory.nebius.com/docs — OpenAI-compatible inference endpoints; not proof that selected models improve engineering diagnosis.

## Own proposals and epistemic status

| Concept | Existing science involved | What might be original | What would falsify value |
|---|---|---|---|
| EVIDENCE-MESH | digital thread; causal evidence; provenance | efficient separate-scope peer exchange under offline constraints | same performance/availability as simple centralized records at equal rights |
| V-DER | Bayesian value of information and decision theory | domain-constrained implementation with process costs and agent evidence | no decision-loss gain beyond classic IG or rule-based inspection |
| CAIR | active perception / calibration / selective inspection | inspect-where-needed camera/caliper routing for factory evidence | performance and effort worse than fixed next action |
| PACE | safety review / conservative release policy | concrete provenance/dissent constraints | simple rules-only HOLD performs as well or better |
| PC-DAVER v15 | all above plus dual independent cameras | provenance-constrained cross-camera dissent routing in an independent station topology | no benefit after including 2-camera conservative rules baseline and correlated-error tests |

**No “scientific discovery proven” claim.** Real novelty requires broader prior-art search, reproducible physical evaluation, effect sizes/uncertainty and independent scrutiny.

## Evidence provenance matrix

- Previous v5 materials: inherited design assumptions and blueprints; not real factory measurements.
- v9 synthetic calculations: toy model results; the earlier V-DER vs IG differences were near zero, hence no established superiority.
- v14.2 automated tests: software correctness checks; not sensor accuracy or a deployed factory.
- v15 dual node automated tests: software integrity, dedup, disagreement, independent DB and policy checks; not camera detection accuracy.
- Physical print measurements: only valid after specimens actually printed and caliper/independent labels recorded.
- Hailo/NVIDIA/Nebius access: sponsor documentation shows possible resources, not live account integration in this ZIP.

## Reference wording in presentation

“We propose and evaluate an evidence-verified, decentralized multi-camera inspection protocol. We are testing if minority evidence preservation and cost-sensitive follow-up measurements improve the quality and efficiency of manufacturing decisions, compared with conservative non-agent baselines.”
