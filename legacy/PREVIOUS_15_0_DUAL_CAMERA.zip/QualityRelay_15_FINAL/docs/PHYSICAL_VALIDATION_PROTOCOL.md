# QualityRelay 15.0 — Physical Validation Protocol

**Owner:** HyorinmaruK (mechanical engineer). **Data Science review:** Bakdaulet. **Evidence/backend:** adilnurgg.

## Purpose

Determine whether two camera stations complement each other on **3D-printed Slot/Tab objects** and whether source-aware safety rules reduce unsafe review recommendations relative to fair baselines. A successful demonstration is not a production calibration or industrial certification.

## Before collecting test images

1. Freeze specimens, print files/CAD revision, illumination, camera stands and candidate defect taxonomy.
2. Label every physical piece with unique specimen ID visible outside the inspected region. If two specimens are joined, maintain pair ID and the two individual IDs.
3. Photograph both physical cameras independently; record timestamps, view angles, pixel dimensions and device IDs.
4. Caliper inspection must include instrument ID, units, verification, operating conditions, operator, specimen orientation and at least a repeated-gauge study on a stable reference coupon. Use measurement uncertainty—not CAD intended value—as the boundary for claims.
5. Set aside held-out physical specimens/print sessions **before** tuning any visual thresholds. Never train and test on the same frames/crops.
6. Establish safety: no sharp exposed wiring, no live mains for sorter, mechanical pinch protection, and a manual stop for actuator experiments.

## Minimum demonstrator cases

| Case | Geometry | Phone view | Pi view | Actual label |
|---|---|---|---|---|
| A | within local tolerance and safe clearance | clear | clear | safe only if verified physical assembly |
| B | local pass but poor paired clearance | looks normal | looks normal | dimension/assembly risk; do not rely on RGB |
| C | visible missing feature, caliper dimension within tolerance | suspect possible | suspect or clear depending on view | physically adjudicated visible defect |
| D | misleading glare/occlusion | uncertain | maybe clear | unknown until recapture |
| E | changed print session / viewpoint | shift | shift | dataset generalization challenge |
| F | Pi offline and phone online | clear or suspect | no fresh image | HOLD with partial evidence |

## Recommended data sheet columns

`specimen_id,part_type,print_batch,cad_revision,session_id,physical_ground_truth,adjudicator,operator,caliper_id,caliper_mm,caliper_repeat1_mm,caliper_repeat2_mm,gauge_uncertainty_mm,phone_device_id,phone_image_sha256,phone_camera_view,phone_model_version,phone_candidate,pi_device_id,pi_image_sha256,pi_camera_view,pi_model_version,pi_candidate,policy_review_status,approved_by,actual_assembly_fit,sorter_command_id,arrival_sensor_event_id,actual_bin,notes`

**Missing result != normal.** Use an explicit `MISSING` or `NOT_MEASURED` value.

## Statistical analysis

- Main performance unit: specimen/independent print batch. A dozen frames from one object are repeated views, not independent specimens.
- Report uncertainty intervals for false-PASS rate and absolute risk difference. If no unsafe examples exist, do not report 0% false-PASS.
- Cluster bootstrap by specimen/batch for paired policy differences.
- Include conservative rules-only HOLD baseline. If your new multi-agent policy only raises HOLD frequency, report its extra inspection burden and compare on identical unsafe-PASS constraints.
- Use inspection cost schedule declared before running, not chosen to make QualityRelay win.
- Record calibration score/threshold and complete model lineage per camera. Separate CNN probability calibration from OpenCV difference fraction (not a probability).
- Hold out one illumination/view/batch condition specifically to test domain shift.

## Camera calibration and go/no-go

Phone/Pi defect detection: demonstrate acceptable recall/false-alarm performance on actual target defects with test intervals. **No numerical accuracy promise before data.** 

Phone/Pi metrology: DO NOT infer 0.1 mm reliably from unconstrained RGB. If calibrated planar optical metrology is attempted, include fiducial pitch, lens distortion, pose homography, focus, repeated measurements, gauge comparison and total uncertainty. Make no pass/fail decisions near decision boundaries unless uncertainty tolerances and human validation support them.

## Counting if sorter is installed

An image frame is **not** a new piece. Count inspected and physically routed parts independently by stable specimen ID. Require authenticated command, operator authorization, servo route result **and** sensor arrival ack. No arrival = not physically counted. Hold missing/duplicate/contradictory acknowledgements.

## Deliverables

- Three signed review sheets, annotated specimen photos, camera-position photos and instrument readings.
- Machine-readable CSV dataset manifest, immutable hashes, frozen model/config versions and reviewer comments.
- One reproducible baseline comparison and uncertainty statement, even if effect is neutral/negative.
- Final slide says **prototype tested on N physical specimens**, not "factory-ready".
