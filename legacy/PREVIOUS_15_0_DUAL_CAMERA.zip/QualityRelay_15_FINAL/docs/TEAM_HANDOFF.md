# QualityRelay 15.0 — exact team handoff

## Shared rule

**Only one Google Cloud deployment owner team: adilnurgg + HyorinmaruK.** Bakdaulet does not set up, administer, troubleshoot, provision or deploy Google Cloud. The hackathon gives a maximum of two Google Cloud accounts per team; temporary accounts are deleted Sunday night according to the event handout.

## Bakdaulet — Scientific lead

- Register hypotheses, data splits, labels, controlled comparison arms B0–B10 and matching random seeds.
- Own target false-PASS / HOLD metrics, cost matrix, information-theoretic inspection and calibrated uncertainty.
- NVIDIA Brev/GPU usage: optional, for real visual-model comparisons only after physical data and baseline exist; track GPU billing and stop instances.
- Own results: experimental CSV schema, statistical summary, comparison chart, reproducibility manifest, honest claim register.
- Hand-off to adilnurgg: a versioned JSON `inspection_result`, score semantics (not fake probabilities), model identity and event ID requirements.
- Hand-off to HyorinmaruK: exact physical labels needed; calibration and validation protocol, printed specimen plan, presentation results with uncertainty.

## adilnurgg — Backend and agent owner

- Own station services, separated SQLite stores, signature verification, event dedup, offline/reconnect behavior, permission scopes, audit trail and bounded LLM tools.
- Nebius Token Factory/model access is distinct from H100 GPU, use one model ID returned by account, private secrets, strict tool schemas and response validation.
- P0: services on separate processes; validated `HOLD` on disagreement and missing/forged evidence; real phone/Pi station summaries; APIs and tests.
- P1: self-hosted single-domain authenticated gateway, Google Cloud backend (or an alternative authorized host), HTTPS, operator auth, monitoring and deployment diagnostics.
- Hand-off to HyorinmaruK: API URLs, sample payloads, CORS/proxy plan and status flags; device token onboarding.

## HyorinmaruK — Mechanical engineer + UX/validation/presentation

- Borrow Pi 5 + Hailo-8L + Pi camera early; check power, compatible Pi OS/camera and Hailo runtime **before** proposing HEF conversion.
- Build mounts, lighting, part fixtures, 3D-print Slot/Tab, and digital-caliper measurement record; avoid servo-driven caliper jaws.
- Use real independent Pi photo acquisition; if Hailo neural model is not compatible, use OpenCV CPU and label backend clearly.
- Take blinded physical labels, collect paired camera views and record Assembly fit observations.
- Own site UX and Google Cloud frontend/deployment together with adilnurgg.
- Own **final presentation**: clear problem, baseline, actual evidence, uncertainty, limitations, photo of real apparatus and readable result chart. No synthetic chart represented as physical.

## Optional 4th member — adversarial QA

- Blind-label a held-out batch; run credential, injection, identity, stale source, replay, offline, duplicate count and actuation denial tests.
- Independently review paper/novelty claims; execute reproducibility and security gates. Supply signed QA note.

## Merge order

1. Freeze schema fields and ID conventions; review by adilnurgg + Bakdaulet.
2. Device data capture by HyorinmaruK, signal/numeric semantics reviewed by Bakdaulet.
3. Backend merges station contracts; v14.2 specialist adapter stays evidence-scoped; no new tool privileges.
4. UI merges and displays source availability, classifier mode, missing sources and original evidence IDs.
5. One mandatory adversarial scenario: phone clear, Pi suspect, manual caliper pass ⇒ `HOLD` with dissent retained.
6. Run new 15.0 tests and inherited 14.2 tests, compare manifests and save an immutable tagged release.
7. HyorinmaruK rehearses final physical demo; Bakdaulet checks metric claims; adilnurgg verifies API logs.
