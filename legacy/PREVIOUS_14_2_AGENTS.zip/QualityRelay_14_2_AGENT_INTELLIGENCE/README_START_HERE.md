# QualityRelay 14.2 — Start Here

**This is an additive, evidence-grounded agent upgrade to QualityRelay 14.0.** It preserves the original v14 archive byte-for-byte under `reference_14/`, including v5, v8, v9, v10, v12 and v13.1 assets. It does not alter your previous files in place.

## Жаңа не бар?

- **21 мамандықтың рөлдік контрактілері** — бірақ 21 бөлек үйретілген нейрожелі емес.
- **Nebius LLM tool-calling loop** — LLM құралды сұрайды; бекітілген backend ғана орындайды; модельге тек расталған деректер беріледі.
- **Per-role permission** — бір маман басқа станцияның құпия шикі деректерін еркін аша алмайды.
- **Evidence-Mesh reference** — станциялардың жеке деректері, scoped signed summaries, қайталанған event ID тексеруі және offline/denial тесттері.
- **Independent decision gate** — соңғы PASS/REJECT-ті LLM шешпейді; күмәнді жағдай HOLD.
- **One web demo** — бұрынғы телефон камерасы + caliper OCR + жаңа AI-мамандар симуляциясы.
- **65/65 reference tests passed** at package creation (40 new + 25 inherited); run again on your machine before relying on this.

## 1. Тегін offline тексеру

```bash
cd QualityRelay_14_2_AGENT_INTELLIGENCE
python3 -m pytest -q tests implementation/tests
python3 -m agent_runtime.demo
```

Бірінші тәжірибе **SIMULATED** екенін жасырмайды. Кез келген қорғау/кейіптеу тесті түпкілікті өндірістік тексеріс емес.

## 2. Бір сайт

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install -r implementation/requirements.txt
PYTHONPATH=.:implementation uvicorn agent_runtime.unified_app:app --reload
```

Open <http://127.0.0.1:8000/> on your Mac. For iPhone on another device, use HTTPS and an appropriately secured server/tunnel. Do **not** expose a debug server with manufacturing data on public internet.

New page block: **7. Engineering agents (simulated test)**. It only runs the free scripted fake agent (not a paid AI). The actual Nebius tool-call session is a separate opt-in CLI action; read the full Master MD for provider access and safety.

## 3. Nebius live session (optional, costs credits)

Check which Nebius service you actually have. Token Factory is not the same as the shared H100 or Scientific AI Platform. Set `NEBIUS_API_KEY`, then choose a model ID from your account's `/v1/models`; set `NEBIUS_MODEL`. Only if you accept a real inference call:

```bash
export ALLOW_LIVE_NEBIUS_REVIEW=YES
python3 -m agent_runtime.live_review
```

No live key was used to develop this package. Never commit `.env`, screenshots of credentials or event redemption links.

## 4. Files

- `QUALITYRELAY_14_2_AGENT_INTELLIGENCE_MASTER.md` — one updated scientific and implementation Master Blueprint (plus full original v14 text in appendix).
- `agent_runtime/` — reference tool-calling and evidence-validation code.
- `implementation/qualityrelay14/` — directly copied original 14 phone/camera prototype code; `implementation/tests/` preserves inherited tests.
- `web/index.html` — previous web front end with new simulated agent section.
- `reference_14/QualityRelay_14_COMPLETE_ORIGINAL.zip` — byte-unchanged full previous package.
- `tests/` — new agent safety tests; `results/` — simulated test log.
- `schemas/` — JSON schemas for source evidence and agent proposal.
- `.env.example` — optional environment variable template, no secrets.

## Scientific integrity

The status `PASS_REVIEW` is not a human-approved PASS. All demo-created specimens are `origin=simulated`; none are claimed as experimental factory validation. The simulated demo does not use paid LLMs or NVIDIA inference. LLM provider, model and actual factory performance must be separately verified. The work is an **engineering research reference**, not an industrial safety product.
