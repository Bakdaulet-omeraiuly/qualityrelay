"""Optional FastAPI reference endpoints for web integration.
No anonymous live provider endpoint; no secrets in responses.
Run: uvicorn agent_runtime.api:app --reload
"""
from fastapi import FastAPI
from pydantic import BaseModel,Field
from .roles import ROLES
from .demo import demo_case

app=FastAPI(title='QualityRelay 14.2 Specialist Brain API',version='14.2-reference')
class DemoParams(BaseModel):
    visual_suspect:bool=True
    role_budget:int=Field(4,ge=1,le=21)

@app.get('/api/agent-intelligence/health')
def health():
    return {'reference_version':'14.2','specialist_role_contracts':len(ROLES),
            'live_nebius_default':False,'safe_hardware_action':False,
            'real_peer_network_deployed':False,'outcomes_calibrated':False}

@app.get('/api/agent-intelligence/roles')
def roles():
    return [{'name':v.name,'domain':v.domain,'tools':v.tools,'required_sources':v.required_sources,
             'status':'ROLE_CONTRACT_WITH_BOUNDED_TOOLS_NOT_TRAINED_PERSONA'} for v in ROLES.values()]

@app.post('/api/agent-intelligence/simulate')
def simulate(x:DemoParams):
    # Deliberately simulate without live keys or claims.
    return demo_case(visual_suspect=x.visual_suspect, role_budget=x.role_budget)
