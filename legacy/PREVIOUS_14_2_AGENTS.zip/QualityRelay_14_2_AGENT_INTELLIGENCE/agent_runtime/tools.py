"""Only backend grants tools. JSON shapes are exact, no free-form SQL/shell/HTTP.
A role may never see full raw station databases.
"""
from dataclasses import dataclass
from decimal import Decimal
from typing import Any
from .roles import ROLES

SCHEMAS = {
 "read_evidence":{"event_id":"string"},
 "check_clearance":{"slot_event_id":"string", "tab_event_id":"string"},
 "check_visual":{"visual_event_id":"string"},
 "request_inspection":{"action":"enum", "specimen_id":"string"},
}
INSPECTIONS={"recapture_caliper", "manual_caliper", "top_photo", "side_photo", "engineer_review"}

@dataclass
class AgentContext:
    role_name: str
    visible: dict[str,dict]
    returned_ids: set[str]
    audit: list[dict]
    tool_calls: int = 0
    max_calls: int = 5
    def __post_init__(self):
        if self.role_name not in ROLES: raise ValueError("unknown role")
        allowed=set(ROLES[self.role_name].required_sources)
        if any(ev.get('kind') not in allowed for ev in self.visible.values()):
            raise PermissionError('role received evidence outside server-granted scope')


def tool_definitions(ctx):
    defs=[]
    for name in ROLES[ctx.role_name].tools:
        props={}
        for arg, typ in SCHEMAS[name].items():
            props[arg]={"type":"string"}
            if typ=='enum': props[arg]["enum"]=sorted(INSPECTIONS)
        defs.append({"type":"function", "function": {"name":name,"description":"Read verified evidence or propose non-actuating inspection. Numeric truth is tool-owned.","parameters":{"type":"object","properties":props,"required":list(props),"additionalProperties":False}}})
    return defs


def call_tool(ctx:AgentContext,name:str,args:dict[str,Any]):
    if ctx.tool_calls >= ctx.max_calls: raise RuntimeError("tool budget exceeded")
    ctx.tool_calls += 1
    if name not in ROLES[ctx.role_name].tools: raise PermissionError("tool not authorized for role")
    expected=SCHEMAS[name]
    if not isinstance(args,dict) or set(args)!=set(expected): raise ValueError("tool arguments not exact schema")
    if not all(isinstance(v,str) and len(v)<=120 for v in args.values()): raise ValueError("invalid tool arguments")
    if name=='request_inspection':
        if args['action'] not in INSPECTIONS: raise ValueError("inspection not allowlisted")
        known_specimens = {e['specimen_id'] for e in ctx.visible.values()}
        if args['specimen_id'] not in known_specimens: raise PermissionError('specimen not scoped to role')
        result={"proposed_action":args['action'],"specimen_id":args['specimen_id'],"actuated":False,"requires_human":True}
    else:
        ids= [args[k] for k in expected if k.endswith('event_id')]
        records=[]
        for event_id in ids:
            if event_id not in ctx.visible: raise PermissionError("event not scoped to role")
            rec=ctx.visible[event_id]
            # This is the only data pathway from evidence store into model context.
            records.append(rec)
        ctx.returned_ids.update(ids)
        if name=='read_evidence':
            result=records[0]
        elif name=='check_visual':
            r=records[0]
            if r['kind']!='VISION': raise ValueError("not vision evidence")
            p=r['payload']; result={"suspected":p.get('defect_suspected',None),"usable":p.get('visual_usable',False),"source_event_ids":ids,"calibrated":False}
        elif name=='check_clearance':
            a,b=records
            if a['kind']!='METROLOGY' or b['kind']!='METROLOGY': raise ValueError("not metrology evidence")
            if a['specimen_id']==b['specimen_id']: raise ValueError("same specimen")
            if not a['payload'].get('caliper_verified') or not b['payload'].get('caliper_verified'):
                result={"status":"UNVERIFIED", "source_event_ids":ids}
            else:
                w=Decimal(str(a['payload']['width_mm'])); t=Decimal(str(b['payload']['thickness_mm']))
                if not all(x.is_finite() and 0<x<1000 for x in (w,t)): raise ValueError('invalid size')
                clearance=w-t
                # Original v5 demonstrator values. These are NOT factory acceptance criteria.
                sufficient=clearance>=Decimal('0.5')
                result={"clearance_mm":str(clearance),"min_clearance_mm":"0.5", "sufficient":sufficient,
                        "v5_educational_demo_only":True,"source_event_ids":ids}
        else: raise ValueError("invalid tool")
    ctx.audit.append({"role":ctx.role_name,"tool":name,"arguments":args,"status":"executed_no_actuation"})
    return result
