"""Runnable no-key demonstration. Synthetic records always explicitly labeled.
Usage: python -m agent_runtime.demo
"""
import json
from datetime import datetime, timezone
from .evidence import Evidence,Station,EvidenceMesh
from .roles import ROLES,plan_roles
from .runtime import run_agent,evidence_gate
from .reconcile import independence_report


def demo_case(physical=False, visual_suspect=True, role_budget=4, brain_factory=None):
    # Demonstration-generated observations are ALWAYS simulated regardless of caller.
    origin='simulated'
    now=datetime.now(timezone.utc).isoformat()
    ns={s:Station(s,('demo-only-'+s).encode()) for s in ('slot','tab','vision','assembly','sorter')}
    values=[('slot','s-01','SLOT-A03','METROLOGY',{'width_mm':'20.6','caliper_verified':True,'gauge_id':'demo-G1','unit':'mm'}),
            ('tab','t-01','TAB-B07','METROLOGY',{'thickness_mm':'20.3','caliper_verified':True,'gauge_id':'demo-G1','unit':'mm'}),
            ('vision','v-01','TAB-B07','VISION',{'defect_suspected':visual_suspect,'visual_usable':True})]
    for station,eid,spec,kind,payload in values:
        ns[station].insert(Evidence(eid,spec,kind,station,payload,now,origin=origin))
    mesh=EvidenceMesh(ns)
    evidence=[mesh.request('assembly','slot','s-01',{'METROLOGY'}),
              mesh.request('assembly','tab','t-01',{'METROLOGY'}),
              mesh.request('assembly','vision','v-01',{'VISION'})]
    selected=plan_roles(bool(evidence),True,budget=role_budget)
    reviews=[]
    for role in selected:
        allowed = set(ROLES[role].required_sources)
        view={e['event_id']:e for e in evidence if e['kind'] in allowed}
        # Physical deployments must also enforce role permissions at each peer node.
        brain=brain_factory() if brain_factory else None
        reviews.append(run_agent(role,view,brain=brain))
    decision=evidence_gate(evidence,reviews)
    return {'mode':'SIMULATED_RESEARCH_REFERENCE','live_llm_not_verified_here':brain_factory is not None,
            'model_runs_were_real':False,'station_names':sorted(ns),
            'selected_roles':selected,'reviews':reviews,
            'independence':independence_report(reviews,evidence),
            'decision_gate':decision,'mesh_audit':mesh.audit,
            'next_physical_step':'Run independently measured and labeled real specimens. Never claim simulation as physical validation.'}

if __name__=='__main__':
    print(json.dumps(demo_case(),ensure_ascii=False,indent=2))
