"""One FastAPI app for the phone vision demo and the new agent API.
Start from bundle root: PYTHONPATH=.:implementation uvicorn agent_runtime.unified_app:app --reload
"""
from qualityrelay14.api import app
from .api import app as agent_app
app.include_router(agent_app.router)
