"""Do not count repeated model opinion as independent sensor evidence."""

def independence_report(reviews: list[dict], evidence: list[dict]):
    mapping={x['event_id']:x for x in evidence}
    by_root={}
    for r in reviews:
        p=r.get('proposal',{})
        for id in p.get('evidence_ids',[]):
            src=mapping.get(id)
            if not src: continue
            roots=src.get('source_event_ids') or [id]
            for root in roots:by_root.setdefault(root,set()).add(r['role'])
    dissent=[]
    # No majority vote by AI roles; flag contradictory instrument vs vision in a real incident.
    met=[x for x in evidence if x['kind']=='METROLOGY']
    vis=[x for x in evidence if x['kind']=='VISION']
    if met and any(x.get('payload',{}).get('defect_suspected') for x in vis):
        dissent.append('vision_suspicion_not_cancelled_by_in_tolerance_metrology')
    return {'unique_independent_root_ids':sorted(by_root),
            'agent_citations_by_root':{k:sorted(v) for k,v in by_root.items()},
            'critical_dissent':dissent,
            'vote_count_is_not_statistical_confidence':True}
