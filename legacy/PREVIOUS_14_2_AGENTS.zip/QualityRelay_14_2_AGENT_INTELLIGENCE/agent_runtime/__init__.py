"""QualityRelay 14.2: bounded, evidence-grounded agent research reference."""
