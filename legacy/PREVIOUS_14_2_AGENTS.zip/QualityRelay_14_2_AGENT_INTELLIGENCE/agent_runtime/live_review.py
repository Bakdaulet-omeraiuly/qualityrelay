"""Opt-in live Nebius test with simulated evidence only.
This consumes the team's Nebius Token Factory API quota. Never run at import time.
"""
import json,os
from .brain import NebiusBrain
from .demo import demo_case

if __name__=='__main__':
    if os.getenv('ALLOW_LIVE_NEBIUS_REVIEW')!='YES':
        raise SystemExit('Set ALLOW_LIVE_NEBIUS_REVIEW=YES explicitly before a paid live model call.')
    # The factory checks the current /models catalog; do not hardcode model names.
    out=demo_case(role_budget=2,brain_factory=NebiusBrain)
    out['successful_model_review_count']=sum('fallback_reason' not in r for r in out['reviews'])
    out['source_is_simulated_even_with_real_model']=True
    print(json.dumps(out,indent=2))
