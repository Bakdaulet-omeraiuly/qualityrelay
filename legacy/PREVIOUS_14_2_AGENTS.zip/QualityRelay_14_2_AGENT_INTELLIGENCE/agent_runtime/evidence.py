"""Local evidence nodes + bounded authorized summaries.
The in-memory message broker is demonstrative, not a deployed peer mesh.
"""
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from typing import Any
import hashlib, hmac, json

ALLOWED_KINDS = frozenset({"METROLOGY", "VISION", "CAD", "PROCESS", "CNC", "PRINT_LOG", "CERTIFICATE", "SPC", "MODEL", "MAINTENANCE", "SUPPLIER", "AUTH_AUDIT", "NETWORK", "RUN_MANIFEST", "IMPROVEMENT"})

@dataclass(frozen=True)
class Evidence:
    event_id: str
    specimen_id: str
    kind: str
    origin_station: str
    payload: dict[str, Any]
    observed_at: str
    origin: str = "physical"  # or simulated; must never be blurred
    source_event_ids: tuple[str, ...] = ()
    # reference events have no cryptographic signature; authenticated envelope is separate

    def __post_init__(self):
        if self.kind not in ALLOWED_KINDS: raise ValueError("invalid evidence kind")
        if self.origin not in {"physical", "simulated"}: raise ValueError("invalid evidence origin")
        if not self.event_id or not self.specimen_id or not self.origin_station: raise ValueError("missing id")
        if not isinstance(self.payload, dict): raise ValueError("invalid payload")
        if len(json.dumps(self.payload)) > 6000: raise ValueError("payload too large")
        datetime.fromisoformat(self.observed_at.replace('Z', '+00:00'))

    def is_fresh(self, now: datetime, max_age_seconds: int) -> bool:
        t = datetime.fromisoformat(self.observed_at.replace('Z', '+00:00'))
        if t.tzinfo is None: return False
        dt = (now - t).total_seconds()
        return 0 <= dt <= max_age_seconds

    def summary(self):
        # Only strictly allowlisted machine fields are allowed across station boundaries.
        fields = {"width_mm", "thickness_mm", "caliper_verified", "defect_suspected", "visual_usable", "cad_revision", "gauge_id", "unit", "confidence_label"}
        return {"event_id":self.event_id, "specimen_id":self.specimen_id,
                "kind":self.kind, "origin_station":self.origin_station,
                "observed_at":self.observed_at, "origin":self.origin,
                "payload":{k:v for k,v in self.payload.items() if k in fields},
                "source_event_ids":list(self.source_event_ids)}

class Station:
    def __init__(self, name: str, key: bytes):
        self.name=name; self._key=key; self._evidence={}; self.online=True
    def insert(self, ev: Evidence):
        if ev.origin_station!=self.name: raise PermissionError("station origin mismatch")
        old=self._evidence.get(ev.event_id)
        if old and old!=ev: raise ValueError("event id collision")
        self._evidence[ev.event_id]=ev
    def local(self, event_id):
        return self._evidence.get(event_id)
    def signed_summary(self, event_id, request_station, allowed_kinds):
        if not self.online: raise ConnectionError("station offline")
        ev=self._evidence[event_id]
        if ev.kind not in allowed_kinds: raise PermissionError("unauthorized evidence kind")
        body={"requested_by":request_station,"summary":ev.summary()}
        raw=json.dumps(body,sort_keys=True,separators=(',',':')).encode()
        return {"body":body,"signature":hmac.new(self._key,raw,hashlib.sha256).hexdigest()}

# Reviewer grants are server-controlled; input allowlists cannot enlarge them.
STATION_SCOPE = {
    ('assembly','slot'): {'METROLOGY','CAD'},
    ('assembly','tab'): {'METROLOGY','CAD'},
    ('assembly','vision'): {'VISION'},
    ('slot','assembly'): {'MODEL'},
    ('tab','assembly'): {'MODEL'},
    ('sorter','assembly'): {'MODEL'},
    ('assembly','sorter'): {'MODEL'},
}

class EvidenceMesh:
    def __init__(self, stations: dict[str,Station]):
        self.stations=stations; self.received={}; self.audit=[]
    def request(self, requester: str, source: str, event_id: str, allowed_kinds: set[str]):
        if requester not in self.stations or source not in self.stations:
            raise PermissionError("unknown station")
        granted=STATION_SCOPE.get((requester,source),set())
        if not allowed_kinds or not allowed_kinds.issubset(granted):
            self.audit.append({'kind':'scope_denied','requester':requester,'source':source,'event_id':event_id})
            raise PermissionError('station-to-station scope denied')
        signed=self.stations[source].signed_summary(event_id,requester,allowed_kinds)
        raw=json.dumps(signed['body'],sort_keys=True,separators=(',',':')).encode()
        expected=hmac.new(self.stations[source]._key,raw,hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected,signed['signature']): raise PermissionError("signature mismatch")
        ev=signed['body']['summary']
        key=(requester,ev['event_id'])
        prev=self.received.get(key)
        if prev is not None and prev!=ev: raise ValueError("conflicting replay")
        self.received[key]=ev
        self.audit.append({"kind":"authorized_summary", "requester":requester,"source":source,"event_id":event_id})
        return ev
