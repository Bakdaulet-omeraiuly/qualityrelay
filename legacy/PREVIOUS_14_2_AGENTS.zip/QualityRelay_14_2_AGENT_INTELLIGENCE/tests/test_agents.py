from datetime import datetime, timezone,timedelta
import json
import pytest
from agent_runtime.roles import ROLES,plan_roles
from agent_runtime.tools import AgentContext,call_tool,tool_definitions
from agent_runtime.evidence import Evidence,Station,EvidenceMesh
from agent_runtime.runtime import run_agent, evidence_gate, validate_proposal
from agent_runtime.reconcile import independence_report
from agent_runtime.demo import demo_case

NOW=datetime.now(timezone.utc)

def rec(id,kind,payload,origin='physical', station='slot',old_seconds=0,parents=None):
    return Evidence(id,'SPEC-01',kind,station,payload,(NOW-timedelta(seconds=old_seconds)).isoformat(),origin,tuple(parents or [])).summary()

class FailingBrain:
    def respond(self,messages,tools):raise RuntimeError('provider outage')
class BadBrain:
    def __init__(self, s):self.s=s
    def respond(self,messages,tools):return {'content':self.s,'tool_calls':[]}
class ToolBrain:
    def __init__(self):self.rounds=0
    def respond(self,messages,tools):
        self.rounds+=1
        if self.rounds==1:
            return {'content':None,'tool_calls':[{'id':'call-X','name':'read_evidence','arguments':{'event_id':'s1'}}]}
        return {'content':json.dumps({'kind':'OBSERVATION','claim':'Measurement returned','evidence_ids':['s1'], 'next_action':'engineer_review','confidence_label':'low'}),'tool_calls':[]}
class IllegalToolBrain:
    def respond(self,messages,tools):
        return {'content':None,'tool_calls':[{'id':'X','name':'actuate_servo','arguments':{}}]}
class RepeatBrain:
    def respond(self,messages,tools):return {'content':None,'tool_calls':[{'id':'X','name':'read_evidence','arguments':{'event_id':'s1'}}]}


def test_exact_21_original_specialists():
    assert len(ROLES)==21
    for name in ['metrology_engineer','assembly_engineer','scientific_auditor','privacy_security','safety_governance','kaizen_pdca']:
        assert name in ROLES

def test_role_trigger_budget():
    assert len(plan_roles(True,True,21))<=7
    assert len(plan_roles(True,False,2))==2

def test_tool_not_granted():
    ctx=AgentContext('design_geometry',{'s1':rec('s1','CAD',{'cad_revision':'A'})},set(),[])
    with pytest.raises(PermissionError):call_tool(ctx,'check_clearance',{'slot_event_id':'s1','tab_event_id':'t1'})

def test_tool_nonexistent_for_any_role():
    ctx=AgentContext('quality_inspector',{},set(),[])
    with pytest.raises(PermissionError):call_tool(ctx,'execute_shell',{})

def test_tool_schema_rejects_extra_args():
    ctx=AgentContext('quality_inspector',{},set(),[])
    with pytest.raises(ValueError):call_tool(ctx,'read_evidence',{'event_id':'s1','sql':'SELECT *'})

def test_unseen_id_is_denied():
    ctx=AgentContext('quality_inspector',{},set(),[])
    with pytest.raises(PermissionError):call_tool(ctx,'read_evidence',{'event_id':'secret'})

def test_tool_budget_enforced():
    ctx=AgentContext('quality_inspector',{'s1':rec('s1','METROLOGY',{})},set(),[],max_calls=1)
    call_tool(ctx,'read_evidence',{'event_id':'s1'})
    with pytest.raises(RuntimeError):call_tool(ctx,'read_evidence',{'event_id':'s1'})

def test_clearance_tool_math():
    ctx=AgentContext('assembly_engineer',{
       's1':rec('s1','METROLOGY',{'width_mm':'20.6','caliper_verified':True}),
       't1':{**rec('t1','METROLOGY',{'thickness_mm':'20.3','caliper_verified':True}), 'specimen_id':'SPEC-02'}},set(),[])
    out=call_tool(ctx,'check_clearance',{'slot_event_id':'s1','tab_event_id':'t1'})
    assert out['clearance_mm']=='0.3' and not out['sufficient']

def test_unverified_caliper_cannot_become_verified():
    ctx=AgentContext('assembly_engineer',{
      's1':rec('s1','METROLOGY',{'width_mm':'20.6','caliper_verified':False}),
      't1':{**rec('t1','METROLOGY',{'thickness_mm':'20.0','caliper_verified':True}), 'specimen_id':'SPEC-02'}},set(),[])
    assert call_tool(ctx,'check_clearance',{'slot_event_id':'s1','tab_event_id':'t1'})['status']=='UNVERIFIED'

def test_scripted_loop_reads_tool():
    result=run_agent('quality_inspector',{'s1':rec('s1','METROLOGY',{'width_mm':'20.6'})})
    assert result['tool_calls']==1
    assert result['proposal']['evidence_ids']==['s1']
    assert result['verified'] is False

def test_realistic_fake_model_tool_loop():
    result=run_agent('quality_inspector',{'s1':rec('s1','METROLOGY',{})},ToolBrain())
    assert result['proposal']['kind']=='OBSERVATION' and result['tool_calls']==1

def test_provider_outage_safe_abstain():
    result=run_agent('quality_inspector',{'s1':rec('s1','METROLOGY',{})},FailingBrain())
    assert result['proposal']['kind']=='ABSTAIN'
    assert result['fallback_reason']=='provider_failure'

def test_invented_evidence_id_denied():
    bad={'kind':'OBSERVATION','claim':'all passed','evidence_ids':['invented'],'next_action':'none','confidence_label':'high'}
    result=run_agent('quality_inspector',{'s1':rec('s1','METROLOGY',{})},BadBrain(json.dumps(bad)))
    assert result['fallback_reason']=='invalid_proposal'

def test_final_pass_claim_not_machine_authority():
    good={'kind':'OBSERVATION','claim':'PASS approved','evidence_ids':['s1'],'next_action':'none','confidence_label':'high'}
    ctx=AgentContext('quality_inspector',{'s1':rec('s1','METROLOGY',{})},{'s1'},[])
    assert validate_proposal(good,ctx)['claim']=='PASS approved'
    result=evidence_gate([], [{'proposal':good}])
    assert result['review_status']=='HOLD' and result['may_route_hardware'] is False

def test_model_requests_servo_denied():
    result=run_agent('quality_inspector',{},IllegalToolBrain())
    assert result['fallback_reason']=='denied_tool'

def test_max_rounds_stops_infinite_tool_loop():
    result=run_agent('quality_inspector',{'s1':rec('s1','METROLOGY',{})},RepeatBrain(),max_calls=2,max_rounds=5)
    assert result['fallback_reason']=='tool_budget_exceeded'

def test_weak_evidence_hold():
    e=[rec('s1','METROLOGY',{'width_mm':'21','caliper_verified':False})]
    assert evidence_gate(e,[])['review_status']=='HOLD'

def test_simulated_cannot_claim_physical_validation():
    e=[rec('s1','METROLOGY',{'width_mm':'21','caliper_verified':True},origin='simulated')]
    assert 'simulation_is_not_physical_validation' in evidence_gate(e,[])['reasons']

def test_stale_evidence_fails_closed():
    e=[rec('s1','METROLOGY',{'width_mm':'21','caliper_verified':True},old_seconds=4000)]
    assert 'missing_or_stale_evidence' in evidence_gate(e,[],now=NOW)['reasons']

def test_visual_suspicion_overrides_good_clearance():
    es=[rec('s1','METROLOGY',{'width_mm':'21','caliper_verified':True}),
        {**rec('t1','METROLOGY',{'thickness_mm':'20','caliper_verified':True}), 'specimen_id':'SPEC-02'},
        rec('v1','VISION',{'defect_suspected':True,'visual_usable':True})]
    out=evidence_gate(es,[],now=NOW)
    assert 'possible_visual_defect' in out['reasons'] and out['review_status']=='HOLD'

def test_physically_healthy_still_review_only():
    es=[rec('s1','METROLOGY',{'width_mm':'21','caliper_verified':True}),
        {**rec('t1','METROLOGY',{'thickness_mm':'20','caliper_verified':True}),'specimen_id':'SPEC-02'},
        rec('v1','VISION',{'defect_suspected':False,'visual_usable':True})]
    out=evidence_gate(es,[],now=NOW)
    assert out['review_status']=='PASS_REVIEW' and out['human_approval_required'] and not out['may_route_hardware']

def test_duplicate_event_conflict_hold():
    a=rec('s1','METROLOGY',{'width_mm':'21','caliper_verified':True})
    b=rec('s1','METROLOGY',{'width_mm':'22','caliper_verified':True})
    out=evidence_gate([a,b],[])
    assert 'evidence_id_collision' in out['reasons']

def test_dedup_root_evidence_no_duplicate_votes():
    e1=rec('s1','METROLOGY',{'width_mm':'21'},parents=['root-01'])
    e2=rec('s2','METROLOGY',{'width_mm':'21'},parents=['root-01'])
    rev=[{'role':'a','proposal':{'evidence_ids':['s1']}},{'role':'b','proposal':{'evidence_ids':['s2']}}]
    report=independence_report(rev,[e1,e2])
    assert report['unique_independent_root_ids']==['root-01']

def test_minority_visual_warning_preserved():
    e=[rec('s1','METROLOGY',{'width_mm':'21'}),rec('v1','VISION',{'defect_suspected':True})]
    assert independence_report([],e)['critical_dissent']

def test_station_enforces_origin():
    st=Station('slot',b'k')
    with pytest.raises(PermissionError):st.insert(Evidence('e','X','METROLOGY','tab',{},NOW.isoformat()))

def test_station_acl_denies_cross_station():
    ns={x:Station(x,x.encode()) for x in ('assembly','slot','tab')}
    ns['tab'].insert(Evidence('test','X','METROLOGY','tab',{},NOW.isoformat()))
    mesh=EvidenceMesh(ns)
    with pytest.raises(PermissionError):mesh.request('slot','tab','test',{'METROLOGY'})

def test_station_sanitizes_raw_customer_data():
    ns={x:Station(x,x.encode()) for x in ('assembly','tab')}
    ns['tab'].insert(Evidence('test','X','METROLOGY','tab',{'thickness_mm':'20','supplier_secret':'DO_NOT_LEAK'},NOW.isoformat()))
    mesh=EvidenceMesh(ns)
    ev=mesh.request('assembly','tab','test',{'METROLOGY'})
    assert 'supplier_secret' not in json.dumps(ev)

def test_station_offline_not_faked():
    ns={x:Station(x,x.encode()) for x in ('assembly','tab')}
    ns['tab'].insert(Evidence('test','X','METROLOGY','tab',{},NOW.isoformat()))
    ns['tab'].online=False
    with pytest.raises(ConnectionError):EvidenceMesh(ns).request('assembly','tab','test',{'METROLOGY'})

def test_idempotent_evidence_replay():
    ns={x:Station(x,x.encode()) for x in ('assembly','tab')}
    ns['tab'].insert(Evidence('test','X','METROLOGY','tab',{},NOW.isoformat()))
    m=EvidenceMesh(ns);a=m.request('assembly','tab','test',{'METROLOGY'});b=m.request('assembly','tab','test',{'METROLOGY'})
    assert a==b and len(m.received)==1

def test_cannot_use_inspection_to_actuate():
    ctx=AgentContext('inspection_planner',{'v1':rec('v1','VISION',{})},set(),[])
    result=call_tool(ctx,'request_inspection',{'action':'manual_caliper','specimen_id':'SPEC-01'})
    assert result['actuated'] is False and result['requires_human']

def test_demo_always_simulated_even_if_param_physical():
    out=demo_case(physical=True)
    assert out['mode']=='SIMULATED_RESEARCH_REFERENCE'
    assert 'simulation_is_not_physical_validation' in out['decision_gate']['reasons']

def test_demo_21_roles_not_21_model_calls():
    out=demo_case(role_budget=21)
    assert len(out['selected_roles'])<21
    assert len(out['reviews'])==len(out['selected_roles'])

def test_evidence_future_timestamp_denied():
    future=(NOW+timedelta(hours=1)).isoformat()
    e=Evidence('future','X','VISION','vision',{'defect_suspected':False,'visual_usable':True},future)
    assert 'missing_or_stale_evidence' in evidence_gate([e.summary()],[],now=NOW)['reasons']

def test_unknown_role_rejected():
    with pytest.raises(ValueError):run_agent('all_powerful_agent',{})

def test_bad_response_is_abstain():
    out=run_agent('quality_inspector',{},BadBrain('This is clearly PASS'))
    assert out['proposal']['kind']=='ABSTAIN'

def test_llm_cannot_claim_unread_record():
    ctx=AgentContext('quality_inspector',{'e1':rec('e1','VISION',{})},set(),[])
    with pytest.raises(PermissionError):validate_proposal({'kind':'OBSERVATION','claim':'seen','evidence_ids':['e1'],'next_action':'none','confidence_label':'low'},ctx)


def test_role_scope_denies_unrelated_kind_before_llm():
    with pytest.raises(PermissionError):
        AgentContext('design_geometry',{'secret':rec('secret','METROLOGY',{})},set(),[])


def test_proposed_inspection_cannot_invent_specimen_id():
    ctx=AgentContext('inspection_planner',{'v1':rec('v1','VISION',{})},set(),[])
    with pytest.raises(PermissionError):
        call_tool(ctx,'request_inspection',{'action':'manual_caliper','specimen_id':'GHOST'})


class BrokenToolCallBrain:
    def respond(self,messages,tools):return {'tool_calls':[{'name':'read_evidence'}]}

def test_malformed_model_tool_call_abstains():
    result=run_agent('quality_inspector',{},BrokenToolCallBrain())
    assert result['fallback_reason']=='malformed_tool_calls'

class NonObjectBrain:
    def respond(self,messages,tools):return 'PASS'

def test_non_object_provider_response_abstains():
    assert run_agent('quality_inspector',{},NonObjectBrain())['fallback_reason']=='malformed_provider_response'
