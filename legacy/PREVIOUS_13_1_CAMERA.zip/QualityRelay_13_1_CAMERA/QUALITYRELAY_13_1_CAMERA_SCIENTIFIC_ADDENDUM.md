# QualityRelay 13.1 — VISION-EVIDENCE: Scientific Camera Integration

**Status:** Research-grounded design addendum, with a small tested computer-vision proof of concept; **not** a certified camera measurement device or a validated factory product.  
**Date:** 2026-10-30  
**Base:** QualityRelay 13.0 EVIDENCE-MESH, unmodified original package retained in ZIP.  
**Audience:** scientific team, mechanical engineer, decentralized backend engineer, potential factory pilot partner.

---

## Executive decision: YES, the camera must detect actual defects

The web camera must not be a decorative photo capture or a general LLM saying "looks fine". It must produce a **traceable, auditable visual observation** with a defect region, reason, model/version, confidence characterization, device conditions, and an appropriate follow-up action. The camera integrates with the physical Slot/Tab/Assembly/Sorter system and the scientific EVIDENCE-MESH protocol.

**Recommended core concept: VISION-EVIDENCE** — *calibrated, decision-aware active visual inspection in a decentralized manufacturing evidence network*. This is a proposed combination of existing scientific methods, **not a proven novel theorem or discovered scientific law**.

The camera adds two distinct evidence families:

1. **Visual appearance / anomaly detection:** detect visible defects (warping, layer shift, stringing, gaps, cracks, missing geometry, contamination, material blobs). This can be possible with RGB imagery and controlled lighting, after validation.
2. **Optical geometric metrology:** estimate visible planar geometry in millimeters **only** when proper calibration, reference plane, uncertainty budget, and independent verification make the estimate credible. With an ordinary phone and uncontrolled perspective, report *visual estimate* or *cannot measure*, not certified millimeters.

**Do not claim:** RGB detects subsurface voids, material strength, all micrometer-size defects, exact 3D dimensions from a single image, or universal fault-source causality. A photo cannot unambiguously infer internal quality and process root cause.

### Preserve from v13.0
- Four independently running peers: Slot, Tab, Assembly, Sorter; **fully decentralized** is the main mode. Camera capability is attached **locally** to owning peer(s). The website is an operator interface, not a global camera decision authority.
- 21 existing expert roles remain; add **22. Vision & Metrology Engineer** as a specialist capability, not as a mandatory centralized hub.
- Evidence origin IDs, access control, direct peer requests, anti-double-counting, signed provenance, degraded/offline behavior, Evidence Debt Ledger, decision-aware V-DER / expected value of sample information (EVSI), PACE guard, expert dissent, human confirmation, conservative HOLD and independently confirmed REJECT.
- Real 3D-printed coupons + real caliper fit testing + optional physical sorter; simulation must stay separate from physical observation.

---

## 1. Research evidence and what it does *and does not* establish

| Evidence | Verified finding | QualityRelay implication | Limitation |
|---|---|---|---|
| MVTec AD, CVPR 2019 / IJCV | 5,354 images, 15 classes, pixel-level abnormal regions | Start with known anomaly benchmarks | Metal/consumer objects are not your printed Slot/Tab distribution; CC BY-NC-SA commercial restriction [S01] |
| MVTec LOCO AD, IJCV 2022 | Detect structural **and logical** anomalies | A visually normal part may be invalid in a pairing | General logical dataset ≠ evidence of pair-fit performance [S02] |
| PatchCore, CVPR 2022 | Good few-normal-image industrial anomaly baseline; up to 99.6% AUROC on a benchmark | Compare against non-generative normal-only baseline | **This AUROC is not the camera's accuracy on your part** [S03] |
| EfficientAD, WACV 2024 | Very fast student/teacher industrial anomaly detection, includes logical anomaly variants | Real-time candidate with appropriate compute | Published paper latency is not MacBook/iPhone browser latency [S04] |
| CVPRW RobustAD 2025 | Lighting, pose, clutter and other *real* domain shifts degrade anomaly detectors | Mandatory out-of-distribution experiments and abstention | Benchmark transfer is not guaranteed [S05] |
| FDM process monitoring review, 2024 | Under/overextrusion and related defects can have visual signatures | Tailor appearance taxonomy to actual PLA defects | Visible surface ≠ proven strength/structural conformity [S06] |
| FDM image dataset, Zenodo 2026 | Real 3-angle printed-object imagery includes layer shift, extrusion, stringing, good prints | Use as external pretraining/evaluation *subject to license* | 48.4 GB; transfer to your printer and optics must be evaluated [S07] |
| FDM dataset Hu et al. 2024 | 1,912 images, 5 defect types, lightweight deployment work | Smaller reference for FDM-specific classes | Check labels, split and deployment conditions [S08] |
| OpenCV calibration docs | ChArUco/chessboard calibration needs multiple good views; pattern geometry and sharpness matter | Calibration workflow with reprojection audit | Pixel-per-mm alone is not full measurement uncertainty [S09] |
| NIST 2005 camera inspection calibration | Part-feature accuracy can be ~1 mm in a specific 45 cm distance experiment | Validate rig at YOUR geometry and desired threshold | Do not transpose published accuracy to our system [S10] |
| NIST traceability | Traceable results require documented calibration chain and uncertainty | Metadata, check references, uncertainty fields and limits | A calibrated instrument alone does not certify results [S11] |
| Structured light vs CMM, CIRP 2024 | Comparing printed-part optical 3D measurements against contact CMM is an established route | Optical 3D as future P2 extension | Greater hardware burden; not required for P0 [S12] |
| Photometric stereo inspection, Scientific Data 2025 | Multi-illumination and multiple perspectives reveal complex surface anomalies | Optional P1 lighting-angle upgrade | Surface normal estimation needs controlled illumination/geometry [S13] |
| Manufacturing visual-survey, 2025 | Review of 196 papers; domain shift and rare defects remain challenges | No unsubstantiated 'universal accuracy' | Prior art is extensive [S14] |
| Printed-part tolerance study, 2025 | Controlled dimensions and assembled part response can be experimentally analyzed | Physical Slot/Tab pairing gives meaningful independent outcomes | Dimensional/geometry print deviations perturb results [S15] |
| NIST camera system validation, Oct 2026 | Metrology-grade optical instrument reported submicron uncertainty with controlled machine hardware | Rig matters more than neural-network marketing | An iPhone or webcam is NOT equivalent to the NIST instrument [S16] |

**Interpretation:** camera-based defect detection exists; adding YOLO or PatchCore is not a scientific discovery. The investigable gap is whether **calibrated, provenance-aware, selectively acquired camera evidence** improves the *safe industrial decision* made by decentralized peers under access limits, model shift, conflicting expert conclusions and communication failures.

---

## 2. Exactly what the camera should detect

### 2.1 Part-level appearance taxonomy

| Target | RGB feasibility | Ground-truth method | Recommended first model | Safe output |
|---|---|---|---|---|
| Slot/Tab identity, orientation, missing part | High in jig | ID record + manual confirmation | Fiducial/QR + geometry | IDENTIFIED / RECAPTURE |
| Slot not open, tab missing tip, gross shape deformity | High with backlit silhouette | CAD outline + independent examiner | OpenCV silhouette/contours | SUSPECT_DEFECT + ROI |
| Stringing, protrusions, blobs | Conditional on visible size/angle | Human annotation + alternate view | Baseline threshold + PatchCore | SUSPECT_SURFACE + ROI |
| Layer shift and side warping | Good from suitable side/top | Caliper/straightedge + human labeling | silhouette geometry / anomaly model | SUSPECT_WARP + ROI |
| Surface cracks, delamination | Depends on crack resolution and lighting | Macroscopic examiner/magnification | multilight imagery + PatchCore | SUSPECT_CRACK + ROI |
| Near-threshold dimensions (e.g., 0.3 vs 0.5 mm clearance) | **Not automatically dependable** | calibrated gauge, repeatability and independent fit | Calibrated fixed-geometry machine vision | ESTIMATE_WITH_U or REQUEST_CALIPER |
| Hidden internal porosity, bond strength | Not established by RGB | CT/mechanical tests | **none** | NOT_OBSERVABLE |
| Assembly-specific actual fit | Vision can observe contact/failure signs | Recorded physical fit protocol | Vision + fit outcome, not vision alone | OBSERVED_FIT or UNKNOWN |

**Labels distinguish:** `visual_anomaly`, `optical_measurement`, `caliper_measurement`, `operator_fit_outcome`, `simulated_measurement`, `model_inference`. The AI cannot quietly relabel one source as another.

### 2.2 In-process print camera vs post-print inspection camera

- **Post-print inspection**: essential for the hackathon; images of coupon after printing; consistent jig, dark matte backing or backlit silhouette, optional alternate illumination; match part ID and lot.
- **In-process monitoring**: optional advanced workflow, uses printer-side frames to detect spaghetti, bed adhesion, layer shift and some extrusion failures early. Frame sequences from a single event are **correlated**; avoid treating each frame as independent evidence.
- **CAD / pairing**: neither camera alone nor LLM chooses a safe assembly. Assembly peer combines design requirements + authenticated slot/tab evidence + conservative uncertainty and actual fit outcomes.

---

## 3. Camera hardware and rigorous acquisition

### P0 — ready for a 3-person hackathon
1. MacBook camera, spare webcam or smartphone **mounted rigidly** above small parts (no handholding during measurements).
2. Fixed part jig: consistent object pose, photo-matte neutral background and clear part ID.
3. Diffuse LED illumination for surfaces; backlight (or high-contrast board) for silhouettes, separated into two capture modes.
4. Reference ChArUco board or ArUco + verified reference length **on the same geometric plane as the measurement**. Record printed fiducial physical dimensions and do not assume a paper printer reproduces its nominal size.
5. Caliper for actual physical dimension ground truth; record gauge ID, resolution, verification and repeated measures.
6. Browser capture through `navigator.mediaDevices.getUserMedia()` over HTTPS/localhost; camera permission remains under user's control. UI previews a frame; backend processes a frozen, hashed image. Capture resolution and focus/exposure must be recorded where available.

### P1 — robust validation / more useful visual defects
- Second side-view camera or manually indexed side view with repeatable physical jig.
- 2–4 switchable LED directions for photometric-like surface comparison.
- OpenCV camera intrinsics, lens distortion correction, checked image sharpness/blur, exposure, marker visibility and spatial resolution; acquisition-quality gate.
- Trainable normal-only anomaly detector: PatchCore **versus** EfficientAD **versus** an interpretable geometry baseline, tested on held-out parts and print runs.

### P2 — industrial optical measurement
- Industrial fixed-focus and, where needed, telecentric lens; calibrated optics; high-stability lighting; CMM/structured-light benchmark; measurement systems analysis (repeatability/reproducibility) under varied operators.
- For true 3D geometry: structured light, stereo or controlled multi-view reconstruction. Do not infer depth from one arbitrary monocular RGB image.

### Pixel footprint vs actual measurement uncertainty — explicit example

If a 1920-pixel image shows a **100 mm field of view**, the nominal image scale is `100/1920 = 0.0521 mm/pixel`. This is pixel sampling, **NOT a claimed 0.0521 mm measurement accuracy**. Depth offsets, lens distortion, edge ambiguity, reflections, thermal/print effects and setup repeats may dominate. If the functional clearance is only 0.5 mm, the decision boundary is delicate; `u_camera` must be measured on independent reference artifacts. If calibrated uncertainty is too high relative to the acceptance margin, the policy requires a caliper measurement.

### Planarity limitation
A marker glued to the table and a tab surface elevated 5 mm are **not necessarily coplanar**. Do not measure raised surfaces using an uncorrected planar table homography. The experimental camera proof-of-concept below deliberately marks calibration as `unverified` until a proper controlled-height setup and independent uncertainty study are performed.

---

## 4. Camera pipeline: 7 audited stages

1. **Acquire**: `CameraCapture` from the owning station, actual physical specimen ID, timestamp, exposure/pose/lighting mode, source origin hash. Never accept an arbitrary remote URL as authenticated sensor evidence.
2. **Quality gate**: sharpness, glare, occlusion, reference pattern visible, target not clipped, physically valid plane, expected resolution. Reject/recapture if not satisfied.
3. **Geometry calibration**: internal lens parameters and distortion; pattern corners; plane-specific homography (or industrial 3D pose). Record calibration version and uncertainty; if unavailable, no authoritative mm result.
4. **Segmentation / localization**: controlled OpenCV silhouette/scanline baseline; optional trained anomaly heatmap (PatchCore/EfficientAD); localize defect ROI and compare with CAD regions.
5. **Evidence typing**: create `VisualEvidence` referencing specimen ID, event/origin ID, model hash, score, confidence calibration method, mask/ROI, lighting, artifact URI/hash, source_kind=physical, and `measurement_status`.
6. **Independent check / dissent**: Quality & Metrology agents inspect evidence; Design/Assembly agents check functional tolerance. Uncertain or conflicting claims trigger a **new useful observation** (different view, lighting, caliper or physical fit), not LLM majority vote.
7. **Safe disposition**: `HOLD` for inconclusive; `PASS_ELIGIBLE` only under independently validated station quality rules and allowed policy; `CONFIRMED_REJECT` only with verified independent nonconformance. Operator approves sorter action and feedback confirms real motion.

### Critical anti-correlation rule
A burst of 30 images from one object and one camera condition is **one correlated acquisition group**, not 30 independent physical proofs. Repeated photos under different light/angles also share physical sources and calibration errors. Assign `physical_origin_id` and `acquisition_group_id`; do not multiply likelihood ratios without a tested dependence model.

---

## 5. Proposed science: Calibrated Active Inspection Routing (CAIR)

**Research idea (not an established novel theorem):** make camera *view/illumination selection* and *caliper inspection requests* compete in the same decision-value policy as V-DER, while respecting uncertainty, data ownership, image-provenance and correlated evidence.

### 5.1 Variables
- `H`: latent failure source / defect type / assembly-fit hypothesis (e.g., slot_shift, tab_shift, both_shift, visual_warp, misalignment, nominal).
- `E`: authorized, fresh, provenance-validated evidence seen by this peer.
- `D`: safe actions such as HOLD, additional inspection, propose alternate pairing, propose release after human gate.
- `a`: one actual feasible inspection: `CAPTURE_TOP`, `CAPTURE_SIDE`, `CAPTURE_RAKING_LED`, `MEASURE_CALIPER`, `TRIAL_FIT`.
- `y`: possible result generated from empirically estimated sensor likelihood `p(y|H,a,setup)`.
- `L(d,H)`: pre-registered asymmetric loss for real production outcomes.

**Decision-based value of camera evidence:**

`VOI(a|E) = min_d E[L(d,H)|E] - E_y[min_d E[L(d,H)|E,y,a]] - C(a) - Risk_penalty(a)`

Subject to: camera can only make claims at the supported acquisition state, authorized data access, explicit calibration/uncertainty, high-risk release blocked when posterior unreliable. Choose the highest feasible positive-value observation; if none, apply conservative HOLD or human specialist review. Known Bayesian EVSI principles underpin this; the potential contribution is **the deployable constrained, calibrated, decentralized integration**, which must be benchmarked.

### 5.2 New *falsifiable* research hypotheses
- **H1 (visual utility):** adding visual evidence to caliper/SPC changes the correct diagnosis under held-out appearance faults while not increasing false safe-release proposals.
- **H2 (active sensing):** a *decision-value* next-view/caliper policy uses fewer seconds / lower inspection loss than fixed three-view and entropy-based IG, at comparable safety.
- **H3 (source integrity):** acquisition-group dependence handling produces better calibration and less overconfidence than naive independent-frame fusion.
- **H4 (domain shift):** quality gating and abstention reduce false safe-release proposals under new light/angle/printer compared with visually confident always-predict baseline, though HOLD frequency may increase.
- **H5 (decentralization):** with identical sensor models and budget, peer-only selective evidence exchange approaches centralized decision quality with fewer raw-image bytes crossing ownership boundaries; connection loss does not silently turn stale images into evidence.
- **H6 (real benefit):** camera reduces unneeded manual inspections compared with caliper-only QC **without worsening safety**, when mixed appearance + dimensional faults occur. If camera adds no benefit, report null result.

### 5.3 Methods and baselines
| Baseline | Camera | Coordination | Inspection choice |
|---|---|---|---|
| B0 Traditional | No | Station-local | Caliper on fixed sample plan |
| B1 Classical CV | Yes | Local only | Fixed image threshold / ROI |
| B2 PatchCore | Yes | Local only | Fixed views; normal-only learned model |
| B3 EfficientAD | Yes | Local only | Fixed views; learned model |
| B4 CV + caliper | Yes | Centralized | Fixed plan |
| B5 Agent + camera | Yes | Single centralized AI | Same tool list/budget |
| B6 EVIDENCE-MESH with camera | Yes | True peer-only | entropy / IG next view |
| B7 CAIR (proposed) | Yes | True peer-only | VOI with calibration + abstention |
| B8 Ablation | Yes | Peer | CAIR **without** origin dedup or uncertainty guard |
| B9 Offline network | Yes | Peer | CAIR with missing camera/stale evidence |

**Fairness:** same raw physical specimens, image streams, frozen lens/detector versions, time/measurement budgets and hidden labels. No cheating by allowing a baseline less data or weaker models. Centralized full-evidence reference can be an upper bound, not a strawman.

---

## 6. Physical experiment plan using the existing 100 printed coupons

**Preserve existing target:** 50 Slot + 50 Tab, if printing capacity permits, split across normal, near-threshold tolerance, intentionally warped, and visibly defective conditions. Avoid damaging all samples before ground truth. Record exact number produced, not aspirational counts.

### Ground truth & split
1. Design in CAD with frozen revision and explicit functional clearance `C=W-T`, required `c_min=0.5 mm` in demonstration config (a configuration assumption, not universal engineering threshold).
2. Print across **at least two print runs** if feasible; label specimens BEFORE inspection; record printer, nozzle, PLA batch, direction, slicer, temperature, STL hash, run ID, lot ID.
3. **Blind held-out print run/lot**, never random-frame split — multiple frames of one specimen must stay within the same split. Avoid hyperparameter and threshold tuning on test specimens.
4. One independent mechanical examiner measures Slot width and Tab thickness with verified caliper, repeats at multiple points/positions, documents gauge repeatability; engineer separately records fit outcomes and visible defect annotations, marking ambiguous labels.
5. For each specimen, fixed top and side photos; optionally change LED direction and repeat capture under shifted conditions. Assign `acquisition_group_id`; annotators must not see the AI prediction.
6. Freeze thresholds / priors / costs before held-out evaluation. If limited defect coverage makes calibration impossible, report **feasibility demonstration**, not a validated classifier.

### Primary and secondary outcomes
**Primary safety gate:** no unsupported unconditional PASS / RELEASE; compare paired false-safe-release proposals to baseline and HOLD rate. High-risk acceptance criteria must be set before running; *no single toy sample can certify an industrial safety rate*.

**Primary scientific endpoint (pre-register one):** paired **decision-loss per incident** or cost of inspection to attain a predefined conservative decision quality, including label uncertainty and safety penalty.

Secondary:
- per-defect class sensitivity/recall, specificity, precision, F1; report numerator/denominator and confidence intervals;
- image AUROC and pixel-level AUPRO / IoU only when valid masks exist;
- calibration ECE/Brier and selective risk as fraction of images abstained grows;
- mean absolute error, signed bias, repeatability and uncertainty of optical dimensions **versus** verified gauge, stratified by height/orientation/lighting;
- count and duration of extra manual inspections, time per part including capture & processing, false HOLD and false REJECT;
- assembly fit success rates with actual physical trials, distinct from optical guess;
- peer message bytes, image bytes exposed, replay idempotence, offline recovery, degree of duplicated evidence.

### Statistical rigor
- Paired comparisons by **specimen/lot**, not frame. Bootstrap sampling at specimen/print-run cluster level. Report 95% confidence intervals and both advantages **and** failures. 100 physical coupons are not 100 independent defect types or a factory field trial.
- One printer, one filament, fixed background and lighting leads to severe generalization limits. Use shifted lighting, moved camera, changed orientation and at least one held-out printer/process configuration if feasible.
- Do *not* select the best of many algorithms using the final test data. Use fixed model selection plan or nested validation.
- Safety decision thresholds should depend on documented loss and uncertainty, not arbitrary 'confidence > 90%' labels.

### Camera vs caliper classification (explicit)
- `CAMERA_VISIBLE_NONCONFORMANCE`: only if objective pre-validated visible criterion and acceptable detection uncertainty; otherwise `SUSPECT_VISUAL_FAULT`.
- `CAMERA_GEOMETRIC_CANDIDATE`: geometric measurement with uncertainty; cannot assert final tolerance when boundary overlaps uncertainty interval.
- `INDEPENDENT_GAUGE_CONFIRMATION`: physical calibrated or verified gauge event.
- `PROPOSE_PAIR / HOLD`: inferred assembly decision from accepted sources.
- `CONFIRMED_REJECT`: independently documented part nonconformance, owner-authorized, human-controlled physical sorter.

---

## 7. Peer architecture: camera is NOT a new single point of failure

```text
                      [Browser UI: capture / inspect / propose]
                                    |
                    [owner-specific authorized endpoints]
                                    |
    [Slot peer + local DB] <----------> [Tab peer + local DB]
        |  Visual module                | Visual module
        |  + frame store                | + frame store
        |                               |
        +-------- scoped VISUAL EVIDENCE summary --------+
                                                        |
            [Assembly peer + local DB] <--> [Sorter peer + local DB]
                  | risk / diagnosis          | safe physical action
                  |                           | idempotent feedback
                  +---------- peer evidence --+

Optional: Chief Engineer for hybrid baseline / non-authoritative advisory.
Neither website nor LLM is authoritative measurement or actuation hub.
```

- Camera process lives next to owning station. Image files stay on local storage by default. Authorized peer receives a signed defect summary, crop, feature summary or need-to-know image if policy explicitly permits.
- Each image/crop/model output refers to immutable origin; derivative transformations retain `parent_evidence_ids`.
- `camera_unavailable` marks source missing; local caliper / SPC monitoring continues. A missing image cannot become an inferred good image.
- The system shares only needed evidence; no global aggregator sees all raw video by default.
- Chief Engineer, if enabled in hybrid comparison, can request reinspection but has no universal raw image privilege and cannot actuate hardware alone.

### Suggested JSON schema — camera event (illustrative)

```json
{
  "event_type": "VISUAL_INSPECTION",
  "event_id": "slot-ev-00412",
  "physical_origin_id": "capture-camA-partS08-top-001",
  "acquisition_group_id": "partS08-camA-session3",
  "specimen_id": "S08",
  "lot_id": "SLOT-A07",
  "owner_peer_id": "slot",
  "source_kind": "physical",
  "camera_device_id": "camA",
  "capture_mode": "TOP_DIFFUSE",
  "capture_time_utc": "2026-10-30T21:00:00Z",
  "image_sha256": "<actual computed SHA256>",
  "model_version": "silhouette-baseline-v0.1",
  "lens_calibration_version": null,
  "measurement_status": "unverified",
  "measurement_value_mm": null,
  "measurement_uncertainty_mm": null,
  "anomaly_classes": ["suspected_warp"],
  "roi_mask_sha256": null,
  "distribution_shift_flags": ["new_lighting"],
  "confidence_status": "uncalibrated",
  "recommended_action": "REQUEST_CALIPER",
  "parent_evidence_ids": [],
  "permissions": ["assembly:read_summary"],
  "signature": "<actual signature from owning peer>"
}
```

The placeholders are **not** valid hashes or signatures. Do not display these as captured reality. Production schema uses strict validation, nonempty legal permissions, typed uncertainty, ACL, and genuine cryptographic signing.

### API additions (per owner)
- `POST /v1/vision/captures`: authenticated local image upload + part ID + scene metadata; returns a capture ID, never self-reported PASS.
- `POST /v1/vision/captures/{id}/inspect`: quality gate / detector / uncertainty metadata; deterministic structured result.
- `GET /v1/vision/events/{event_id}`: owner authorized evidence view.
- `POST /v1/vision/inspect-options`: allowlisted next views / gauging actions and estimated risk/cost, in a frozen model.
- `POST /v1/evidence-requests`: remote peers request allowed image summary or selected crop; raw images denied by default.
- `POST /v1/incidents/{id}/inspection-options`: V-DER/CAIR enters same candidate ranking as other existing physical actions.
- `POST /v1/sorter/requests`: unchanged signed, human-approved safe physical sorter contract.

### Camera agent tool contract
`Vision & Metrology Engineer` consumes owned `VisualEvidence` and optional documented engineering drawings; outputs one of `OBSERVED_SURFACE_ANOMALY`, `ESTIMATED_GEOMETRY_WITH_UNCERTAINTY`, `CANNOT_MEASURE`, `RECAPTURE`, `REQUEST_ALTERNATE_VIEW`, `REQUEST_CALIPER`. It has **no authority to invent numerical mm measurements, overwrite another station's sensor data, or release/reject a part**.

---

## 8. Site walkthrough for the judges

1. **Factory Dashboard:** four peer status tiles; camera connected to Slot/Tab; active physical and simulated evidences clearly separate.
2. **Camera Inspection:** scan physical sticker/ID; camera preview opens; pick TOP/SIDE light mode; display image-quality meter and calibration marker visible/invalid state.
3. **AI Analysis:** side-by-side original image and defect heatmap/outlined ROI, model name and label, calibration status, "what camera can/cannot tell". Display an `unverified camera dimension` only as an estimate.
4. **Peer Collaboration:** Assembly requests the smallest authorized Slot/Tab summaries; minority visual alert contradicts initial statistical prognosis; evidence-debt panel marks issue unresolved.
5. **Next Best Evidence:** system compares `RECAPTURE_SIDE` (time cost), `CALIPER_S08` (time cost), `TRIAL_FIT` (risk/cost) via decision-value calculations; show why one action chosen.
6. **Physical Verification:** HyorinmaruK performs actual measurement or fit trial; source event gets `physical` label; diagnosis and posterior update, with provenance.
7. **Sorter:** only authorized operator confirms the PASS/HOLD/CONFIRMED REJECT action; low-energy sorter reports actual hardware sensor confirmation. No fake sort if physically not tested.
8. **Research Results:** identical physical images and trial sequences for traditional CV, PatchCore/EfficientAD, isolated AI, centralized and peer-structured methods. Use uncertainty bars; label simulated or physical each metric.
9. **Resilience:** disconnect camera peer / station; show stale evidence and local continuity with HOLD, reconnect and idempotent replay.

---

## 9. Engineering work allocation (3 + optional 4)

**Bakdaulet-omeraiuly — science, statistics, evidence-policy**
- Freeze visual defect taxonomy, priors and loss matrix, design CAIR/IG/EVSI controls, evidence dependence handling; train/evaluate normal-only and classical CV baselines in fair split.
- Build paired benchmark scripts, camera calibration error and decision-loss analysis, intervals, preregistration and claim register.
- Own endpoint contracts specifying what can be called a calibrated result.

**adilnurgg — decentralized/backend/security and camera ingestion**
- Implement browser authenticated camera ingestion route, owner-local storage, image SHA-256, metadata schema, scoped evidence retrieval, peer events and ACL.
- Connect inspector to Slot/Tab and Assembly plus next-inspection API; missing camera/invalid calibrator -> HOLD; offline/replay, genuine signed human sorter actuation.
- Implement guard: no LLM prose promoted to instrument measurement; no browser permissions bypass; image denial to unauthorized peers.

**HyorinmaruK — MECHANICAL ENGINEER, camera rig, physical ground truth, FINAL PRESENTATION**
- Own camera/part fixture, lighting modes, actual marker/gauge measurements, printed coupons/defect injection, part ID and ground-truth inspection protocol, repeated physical fit tests.
- Evaluate physical feasibility of detecting small warps/gaps and report measurement uncertainty; demonstrate camera-to-caliper-to-fit loop and the sorter.
- Own final slide deck, hands-on jury demo, and limitations slide. This responsibility remains unchanged.

**Fourth teammate (if recruited) — frontend + independent CV evaluation**
- Build polished camera preview/heatmap + evidence uncertainty widgets; accessibility; browser camera permission handling; shareable replay.
- Blind audit a held-out subset, reproduce CV benchmarks, verify network offline scenarios and no simulated/physical mixing.

If no fourth person joins: adilnurgg handles minimal camera UI, Bakdaulet helps benchmark reporting; **HyorinmaruK stays physical validation + pitch owner**.

---

## 10. Practical implementation priorities and cut lines

**P0 (must exist in live demonstration):**
- a real camera in website, actual physical Slot/Tab ID and captured image;
- local image hash and authorized owner event with true source label;
- a working deterministic silhouette / shape anomaly baseline plus at least one genuine positive and negative image;
- automated `SUSPECT_VISUAL_FAULT`/`RECAPTURE`/`REQUEST_CALIPER` action with evidence ROI;
- operator caliper or physical fit evidence; independent peer decision changes or abstains on insufficient evidence;
- physical sorter interaction if already built, otherwise honestly labeled manual routing;
- evidence and simulation do not mix; no unsupported numeric accuracy.

**P1 (research strength):**
- lens calibration and hard image-quality gate; verified reference artifact; camera dimensional estimate ± empirical uncertainty;
- PatchCore/EfficientAD compared to classical baseline, held-out print-run split and light/angle shifts;
- alternate-angle/light selection through V-DER/CAIR; measure decision cost, uncertainty and failure rate;
- calibrated uncertainty, evidence dependence IDs, denied raw access and peer outage test.

**P2 (future industrial pilot):**
- multi-view / structured-light optical measurement, independent CMM/industrial metrology cross-check;
- actual factory datasets and equipment protocols, MSA (gauge R&R), audited change control, security, task-specific industry validation; vendor-specific industrial integration.

**Do not cut** original v13.0 mathematical/statistical evidence and peer topology in order to add camera shine. A single working camera-to-decision-to-physical-check loop is more valuable than announcing 22 untested neural networks.

---

## 11. Delivered experimental code, exact scope

`prototype/vision_evidence.py` is a **small, executable OpenCV reference**, with:
- ArUco marker finder and 2D planar homography (not full lens-distortion corrected calibration);
- scanline thresholding with `dark_runs` and ambiguous-image abstention;
- candidate slot-gap estimation in the reference plane with explicit **unverified** status;
- a HOLD state and forced physical caliper confirmation; never a standalone safe-release.

`tests/test_vision_evidence.py` contains 7 **synthetic/software tests** (not 7 physical validations). See `results/tests.txt` for actual output. This code cannot infer arbitrary defect heatmaps, guarantee automatic image ROI detection, measure raised geometry, compute a metrologically traceable uncertainty, or certify a defect detector. These must be implemented and tested as specified above.

Example:

```bash
python -m unittest discover -s tests -v
python prototype/vision_evidence.py sample.png --scan-y 400 --marker-side-mm 20 --event-id physical-image-001
```

The sample image needs the required ArUco marker in the reference plane and controlled two-arm silhouette. Without a marker, it returns `HOLD_CAMERA_INVALID`. The user must select a valid scanline. It does **not** produce measured physical evidence on its own; images are needed for physical evaluation.

---

## 12. References (original sources; research retrieval verified 2026-10-30)

[S01] MVTec AD, Bergmann et al., 2019/2021. https://www.mvtec.com/research-teaching/datasets/mvtec-ad  
[S02] MVTec LOCO AD, Bergmann et al., IJCV 2022. https://www.mvtec.com/research-teaching/datasets/mvtec-loco-ad  
[S03] Roth et al., PatchCore, CVPR 2022. https://openaccess.thecvf.com/content/CVPR2022/html/Roth_Towards_Total_Recall_in_Industrial_Anomaly_Detection_CVPR_2022_paper.html  
[S04] Batzner et al., EfficientAD, WACV 2024. https://openaccess.thecvf.com/content/WACV2024/html/Batzner_EfficientAD_Accurate_Visual_Anomaly_Detection_at_Millisecond-Level_Latencies_WACV_2024_paper.html  
[S05] Pemula et al., RobustAD, CVPRW 2025. https://openaccess.thecvf.com/content/CVPR2025W/VAND/html/Pemula_Robust_AD_A_Real_World_Benchmark_Dataset_For_Robustness_in_CVPRW_2025_paper.html  
[S06] FDM machine monitoring review, IJAMT 2024. https://link.springer.com/article/10.1007/s00170-024-13630-8  
[S07] Bast et al., FFF visual defect image dataset, Zenodo 2026. https://zenodo.org/records/18628777  
[S08] Hu et al., Lightweight FFF fault detection, IJAMT 2024 + dataset. https://github.com/wengmhu/FDM-3D-Printing-Defect-Dataset  
[S09] OpenCV camera calibration documentation. https://docs.opencv.org/5.0/tutorials/calib3d/camera_calibration_pattern/camera_calibration_pattern.html  
[S10] Tsai/NISTIR 7197, Camera Calibration for a Manufacturing Inspection Workstation. https://www.nist.gov/publications/camera-calibration-manufacturing-inspection-workstation  
[S11] NIST Metrological Traceability policy. https://www.nist.gov/metrology/metrological-traceability  
[S12] Structured-light scanner vs CMM for 3D printed parts, Procedia CIRP 2024. https://www.sciencedirect.com/science/article/pii/S2212827124009442  
[S13] Complex structured surface dataset / photometric stereo, Scientific Data 2025. https://www.nature.com/articles/s41597-025-04454-6  
[S14] Deep learning survey for visual industrial anomaly, 2025. https://link.springer.com/article/10.1007/s10462-025-11287-7  
[S15] Armillotta, Experimental dimensional tolerance analysis using 3D printed parts, 2025. https://link.springer.com/article/10.1007/s00170-025-15040-w  
[S16] NIST optical metrology system validation, 2026-10-08. https://www.nist.gov/publications/validation-upgrades-nist-m48-vision-measurement-system  
[S17] FDM faults Mendeley Data 2024. https://data.mendeley.com/datasets/y74xtkk72z/1  
[S18] MVTec 3D-AD official benchmark for future 3D. https://www.mvtec.com/research-teaching/datasets/mvtec-3d-ad  

**Research integrity:** These sources establish relevant technology and open challenges; they do **not** validate this project's optical accuracy or industrial ROI. Newly proposed CAIR integration must undergo independent peer-reviewed novelty search and prospective experiments before being described as a discovered scientific contribution.
