# QualityRelay 13.1 — FULL Scientific Master Blueprint (13.0 + VISION-EVIDENCE)

**Merged reference document:** full unmodified 13.0 research text followed by a clearly labeled camera integration addendum. The addendum extends, rather than replaces, the original. The primary decentralized topology and physical-sorting safety rules are preserved.

---

## PART I — QualityRelay 13.0 original scientific blueprint (unmodified source content)

# QualityRelay 13.0 — EVIDENCE-MESH Research Edition

**Title:** Provenance-Aware, Decision-Sensitive, Fail-Closed Collaboration in Decentralized Manufacturing Quality Control  
**Date:** 2026-10-30  
**Status:** Research synthesis + **tested synthetic reference module**, **not** an industrially validated system.  
**Primary event:** ScienceClaw, MIT Media Lab, October 30–November 1, 2026.  
**Original lineage:** QualityRelay 5.0 → 6–10 → 11 → 12.0 (fully decentralized peers + sorting) → **13.0 scientific test plan**.  
**Team:** Bakdaulet-omeraiuly (statistical and scientific core); adilnurgg (backend/distributed systems/security); HyorinmaruK (mechanical engineering, physical validation, final presentation); optional fourth member (integration/frontend and independent QA).

> **Actual scientific claim now:** We have identified a precise open **engineering research question** and created a runnable hypothesis-testing prototype. We have **not established a scientific discovery** or measured improvement in an industrial plant. Our contribution should be judged by reproducible experimental evidence, not number of agents or pages.

## 0. Executive decision: what QualityRelay IS

**One-sentence pitch:** QualityRelay is a peer-to-peer manufacturing-quality investigation network in which independently authorized station agents exchange traceable evidence, choose useful inspections, assess assembly compatibility, and safely quarantine ambiguous parts instead of blindly rejecting them.

1. **Product and mandatory live demo:** `fully_decentralized` is primary. Four independently running peers: **Slot, Tab, Assembly, Sorter**. A website shows and requests actions but is not the system's mandatory decision authority.
2. **Research comparators:** `isolated`, `single-agent-full-info`, `centralized`, and `hybrid-chief-engineer`; centralized Chief Engineer is never necessary for the primary peer demonstration.
3. **Scientific core:** preserve original clearance / acceptance-conditioning / EWMA / Bayesian diagnosis / information-gain validation from QualityRelay 5.0. Extend with **Evidence-Mesh, V-DER (decision-value routing), protected minority evidence, source-origin deduplication, and uncertainty-safe abstention**.
4. **Product constraints:** no unsupervised machine control; no false industrial qualification; a pairwise incompatibility does not automatically condemn either component; untrusted measurement is HOLD, not PASS.
5. **Physical setup:** 3D-printed coupons, real caliper measurements, fit trials, and a PASS/HOLD/CONFIRMED REJECT bench sorter. Simulation and physical measurements must remain distinguishable.
6. **Agent quantity:** retain **21 specialist role contracts**, but only invoke 2–6 relevant specialists per incident. Their names alone do not demonstrate working AI. Deterministic approved tools supply numeric truth; LLMs offer bounded narratives/explanations.
7. **Factory-facing target:** a quality engineer in precision component machining/assembly. The present 3D-printed PLA setup is **not** evidence of factory deployment readiness.

### 0.1 Truth matrix (no exaggerated readiness)

| Artifact | Verified available in supplied ZIP lineage | NOT established |
|---|---|---|
| Original 5.0 | Existing schemas, STL/SCAD, design and experiment plan; preserved in v12 nested archive | Complete standalone factory backend |
| v10 reference | A prior single-process FastAPI proof-of-concept and earlier reported tests | Fully distributed runtime |
| v12 | Design blueprint for four peers + bench sorter | Four independent deployed peers / physical sorter tested |
| **v13 added here** | Deterministic synthetic Bayes/EVSI/IG prototype; toy counterexample; tests; reproducible benchmark and literature index | A real industrial performance improvement; causal scientific discovery; fully operational 21-LLM swarm |
| 10,000-literature program | An earlier collector program and research protocol preserved in lineage | 10,000 independently retrieved, screened and read papers |

### 0.2 The win condition

The official rubric weights: problem significance **20%**, scientific/technical impact **25%**, decentralized agency **20%**, collective capability **25%**, execution/validation **10%**; an optional **+10 collaboration bonus** is separate. The official site says final slides are due **Sunday November 1, 13:00** (verify any organizer updates). [R01]

An actual demonstration with independent peer processes, partial-evidence behavior, a real fit trial, and an honest matched benchmark beats an unimplemented 21-agent narrative.

---

## 1. Research foundations: what published science ALREADY solved

### 1.1 Manufacturing integration and sequential inspection

- **NIST / Hedberg et al. (2021)** studied the incomplete digital thread between design, production, and inspection. QualityRelay's station-specific evidence problem is authentic. It is not a new discovery. [R02]
- **Moliner-Heredia et al. (Sensors 2021)** already used **Bayesian sequential inspection based on expected information gain** to diagnose multistage process faults. It explicitly assumed **only one concurrent fault** and negligible classification errors in the analyzed case. Our `both_shift` hypothesis and noisy measurements test departures from that simplified setting. [R03]
- **Magnanini et al. (CIRP Annals 2024)** examined quality gates and feedback/feedforward control over multiple stages. We must not claim to invent proactive quality gates. [R04]
- Published machining monitoring and trust-aware decentralized manufacturing exist. QualityRelay must be evaluated as an **applied integration and experimental protocol**, not first-in-world autonomous factory AI. [R09, R15, R17]

### 1.2 Multi-agent information failures

- **HiddenBench (ICML 2026)** observed 30.1% accuracy on distributed-information tasks versus 80.7% for a complete-information individual under its test conditions. This is **not** a predicted QualityRelay score. The central failure mechanism is missing information that agents fail to request. [R05]
- **Multi-Agent Teams Hold Experts Back (ICML 2026)** shows experts can be overridden through compromise rather than evidence-based weighting. Role multiplication is not sufficient. [R06]
- A **2026 preprint** studies suppressed minority signals and premature consensus, while an EMNLP 2026 paper proposes auditing evidence at disagreement branches. Therefore evidence-based debate/audit also predates us. [R07, R08]
- **Distributed fusion literature** has long addressed shared-source correlations and double counting. Basic provenance-based duplicate filtering is not a newly discovered solution to arbitrary statistical dependence. [R10, R11]

### 1.3 Value of information and metrology

- **EVSI** formalizes the expected effect of new information on the optimal decision, distinct from entropy reduction. This is established Bayesian decision theory; our use in manufacturing is a research application. [R12]
- Online selective inference and industrial distribution shifts make naive confidence/safety statements dangerous; no unconditional coverage guarantee follows from a small 3D-print sample. [R13, R14]
- NIST's **Gauge R&R** treats repeatability, reproducibility, resolution, stability and bias as separate problems; caliper reading is not ground truth without a measurement plan. [R16]

### 1.4 Candidate scientific gap (not a proven priority claim)

Published components exist separately, but our **specific target experiment** asks:

> Under station-local authorization and intermittent network links, can a provenance-constrained, decision-value inspection protocol preserve safe decision quality and relevant minority evidence, while disclosing fewer raw records and using less inspection time than equal-budget peers without structured evidence requests?

This **may** yield a publishable result if it is new relative to a systematic literature review, tested under strong baselines, replicated, and independently assessed. The current research scan of 18 references is **not** such a review; novelty remains unverified.

---

## 2. Proposed research protocol: EVIDENCE-MESH / V-DER + PACE guard

We retain the previous name **EVIDENCE-MESH / V-DER (Value-guided Decision-Evidence Routing)**. New proposed integration layer: **PACE = Provenance-Aware Counterfactual Evidence guard**. PACE is a working title, **not a discovered scientific law**.

### 2.1 Mathematical objects

- `H`: finite fault hypotheses, initial `H0` stable, `H1` slot mean shift down, `H2` tab mean shift up, `H4` both shifts. Multi-source faults matter.
- `E`: currently authorized, fresh and origin-resolved evidence set. Each raw measurement has one stable **physical origin ID** even if forwarded by multiple agents.
- `p(H|E)`: posterior under a frozen, empirically validated likelihood model. Do not confuse model posterior with guaranteed physical truth.
- `D`: actions `CONTINUE/PROPOSE_RELEASE`, `HOLD`, `REQUEST_INSPECTION`, `PROPOSE_ALTERNATIVE`. **Final production release is human-approved.**
- `a`: candidate inspection/action from an allowlisted catalog with a real specimen ID, measurement model, expected duration, access cost and instrument availability.
- `L(d,H)`: asymmetric economic/safety loss. Cost parameters are explicitly **hypothetical** until a factory provides calibrated data.
- `R(E) = min_d Σ_H p(H|E)L(d,H)` is the current minimum expected decision loss.

For a potential measurement `Y_a`, the conventional **expected value of sample information** is:

`EVSI(a|E) = R(E) - Σ_y p(y|E,a) min_d Σ_H p(H|E,y,a)L(d,H)`.

Proposed **net value for selecting an inspection**:

`NetValue(a) = EVSI(a|E) - C_measure(a) - C_delay(a) - C_comm(a) - C_disclosure(a)`.

**Important:** Cost-aware EVSI is established mathematics, not an original theorem. Our research question is whether this policy **within a permissioned peer evidence network** performs well under realistic errors, drift, correlated evidence, missing links, and competing agents.

### 2.2 PACE safety / evidence rules

1. **Source-level attribution:** every assertion references owner, event ID, measurement origin ID, specimen/lot ID, instrument, unit, timestamp, input hash, model version, and `physical` / `simulated` / `inferred` label.
2. **No double counting:** two copies of the *same* physical observation are one measurement. Shared ancestors and unknown correlations require explicit dependence modeling or conservative fallback. Simple ID deduplication **does not solve arbitrary correlations**.
3. **No majority override:** a sourced engineer challenge is not voted away. Request disconfirming measurement; until resolved flag HOLD/REVIEW.
4. **No missing-evidence optimism:** unreachable authorized peer means `MISSING/STALE` rather than assumed-normal measurement. Local SPC may continue, but global pair release waits.
5. **Decision-sensitive request:** choose `EVSI − costs` among authorized, available tests, unless validity/safety fallback forbids it. Preserve IG as a baseline, not a strawman.
6. **Specimen whitelist:** the model cannot invent inspection targets or measurements. Numeric outputs come only from deterministic services.
7. **Physical dispositions:** source-owned local conformity permits `PASS_ELIGIBLE` inventory only; pair compatibility is a separate Assembly predicate. `CONFIRMED_REJECT` requires an authorized independent part nonconformance, not a mere failed pairing.
8. **Partition behavior:** event sourcing and at-least-once delivery; inbox applies events idempotently. No assertion of exactly-once transport; no central dashboard dependency.
9. **Human gate:** plant actuation and hold release need a human-signed policy-controlled action; bench sorter is guarded and physically verified.

### 2.3 Counterfactual decision stability (research diagnostic, not safety certification)

For a finite set of missing binary tests `M`, enumerate every modeled outcome vector `y ∈ {0,1}^|M|` and recompute `d*(E,y)`. If **all** modeled outcomes produce the same preferred *proposal*, call it `MODEL_DECISION_STABLE`.

This is a direct finite-enumeration property, **not an industrial certification**. It depends on correct likelihoods, complete action space, known source dependencies, finite outcome support and loss assumptions. An actual PASS still requires fresh mandatory evidence and human authorization.

Reference implementation: `prototype/peer_decision.py::counterfactual_decision_stability`.

### 2.4 Source-bearing communication contract

```json
{
  "schema_version":"13.0-draft",
  "message_type":"EvidenceResponse",
  "incident_id":"UUID",
  "owner_station":"slot",
  "specimen_id":"S-014",
  "event_id":"UUID",
  "measurement_origin_id":"caliper-event-UUID",
  "measurement_kind":"slot_width",
  "measurement_value":20.61,
  "units":"mm",
  "source_kind":"physical",
  "instrument_id":"caliper-01",
  "measurement_uncertainty_mm":null,
  "calibration_status":"unverified",
  "measurement_timestamp_utc":"EXAMPLE_NOT_AN_ACTUAL_MEASUREMENT",
  "producer_version":"tool-version",
  "evidence_snapshot_hash":"sha256:...",
  "authorized_fields":["measurement_kind","measurement_value","units"],
  "freshness_status":"current",
  "signature_status":"to_be_verified",
  "human_verified":false
}
```

Numbers above are illustrative; **never** use uncalibrated readings as conclusive factory results. Production schema must use valid date types, typed uncertainty and signatures. Peers cannot edit another owner's event.

---

## 3. Research experiments (preregistered plan)

### 3.1 Main factorial design

**Primary architecture factor** (`same inference library, allowed inputs, seed and inspection budget`):

- `B0`: conventional local threshold/SPC and fixed inspection;
- `B1`: isolated stations, no peer requests;
- `B2`: fair single AI/decision service with **the same permitted evidence**;
- `B3`: central full-information **upper bound**, explicitly privileged and not a fair same-access competitor;
- `B4`: distributed agents with naive broadcast/majority;
- `B5`: distributed + structured owner-scoped evidence requests;
- `B6`: `B5` + provenance deduplication;
- `B7`: `B6` + evidence-bearing dissent gate;
- `B8`: `B7` + cost-aware EVSI / PACE (full experimental treatment);
- `B9`: Hybrid Chief comparator (not primary decentralized product).

**Network factor:** all online / Slot offline / Tab offline / intermittent connection / delayed duplicated messages.  
**Fault factor:** stable / slot shift / tab shift / both / mismeasurement / shared-sensor bias / stale data / malicious forged event / unseen shift.  
**Physical factor:** acceptance-conditioned lot pairing and held-out printed coupons; actual caliper repeats separated from simulation.

Use a frozen train/calibration/test split **by manufacturing lot and print run**, not random measurement row. Freeze likelihoods, policy costs, thresholds, seeds and success criteria **before** opening held-out outcomes. Pre-register a primary endpoint to avoid cherry-picking.

### 3.2 Primary research questions

- **RQ1 — legitimate collective gain:** At equal evidence access and compute budget, does structured owner-scoped collaboration improve diagnosis accuracy or lower model decision loss versus B1/B2?
- **RQ2 — source integrity:** With forwarded/duplicated observations, does provenance dedup lower posterior overconfidence and false confident decisions versus B5? Test **unknown shared correlations** separately (ID dedup is insufficient).
- **RQ3 — minority protection:** When an evidence-backed specialist dissents from 3–10 unsupported agents, does the veto/challenge procedure lower unsafe-release proposals without excessive HOLD time?
- **RQ4 — value vs entropy:** Under an equal physical inspection budget, does EVSI policy lower decision loss relative to cost-normalized IG? Which priors and loss ratios lead to **no difference**?
- **RQ5 — partition robustness:** Does peer-mode retain more authorized local monitoring and audit progress during a link failure without falsely declaring a missing-evidence pair safe?
- **RQ6 — 21 roles:** Is selective activation (2–6 relevant experts) more efficient than always activating 21 at matched tool availability and token/call budget? Report latency and failure modes.
- **RQ7 — physical containment:** Does a HOLD-capable sorter reduce **false scrap/rejection** and preserve valid rematch options without increasing confirmed bad PASS relative to identical non-agent sorting hardware?
- **RQ8 — generalization:** Do synthetic improvements persist with real measurement noise, non-normal print distributions, changed filament lots and 3D printer temperatures? Negative results are legitimate findings.

### 3.3 Primary outcomes and statistical method

Primary outcome: **paired mean decision loss per incident** under frozen, explicit cost units (or a safety-first lexicographic endpoint where confirmed unsafe release rate is controlled first). Secondary: number of inspections, diagnosis accuracy, false-release proposal rate, unnecessary quarantine, confirmed reject errors, physical successful pairings, elapsed inspection seconds, message bytes, distinct raw measurement IDs disclosed, source confidence calibration/Brier, stale-evidence rate, network recovery, operator approval events.

Use matched random incident streams for all policies. Report both differences and **95% paired confidence intervals** with pre-specified nonparametric bootstrap or suitable paired uncertainty estimators. Do not extrapolate from 2–3 physical pairings to a calibrated industrial percentage; raw/caliper observations stay distinct from simulation. If the pilot has too few parts, emphasize feasibility and confidence limitations.

A credible **negative result** (no gain over classical IG or central upper bound) is a success in scientific integrity, not grounds to hide the baseline.

---

## 4. Reproducible new synthetic prototype: observed facts

### 4.1 What actually runs in this release

```
prototype/peer_decision.py      deterministic Bayesian tool, IG, EVSI, safety/provenance ledger,
                                simple counterfactual stability check
prototype/paired_benchmark.py  4 scenarios × 5,000 synthetic incidents × 4 policies
prototype/decision_trap.py     exact 3-hypothesis counterexample: entropy ≠ decision value
tests/test_peer_decision.py     21 deterministic unit tests
results/benchmark.json         full reproducible aggregate results + normal-approx paired CIs
results/decision_trap.json     exact calculation without random simulation
results/TESTS.txt              unittest output
```

**Environment:** Python standard library only. No external network call, LLM, device, factory API, signed transport or deployed peer services. Source code has documented toy priors, likelihoods, costs and seed. In particular, numeric `false_release_rate` is a **simulated proposed decision outcome**, not a real hardware release.

### 4.2 Completed reference-model comparison

In the `reference` synthetic case, 5,000 matched trials:

| One-step policy | Mean synthetic loss |
|---|---:|
| No inspection | **1.50000** |
| Random inspection | **1.19916** |
| Cost-normalized Information Gain | **1.12590** |
| EVSI-driven V-DER | **1.12590** |

V-DER and IG select the **same inspection** and are **identical** in this toy scenario. This does **not** establish new performance. See `results/benchmark.json` for all four scenarios, including `rare_fault` where the empirical decision policy does **not** outperform the no-test baseline. In the rare-fault scenario, the estimated difference CI includes zero. This result must not be hidden.

**Scope:** loss units arbitrary, highly simplified conditional independence, modeled probabilities, one inspection per incident and no industrial distribution shift. We cannot infer plant ROI or “saves 30% inspections”.

### 4.3 Exact decision-trap counterexample (established theory, good demo)

Consider `H ∈ {safe, fault_A, fault_B}` with prior `{0.5, 0.25, 0.25}`. Action choices release or hold, loss for release under either fault **16 units**, hold **5**, and both test costs **0.1**. Candidate tests:

- `fault_type_marker`: very effective at distinguishing `fault_A` from `fault_B`, but **does not change release-versus-hold choice**.
- `release_risk_signal`: less diagnostic entropy reduction but can reveal that a release recommendation is worth reconsidering.

**Computed exactly** (not Monte Carlo):

| Inspection | Entropy reduction (bits) | EVSI before test cost | EVSI net cost |
|---|---:|---:|---:|
| Fault-type marker | 0.50000 | 0.00000 | -0.10000 |
| Release-risk signal | 0.27807191 | 0.90000 | +0.80000 |

Thus entropy chooses the **wrong inspection for this loss objective**; the decision-value rule chooses the right one. **This is a constructed illustration of existing Bayesian decision theory, not an original theorem or a unique manufacturing discovery.** Its value is to define a falsifiable experimental contrast for the physical system.

### 4.4 Actual demonstrated test status

`python -m unittest discover -s tests -v` → **21/21 tests pass** in this package. Covered: simple Bayes updating, EVSI/IG non-negativity, origin duplicates, authorization/freshness checks, wrong-station measurement rejection, missing-evidence HOLD, human gate, no actuation capability, counterfactual enumeration, exact theory trap.  
Not covered: true signed peer messages, malformed JSON fuzzing, actual hardware command replay, live 3D printing or 21 operational AI agents.

---

## 5. Twenty-one specialist role architecture — retained, with evidence contracts

A role is implemented only when it has `input_schema`, `owner/permissions`, versioned tool, real or simulated truth label, explicit source IDs, failure mode, test and latency budget.

| # | Specialist role | Authorized evidence / output | Testable fail-closed condition |
|---:|---|---|---|
| 01 | Design Geometry | CAD rev / revision-linked constraint | Missing rev: abstain |
| 02 | Tolerance Analyst | Width distributions / clearance and sensitivity | Unknown dependence: warn |
| 03 | Materials Engineer | Batch and temperature / warp hypothesis | Uncalibrated model: unknown |
| 04 | Process Engineer | Local operation log / alternative fault paths | Missing history: conditional explanation |
| 05 | CNC Machining Expert | Tool wear/offset evidence / machining cause | 3D print demo: N/A |
| 06 | Additive Manufacturing Expert | STL/slicer/filament/print logs | No print metadata: unknown |
| 07 | Metrology Engineer | Gauge + repeated readings / measurement uncertainty | Unverified gauge: HOLD |
| 08 | SPC Statistician | Frozen calibration series / EWMA alarm | No baseline: no alarm confidence |
| 09 | Quality Inspector | Owner readings + spec / local part status | Missing reading: HOLD |
| 10 | Assembly Engineer | Slot/tab evidence / pair compatibility | Missing partner: no pairing release |
| 11 | Causal Diagnosis | Process graph, traces / falsifiable hypotheses | Observationally identical causes: unidentifiable |
| 12 | Bayesian Statistician | Validated likelihood / posterior and sensitivity | Unsupported likelihood: exploratory label |
| 13 | Inspection Planner | Allowlisted specimen and cost / IG/EVSI action | No measurement model: fixed fallback |
| 14 | Operations Research | Eligible inventory / candidate matching | Unknown inventory: no automatic pairing |
| 15 | Maintenance Engineer | Machine log / repair hypothesis | No relevant sensor: unknown |
| 16 | Supplier Boundary Agent | Disclosure policy / allowed summaries | Raw field unauthorized: deny + log |
| 17 | Safety and Governance | Safety policy / veto and human gate | Unsafe automatic action: deny |
| 18 | Privacy and Security | Peer identity / auth status | Unauthenticated peer: reject |
| 19 | Reliability and Network | Link history / evidence freshness | Offline: reduce coverage, no green claim |
| 20 | Scientific Auditor | Seeds, hashes, provenance / reproduction report | Mixing synthetic/physical: reject |
| 21 | Kaizen / PDCA | Verified change history / controlled improvement experiment | No causal evidence: hypothesis only |

**Normal incident activates:** 7 Metrology, 8 SPC, 9 Quality, 10 Assembly, 13 Inspection Planner, optionally 6 Additive Manufacturing and 20 Auditor. Others remain available by capability discovery, not all token-billed in a single prompt.

**Three types of distributed actors must not be conflated:**

- **Station peer** = authoritative service owning local raw records and hardware permissions.
- **Specialist agent** = constrained capability, perhaps deployed with the relevant peer, not a new global raw-data reader.
- **Centralized Chief Engineer** = research-comparator orchestrator. `hybrid_chief` can assign requests; it cannot silently override safety veto or become mandatory in `peer_mesh`.

---

## 6. System architecture and one website

```
 [Slot peer + DB]  <---- authenticated evidence requests ----> [Assembly peer + DB]
      ^                                                       ^      |
      |  owner-signed, scoped summaries                       |      | pair-specific HOLD
      v                                                       v      v
 [Tab peer + DB]   <---- peer capability discovery ----> [Sorter peer + local actuator state]
      |                                                               |
 local measurement continued                                        guarded bench action
      +----------------- replicated audit references -----------------+
                                |
                         [Read-only-first Web App]
                                |
                     operator: inspect / hold / approve

    Chief Engineer (centralized/hybrid comparison only): not required above.
```

**Dashboard page structure:**

1. `Factory Overview`: process/lot status, local alerts, evidence freshness, communication topology.
2. `Incident Workspace`: chosen slot/tab pair, risk **with model limitations**, source IDs, disagreements, alternative hypotheses.
3. `Agent Evidence Room`: relevant specialist statements and their cited deterministic tool outputs; vote count never substitutes for proof.
4. `Next Best Inspection`: comparison of IG, EVSI, cost/time, permission, possible decision impact; actual specimen whitelist.
5. `Physical Experiment`: caliper measurements, pairing results and separate simulated scenarios.
6. `Sorter Panel`: PASS / HOLD / CONFIRMED REJECT; ID confirmation; sensor feedback; fail-closed status.
7. `Research Benchmarks`: matched B0–B9 outcomes, error bars, ablation toggles, event manifests and limitations.
8. `Audit and Export`: immutable origin manifest, hashes, posterior snapshot version, tool revision, operator signature, JSON/CSV download.

**Non-negotiable:** closing the website does **not** stop local station measurements. A web UI is an observer and user-action interface, not an agent brain. Camera may help record specimen appearance, but a plain phone photo is not a calibrated millimeter measurement.

### 6.1 Minimum service API contract (target, not already implemented)

- `POST /v1/incidents` at Assembly peer (authorized requester, incident idempotency key)
- `POST /v1/peers/{peer}/evidence-requests` → 200 authorized summary / 403 field denied / 409 obsolete snapshot
- `POST /v1/evidence-events` per owner; monotonic sequence, event ID, physical source ID, schema validation and origin label
- `GET /v1/incidents/{id}/evidence-coverage` → current/expired/denied/partitioned flags
- `POST /v1/incidents/{id}/assessments` → hypothesis posterior, **model** risk, dissent, source references
- `POST /v1/incidents/{id}/inspection-options` → allowlisted actions with net value and costs
- `POST /v1/parts/{id}/disposition-proposals` (local owner role only)
- `POST /v1/sorter/requests` (bounded signed disposition, operator safety gate, no bare LLM string)
- `POST /v1/sorter/confirmations` (actual sensor/operator confirmed motion, never infer success from send)
- `GET /v1/replay/{run_id}` (manifest and replay data)

**Implementation invariants:** prohibit cross-owner raw SQL; authenticated mutually authorized peers; per-field allowlists; schema versions; per-owner outbox/inbox; dedup `(origin_measurement_id, semantic_observation_id)` not merely message ID; hash-chained records where supported; reliable time handling; replay after partition; no silent stale overwrite; approve only the exact evidence snapshot hash reviewed by the operator.

### 6.2 Three operating modes — non-conflicting

- **Primary product:** `fully_decentralized` — source peers initiate requests, challenge and propose without planner.
- **Research:** `centralized_full_info` — explicit privileged raw access, theoretical upper bound; disclose this asymmetry.
- **Research:** `hybrid_chief` — bounded centralized task allocator acting **only as optional coordinator**. Its failure must not stop local peers in the main mode.

---

## 7. The real 3D-printed physical protocol

### 7.1 Geometry and risks

Original teaching assumptions (NOT measured factory tolerances): slot width `20.5–21.5 mm`, tab thickness `19.5–20.5 mm`, minimum functional clearance `0.5 mm`, nominal widths `21.0 mm` and `20.0 mm`. Pair clearance `C = W − T`. Individual local PASS does **not** imply `C ≥ 0.5 mm`.

Generate a planned **50 slots + 50 tabs**, with controlled safe, nominal, near-threshold, and tighter-risk groups. Track printer, STL and slicer revision, filament/lot, temperature/orientation, specimen ID and measurement order. 100 is a target if printing capacity permits, **not a prerequisite to start proving the peer architecture**. Use a small physical subset for live demo plus honest simulation.

### 7.2 Metrology: measurement before AI

1. Caliper instrument ID, resolution, calibration/verification status; use a reference block where available.
2. Repeat 10 readings of a stable coupon to estimate within-operator repeatability. If possible, two operators and repeated specimen orders to assess reproducibility. Retain raw readings, never only an average.
3. Independently measure each `W`, `T` (and geometry orientation/obvious warp) with operator ID, date and room conditions. Do not treat nominal CAD as ground truth.
4. **Physical outcome**: record whether pairing satisfies a documented fit test; do not silently define “fits” by AI forecast. If force-fit affects plastic, log trial order and wear effects.
5. Freeze actual classification rules and hardware safety before held-out evaluation.

### 7.3 Physical demo, exactly what the audience sees

1. Show real slot `S-014` and tab `T-026`, with QR/ID, photograph and two independent local measurement records.
2. Kill one station API process. Its local collection continues; Assembly shows `MISSING_AUTHORIZED_EVIDENCE` and **HOLD**. No fake normal estimate.
3. Restore link; replay queued evidence once. Show same event IDs applied one time and audit proof.
4. Quality and Assembly request only allowed summaries; an evidence-backed dissent invokes inspection rather than majority voting.
5. Inspection Planner proposes an **actual named piece** for caliper re-check; operator performs measurement. New source event updates posterior/compatibility proposal.
6. The person approves physical **bench** routing; Sorter peer routes to PASS/HOLD/CONFIRMED REJECT and waits for sensor/operator confirmation.
7. Show a pair that fails `C≥c_min` yet both parts remain locally conforming, so HOLD/rematch is possible rather than scrap.
8. On the research screen compare identical trials of isolated, centralized, structured peer and ablation modes with uncertainty bars. Clearly identify results simulated versus physically observed.

### 7.4 Hardware safeguards

Low-energy actuator, guarded moving parts, emergency stop, startup default HOLD, no remote control of industrial equipment; unknown part, stale disposition, bin occupancy uncertain, blocked actuator, lost sensor confirmation, duplicated command → **HOLD/STOP**. “Command accepted” is not “part physically sorted.”

### 7.5 Minimum independent validation

The mechanical engineer signs a **Measurement and Fit Report** with all coupon IDs, raw readings, repeatability, failed trials, physical limitations and objective fit rule; a local independent QA observer or fourth teammate may repeat a blinded subset. A paid factory inspection report can validate dimensions, **not** certify the multi-agent system's AI decisions. Actual plant pilot needs real plant data authorization, integration, measurement system analysis, operator validation, risk assessment and further trials.

---

## 8. Team ownership and precise boundaries

### Bakdaulet-omeraiuly — scientific lead / statistics

Own `prototype/`, experiment configs, calibrated likelihoods and baseline fairness, Monte Carlo acceptance conditioning, hypothesis sensitivity, IG/EVSI comparison, posterior calibration, confidence intervals, preregistration, raw results/manifests, and the scientific narrative. Produce `scientific_results.json`, `paired_trials.csv`, `claim_register.md`. **Do not take over the final physical validation/pitch.**

**Definition of done:** frozen seed scripts produce repeatable results; B0–B9 and source-veto ablations run; null results included; clear claims separated from toy assumptions; no unsupported factory ROI.

### adilnurgg — distributed backend / security lead

Own four independently running peer services, per-peer owner DBs, permissioned schemas, direct peer communication or non-authoritative relay, event origin IDs, cryptographic authenticity where feasible, scoped disclosure and HTTP 403 tests, offline local continuity and replay, inspection action whitelist, physical sorter command idempotency and secured human approval. Implement **only** source-bearing deterministic numeric outputs; LLM text cannot act as measurement.

**Definition of done:** four killed/restarted processes with separate local stores, unauthorized read blocked, peer outage changes coverage, no duplicate origin application after reconnect, sorter cannot move without appropriate safety controls.

### HyorinmaruK — mechanical engineering / **physical validation and final pitch**

Own specimen CAD/STL revisions and 3D print logistics, caliper repeatability, controlled variation plan, labeling and physically testable pairings, guarded low-energy sorter mechanism, motion/sensor confirmation, **Measurement & Fit Validation Report**, independent engineering limitations, website presentation flow and **final slides and oral pitch**. The frontend can be shared with an optional fourth member or with adilnurgg; mechanical validation and presentation remain HyorinmaruK's clear accountability.

**Definition of done:** traceable physical demonstration can be repeated twice; all specimens have IDs and raw records; safe HOLD fallback works; presenter can explain why 21 roles do not equal 21 proven LLM agents.

### Optional fourth person — frontend integration / independent QA

Own browser interaction and dashboard polish, contract-driven typed client, live connection status, accessibility, role permission displays, signed-run manifest export, independent regression and cross-peer integration tests, blinded reinspection of physical subset and backup demo recording. If no fourth arrives, create the minimal read-only dashboard with shared work; **do not shift physical validation/pitch away from HyorinmaruK**.

### Interfaces to freeze before parallel work

`part_id`, `lot_id`, `measurement_origin_id`, `event_id`, `owner_peer_id`, `source_kind`, `measurement_units`, `evidence_snapshot_hash`, `schema_version`, `calibration_status`, `approved_action_ids`, `measurement_time_utc`, `run_id`, `simulation_seed`.

- Scientific core returns immutable numeric result + model/version/assumptions; never direct hardware commands.
- Peer services authorize evidence with owner-owned policies; never send a raw DB handle to specialist.
- Site renders typed results, source labels and human approval; never generates missing numbers.
- Sorter validates signed disposition + sensor confirmation, independent of website rendering.

---

## 9. Scope and build order: aim for validated achievement, not maximal claims

### P0: indispensable working decentralized scientific loop

- [ ] One process each for Slot, Tab, Assembly and Sorter, each with separate persisted state
- [ ] Local measurement event + origin and permissioned request/response
- [ ] Compatibility risk and HOLD on missing/stale evidence
- [ ] Offline peer kill/recover test with idempotent replay
- [ ] At least one physical caliper reading and one real fit result
- [ ] One confirmed physical sorting decision or, if hardware fails, clearly labeled operator-assisted sorting **not** disguised as automated actuation
- [ ] One matched statistical comparison and one 95% interval, including a negative/null baseline if found
- [ ] Source hashes, provenance, human gate, visible research limitations

### P1: if P0 passes with time left

- [ ] Distinct source-origin evidence deduplication in **distributed**, not in-process, transport
- [ ] Signed minority-dissent evidence challenge and a physical re-check
- [ ] One controlled V-DER versus IG ablation, same data/cost/seed
- [ ] 21-role registry displayed with **implemented vs contract-only** status
- [ ] Kaizen PDCA controlled experiment proposal (no untested claim of improvement)

### P2: post-hackathon industrial research

- [ ] Multi-factory authorization, real CMM sensor integration, OPC UA adapter
- [ ] Dependence-aware calibrated fusion beyond simple ID dedup
- [ ] Repeated physical print runs, shift calibration, prospective blinded validation
- [ ] Usability and human factors evaluation, factory pilot and risk analysis
- [ ] Registered external replication, systematic novelty search and peer-reviewed submission

---

## 10. Internal acceptance / scientific gate

**No unconditional 10/10:** judge performance is outside our control. Internal scientific completion is a binary contract:

1. **Truth:** source event IDs from real sensors or labeled simulation; no fake factory validation or 10k read-paper claim.
2. **Reproducibility:** tests/seed/config known, negative and positive results exported.
3. **Decentralization:** genuine independently stopped processes, no shared root DB required for a quality incident.
4. **Safety:** unauthorized reads rejected; physical actuation fail-closed; human approves consequential actions.
5. **Collective value:** fair same-budget comparison shows measured tradeoff; if no performance gain, report the honest limit.
6. **Hardware:** at least one actual print, caliper and fit observation; physical/simulation metrics separated.
7. **User value:** one clear quality-engineer decision with timing/cost explained, not a list of 21 chatbots.
8. **Research scope:** position novelty as a hypothesis plus evidence, not an undisputed new theorem.

If any of these are incomplete, the website must identify the gap. This is safer and more credible than decorating an unbuilt demo with a scientific score.

---

## 11. Runnable reproduction (available now)

From the root of this v13 package:

```bash
python -m unittest discover -s tests -v
PYTHONPATH=prototype python prototype/decision_trap.py
PYTHONPATH=prototype python prototype/paired_benchmark.py --n 5000 --out results/benchmark.json
```

Expected result at package creation: **21 tests passed**. Result JSON reports mean loss and 95% paired normal-approximation CI for `decision - IG` and `decision - no inspection`. Because this is **single-process toy code**, do not call these network tests or a distributed implementation.

### 11.1 Reuse the earlier versions without losing anything

`legacy/QualityRelay_12_ORIGINAL_UNMODIFIED.zip` is the **original supplied v12 archive copied intact**; it includes nested v11 and earlier references (including v10 and v5 materials). Run an archive integrity check before extraction. The new master blueprint records the v12 no-regression requirements, but original schemas/STL are preserved in the prior archive rather than silently edited. If a requested production feature is not implemented, carry it as a tracked task, never an achieved claim.

---

## 12. Research references and literature audit

The auditable index `research/verified_sources.csv` contains **18 references** with title, year, publisher or source, DOI/URL, literature status, and **reading depth**. Neither that index nor any nested archive demonstrates a completed systematic review of 10,000 works. All URLs below identify source publications; a direct source URL should be used in a paper or slide instead of an unsupported secondary paraphrase.

- **[R01]** Official ScienceClaw event and judging: https://scienceclawhack.ai/
- **[R02]** NIST digital-thread case (Hedberg et al., 2021): https://doi.org/10.1080/00207543.2021.1920057
- **[R03]** Moliner-Heredia et al., sequential inspection (2021): https://doi.org/10.3390/s21227524
- **[R04]** CIRP Annals quality gates (2024): https://doi.org/10.1016/j.cirp.2024.04.015
- **[R05]** Li, Naito & Shirado, HiddenBench, ICML (2026): https://proceedings.mlr.press/v306/li26ej.html
- **[R06]** Pappu et al., expert dilution, ICML (2026): https://proceedings.mlr.press/v306/pappu26a.html
- **[R07]** Pitre et al., communication failures (2026, **preprint**): https://arxiv.org/abs/2610.32060
- **[R08]** AgentAuditor, EMNLP (2026): https://aclanthology.org/2026.emnlp-main.2642/
- **[R09]** Procedia CIRP trust in manufacturing agents (2025): https://doi.org/10.1016/j.procir.2025.02.183
- **[R10]** Automatica decentralized common-information fusion (2017): https://doi.org/10.1016/j.automatica.2017.01.019
- **[R11]** Fully decentralized fusion and dependencies (2021): https://isif.org/media/fully-decentralized-estimation-using-square-root-decompositions
- **[R12]** EVSI tutorial (2022): https://doi.org/10.1177/0272989X211026292
- **[R13]** Selective conformal prediction CAP (2025): https://jmlr.org/papers/v26/24-0452.html
- **[R14]** Industrial time series distribution shift uncertainty (2025): https://doi.org/10.1109/TII.2025.3529920
- **[R15]** Multi-agent manufacturing scheduling (2025): https://doi.org/10.1016/j.jmsy.2025.01.004
- **[R16]** NIST Gauge R&R technical guide: https://www.itl.nist.gov/div898/handbook/mpc/section4/mpc4.htm
- **[R17]** Bayesian monitoring of machining processes (2025): https://doi.org/10.1007/s00170-025-15174-x
- **[R18]** Belief entrenchment and debate (TACL 2026): https://aclanthology.org/2026.tacl-1.58/

### 12.1 How to turn this into real publishable work

A later paper needs: systematic PRISMA-style eligibility rules, registered search date and screening decisions, full industrial model calibration, at least one external replication, leakage-free randomization by lot/run, uncertainty and costs estimated from practice, comparison to **strong** published methods and significance/effect-size reporting, and explicit industrial risk evaluation. The present artifact advances the **design and testability** of the question, not its final scientific resolution.

---

## 13. Final presentation script (claim-safe)

> *“Most factory quality systems can measure parts and detect anomalies. Our research question is different: when each station owns only part of the evidence, can decentralized agents identify the most useful next physical test without overconfidently merging copies of the same evidence? QualityRelay preserves local data ownership, records every source, allows a measured dissent to override unsupported consensus, and recommends inspections against an explicit decision-loss model. We tested the algorithms in reproducible simulations, and we demonstrate a real 3D-printed assembly and safe HOLD-based sorting. We do not claim the method already outperforms every centralized or information-gain baseline. Our experiment reports exactly when it helps, when it ties, and what remains uncertain.”*

**Keep the 5.0 scientific core. Keep 12.0 physical sorter and genuine decentralized direction. Elevate 13.0 source integrity, decision-aware inspection and fair falsifiable tests. Build one true experiment instead of claiming 21 untested AI experts as an invention.**


---

## PART II — QualityRelay 13.1 VISION-EVIDENCE camera research and implementation

# QualityRelay 13.1 — VISION-EVIDENCE: Scientific Camera Integration

**Status:** Research-grounded design addendum, with a small tested computer-vision proof of concept; **not** a certified camera measurement device or a validated factory product.  
**Date:** 2026-10-30  
**Base:** QualityRelay 13.0 EVIDENCE-MESH, unmodified original package retained in ZIP.  
**Audience:** scientific team, mechanical engineer, decentralized backend engineer, potential factory pilot partner.

---

## Executive decision: YES, the camera must detect actual defects

The web camera must not be a decorative photo capture or a general LLM saying "looks fine". It must produce a **traceable, auditable visual observation** with a defect region, reason, model/version, confidence characterization, device conditions, and an appropriate follow-up action. The camera integrates with the physical Slot/Tab/Assembly/Sorter system and the scientific EVIDENCE-MESH protocol.

**Recommended core concept: VISION-EVIDENCE** — *calibrated, decision-aware active visual inspection in a decentralized manufacturing evidence network*. This is a proposed combination of existing scientific methods, **not a proven novel theorem or discovered scientific law**.

The camera adds two distinct evidence families:

1. **Visual appearance / anomaly detection:** detect visible defects (warping, layer shift, stringing, gaps, cracks, missing geometry, contamination, material blobs). This can be possible with RGB imagery and controlled lighting, after validation.
2. **Optical geometric metrology:** estimate visible planar geometry in millimeters **only** when proper calibration, reference plane, uncertainty budget, and independent verification make the estimate credible. With an ordinary phone and uncontrolled perspective, report *visual estimate* or *cannot measure*, not certified millimeters.

**Do not claim:** RGB detects subsurface voids, material strength, all micrometer-size defects, exact 3D dimensions from a single image, or universal fault-source causality. A photo cannot unambiguously infer internal quality and process root cause.

### Preserve from v13.0
- Four independently running peers: Slot, Tab, Assembly, Sorter; **fully decentralized** is the main mode. Camera capability is attached **locally** to owning peer(s). The website is an operator interface, not a global camera decision authority.
- 21 existing expert roles remain; add **22. Vision & Metrology Engineer** as a specialist capability, not as a mandatory centralized hub.
- Evidence origin IDs, access control, direct peer requests, anti-double-counting, signed provenance, degraded/offline behavior, Evidence Debt Ledger, decision-aware V-DER / expected value of sample information (EVSI), PACE guard, expert dissent, human confirmation, conservative HOLD and independently confirmed REJECT.
- Real 3D-printed coupons + real caliper fit testing + optional physical sorter; simulation must stay separate from physical observation.

---

## 1. Research evidence and what it does *and does not* establish

| Evidence | Verified finding | QualityRelay implication | Limitation |
|---|---|---|---|
| MVTec AD, CVPR 2019 / IJCV | 5,354 images, 15 classes, pixel-level abnormal regions | Start with known anomaly benchmarks | Metal/consumer objects are not your printed Slot/Tab distribution; CC BY-NC-SA commercial restriction [S01] |
| MVTec LOCO AD, IJCV 2022 | Detect structural **and logical** anomalies | A visually normal part may be invalid in a pairing | General logical dataset ≠ evidence of pair-fit performance [S02] |
| PatchCore, CVPR 2022 | Good few-normal-image industrial anomaly baseline; up to 99.6% AUROC on a benchmark | Compare against non-generative normal-only baseline | **This AUROC is not the camera's accuracy on your part** [S03] |
| EfficientAD, WACV 2024 | Very fast student/teacher industrial anomaly detection, includes logical anomaly variants | Real-time candidate with appropriate compute | Published paper latency is not MacBook/iPhone browser latency [S04] |
| CVPRW RobustAD 2025 | Lighting, pose, clutter and other *real* domain shifts degrade anomaly detectors | Mandatory out-of-distribution experiments and abstention | Benchmark transfer is not guaranteed [S05] |
| FDM process monitoring review, 2024 | Under/overextrusion and related defects can have visual signatures | Tailor appearance taxonomy to actual PLA defects | Visible surface ≠ proven strength/structural conformity [S06] |
| FDM image dataset, Zenodo 2026 | Real 3-angle printed-object imagery includes layer shift, extrusion, stringing, good prints | Use as external pretraining/evaluation *subject to license* | 48.4 GB; transfer to your printer and optics must be evaluated [S07] |
| FDM dataset Hu et al. 2024 | 1,912 images, 5 defect types, lightweight deployment work | Smaller reference for FDM-specific classes | Check labels, split and deployment conditions [S08] |
| OpenCV calibration docs | ChArUco/chessboard calibration needs multiple good views; pattern geometry and sharpness matter | Calibration workflow with reprojection audit | Pixel-per-mm alone is not full measurement uncertainty [S09] |
| NIST 2005 camera inspection calibration | Part-feature accuracy can be ~1 mm in a specific 45 cm distance experiment | Validate rig at YOUR geometry and desired threshold | Do not transpose published accuracy to our system [S10] |
| NIST traceability | Traceable results require documented calibration chain and uncertainty | Metadata, check references, uncertainty fields and limits | A calibrated instrument alone does not certify results [S11] |
| Structured light vs CMM, CIRP 2024 | Comparing printed-part optical 3D measurements against contact CMM is an established route | Optical 3D as future P2 extension | Greater hardware burden; not required for P0 [S12] |
| Photometric stereo inspection, Scientific Data 2025 | Multi-illumination and multiple perspectives reveal complex surface anomalies | Optional P1 lighting-angle upgrade | Surface normal estimation needs controlled illumination/geometry [S13] |
| Manufacturing visual-survey, 2025 | Review of 196 papers; domain shift and rare defects remain challenges | No unsubstantiated 'universal accuracy' | Prior art is extensive [S14] |
| Printed-part tolerance study, 2025 | Controlled dimensions and assembled part response can be experimentally analyzed | Physical Slot/Tab pairing gives meaningful independent outcomes | Dimensional/geometry print deviations perturb results [S15] |
| NIST camera system validation, Oct 2026 | Metrology-grade optical instrument reported submicron uncertainty with controlled machine hardware | Rig matters more than neural-network marketing | An iPhone or webcam is NOT equivalent to the NIST instrument [S16] |

**Interpretation:** camera-based defect detection exists; adding YOLO or PatchCore is not a scientific discovery. The investigable gap is whether **calibrated, provenance-aware, selectively acquired camera evidence** improves the *safe industrial decision* made by decentralized peers under access limits, model shift, conflicting expert conclusions and communication failures.

---

## 2. Exactly what the camera should detect

### 2.1 Part-level appearance taxonomy

| Target | RGB feasibility | Ground-truth method | Recommended first model | Safe output |
|---|---|---|---|---|
| Slot/Tab identity, orientation, missing part | High in jig | ID record + manual confirmation | Fiducial/QR + geometry | IDENTIFIED / RECAPTURE |
| Slot not open, tab missing tip, gross shape deformity | High with backlit silhouette | CAD outline + independent examiner | OpenCV silhouette/contours | SUSPECT_DEFECT + ROI |
| Stringing, protrusions, blobs | Conditional on visible size/angle | Human annotation + alternate view | Baseline threshold + PatchCore | SUSPECT_SURFACE + ROI |
| Layer shift and side warping | Good from suitable side/top | Caliper/straightedge + human labeling | silhouette geometry / anomaly model | SUSPECT_WARP + ROI |
| Surface cracks, delamination | Depends on crack resolution and lighting | Macroscopic examiner/magnification | multilight imagery + PatchCore | SUSPECT_CRACK + ROI |
| Near-threshold dimensions (e.g., 0.3 vs 0.5 mm clearance) | **Not automatically dependable** | calibrated gauge, repeatability and independent fit | Calibrated fixed-geometry machine vision | ESTIMATE_WITH_U or REQUEST_CALIPER |
| Hidden internal porosity, bond strength | Not established by RGB | CT/mechanical tests | **none** | NOT_OBSERVABLE |
| Assembly-specific actual fit | Vision can observe contact/failure signs | Recorded physical fit protocol | Vision + fit outcome, not vision alone | OBSERVED_FIT or UNKNOWN |

**Labels distinguish:** `visual_anomaly`, `optical_measurement`, `caliper_measurement`, `operator_fit_outcome`, `simulated_measurement`, `model_inference`. The AI cannot quietly relabel one source as another.

### 2.2 In-process print camera vs post-print inspection camera

- **Post-print inspection**: essential for the hackathon; images of coupon after printing; consistent jig, dark matte backing or backlit silhouette, optional alternate illumination; match part ID and lot.
- **In-process monitoring**: optional advanced workflow, uses printer-side frames to detect spaghetti, bed adhesion, layer shift and some extrusion failures early. Frame sequences from a single event are **correlated**; avoid treating each frame as independent evidence.
- **CAD / pairing**: neither camera alone nor LLM chooses a safe assembly. Assembly peer combines design requirements + authenticated slot/tab evidence + conservative uncertainty and actual fit outcomes.

---

## 3. Camera hardware and rigorous acquisition

### P0 — ready for a 3-person hackathon
1. MacBook camera, spare webcam or smartphone **mounted rigidly** above small parts (no handholding during measurements).
2. Fixed part jig: consistent object pose, photo-matte neutral background and clear part ID.
3. Diffuse LED illumination for surfaces; backlight (or high-contrast board) for silhouettes, separated into two capture modes.
4. Reference ChArUco board or ArUco + verified reference length **on the same geometric plane as the measurement**. Record printed fiducial physical dimensions and do not assume a paper printer reproduces its nominal size.
5. Caliper for actual physical dimension ground truth; record gauge ID, resolution, verification and repeated measures.
6. Browser capture through `navigator.mediaDevices.getUserMedia()` over HTTPS/localhost; camera permission remains under user's control. UI previews a frame; backend processes a frozen, hashed image. Capture resolution and focus/exposure must be recorded where available.

### P1 — robust validation / more useful visual defects
- Second side-view camera or manually indexed side view with repeatable physical jig.
- 2–4 switchable LED directions for photometric-like surface comparison.
- OpenCV camera intrinsics, lens distortion correction, checked image sharpness/blur, exposure, marker visibility and spatial resolution; acquisition-quality gate.
- Trainable normal-only anomaly detector: PatchCore **versus** EfficientAD **versus** an interpretable geometry baseline, tested on held-out parts and print runs.

### P2 — industrial optical measurement
- Industrial fixed-focus and, where needed, telecentric lens; calibrated optics; high-stability lighting; CMM/structured-light benchmark; measurement systems analysis (repeatability/reproducibility) under varied operators.
- For true 3D geometry: structured light, stereo or controlled multi-view reconstruction. Do not infer depth from one arbitrary monocular RGB image.

### Pixel footprint vs actual measurement uncertainty — explicit example

If a 1920-pixel image shows a **100 mm field of view**, the nominal image scale is `100/1920 = 0.0521 mm/pixel`. This is pixel sampling, **NOT a claimed 0.0521 mm measurement accuracy**. Depth offsets, lens distortion, edge ambiguity, reflections, thermal/print effects and setup repeats may dominate. If the functional clearance is only 0.5 mm, the decision boundary is delicate; `u_camera` must be measured on independent reference artifacts. If calibrated uncertainty is too high relative to the acceptance margin, the policy requires a caliper measurement.

### Planarity limitation
A marker glued to the table and a tab surface elevated 5 mm are **not necessarily coplanar**. Do not measure raised surfaces using an uncorrected planar table homography. The experimental camera proof-of-concept below deliberately marks calibration as `unverified` until a proper controlled-height setup and independent uncertainty study are performed.

---

## 4. Camera pipeline: 7 audited stages

1. **Acquire**: `CameraCapture` from the owning station, actual physical specimen ID, timestamp, exposure/pose/lighting mode, source origin hash. Never accept an arbitrary remote URL as authenticated sensor evidence.
2. **Quality gate**: sharpness, glare, occlusion, reference pattern visible, target not clipped, physically valid plane, expected resolution. Reject/recapture if not satisfied.
3. **Geometry calibration**: internal lens parameters and distortion; pattern corners; plane-specific homography (or industrial 3D pose). Record calibration version and uncertainty; if unavailable, no authoritative mm result.
4. **Segmentation / localization**: controlled OpenCV silhouette/scanline baseline; optional trained anomaly heatmap (PatchCore/EfficientAD); localize defect ROI and compare with CAD regions.
5. **Evidence typing**: create `VisualEvidence` referencing specimen ID, event/origin ID, model hash, score, confidence calibration method, mask/ROI, lighting, artifact URI/hash, source_kind=physical, and `measurement_status`.
6. **Independent check / dissent**: Quality & Metrology agents inspect evidence; Design/Assembly agents check functional tolerance. Uncertain or conflicting claims trigger a **new useful observation** (different view, lighting, caliper or physical fit), not LLM majority vote.
7. **Safe disposition**: `HOLD` for inconclusive; `PASS_ELIGIBLE` only under independently validated station quality rules and allowed policy; `CONFIRMED_REJECT` only with verified independent nonconformance. Operator approves sorter action and feedback confirms real motion.

### Critical anti-correlation rule
A burst of 30 images from one object and one camera condition is **one correlated acquisition group**, not 30 independent physical proofs. Repeated photos under different light/angles also share physical sources and calibration errors. Assign `physical_origin_id` and `acquisition_group_id`; do not multiply likelihood ratios without a tested dependence model.

---

## 5. Proposed science: Calibrated Active Inspection Routing (CAIR)

**Research idea (not an established novel theorem):** make camera *view/illumination selection* and *caliper inspection requests* compete in the same decision-value policy as V-DER, while respecting uncertainty, data ownership, image-provenance and correlated evidence.

### 5.1 Variables
- `H`: latent failure source / defect type / assembly-fit hypothesis (e.g., slot_shift, tab_shift, both_shift, visual_warp, misalignment, nominal).
- `E`: authorized, fresh, provenance-validated evidence seen by this peer.
- `D`: safe actions such as HOLD, additional inspection, propose alternate pairing, propose release after human gate.
- `a`: one actual feasible inspection: `CAPTURE_TOP`, `CAPTURE_SIDE`, `CAPTURE_RAKING_LED`, `MEASURE_CALIPER`, `TRIAL_FIT`.
- `y`: possible result generated from empirically estimated sensor likelihood `p(y|H,a,setup)`.
- `L(d,H)`: pre-registered asymmetric loss for real production outcomes.

**Decision-based value of camera evidence:**

`VOI(a|E) = min_d E[L(d,H)|E] - E_y[min_d E[L(d,H)|E,y,a]] - C(a) - Risk_penalty(a)`

Subject to: camera can only make claims at the supported acquisition state, authorized data access, explicit calibration/uncertainty, high-risk release blocked when posterior unreliable. Choose the highest feasible positive-value observation; if none, apply conservative HOLD or human specialist review. Known Bayesian EVSI principles underpin this; the potential contribution is **the deployable constrained, calibrated, decentralized integration**, which must be benchmarked.

### 5.2 New *falsifiable* research hypotheses
- **H1 (visual utility):** adding visual evidence to caliper/SPC changes the correct diagnosis under held-out appearance faults while not increasing false safe-release proposals.
- **H2 (active sensing):** a *decision-value* next-view/caliper policy uses fewer seconds / lower inspection loss than fixed three-view and entropy-based IG, at comparable safety.
- **H3 (source integrity):** acquisition-group dependence handling produces better calibration and less overconfidence than naive independent-frame fusion.
- **H4 (domain shift):** quality gating and abstention reduce false safe-release proposals under new light/angle/printer compared with visually confident always-predict baseline, though HOLD frequency may increase.
- **H5 (decentralization):** with identical sensor models and budget, peer-only selective evidence exchange approaches centralized decision quality with fewer raw-image bytes crossing ownership boundaries; connection loss does not silently turn stale images into evidence.
- **H6 (real benefit):** camera reduces unneeded manual inspections compared with caliper-only QC **without worsening safety**, when mixed appearance + dimensional faults occur. If camera adds no benefit, report null result.

### 5.3 Methods and baselines
| Baseline | Camera | Coordination | Inspection choice |
|---|---|---|---|
| B0 Traditional | No | Station-local | Caliper on fixed sample plan |
| B1 Classical CV | Yes | Local only | Fixed image threshold / ROI |
| B2 PatchCore | Yes | Local only | Fixed views; normal-only learned model |
| B3 EfficientAD | Yes | Local only | Fixed views; learned model |
| B4 CV + caliper | Yes | Centralized | Fixed plan |
| B5 Agent + camera | Yes | Single centralized AI | Same tool list/budget |
| B6 EVIDENCE-MESH with camera | Yes | True peer-only | entropy / IG next view |
| B7 CAIR (proposed) | Yes | True peer-only | VOI with calibration + abstention |
| B8 Ablation | Yes | Peer | CAIR **without** origin dedup or uncertainty guard |
| B9 Offline network | Yes | Peer | CAIR with missing camera/stale evidence |

**Fairness:** same raw physical specimens, image streams, frozen lens/detector versions, time/measurement budgets and hidden labels. No cheating by allowing a baseline less data or weaker models. Centralized full-evidence reference can be an upper bound, not a strawman.

---

## 6. Physical experiment plan using the existing 100 printed coupons

**Preserve existing target:** 50 Slot + 50 Tab, if printing capacity permits, split across normal, near-threshold tolerance, intentionally warped, and visibly defective conditions. Avoid damaging all samples before ground truth. Record exact number produced, not aspirational counts.

### Ground truth & split
1. Design in CAD with frozen revision and explicit functional clearance `C=W-T`, required `c_min=0.5 mm` in demonstration config (a configuration assumption, not universal engineering threshold).
2. Print across **at least two print runs** if feasible; label specimens BEFORE inspection; record printer, nozzle, PLA batch, direction, slicer, temperature, STL hash, run ID, lot ID.
3. **Blind held-out print run/lot**, never random-frame split — multiple frames of one specimen must stay within the same split. Avoid hyperparameter and threshold tuning on test specimens.
4. One independent mechanical examiner measures Slot width and Tab thickness with verified caliper, repeats at multiple points/positions, documents gauge repeatability; engineer separately records fit outcomes and visible defect annotations, marking ambiguous labels.
5. For each specimen, fixed top and side photos; optionally change LED direction and repeat capture under shifted conditions. Assign `acquisition_group_id`; annotators must not see the AI prediction.
6. Freeze thresholds / priors / costs before held-out evaluation. If limited defect coverage makes calibration impossible, report **feasibility demonstration**, not a validated classifier.

### Primary and secondary outcomes
**Primary safety gate:** no unsupported unconditional PASS / RELEASE; compare paired false-safe-release proposals to baseline and HOLD rate. High-risk acceptance criteria must be set before running; *no single toy sample can certify an industrial safety rate*.

**Primary scientific endpoint (pre-register one):** paired **decision-loss per incident** or cost of inspection to attain a predefined conservative decision quality, including label uncertainty and safety penalty.

Secondary:
- per-defect class sensitivity/recall, specificity, precision, F1; report numerator/denominator and confidence intervals;
- image AUROC and pixel-level AUPRO / IoU only when valid masks exist;
- calibration ECE/Brier and selective risk as fraction of images abstained grows;
- mean absolute error, signed bias, repeatability and uncertainty of optical dimensions **versus** verified gauge, stratified by height/orientation/lighting;
- count and duration of extra manual inspections, time per part including capture & processing, false HOLD and false REJECT;
- assembly fit success rates with actual physical trials, distinct from optical guess;
- peer message bytes, image bytes exposed, replay idempotence, offline recovery, degree of duplicated evidence.

### Statistical rigor
- Paired comparisons by **specimen/lot**, not frame. Bootstrap sampling at specimen/print-run cluster level. Report 95% confidence intervals and both advantages **and** failures. 100 physical coupons are not 100 independent defect types or a factory field trial.
- One printer, one filament, fixed background and lighting leads to severe generalization limits. Use shifted lighting, moved camera, changed orientation and at least one held-out printer/process configuration if feasible.
- Do *not* select the best of many algorithms using the final test data. Use fixed model selection plan or nested validation.
- Safety decision thresholds should depend on documented loss and uncertainty, not arbitrary 'confidence > 90%' labels.

### Camera vs caliper classification (explicit)
- `CAMERA_VISIBLE_NONCONFORMANCE`: only if objective pre-validated visible criterion and acceptable detection uncertainty; otherwise `SUSPECT_VISUAL_FAULT`.
- `CAMERA_GEOMETRIC_CANDIDATE`: geometric measurement with uncertainty; cannot assert final tolerance when boundary overlaps uncertainty interval.
- `INDEPENDENT_GAUGE_CONFIRMATION`: physical calibrated or verified gauge event.
- `PROPOSE_PAIR / HOLD`: inferred assembly decision from accepted sources.
- `CONFIRMED_REJECT`: independently documented part nonconformance, owner-authorized, human-controlled physical sorter.

---

## 7. Peer architecture: camera is NOT a new single point of failure

```text
                      [Browser UI: capture / inspect / propose]
                                    |
                    [owner-specific authorized endpoints]
                                    |
    [Slot peer + local DB] <----------> [Tab peer + local DB]
        |  Visual module                | Visual module
        |  + frame store                | + frame store
        |                               |
        +-------- scoped VISUAL EVIDENCE summary --------+
                                                        |
            [Assembly peer + local DB] <--> [Sorter peer + local DB]
                  | risk / diagnosis          | safe physical action
                  |                           | idempotent feedback
                  +---------- peer evidence --+

Optional: Chief Engineer for hybrid baseline / non-authoritative advisory.
Neither website nor LLM is authoritative measurement or actuation hub.
```

- Camera process lives next to owning station. Image files stay on local storage by default. Authorized peer receives a signed defect summary, crop, feature summary or need-to-know image if policy explicitly permits.
- Each image/crop/model output refers to immutable origin; derivative transformations retain `parent_evidence_ids`.
- `camera_unavailable` marks source missing; local caliper / SPC monitoring continues. A missing image cannot become an inferred good image.
- The system shares only needed evidence; no global aggregator sees all raw video by default.
- Chief Engineer, if enabled in hybrid comparison, can request reinspection but has no universal raw image privilege and cannot actuate hardware alone.

### Suggested JSON schema — camera event (illustrative)

```json
{
  "event_type": "VISUAL_INSPECTION",
  "event_id": "slot-ev-00412",
  "physical_origin_id": "capture-camA-partS08-top-001",
  "acquisition_group_id": "partS08-camA-session3",
  "specimen_id": "S08",
  "lot_id": "SLOT-A07",
  "owner_peer_id": "slot",
  "source_kind": "physical",
  "camera_device_id": "camA",
  "capture_mode": "TOP_DIFFUSE",
  "capture_time_utc": "2026-10-30T21:00:00Z",
  "image_sha256": "<actual computed SHA256>",
  "model_version": "silhouette-baseline-v0.1",
  "lens_calibration_version": null,
  "measurement_status": "unverified",
  "measurement_value_mm": null,
  "measurement_uncertainty_mm": null,
  "anomaly_classes": ["suspected_warp"],
  "roi_mask_sha256": null,
  "distribution_shift_flags": ["new_lighting"],
  "confidence_status": "uncalibrated",
  "recommended_action": "REQUEST_CALIPER",
  "parent_evidence_ids": [],
  "permissions": ["assembly:read_summary"],
  "signature": "<actual signature from owning peer>"
}
```

The placeholders are **not** valid hashes or signatures. Do not display these as captured reality. Production schema uses strict validation, nonempty legal permissions, typed uncertainty, ACL, and genuine cryptographic signing.

### API additions (per owner)
- `POST /v1/vision/captures`: authenticated local image upload + part ID + scene metadata; returns a capture ID, never self-reported PASS.
- `POST /v1/vision/captures/{id}/inspect`: quality gate / detector / uncertainty metadata; deterministic structured result.
- `GET /v1/vision/events/{event_id}`: owner authorized evidence view.
- `POST /v1/vision/inspect-options`: allowlisted next views / gauging actions and estimated risk/cost, in a frozen model.
- `POST /v1/evidence-requests`: remote peers request allowed image summary or selected crop; raw images denied by default.
- `POST /v1/incidents/{id}/inspection-options`: V-DER/CAIR enters same candidate ranking as other existing physical actions.
- `POST /v1/sorter/requests`: unchanged signed, human-approved safe physical sorter contract.

### Camera agent tool contract
`Vision & Metrology Engineer` consumes owned `VisualEvidence` and optional documented engineering drawings; outputs one of `OBSERVED_SURFACE_ANOMALY`, `ESTIMATED_GEOMETRY_WITH_UNCERTAINTY`, `CANNOT_MEASURE`, `RECAPTURE`, `REQUEST_ALTERNATE_VIEW`, `REQUEST_CALIPER`. It has **no authority to invent numerical mm measurements, overwrite another station's sensor data, or release/reject a part**.

---

## 8. Site walkthrough for the judges

1. **Factory Dashboard:** four peer status tiles; camera connected to Slot/Tab; active physical and simulated evidences clearly separate.
2. **Camera Inspection:** scan physical sticker/ID; camera preview opens; pick TOP/SIDE light mode; display image-quality meter and calibration marker visible/invalid state.
3. **AI Analysis:** side-by-side original image and defect heatmap/outlined ROI, model name and label, calibration status, "what camera can/cannot tell". Display an `unverified camera dimension` only as an estimate.
4. **Peer Collaboration:** Assembly requests the smallest authorized Slot/Tab summaries; minority visual alert contradicts initial statistical prognosis; evidence-debt panel marks issue unresolved.
5. **Next Best Evidence:** system compares `RECAPTURE_SIDE` (time cost), `CALIPER_S08` (time cost), `TRIAL_FIT` (risk/cost) via decision-value calculations; show why one action chosen.
6. **Physical Verification:** HyorinmaruK performs actual measurement or fit trial; source event gets `physical` label; diagnosis and posterior update, with provenance.
7. **Sorter:** only authorized operator confirms the PASS/HOLD/CONFIRMED REJECT action; low-energy sorter reports actual hardware sensor confirmation. No fake sort if physically not tested.
8. **Research Results:** identical physical images and trial sequences for traditional CV, PatchCore/EfficientAD, isolated AI, centralized and peer-structured methods. Use uncertainty bars; label simulated or physical each metric.
9. **Resilience:** disconnect camera peer / station; show stale evidence and local continuity with HOLD, reconnect and idempotent replay.

---

## 9. Engineering work allocation (3 + optional 4)

**Bakdaulet-omeraiuly — science, statistics, evidence-policy**
- Freeze visual defect taxonomy, priors and loss matrix, design CAIR/IG/EVSI controls, evidence dependence handling; train/evaluate normal-only and classical CV baselines in fair split.
- Build paired benchmark scripts, camera calibration error and decision-loss analysis, intervals, preregistration and claim register.
- Own endpoint contracts specifying what can be called a calibrated result.

**adilnurgg — decentralized/backend/security and camera ingestion**
- Implement browser authenticated camera ingestion route, owner-local storage, image SHA-256, metadata schema, scoped evidence retrieval, peer events and ACL.
- Connect inspector to Slot/Tab and Assembly plus next-inspection API; missing camera/invalid calibrator -> HOLD; offline/replay, genuine signed human sorter actuation.
- Implement guard: no LLM prose promoted to instrument measurement; no browser permissions bypass; image denial to unauthorized peers.

**HyorinmaruK — MECHANICAL ENGINEER, camera rig, physical ground truth, FINAL PRESENTATION**
- Own camera/part fixture, lighting modes, actual marker/gauge measurements, printed coupons/defect injection, part ID and ground-truth inspection protocol, repeated physical fit tests.
- Evaluate physical feasibility of detecting small warps/gaps and report measurement uncertainty; demonstrate camera-to-caliper-to-fit loop and the sorter.
- Own final slide deck, hands-on jury demo, and limitations slide. This responsibility remains unchanged.

**Fourth teammate (if recruited) — frontend + independent CV evaluation**
- Build polished camera preview/heatmap + evidence uncertainty widgets; accessibility; browser camera permission handling; shareable replay.
- Blind audit a held-out subset, reproduce CV benchmarks, verify network offline scenarios and no simulated/physical mixing.

If no fourth person joins: adilnurgg handles minimal camera UI, Bakdaulet helps benchmark reporting; **HyorinmaruK stays physical validation + pitch owner**.

---

## 10. Practical implementation priorities and cut lines

**P0 (must exist in live demonstration):**
- a real camera in website, actual physical Slot/Tab ID and captured image;
- local image hash and authorized owner event with true source label;
- a working deterministic silhouette / shape anomaly baseline plus at least one genuine positive and negative image;
- automated `SUSPECT_VISUAL_FAULT`/`RECAPTURE`/`REQUEST_CALIPER` action with evidence ROI;
- operator caliper or physical fit evidence; independent peer decision changes or abstains on insufficient evidence;
- physical sorter interaction if already built, otherwise honestly labeled manual routing;
- evidence and simulation do not mix; no unsupported numeric accuracy.

**P1 (research strength):**
- lens calibration and hard image-quality gate; verified reference artifact; camera dimensional estimate ± empirical uncertainty;
- PatchCore/EfficientAD compared to classical baseline, held-out print-run split and light/angle shifts;
- alternate-angle/light selection through V-DER/CAIR; measure decision cost, uncertainty and failure rate;
- calibrated uncertainty, evidence dependence IDs, denied raw access and peer outage test.

**P2 (future industrial pilot):**
- multi-view / structured-light optical measurement, independent CMM/industrial metrology cross-check;
- actual factory datasets and equipment protocols, MSA (gauge R&R), audited change control, security, task-specific industry validation; vendor-specific industrial integration.

**Do not cut** original v13.0 mathematical/statistical evidence and peer topology in order to add camera shine. A single working camera-to-decision-to-physical-check loop is more valuable than announcing 22 untested neural networks.

---

## 11. Delivered experimental code, exact scope

`prototype/vision_evidence.py` is a **small, executable OpenCV reference**, with:
- ArUco marker finder and 2D planar homography (not full lens-distortion corrected calibration);
- scanline thresholding with `dark_runs` and ambiguous-image abstention;
- candidate slot-gap estimation in the reference plane with explicit **unverified** status;
- a HOLD state and forced physical caliper confirmation; never a standalone safe-release.

`tests/test_vision_evidence.py` contains 7 **synthetic/software tests** (not 7 physical validations). See `results/tests.txt` for actual output. This code cannot infer arbitrary defect heatmaps, guarantee automatic image ROI detection, measure raised geometry, compute a metrologically traceable uncertainty, or certify a defect detector. These must be implemented and tested as specified above.

Example:

```bash
python -m unittest discover -s tests -v
python prototype/vision_evidence.py sample.png --scan-y 400 --marker-side-mm 20 --event-id physical-image-001
```

The sample image needs the required ArUco marker in the reference plane and controlled two-arm silhouette. Without a marker, it returns `HOLD_CAMERA_INVALID`. The user must select a valid scanline. It does **not** produce measured physical evidence on its own; images are needed for physical evaluation.

---

## 12. References (original sources; research retrieval verified 2026-10-30)

[S01] MVTec AD, Bergmann et al., 2019/2021. https://www.mvtec.com/research-teaching/datasets/mvtec-ad  
[S02] MVTec LOCO AD, Bergmann et al., IJCV 2022. https://www.mvtec.com/research-teaching/datasets/mvtec-loco-ad  
[S03] Roth et al., PatchCore, CVPR 2022. https://openaccess.thecvf.com/content/CVPR2022/html/Roth_Towards_Total_Recall_in_Industrial_Anomaly_Detection_CVPR_2022_paper.html  
[S04] Batzner et al., EfficientAD, WACV 2024. https://openaccess.thecvf.com/content/WACV2024/html/Batzner_EfficientAD_Accurate_Visual_Anomaly_Detection_at_Millisecond-Level_Latencies_WACV_2024_paper.html  
[S05] Pemula et al., RobustAD, CVPRW 2025. https://openaccess.thecvf.com/content/CVPR2025W/VAND/html/Pemula_Robust_AD_A_Real_World_Benchmark_Dataset_For_Robustness_in_CVPRW_2025_paper.html  
[S06] FDM machine monitoring review, IJAMT 2024. https://link.springer.com/article/10.1007/s00170-024-13630-8  
[S07] Bast et al., FFF visual defect image dataset, Zenodo 2026. https://zenodo.org/records/18628777  
[S08] Hu et al., Lightweight FFF fault detection, IJAMT 2024 + dataset. https://github.com/wengmhu/FDM-3D-Printing-Defect-Dataset  
[S09] OpenCV camera calibration documentation. https://docs.opencv.org/5.0/tutorials/calib3d/camera_calibration_pattern/camera_calibration_pattern.html  
[S10] Tsai/NISTIR 7197, Camera Calibration for a Manufacturing Inspection Workstation. https://www.nist.gov/publications/camera-calibration-manufacturing-inspection-workstation  
[S11] NIST Metrological Traceability policy. https://www.nist.gov/metrology/metrological-traceability  
[S12] Structured-light scanner vs CMM for 3D printed parts, Procedia CIRP 2024. https://www.sciencedirect.com/science/article/pii/S2212827124009442  
[S13] Complex structured surface dataset / photometric stereo, Scientific Data 2025. https://www.nature.com/articles/s41597-025-04454-6  
[S14] Deep learning survey for visual industrial anomaly, 2025. https://link.springer.com/article/10.1007/s10462-025-11287-7  
[S15] Armillotta, Experimental dimensional tolerance analysis using 3D printed parts, 2025. https://link.springer.com/article/10.1007/s00170-025-15040-w  
[S16] NIST optical metrology system validation, 2026-10-08. https://www.nist.gov/publications/validation-upgrades-nist-m48-vision-measurement-system  
[S17] FDM faults Mendeley Data 2024. https://data.mendeley.com/datasets/y74xtkk72z/1  
[S18] MVTec 3D-AD official benchmark for future 3D. https://www.mvtec.com/research-teaching/datasets/mvtec-3d-ad  

**Research integrity:** These sources establish relevant technology and open challenges; they do **not** validate this project's optical accuracy or industrial ROI. Newly proposed CAIR integration must undergo independent peer-reviewed novelty search and prospective experiments before being described as a discovered scientific contribution.
