# QualityRelay 13.0 — EVIDENCE-MESH Research Edition

**Title:** Provenance-Aware, Decision-Sensitive, Fail-Closed Collaboration in Decentralized Manufacturing Quality Control  
**Date:** 2026-10-30  
**Status:** Research synthesis + **tested synthetic reference module**, **not** an industrially validated system.  
**Primary event:** ScienceClaw, MIT Media Lab, October 30–November 1, 2026.  
**Original lineage:** QualityRelay 5.0 → 6–10 → 11 → 12.0 (fully decentralized peers + sorting) → **13.0 scientific test plan**.  
**Team:** Bakdaulet-omeraiuly (statistical and scientific core); adilnurgg (backend/distributed systems/security); HyorinmaruK (mechanical engineering, physical validation, final presentation); optional fourth member (integration/frontend and independent QA).

> **Actual scientific claim now:** We have identified a precise open **engineering research question** and created a runnable hypothesis-testing prototype. We have **not established a scientific discovery** or measured improvement in an industrial plant. Our contribution should be judged by reproducible experimental evidence, not number of agents or pages.

## 0. Executive decision: what QualityRelay IS

**One-sentence pitch:** QualityRelay is a peer-to-peer manufacturing-quality investigation network in which independently authorized station agents exchange traceable evidence, choose useful inspections, assess assembly compatibility, and safely quarantine ambiguous parts instead of blindly rejecting them.

1. **Product and mandatory live demo:** `fully_decentralized` is primary. Four independently running peers: **Slot, Tab, Assembly, Sorter**. A website shows and requests actions but is not the system's mandatory decision authority.
2. **Research comparators:** `isolated`, `single-agent-full-info`, `centralized`, and `hybrid-chief-engineer`; centralized Chief Engineer is never necessary for the primary peer demonstration.
3. **Scientific core:** preserve original clearance / acceptance-conditioning / EWMA / Bayesian diagnosis / information-gain validation from QualityRelay 5.0. Extend with **Evidence-Mesh, V-DER (decision-value routing), protected minority evidence, source-origin deduplication, and uncertainty-safe abstention**.
4. **Product constraints:** no unsupervised machine control; no false industrial qualification; a pairwise incompatibility does not automatically condemn either component; untrusted measurement is HOLD, not PASS.
5. **Physical setup:** 3D-printed coupons, real caliper measurements, fit trials, and a PASS/HOLD/CONFIRMED REJECT bench sorter. Simulation and physical measurements must remain distinguishable.
6. **Agent quantity:** retain **21 specialist role contracts**, but only invoke 2–6 relevant specialists per incident. Their names alone do not demonstrate working AI. Deterministic approved tools supply numeric truth; LLMs offer bounded narratives/explanations.
7. **Factory-facing target:** a quality engineer in precision component machining/assembly. The present 3D-printed PLA setup is **not** evidence of factory deployment readiness.

### 0.1 Truth matrix (no exaggerated readiness)

| Artifact | Verified available in supplied ZIP lineage | NOT established |
|---|---|---|
| Original 5.0 | Existing schemas, STL/SCAD, design and experiment plan; preserved in v12 nested archive | Complete standalone factory backend |
| v10 reference | A prior single-process FastAPI proof-of-concept and earlier reported tests | Fully distributed runtime |
| v12 | Design blueprint for four peers + bench sorter | Four independent deployed peers / physical sorter tested |
| **v13 added here** | Deterministic synthetic Bayes/EVSI/IG prototype; toy counterexample; tests; reproducible benchmark and literature index | A real industrial performance improvement; causal scientific discovery; fully operational 21-LLM swarm |
| 10,000-literature program | An earlier collector program and research protocol preserved in lineage | 10,000 independently retrieved, screened and read papers |

### 0.2 The win condition

The official rubric weights: problem significance **20%**, scientific/technical impact **25%**, decentralized agency **20%**, collective capability **25%**, execution/validation **10%**; an optional **+10 collaboration bonus** is separate. The official site says final slides are due **Sunday November 1, 13:00** (verify any organizer updates). [R01]

An actual demonstration with independent peer processes, partial-evidence behavior, a real fit trial, and an honest matched benchmark beats an unimplemented 21-agent narrative.

---

## 1. Research foundations: what published science ALREADY solved

### 1.1 Manufacturing integration and sequential inspection

- **NIST / Hedberg et al. (2021)** studied the incomplete digital thread between design, production, and inspection. QualityRelay's station-specific evidence problem is authentic. It is not a new discovery. [R02]
- **Moliner-Heredia et al. (Sensors 2021)** already used **Bayesian sequential inspection based on expected information gain** to diagnose multistage process faults. It explicitly assumed **only one concurrent fault** and negligible classification errors in the analyzed case. Our `both_shift` hypothesis and noisy measurements test departures from that simplified setting. [R03]
- **Magnanini et al. (CIRP Annals 2024)** examined quality gates and feedback/feedforward control over multiple stages. We must not claim to invent proactive quality gates. [R04]
- Published machining monitoring and trust-aware decentralized manufacturing exist. QualityRelay must be evaluated as an **applied integration and experimental protocol**, not first-in-world autonomous factory AI. [R09, R15, R17]

### 1.2 Multi-agent information failures

- **HiddenBench (ICML 2026)** observed 30.1% accuracy on distributed-information tasks versus 80.7% for a complete-information individual under its test conditions. This is **not** a predicted QualityRelay score. The central failure mechanism is missing information that agents fail to request. [R05]
- **Multi-Agent Teams Hold Experts Back (ICML 2026)** shows experts can be overridden through compromise rather than evidence-based weighting. Role multiplication is not sufficient. [R06]
- A **2026 preprint** studies suppressed minority signals and premature consensus, while an EMNLP 2026 paper proposes auditing evidence at disagreement branches. Therefore evidence-based debate/audit also predates us. [R07, R08]
- **Distributed fusion literature** has long addressed shared-source correlations and double counting. Basic provenance-based duplicate filtering is not a newly discovered solution to arbitrary statistical dependence. [R10, R11]

### 1.3 Value of information and metrology

- **EVSI** formalizes the expected effect of new information on the optimal decision, distinct from entropy reduction. This is established Bayesian decision theory; our use in manufacturing is a research application. [R12]
- Online selective inference and industrial distribution shifts make naive confidence/safety statements dangerous; no unconditional coverage guarantee follows from a small 3D-print sample. [R13, R14]
- NIST's **Gauge R&R** treats repeatability, reproducibility, resolution, stability and bias as separate problems; caliper reading is not ground truth without a measurement plan. [R16]

### 1.4 Candidate scientific gap (not a proven priority claim)

Published components exist separately, but our **specific target experiment** asks:

> Under station-local authorization and intermittent network links, can a provenance-constrained, decision-value inspection protocol preserve safe decision quality and relevant minority evidence, while disclosing fewer raw records and using less inspection time than equal-budget peers without structured evidence requests?

This **may** yield a publishable result if it is new relative to a systematic literature review, tested under strong baselines, replicated, and independently assessed. The current research scan of 18 references is **not** such a review; novelty remains unverified.

---

## 2. Proposed research protocol: EVIDENCE-MESH / V-DER + PACE guard

We retain the previous name **EVIDENCE-MESH / V-DER (Value-guided Decision-Evidence Routing)**. New proposed integration layer: **PACE = Provenance-Aware Counterfactual Evidence guard**. PACE is a working title, **not a discovered scientific law**.

### 2.1 Mathematical objects

- `H`: finite fault hypotheses, initial `H0` stable, `H1` slot mean shift down, `H2` tab mean shift up, `H4` both shifts. Multi-source faults matter.
- `E`: currently authorized, fresh and origin-resolved evidence set. Each raw measurement has one stable **physical origin ID** even if forwarded by multiple agents.
- `p(H|E)`: posterior under a frozen, empirically validated likelihood model. Do not confuse model posterior with guaranteed physical truth.
- `D`: actions `CONTINUE/PROPOSE_RELEASE`, `HOLD`, `REQUEST_INSPECTION`, `PROPOSE_ALTERNATIVE`. **Final production release is human-approved.**
- `a`: candidate inspection/action from an allowlisted catalog with a real specimen ID, measurement model, expected duration, access cost and instrument availability.
- `L(d,H)`: asymmetric economic/safety loss. Cost parameters are explicitly **hypothetical** until a factory provides calibrated data.
- `R(E) = min_d Σ_H p(H|E)L(d,H)` is the current minimum expected decision loss.

For a potential measurement `Y_a`, the conventional **expected value of sample information** is:

`EVSI(a|E) = R(E) - Σ_y p(y|E,a) min_d Σ_H p(H|E,y,a)L(d,H)`.

Proposed **net value for selecting an inspection**:

`NetValue(a) = EVSI(a|E) - C_measure(a) - C_delay(a) - C_comm(a) - C_disclosure(a)`.

**Important:** Cost-aware EVSI is established mathematics, not an original theorem. Our research question is whether this policy **within a permissioned peer evidence network** performs well under realistic errors, drift, correlated evidence, missing links, and competing agents.

### 2.2 PACE safety / evidence rules

1. **Source-level attribution:** every assertion references owner, event ID, measurement origin ID, specimen/lot ID, instrument, unit, timestamp, input hash, model version, and `physical` / `simulated` / `inferred` label.
2. **No double counting:** two copies of the *same* physical observation are one measurement. Shared ancestors and unknown correlations require explicit dependence modeling or conservative fallback. Simple ID deduplication **does not solve arbitrary correlations**.
3. **No majority override:** a sourced engineer challenge is not voted away. Request disconfirming measurement; until resolved flag HOLD/REVIEW.
4. **No missing-evidence optimism:** unreachable authorized peer means `MISSING/STALE` rather than assumed-normal measurement. Local SPC may continue, but global pair release waits.
5. **Decision-sensitive request:** choose `EVSI − costs` among authorized, available tests, unless validity/safety fallback forbids it. Preserve IG as a baseline, not a strawman.
6. **Specimen whitelist:** the model cannot invent inspection targets or measurements. Numeric outputs come only from deterministic services.
7. **Physical dispositions:** source-owned local conformity permits `PASS_ELIGIBLE` inventory only; pair compatibility is a separate Assembly predicate. `CONFIRMED_REJECT` requires an authorized independent part nonconformance, not a mere failed pairing.
8. **Partition behavior:** event sourcing and at-least-once delivery; inbox applies events idempotently. No assertion of exactly-once transport; no central dashboard dependency.
9. **Human gate:** plant actuation and hold release need a human-signed policy-controlled action; bench sorter is guarded and physically verified.

### 2.3 Counterfactual decision stability (research diagnostic, not safety certification)

For a finite set of missing binary tests `M`, enumerate every modeled outcome vector `y ∈ {0,1}^|M|` and recompute `d*(E,y)`. If **all** modeled outcomes produce the same preferred *proposal*, call it `MODEL_DECISION_STABLE`.

This is a direct finite-enumeration property, **not an industrial certification**. It depends on correct likelihoods, complete action space, known source dependencies, finite outcome support and loss assumptions. An actual PASS still requires fresh mandatory evidence and human authorization.

Reference implementation: `prototype/peer_decision.py::counterfactual_decision_stability`.

### 2.4 Source-bearing communication contract

```json
{
  "schema_version":"13.0-draft",
  "message_type":"EvidenceResponse",
  "incident_id":"UUID",
  "owner_station":"slot",
  "specimen_id":"S-014",
  "event_id":"UUID",
  "measurement_origin_id":"caliper-event-UUID",
  "measurement_kind":"slot_width",
  "measurement_value":20.61,
  "units":"mm",
  "source_kind":"physical",
  "instrument_id":"caliper-01",
  "measurement_uncertainty_mm":null,
  "calibration_status":"unverified",
  "measurement_timestamp_utc":"EXAMPLE_NOT_AN_ACTUAL_MEASUREMENT",
  "producer_version":"tool-version",
  "evidence_snapshot_hash":"sha256:...",
  "authorized_fields":["measurement_kind","measurement_value","units"],
  "freshness_status":"current",
  "signature_status":"to_be_verified",
  "human_verified":false
}
```

Numbers above are illustrative; **never** use uncalibrated readings as conclusive factory results. Production schema must use valid date types, typed uncertainty and signatures. Peers cannot edit another owner's event.

---

## 3. Research experiments (preregistered plan)

### 3.1 Main factorial design

**Primary architecture factor** (`same inference library, allowed inputs, seed and inspection budget`):

- `B0`: conventional local threshold/SPC and fixed inspection;
- `B1`: isolated stations, no peer requests;
- `B2`: fair single AI/decision service with **the same permitted evidence**;
- `B3`: central full-information **upper bound**, explicitly privileged and not a fair same-access competitor;
- `B4`: distributed agents with naive broadcast/majority;
- `B5`: distributed + structured owner-scoped evidence requests;
- `B6`: `B5` + provenance deduplication;
- `B7`: `B6` + evidence-bearing dissent gate;
- `B8`: `B7` + cost-aware EVSI / PACE (full experimental treatment);
- `B9`: Hybrid Chief comparator (not primary decentralized product).

**Network factor:** all online / Slot offline / Tab offline / intermittent connection / delayed duplicated messages.  
**Fault factor:** stable / slot shift / tab shift / both / mismeasurement / shared-sensor bias / stale data / malicious forged event / unseen shift.  
**Physical factor:** acceptance-conditioned lot pairing and held-out printed coupons; actual caliper repeats separated from simulation.

Use a frozen train/calibration/test split **by manufacturing lot and print run**, not random measurement row. Freeze likelihoods, policy costs, thresholds, seeds and success criteria **before** opening held-out outcomes. Pre-register a primary endpoint to avoid cherry-picking.

### 3.2 Primary research questions

- **RQ1 — legitimate collective gain:** At equal evidence access and compute budget, does structured owner-scoped collaboration improve diagnosis accuracy or lower model decision loss versus B1/B2?
- **RQ2 — source integrity:** With forwarded/duplicated observations, does provenance dedup lower posterior overconfidence and false confident decisions versus B5? Test **unknown shared correlations** separately (ID dedup is insufficient).
- **RQ3 — minority protection:** When an evidence-backed specialist dissents from 3–10 unsupported agents, does the veto/challenge procedure lower unsafe-release proposals without excessive HOLD time?
- **RQ4 — value vs entropy:** Under an equal physical inspection budget, does EVSI policy lower decision loss relative to cost-normalized IG? Which priors and loss ratios lead to **no difference**?
- **RQ5 — partition robustness:** Does peer-mode retain more authorized local monitoring and audit progress during a link failure without falsely declaring a missing-evidence pair safe?
- **RQ6 — 21 roles:** Is selective activation (2–6 relevant experts) more efficient than always activating 21 at matched tool availability and token/call budget? Report latency and failure modes.
- **RQ7 — physical containment:** Does a HOLD-capable sorter reduce **false scrap/rejection** and preserve valid rematch options without increasing confirmed bad PASS relative to identical non-agent sorting hardware?
- **RQ8 — generalization:** Do synthetic improvements persist with real measurement noise, non-normal print distributions, changed filament lots and 3D printer temperatures? Negative results are legitimate findings.

### 3.3 Primary outcomes and statistical method

Primary outcome: **paired mean decision loss per incident** under frozen, explicit cost units (or a safety-first lexicographic endpoint where confirmed unsafe release rate is controlled first). Secondary: number of inspections, diagnosis accuracy, false-release proposal rate, unnecessary quarantine, confirmed reject errors, physical successful pairings, elapsed inspection seconds, message bytes, distinct raw measurement IDs disclosed, source confidence calibration/Brier, stale-evidence rate, network recovery, operator approval events.

Use matched random incident streams for all policies. Report both differences and **95% paired confidence intervals** with pre-specified nonparametric bootstrap or suitable paired uncertainty estimators. Do not extrapolate from 2–3 physical pairings to a calibrated industrial percentage; raw/caliper observations stay distinct from simulation. If the pilot has too few parts, emphasize feasibility and confidence limitations.

A credible **negative result** (no gain over classical IG or central upper bound) is a success in scientific integrity, not grounds to hide the baseline.

---

## 4. Reproducible new synthetic prototype: observed facts

### 4.1 What actually runs in this release

```
prototype/peer_decision.py      deterministic Bayesian tool, IG, EVSI, safety/provenance ledger,
                                simple counterfactual stability check
prototype/paired_benchmark.py  4 scenarios × 5,000 synthetic incidents × 4 policies
prototype/decision_trap.py     exact 3-hypothesis counterexample: entropy ≠ decision value
tests/test_peer_decision.py     21 deterministic unit tests
results/benchmark.json         full reproducible aggregate results + normal-approx paired CIs
results/decision_trap.json     exact calculation without random simulation
results/TESTS.txt              unittest output
```

**Environment:** Python standard library only. No external network call, LLM, device, factory API, signed transport or deployed peer services. Source code has documented toy priors, likelihoods, costs and seed. In particular, numeric `false_release_rate` is a **simulated proposed decision outcome**, not a real hardware release.

### 4.2 Completed reference-model comparison

In the `reference` synthetic case, 5,000 matched trials:

| One-step policy | Mean synthetic loss |
|---|---:|
| No inspection | **1.50000** |
| Random inspection | **1.19916** |
| Cost-normalized Information Gain | **1.12590** |
| EVSI-driven V-DER | **1.12590** |

V-DER and IG select the **same inspection** and are **identical** in this toy scenario. This does **not** establish new performance. See `results/benchmark.json` for all four scenarios, including `rare_fault` where the empirical decision policy does **not** outperform the no-test baseline. In the rare-fault scenario, the estimated difference CI includes zero. This result must not be hidden.

**Scope:** loss units arbitrary, highly simplified conditional independence, modeled probabilities, one inspection per incident and no industrial distribution shift. We cannot infer plant ROI or “saves 30% inspections”.

### 4.3 Exact decision-trap counterexample (established theory, good demo)

Consider `H ∈ {safe, fault_A, fault_B}` with prior `{0.5, 0.25, 0.25}`. Action choices release or hold, loss for release under either fault **16 units**, hold **5**, and both test costs **0.1**. Candidate tests:

- `fault_type_marker`: very effective at distinguishing `fault_A` from `fault_B`, but **does not change release-versus-hold choice**.
- `release_risk_signal`: less diagnostic entropy reduction but can reveal that a release recommendation is worth reconsidering.

**Computed exactly** (not Monte Carlo):

| Inspection | Entropy reduction (bits) | EVSI before test cost | EVSI net cost |
|---|---:|---:|---:|
| Fault-type marker | 0.50000 | 0.00000 | -0.10000 |
| Release-risk signal | 0.27807191 | 0.90000 | +0.80000 |

Thus entropy chooses the **wrong inspection for this loss objective**; the decision-value rule chooses the right one. **This is a constructed illustration of existing Bayesian decision theory, not an original theorem or a unique manufacturing discovery.** Its value is to define a falsifiable experimental contrast for the physical system.

### 4.4 Actual demonstrated test status

`python -m unittest discover -s tests -v` → **21/21 tests pass** in this package. Covered: simple Bayes updating, EVSI/IG non-negativity, origin duplicates, authorization/freshness checks, wrong-station measurement rejection, missing-evidence HOLD, human gate, no actuation capability, counterfactual enumeration, exact theory trap.  
Not covered: true signed peer messages, malformed JSON fuzzing, actual hardware command replay, live 3D printing or 21 operational AI agents.

---

## 5. Twenty-one specialist role architecture — retained, with evidence contracts

A role is implemented only when it has `input_schema`, `owner/permissions`, versioned tool, real or simulated truth label, explicit source IDs, failure mode, test and latency budget.

| # | Specialist role | Authorized evidence / output | Testable fail-closed condition |
|---:|---|---|---|
| 01 | Design Geometry | CAD rev / revision-linked constraint | Missing rev: abstain |
| 02 | Tolerance Analyst | Width distributions / clearance and sensitivity | Unknown dependence: warn |
| 03 | Materials Engineer | Batch and temperature / warp hypothesis | Uncalibrated model: unknown |
| 04 | Process Engineer | Local operation log / alternative fault paths | Missing history: conditional explanation |
| 05 | CNC Machining Expert | Tool wear/offset evidence / machining cause | 3D print demo: N/A |
| 06 | Additive Manufacturing Expert | STL/slicer/filament/print logs | No print metadata: unknown |
| 07 | Metrology Engineer | Gauge + repeated readings / measurement uncertainty | Unverified gauge: HOLD |
| 08 | SPC Statistician | Frozen calibration series / EWMA alarm | No baseline: no alarm confidence |
| 09 | Quality Inspector | Owner readings + spec / local part status | Missing reading: HOLD |
| 10 | Assembly Engineer | Slot/tab evidence / pair compatibility | Missing partner: no pairing release |
| 11 | Causal Diagnosis | Process graph, traces / falsifiable hypotheses | Observationally identical causes: unidentifiable |
| 12 | Bayesian Statistician | Validated likelihood / posterior and sensitivity | Unsupported likelihood: exploratory label |
| 13 | Inspection Planner | Allowlisted specimen and cost / IG/EVSI action | No measurement model: fixed fallback |
| 14 | Operations Research | Eligible inventory / candidate matching | Unknown inventory: no automatic pairing |
| 15 | Maintenance Engineer | Machine log / repair hypothesis | No relevant sensor: unknown |
| 16 | Supplier Boundary Agent | Disclosure policy / allowed summaries | Raw field unauthorized: deny + log |
| 17 | Safety and Governance | Safety policy / veto and human gate | Unsafe automatic action: deny |
| 18 | Privacy and Security | Peer identity / auth status | Unauthenticated peer: reject |
| 19 | Reliability and Network | Link history / evidence freshness | Offline: reduce coverage, no green claim |
| 20 | Scientific Auditor | Seeds, hashes, provenance / reproduction report | Mixing synthetic/physical: reject |
| 21 | Kaizen / PDCA | Verified change history / controlled improvement experiment | No causal evidence: hypothesis only |

**Normal incident activates:** 7 Metrology, 8 SPC, 9 Quality, 10 Assembly, 13 Inspection Planner, optionally 6 Additive Manufacturing and 20 Auditor. Others remain available by capability discovery, not all token-billed in a single prompt.

**Three types of distributed actors must not be conflated:**

- **Station peer** = authoritative service owning local raw records and hardware permissions.
- **Specialist agent** = constrained capability, perhaps deployed with the relevant peer, not a new global raw-data reader.
- **Centralized Chief Engineer** = research-comparator orchestrator. `hybrid_chief` can assign requests; it cannot silently override safety veto or become mandatory in `peer_mesh`.

---

## 6. System architecture and one website

```
 [Slot peer + DB]  <---- authenticated evidence requests ----> [Assembly peer + DB]
      ^                                                       ^      |
      |  owner-signed, scoped summaries                       |      | pair-specific HOLD
      v                                                       v      v
 [Tab peer + DB]   <---- peer capability discovery ----> [Sorter peer + local actuator state]
      |                                                               |
 local measurement continued                                        guarded bench action
      +----------------- replicated audit references -----------------+
                                |
                         [Read-only-first Web App]
                                |
                     operator: inspect / hold / approve

    Chief Engineer (centralized/hybrid comparison only): not required above.
```

**Dashboard page structure:**

1. `Factory Overview`: process/lot status, local alerts, evidence freshness, communication topology.
2. `Incident Workspace`: chosen slot/tab pair, risk **with model limitations**, source IDs, disagreements, alternative hypotheses.
3. `Agent Evidence Room`: relevant specialist statements and their cited deterministic tool outputs; vote count never substitutes for proof.
4. `Next Best Inspection`: comparison of IG, EVSI, cost/time, permission, possible decision impact; actual specimen whitelist.
5. `Physical Experiment`: caliper measurements, pairing results and separate simulated scenarios.
6. `Sorter Panel`: PASS / HOLD / CONFIRMED REJECT; ID confirmation; sensor feedback; fail-closed status.
7. `Research Benchmarks`: matched B0–B9 outcomes, error bars, ablation toggles, event manifests and limitations.
8. `Audit and Export`: immutable origin manifest, hashes, posterior snapshot version, tool revision, operator signature, JSON/CSV download.

**Non-negotiable:** closing the website does **not** stop local station measurements. A web UI is an observer and user-action interface, not an agent brain. Camera may help record specimen appearance, but a plain phone photo is not a calibrated millimeter measurement.

### 6.1 Minimum service API contract (target, not already implemented)

- `POST /v1/incidents` at Assembly peer (authorized requester, incident idempotency key)
- `POST /v1/peers/{peer}/evidence-requests` → 200 authorized summary / 403 field denied / 409 obsolete snapshot
- `POST /v1/evidence-events` per owner; monotonic sequence, event ID, physical source ID, schema validation and origin label
- `GET /v1/incidents/{id}/evidence-coverage` → current/expired/denied/partitioned flags
- `POST /v1/incidents/{id}/assessments` → hypothesis posterior, **model** risk, dissent, source references
- `POST /v1/incidents/{id}/inspection-options` → allowlisted actions with net value and costs
- `POST /v1/parts/{id}/disposition-proposals` (local owner role only)
- `POST /v1/sorter/requests` (bounded signed disposition, operator safety gate, no bare LLM string)
- `POST /v1/sorter/confirmations` (actual sensor/operator confirmed motion, never infer success from send)
- `GET /v1/replay/{run_id}` (manifest and replay data)

**Implementation invariants:** prohibit cross-owner raw SQL; authenticated mutually authorized peers; per-field allowlists; schema versions; per-owner outbox/inbox; dedup `(origin_measurement_id, semantic_observation_id)` not merely message ID; hash-chained records where supported; reliable time handling; replay after partition; no silent stale overwrite; approve only the exact evidence snapshot hash reviewed by the operator.

### 6.2 Three operating modes — non-conflicting

- **Primary product:** `fully_decentralized` — source peers initiate requests, challenge and propose without planner.
- **Research:** `centralized_full_info` — explicit privileged raw access, theoretical upper bound; disclose this asymmetry.
- **Research:** `hybrid_chief` — bounded centralized task allocator acting **only as optional coordinator**. Its failure must not stop local peers in the main mode.

---

## 7. The real 3D-printed physical protocol

### 7.1 Geometry and risks

Original teaching assumptions (NOT measured factory tolerances): slot width `20.5–21.5 mm`, tab thickness `19.5–20.5 mm`, minimum functional clearance `0.5 mm`, nominal widths `21.0 mm` and `20.0 mm`. Pair clearance `C = W − T`. Individual local PASS does **not** imply `C ≥ 0.5 mm`.

Generate a planned **50 slots + 50 tabs**, with controlled safe, nominal, near-threshold, and tighter-risk groups. Track printer, STL and slicer revision, filament/lot, temperature/orientation, specimen ID and measurement order. 100 is a target if printing capacity permits, **not a prerequisite to start proving the peer architecture**. Use a small physical subset for live demo plus honest simulation.

### 7.2 Metrology: measurement before AI

1. Caliper instrument ID, resolution, calibration/verification status; use a reference block where available.
2. Repeat 10 readings of a stable coupon to estimate within-operator repeatability. If possible, two operators and repeated specimen orders to assess reproducibility. Retain raw readings, never only an average.
3. Independently measure each `W`, `T` (and geometry orientation/obvious warp) with operator ID, date and room conditions. Do not treat nominal CAD as ground truth.
4. **Physical outcome**: record whether pairing satisfies a documented fit test; do not silently define “fits” by AI forecast. If force-fit affects plastic, log trial order and wear effects.
5. Freeze actual classification rules and hardware safety before held-out evaluation.

### 7.3 Physical demo, exactly what the audience sees

1. Show real slot `S-014` and tab `T-026`, with QR/ID, photograph and two independent local measurement records.
2. Kill one station API process. Its local collection continues; Assembly shows `MISSING_AUTHORIZED_EVIDENCE` and **HOLD**. No fake normal estimate.
3. Restore link; replay queued evidence once. Show same event IDs applied one time and audit proof.
4. Quality and Assembly request only allowed summaries; an evidence-backed dissent invokes inspection rather than majority voting.
5. Inspection Planner proposes an **actual named piece** for caliper re-check; operator performs measurement. New source event updates posterior/compatibility proposal.
6. The person approves physical **bench** routing; Sorter peer routes to PASS/HOLD/CONFIRMED REJECT and waits for sensor/operator confirmation.
7. Show a pair that fails `C≥c_min` yet both parts remain locally conforming, so HOLD/rematch is possible rather than scrap.
8. On the research screen compare identical trials of isolated, centralized, structured peer and ablation modes with uncertainty bars. Clearly identify results simulated versus physically observed.

### 7.4 Hardware safeguards

Low-energy actuator, guarded moving parts, emergency stop, startup default HOLD, no remote control of industrial equipment; unknown part, stale disposition, bin occupancy uncertain, blocked actuator, lost sensor confirmation, duplicated command → **HOLD/STOP**. “Command accepted” is not “part physically sorted.”

### 7.5 Minimum independent validation

The mechanical engineer signs a **Measurement and Fit Report** with all coupon IDs, raw readings, repeatability, failed trials, physical limitations and objective fit rule; a local independent QA observer or fourth teammate may repeat a blinded subset. A paid factory inspection report can validate dimensions, **not** certify the multi-agent system's AI decisions. Actual plant pilot needs real plant data authorization, integration, measurement system analysis, operator validation, risk assessment and further trials.

---

## 8. Team ownership and precise boundaries

### Bakdaulet-omeraiuly — scientific lead / statistics

Own `prototype/`, experiment configs, calibrated likelihoods and baseline fairness, Monte Carlo acceptance conditioning, hypothesis sensitivity, IG/EVSI comparison, posterior calibration, confidence intervals, preregistration, raw results/manifests, and the scientific narrative. Produce `scientific_results.json`, `paired_trials.csv`, `claim_register.md`. **Do not take over the final physical validation/pitch.**

**Definition of done:** frozen seed scripts produce repeatable results; B0–B9 and source-veto ablations run; null results included; clear claims separated from toy assumptions; no unsupported factory ROI.

### adilnurgg — distributed backend / security lead

Own four independently running peer services, per-peer owner DBs, permissioned schemas, direct peer communication or non-authoritative relay, event origin IDs, cryptographic authenticity where feasible, scoped disclosure and HTTP 403 tests, offline local continuity and replay, inspection action whitelist, physical sorter command idempotency and secured human approval. Implement **only** source-bearing deterministic numeric outputs; LLM text cannot act as measurement.

**Definition of done:** four killed/restarted processes with separate local stores, unauthorized read blocked, peer outage changes coverage, no duplicate origin application after reconnect, sorter cannot move without appropriate safety controls.

### HyorinmaruK — mechanical engineering / **physical validation and final pitch**

Own specimen CAD/STL revisions and 3D print logistics, caliper repeatability, controlled variation plan, labeling and physically testable pairings, guarded low-energy sorter mechanism, motion/sensor confirmation, **Measurement & Fit Validation Report**, independent engineering limitations, website presentation flow and **final slides and oral pitch**. The frontend can be shared with an optional fourth member or with adilnurgg; mechanical validation and presentation remain HyorinmaruK's clear accountability.

**Definition of done:** traceable physical demonstration can be repeated twice; all specimens have IDs and raw records; safe HOLD fallback works; presenter can explain why 21 roles do not equal 21 proven LLM agents.

### Optional fourth person — frontend integration / independent QA

Own browser interaction and dashboard polish, contract-driven typed client, live connection status, accessibility, role permission displays, signed-run manifest export, independent regression and cross-peer integration tests, blinded reinspection of physical subset and backup demo recording. If no fourth arrives, create the minimal read-only dashboard with shared work; **do not shift physical validation/pitch away from HyorinmaruK**.

### Interfaces to freeze before parallel work

`part_id`, `lot_id`, `measurement_origin_id`, `event_id`, `owner_peer_id`, `source_kind`, `measurement_units`, `evidence_snapshot_hash`, `schema_version`, `calibration_status`, `approved_action_ids`, `measurement_time_utc`, `run_id`, `simulation_seed`.

- Scientific core returns immutable numeric result + model/version/assumptions; never direct hardware commands.
- Peer services authorize evidence with owner-owned policies; never send a raw DB handle to specialist.
- Site renders typed results, source labels and human approval; never generates missing numbers.
- Sorter validates signed disposition + sensor confirmation, independent of website rendering.

---

## 9. Scope and build order: aim for validated achievement, not maximal claims

### P0: indispensable working decentralized scientific loop

- [ ] One process each for Slot, Tab, Assembly and Sorter, each with separate persisted state
- [ ] Local measurement event + origin and permissioned request/response
- [ ] Compatibility risk and HOLD on missing/stale evidence
- [ ] Offline peer kill/recover test with idempotent replay
- [ ] At least one physical caliper reading and one real fit result
- [ ] One confirmed physical sorting decision or, if hardware fails, clearly labeled operator-assisted sorting **not** disguised as automated actuation
- [ ] One matched statistical comparison and one 95% interval, including a negative/null baseline if found
- [ ] Source hashes, provenance, human gate, visible research limitations

### P1: if P0 passes with time left

- [ ] Distinct source-origin evidence deduplication in **distributed**, not in-process, transport
- [ ] Signed minority-dissent evidence challenge and a physical re-check
- [ ] One controlled V-DER versus IG ablation, same data/cost/seed
- [ ] 21-role registry displayed with **implemented vs contract-only** status
- [ ] Kaizen PDCA controlled experiment proposal (no untested claim of improvement)

### P2: post-hackathon industrial research

- [ ] Multi-factory authorization, real CMM sensor integration, OPC UA adapter
- [ ] Dependence-aware calibrated fusion beyond simple ID dedup
- [ ] Repeated physical print runs, shift calibration, prospective blinded validation
- [ ] Usability and human factors evaluation, factory pilot and risk analysis
- [ ] Registered external replication, systematic novelty search and peer-reviewed submission

---

## 10. Internal acceptance / scientific gate

**No unconditional 10/10:** judge performance is outside our control. Internal scientific completion is a binary contract:

1. **Truth:** source event IDs from real sensors or labeled simulation; no fake factory validation or 10k read-paper claim.
2. **Reproducibility:** tests/seed/config known, negative and positive results exported.
3. **Decentralization:** genuine independently stopped processes, no shared root DB required for a quality incident.
4. **Safety:** unauthorized reads rejected; physical actuation fail-closed; human approves consequential actions.
5. **Collective value:** fair same-budget comparison shows measured tradeoff; if no performance gain, report the honest limit.
6. **Hardware:** at least one actual print, caliper and fit observation; physical/simulation metrics separated.
7. **User value:** one clear quality-engineer decision with timing/cost explained, not a list of 21 chatbots.
8. **Research scope:** position novelty as a hypothesis plus evidence, not an undisputed new theorem.

If any of these are incomplete, the website must identify the gap. This is safer and more credible than decorating an unbuilt demo with a scientific score.

---

## 11. Runnable reproduction (available now)

From the root of this v13 package:

```bash
python -m unittest discover -s tests -v
PYTHONPATH=prototype python prototype/decision_trap.py
PYTHONPATH=prototype python prototype/paired_benchmark.py --n 5000 --out results/benchmark.json
```

Expected result at package creation: **21 tests passed**. Result JSON reports mean loss and 95% paired normal-approximation CI for `decision - IG` and `decision - no inspection`. Because this is **single-process toy code**, do not call these network tests or a distributed implementation.

### 11.1 Reuse the earlier versions without losing anything

`legacy/QualityRelay_12_ORIGINAL_UNMODIFIED.zip` is the **original supplied v12 archive copied intact**; it includes nested v11 and earlier references (including v10 and v5 materials). Run an archive integrity check before extraction. The new master blueprint records the v12 no-regression requirements, but original schemas/STL are preserved in the prior archive rather than silently edited. If a requested production feature is not implemented, carry it as a tracked task, never an achieved claim.

---

## 12. Research references and literature audit

The auditable index `research/verified_sources.csv` contains **18 references** with title, year, publisher or source, DOI/URL, literature status, and **reading depth**. Neither that index nor any nested archive demonstrates a completed systematic review of 10,000 works. All URLs below identify source publications; a direct source URL should be used in a paper or slide instead of an unsupported secondary paraphrase.

- **[R01]** Official ScienceClaw event and judging: https://scienceclawhack.ai/
- **[R02]** NIST digital-thread case (Hedberg et al., 2021): https://doi.org/10.1080/00207543.2021.1920057
- **[R03]** Moliner-Heredia et al., sequential inspection (2021): https://doi.org/10.3390/s21227524
- **[R04]** CIRP Annals quality gates (2024): https://doi.org/10.1016/j.cirp.2024.04.015
- **[R05]** Li, Naito & Shirado, HiddenBench, ICML (2026): https://proceedings.mlr.press/v306/li26ej.html
- **[R06]** Pappu et al., expert dilution, ICML (2026): https://proceedings.mlr.press/v306/pappu26a.html
- **[R07]** Pitre et al., communication failures (2026, **preprint**): https://arxiv.org/abs/2610.32060
- **[R08]** AgentAuditor, EMNLP (2026): https://aclanthology.org/2026.emnlp-main.2642/
- **[R09]** Procedia CIRP trust in manufacturing agents (2025): https://doi.org/10.1016/j.procir.2025.02.183
- **[R10]** Automatica decentralized common-information fusion (2017): https://doi.org/10.1016/j.automatica.2017.01.019
- **[R11]** Fully decentralized fusion and dependencies (2021): https://isif.org/media/fully-decentralized-estimation-using-square-root-decompositions
- **[R12]** EVSI tutorial (2022): https://doi.org/10.1177/0272989X211026292
- **[R13]** Selective conformal prediction CAP (2025): https://jmlr.org/papers/v26/24-0452.html
- **[R14]** Industrial time series distribution shift uncertainty (2025): https://doi.org/10.1109/TII.2025.3529920
- **[R15]** Multi-agent manufacturing scheduling (2025): https://doi.org/10.1016/j.jmsy.2025.01.004
- **[R16]** NIST Gauge R&R technical guide: https://www.itl.nist.gov/div898/handbook/mpc/section4/mpc4.htm
- **[R17]** Bayesian monitoring of machining processes (2025): https://doi.org/10.1007/s00170-025-15174-x
- **[R18]** Belief entrenchment and debate (TACL 2026): https://aclanthology.org/2026.tacl-1.58/

### 12.1 How to turn this into real publishable work

A later paper needs: systematic PRISMA-style eligibility rules, registered search date and screening decisions, full industrial model calibration, at least one external replication, leakage-free randomization by lot/run, uncertainty and costs estimated from practice, comparison to **strong** published methods and significance/effect-size reporting, and explicit industrial risk evaluation. The present artifact advances the **design and testability** of the question, not its final scientific resolution.

---

## 13. Final presentation script (claim-safe)

> *“Most factory quality systems can measure parts and detect anomalies. Our research question is different: when each station owns only part of the evidence, can decentralized agents identify the most useful next physical test without overconfidently merging copies of the same evidence? QualityRelay preserves local data ownership, records every source, allows a measured dissent to override unsupported consensus, and recommends inspections against an explicit decision-loss model. We tested the algorithms in reproducible simulations, and we demonstrate a real 3D-printed assembly and safe HOLD-based sorting. We do not claim the method already outperforms every centralized or information-gain baseline. Our experiment reports exactly when it helps, when it ties, and what remains uncertain.”*

**Keep the 5.0 scientific core. Keep 12.0 physical sorter and genuine decentralized direction. Elevate 13.0 source integrity, decision-aware inspection and fair falsifiable tests. Build one true experiment instead of claiming 21 untested AI experts as an invention.**
