import sys,unittest
from pathlib import Path
import numpy as np
import cv2
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'prototype'))
from vision_evidence import dark_runs,slot_gap_pixels,marker_homography,point_distance_mm,inspect_slot_scanline
class TestVision(unittest.TestCase):
    def test_runs(self):
        x=np.full(100,255,np.uint8);x[10:30]=0;x[50:85]=0
        self.assertEqual(dark_runs(x),[(10,30),(50,85)])
    def test_gap(self):
        x=np.full(100,255,np.uint8);x[10:30]=0;x[50:85]=0
        self.assertEqual(slot_gap_pixels(x),((30.,50.),'OBSERVED_EDGE_CANDIDATES'))
    def test_ambiguous(self):
        x=np.full(100,255,np.uint8);x[10:30]=0
        self.assertEqual(slot_gap_pixels(x)[1],'AMBIGUOUS_CONTOUR')
    def test_transform(self):
        H=cv2.getPerspectiveTransform(np.array([[0,0],[200,0],[200,200],[0,200]],np.float32),np.array([[0,0],[20,0],[20,20],[0,20]],np.float32))
        self.assertAlmostEqual(point_distance_mm(H,(20,60),(120,60)),10.0,places=4)
    def test_missing_marker_returns_hold(self):
        frame=np.full((500,500,3),255,np.uint8)
        r=inspect_slot_scanline(frame,100,reference_side_mm=20,measurement_origin_id='e1')
        self.assertEqual(r.status,'HOLD_CAMERA_INVALID')
        self.assertIsNone(r.value_mm)
    def test_ar_marker_geometry(self):
        marker=cv2.aruco.generateImageMarker(cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50),0,160)
        im=np.full((400,400),255,np.uint8);im[60:220,60:220]=marker
        bgr=cv2.cvtColor(im,cv2.COLOR_GRAY2BGR)
        H,_=marker_homography(bgr,20,0)
        self.assertAlmostEqual(point_distance_mm(H,(60,60),(220,60)),20.0,delta=0.5)
    def test_bad_marker_size(self):
        with self.assertRaises(ValueError):marker_homography(np.zeros((100,100,3),np.uint8),0)
if __name__=='__main__': unittest.main()
