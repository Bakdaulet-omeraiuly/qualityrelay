"""QualityRelay camera metrology proof of concept, NOT calibrated industrial metrology.

Only valid with a fixed camera, a planar target and reference marker at the
SAME physical plane, checked acquisition and stable optical settings.
No factory accept/reject action may be derived from this standalone module.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Sequence
import numpy as np
import cv2

@dataclass(frozen=True)
class VisualResult:
    value_mm: float | None
    status: str
    evidence_type: str
    measurement_origin_id: str
    calibration_status: str
    warnings: tuple[str, ...]


def marker_homography(frame: np.ndarray, marker_side_mm: float = 20.0, marker_id: int = 0):
    """Find ArUco DICT_4X4_50 marker and return image-pixel -> marker-plane millimeters H.

    Lens distortion is NOT corrected here. For measurements in actual parts,
    undistort images using separately obtained intrinsics before calling.
    """
    if marker_side_mm <= 0: raise ValueError('marker_side_mm must be positive')
    dictionary = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)
    detector = cv2.aruco.ArucoDetector(dictionary, cv2.aruco.DetectorParameters())
    corners, ids, rejected = detector.detectMarkers(frame)
    if ids is None: raise ValueError('reference marker not found')
    matches = np.where(ids.reshape(-1) == marker_id)[0]
    if len(matches) != 1: raise ValueError('reference marker ID ambiguous or missing')
    src = corners[int(matches[0])].reshape(4,2).astype(np.float32)
    dst = np.array([[0,0],[marker_side_mm,0],[marker_side_mm,marker_side_mm],[0,marker_side_mm]],dtype=np.float32)
    if cv2.contourArea(src.reshape(-1,1,2)) < 100:
        raise ValueError('marker too small for measurement')
    H = cv2.getPerspectiveTransform(src,dst)
    return H,src


def point_distance_mm(H: np.ndarray, p1: Sequence[float], p2: Sequence[float]) -> float:
    """Geometry-only distance between two located image points on marker plane.

    Endpoint identification, edge uncertainty, reference bias and lens errors
    are NOT assessed here. Never use this as a certified length measurement.
    """
    pts=np.asarray([[p1,p2]],dtype=np.float32)
    xy=cv2.perspectiveTransform(pts,H)[0]
    return float(np.linalg.norm(xy[1]-xy[0]))


def dark_runs(row: np.ndarray, threshold: int=120, min_pixels: int=3) -> list[tuple[int,int]]:
    """Detect dark foreground intervals in controlled monochrome scanline."""
    if row.ndim != 1: raise ValueError('single-channel scanline required')
    if min_pixels < 1: raise ValueError('min_pixels must be positive')
    foreground = (row < threshold).astype(np.uint8)
    diff=np.diff(np.pad(foreground.astype(np.int16),(1,1)))
    starts=np.where(diff==1)[0]
    ends=np.where(diff==-1)[0]
    return [(int(a),int(b)) for a,b in zip(starts,ends) if b-a>=min_pixels]


def slot_gap_pixels(row: np.ndarray, threshold: int=120):
    """Find gap between exactly two dark slot arms; ambiguous geometry -> abstain."""
    runs=dark_runs(row,threshold)
    if len(runs)!=2:
        return None,'AMBIGUOUS_CONTOUR'
    (a,b),(c,d)=runs
    gap=c-b
    if gap <= 0:return None,'NOT_SEPARABLE'
    return (float(b),float(c)),'OBSERVED_EDGE_CANDIDATES'


def inspect_slot_scanline(frame:np.ndarray, scan_y:int, *, reference_side_mm:float,
                          measurement_origin_id:str, source_kind:str='physical') -> VisualResult:
    """Illustrative pipeline: marker + binary silhouette + two-arm scanline.

    The marker and slot edge must be coplanar. No distortion/uncertainty model
    implemented; outputs always QUARANTINE_RECHECK, never measured certification.
    """
    if frame.ndim != 3 or frame.shape[2]!=3:
        raise ValueError('BGR color image required')
    if scan_y<0 or scan_y>=frame.shape[0]:
        raise ValueError('scan_y outside image')
    if source_kind!='physical':raise ValueError('only actual capture accepted here')
    try:
        H,_=marker_homography(frame,reference_side_mm)
    except ValueError as exc:
        return VisualResult(None,'HOLD_CAMERA_INVALID','camera_visual',measurement_origin_id,
                            'unverified',(str(exc),))
    gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
    candidates,status=slot_gap_pixels(gray[scan_y])
    if candidates is None:
        return VisualResult(None,'HOLD_AMBIGUOUS','camera_visual',measurement_origin_id,
                            'unverified',(status,'manual/alternate angle or caliper required'))
    x1,x2=candidates
    width=point_distance_mm(H,(x1,scan_y),(x2,scan_y))
    return VisualResult(width,'HOLD_UNTIL_GAUGE_CONFIRMED','camera_geometric_candidate',
                        measurement_origin_id,'unverified',
                        ('same-plane constraint unverified',
                         'lens distortion not corrected',
                         'edge and reference uncertainty not quantified',
                         'independent calibrated caliper confirmation required'))


if __name__=='__main__':
    import argparse,json
    p=argparse.ArgumentParser(description='Experimental planar 2D slot scanline only')
    p.add_argument('image');p.add_argument('--scan-y',type=int,required=True)
    p.add_argument('--marker-side-mm',type=float,default=20.0)
    p.add_argument('--event-id',required=True)
    a=p.parse_args()
    img=cv2.imread(a.image)
    if img is None:raise SystemExit('cannot read image')
    print(json.dumps(asdict(inspect_slot_scanline(img,a.scan_y,
          reference_side_mm=a.marker_side_mm,measurement_origin_id=a.event_id)),indent=2))
