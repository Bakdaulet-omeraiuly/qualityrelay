# QualityRelay 13.1 — Camera Scientific Addendum

This is an **add-on** to the unchanged `QUALITYRELAY_13_SCIENTIFIC_MASTER_BLUEPRINT.md` held in the original QualityRelay 13 ZIP. The `original_13_package.zip` nested archive is retained for full provenance.

1. Read `QUALITYRELAY_13_1_CAMERA_SCIENTIFIC_ADDENDUM.md` — camera research, verified bibliographic URLs, new camera data contracts, site UI, scientific experiments, and team ownership.
2. Run `python -m unittest discover -s tests -v` (requires NumPy and opencv-contrib-python with ArUco).
3. `prototype/vision_evidence.py` demonstrates a tiny reference pipeline and intentionally **does not** certify any part.
4. Evaluate on your own 3D-printed Slot/Tab samples using the experimental/physical protocol. No camera training data or actual real-world validation is bundled.
5. MVTec images are NOT included (research and redistribution licenses apply).

Never claim actual 3D inspection accuracy, physical test results, or published novelty that has not been measured.
