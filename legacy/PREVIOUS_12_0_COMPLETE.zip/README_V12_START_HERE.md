# QualityRelay 12 — Start here

**Main deliverable:** `QUALITYRELAY_12_DECENTRALIZED_SORTING_MASTER_BLUEPRINT.md`

This file contains the full QualityRelay 11 master blueprint, updated for a fourth independently owned **Sorter peer** and a three-way **PASS / HOLD / CONFIRMED REJECT** physical sorting demonstrator. It includes an architecture decision record (ADR-012), state machine, proposed event contracts, physical hardware concept, fail-safe behavior, tests, matched scientific baselines, team responsibilities and ScienceClaw rubric assessment.

## Current truth versus plan

- **Available as inspected:** QualityRelay 11 blueprint, nested QualityRelay 10 single-process reference code, archived report of 15 earlier local tests.
- **Not demonstrated by the supplied package:** four independent station processes and databases; authenticated live peer exchange; physical servo diversion; new measured sorter results; baseline experiments comparing sorter topologies.
- **Important:** A new document version does not turn the inherited one-process implementation into a decentralized deployment. Do not label unrun designs as completed benchmarks.
- **Human and hardware safety:** Industrial plant actuation is out of scope. The bench sorter must be guarded, low-energy, explicitly enabled and verified with physical sensors or operator inspection.

## Build order

1. Preserve the original Slot–Tab–Assembly measurement and compatibility-risk demo.
2. Split into independently running station peers with owner-scoped databases, authorized messages and outage/replay testing.
3. Add a fourth Sorter peer that accepts a **validated part disposition**, not an LLM verdict.
4. Demonstrate one genuine physical specimen entering PASS, HOLD or REJECT, with actual routing confirmed by sensor/operator.
5. Run matched seeded comparisons to test whether peer exchange adds capability beyond a deterministic standalone sorter.

## Why HOLD matters

Two individually conforming pieces can be incompatible with one another. A failed **pairing** does not make both pieces scrap. HOLD/quarantine/reinspect and selective re-matching are crucial to avoiding false rejection.

## Scoring in the master document

Ratings are **subjective evidence-aware estimates**, **not official judge scores**: 4.9/10 for the supplied v11 package as demonstrable today; 5.1/10 for v12 after this *design-only* sorting addition; 8.3/10 as a conditional target if four independent peers, real sorting and rigorous baselines are built and validated.

**Official rubric:** https://scienceclawhack.ai/

The unmodified original `QualityRelay_11_FINAL_FULLY_DECENTRALIZED_PACKAGE.zip` is also included as a provenance snapshot, not as proof that the revised features were built.
