# QualityRelay 12.0 — DECENTRALIZED QUALITY + SORTING MASTER BLUEPRINT

**Subtitle:** Evidence-Governed Peer-to-Peer Manufacturing Intelligence · Inspection, Quarantine, Selective Assembly, Physical Sorting · ScienceClaw 2026

**Status:** Updated *design specification* after review of supplied v11 ZIP and nested v10 implementation. v12 hardware and peer runtime are **proposed, not built or tested**.  
**Architecture decision:** Fully Decentralized is **the product and live demonstration**. Hybrid and Centralized are **research-only comparator modes**.  
**Date:** 2026-10-30 · **Team:** Bakdaulet-omeraiuly, adilnurgg, HyorinmaruK; optional fourth member.  
**Source lineage:** Preserve all original QualityRelay 5.0 resources; incorporate qualified 6.0–10.0 ideas, Evidence-Mesh, V-DER/EVSI, specialist agents, and Kaizen.  
**Document language:** English for executable engineering specifications. A Kazakh/Russian quick summary follows.

> **One-sentence pitch:** QualityRelay is a peer-to-peer team of independently authorized manufacturing agents that detects quality drift, traces evidence across stations, assesses assembly compatibility, and routes individual parts to PASS, HOLD or CONFIRMED REJECT via a locally governed sorting peer—without a global decision-making agent.

---

## 0. Decision record: what the team agreed (source of truth)

**ADR-011, accepted 2026-10-30:**

1. **Default and primary demo:** `fully_decentralized` (`peer_mesh`). No Chief Engineer, master agent, central diagnosis authority or shared raw-data lake is needed to complete a quality incident.
2. **Compare, do not sell:** `hybrid_chief` (a bounded Chief Engineer orchestrates peers) and `centralized_baseline` (one agent with a deliberately documented information budget) run as experimental arms only. They must never silently execute in the primary demo.
3. **Peers have local ownership:** each physical station owns its measurements, process records and local alarms. A specialist agent has a bounded tool/role contract and scoped access—not unrestricted factory-wide memory.
4. **Peers exchange evidence, not unsupported opinions:** claims must link to actual event IDs, versions, uncertainty and deterministic tool results. Human operators approve consequential changes.
5. **At least 20 specialist roles** remain in the registry. Add a **21st Kaizen/PDCA specialist** explicitly without deleting any prior role. Three historical station actors (`slot`, `tab`, `assembly`) remain. Under ADR-012 add a **fourth independent sorter station actor**, not a fictitious 22nd LLM specialist. The target is **21 specialist role contracts + 4 station actors**. The optional Hybrid Chief is not counted as a production specialist.
6. **Not all agents must run for every incident:** 2–6 relevant specialists are normally activated. An empty prompt or a decorative avatar does not count as an implemented agent.
7. **One website:** reads evidence from the peer network but is not a central judge, central raw database or single mandatory gateway for peer operations.
8. **Physical test:** fabricate **100 specimens** (50 slots, 50 tabs), measure them with a caliper, conduct paired assembly tests, and label physical evidence separately from simulation.
9. **Scientific protocol:** preserve original 5.0 statistical core and fair isolated/centralized baselines; add specialist/Kaizen/peer-communication ablations with matched data access, tools and budgets.
10. **Do not fake research:** V-DER is a *proposed, testable integration of decision-aware evidence selection*, not an established first-in-world discovery. The previous 3,000-trial toy comparison did **not** demonstrate an advantage over classical IG. 10,000 papers were **not** individually analyzed; an acquisition/screening pipeline was developed.
11. **Do not pretend code exists:** the inherited 10.0 FastAPI mini-demo is a useful reference but **is not yet an independently deployed, fully decentralized implementation**; conversion and tests below are mandatory.
12. **No automatic industrial plant actuation, hold release, spec revision, tool-offset changes or unsafe process changes:** these are recommendations pending human approval and site-specific validation. A guarded, low-energy **bench-top demonstration sorter** may operate under an explicit operator enable with deterministic local routing rules; this is not plant deployment.

### 0.3 ADR-012 — part disposition and independent sorting peer (2026-10-30)

**Decision:** Add a fourth independently running node, `sorter`, owning the **physical routing state** of each ID-tagged specimen. It is a **material-handling actor**, not a global orchestration or diagnosis service. Slot and Tab peers still own metrology and local conformance; Assembly owns pair-compatibility assessment. The Sorter receives *authorized, signed/verifiable disposition certificates* and applies a locally validated route policy. It never computes the sole global risk posterior or orders other agents.

**Three destinations, not a misleading binary good/bad choice:**

1. **PASS / eligible stock:** the source station has confirmed individual local conformance with sufficiently credible measurement evidence; the specimen remains eligible for downstream **pair-specific** checks. PASS is **not** an unconditional assembly release.
2. **HOLD / quarantine / re-inspect:** missing, stale, contradictory, near-tolerance, unverified, incompatible-for-current-pair or communication-impaired evidence. The part is **not automatically scrap**. A currently incompatible pair can often be re-matched.
3. **CONFIRMED REJECT:** an individual nonconformance is confirmed by a validated local inspection policy and recorded authorized disposition, or the part is visibly damaged and confirmed by an operator. The physical reject chute remains distinct from HOLD. A human/site rule decides scrap versus rework.

**Safety/integrity invariants:** Unknown or unconfirmed `part_id`, unauthorized disposition, stale certificate, ambiguous occupancy, full bin, part-sensor disagreement, lost actuation feedback, or duplicate conflicting command **must not be routed to PASS**. Stop the feed or move to HOLD only when the mechanical apparatus makes that safely achievable. A commodity servo does **not** itself guarantee power-loss fail-safe behavior; mechanical safe-state design and physical testing are required.

**Classification nuance:** Locally passing dimensions do not prove assembly compatibility. Example using historical teaching specifications: `W=20.60 mm` and `T=20.40 mm` both satisfy local bands, but `C=0.20 mm < 0.50 mm`—hold that **pairing**, not necessarily either part as scrap. Conversely `W=20.40 mm` violates the slot lower bound `20.50 mm` on its face, but first apply the declared uncertainty and confirmation policy before physical rejection.

**No achieved-result claim:** ADR-012 specifies future implementation and acceptance tests. Nothing in the uploaded archive demonstrates a physical sorting actuation, four independent service processes, or experimental improvement caused by sorting.

### 0.1 In Kazakh — қысқаша

Біздің негізгі QualityRelay өніміміз — **Fully Decentralized AI**. Әр өндірістік станция мен AI-маман тәуелсіз, өз деректерін қорғайды және қажет дәлелдермен бір-бірімен алмасады. **Chief Engineer негізгі өнімде болмайды**; Hybrid және Centralized тек ғылыми салыстыруға қалады. 3D-принтерден **50 Slot + 50 Tab** шығарып, 100 бөлшекпен эксперимент жасаймыз. **Bakdaulet** — ғылыми модельдер; **adilnurgg** — P2P backend және қауіпсіздік; **HyorinmaruK** — механика, физикалық валидация және презентация.

### 0.2 По-русски — для команды

**Основная система QualityRelay — полностью децентрализованная сеть AI-специалистов.** Нет обязательного Chief Engineer или центрального управляющего агента: специалисты самостоятельно запрашивают подтверждённые данные, проверяют друг друга и предлагают инженерные решения. **Hybrid и Centralized — только контрольные режимы для научного сравнения.** Физическая демонстрация использует 100 деталей (50 Slot + 50 Tab), независимые измерения и сборочные испытания. Все критические производственные действия подтверждает человек.

---

## 1. Product: who needs it and why

**First customer:** manufacturing quality engineer or process engineer at a precision-machining / small-component assembly operation that combines parts made by different machines, teams or suppliers. The 3D-printed demonstration is a model of that problem, *not a claim that PLA matches industrial metals*.

**Operational problem:** individually conforming components can still assemble poorly when the pairwise clearance constraint fails. Evidence is separated across stations and sometimes unavailable. Rechecking everything is slow. A single centralized actor may require privileged raw-data access that suppliers/shops do not grant.

**Target user action:** before pairing lots, the operator chooses `slot lot A-07` + `tab lot B-12`, asks "Is this pairing safe to attempt, what might be wrong, and what should we inspect next?" The system:

1. Opens an incident at the *Assembly peer*; an initial screen shows `PENDING_EVIDENCE`.
2. Sends authorized, typed peer requests to Slot and Tab nodes; each node may approve or deny disclosure.
3. Combines fresh, permissioned summaries; performs deterministic fit-risk and fault-hypothesis analysis.
4. Invites **relevant** specialists to independently inspect design, metrology, process drift or assembly constraints.
5. Retains a dissenting measurement-based challenge even if most LLM agents disagree.
6. Selects a candidate inspection by an **explicit** policy (IG baseline, constrained EVSI/V-DER experimental policy, or conservative fallback); never invents a specimen ID.
7. Presents evidence coverage, uncertainty, hypotheses, proposed next action, human-approval status and all cited source IDs.
8. On measured follow-up, updates the incident. Later, the Kaizen agent can propose a controlled process-improvement experiment.
9. Independently, for **every physically tracked specimen**, a local source Quality peer issues a signed/versioned `PartDispositionProposed` or `DispositionConfirmed` event; the Sorter peer validates authority and freshness and performs a **bench-only** PASS/HOLD/REJECT route after an operator enables the mock sorting mechanism.
10. Before actual assembly, Assembly may issue an evidence-linked **pair-specific compatibility HOLD** even for two locally passing specimens. It must not silently overwrite a source-owned local conformance certificate or designate a part as scrap.

**The website is not the decision-maker.** If the dashboard disappears, station peers still collect readings and issue/consume allowable events. If a required peer disappears, the remaining peers may keep their local monitoring alive but **must not pretend to have current joint evidence**. Sorting also has a **local** acceptance gate and cannot treat a disconnected source as permission to pass new material.

### 1.1 Explicit out-of-scope promises

No factory-safe autonomous control; no guaranteed cost savings; no industrial certification; no evidence that 21 LLMs outperform one LLM; no truthful claim of 100% defect prediction; no novel Bayesian formula; no "10,000 papers read" statement.

---

## 2. Inherited QualityRelay 5.0: requirements that may not regress

Preserve and test the original source design (verbatim copy of its master blueprint in Appendix A):

- Three **historical** independent logical stations: `slot`, `tab`, `assembly` with scoped raw-data ownership and authority; the v12 target adds a fourth separate `sorter` peer without changing the original v5 baseline.
- Slot local spec `[20.5, 21.5] mm`; Tab local spec `[19.5, 20.5] mm`; functional minimum clearance `c_min=0.5 mm`; nominal means 21.0 and 20.0 mm (teaching assumptions, *not factory measurements*).
- Assembly clearance `C = W − T`; local conformance **does not** ensure assembly acceptance; `W=20.5, T=20.5` gives C=0.0 mm.
- Versioned, deterministic, common statistical engine for all topologies, with a frozen calibration baseline, conditional Monte Carlo acceptance distributions, EWMA SPC, Bayesian hypothesis model (`H0`, `H1`, `H2`, `H4`) and expected information gain.
- Provenance-linked, identity/role-scoped events; request→response links; exact event IDs; no raw cross-station database reads; no fabricated measurements.
- Local operation during a peer outage, visible evidence-coverage decrease, queue replay with **idempotent application** of events.
- A real caliper measurement, a small physical fit demonstration and a **separate** seeded simulation benchmark; do not pool their denominators.
- Reproducible manifests: config version, assumptions, seed, code version, input evidence IDs/hashes, output and runtime.
- Original schemas and STL/SCAD sources must be retained (see package contents and Appendix A). Add schema versions; never silently overwrite a v1 contract.
- Original scenarios including combined shift `slot -0.100 mm`, `tab +0.100 mm` remain available as named simulations. Their results are not automatically "proven".
- Original no-go tests (unauthorized 403, pending-before-evidence, deterministic repeat, 0 duplicated applications, credible physical origin, controlled candidate IDs) remain mandatory.

**Important compatibility note:** `QualityRelay 10.0` provides **one in-process demonstration** with separate in-memory station objects and a Chief/peer-review endpoint; this demonstrates logic, not strong service isolation, industrial permissions or fully decentralized deployment. We must implement the node split below and report tests honestly.

---

## 3. Primary architecture: peer mesh, not pyramid

### 3.1 Runtime diagram

```text
           RAW OWNERSHIP AND LOCAL EXECUTION (not a hierarchy)

   SLOT NODE                      TAB NODE                    ASSEMBLY NODE
   local DB                       local DB                    local DB
   sensor/caliper W               sensor/caliper T            pairing/fit outcomes
   local EWMA                     local EWMA                  joint-risk tool
   local Outbox                   local Outbox                incident & Outbox
       |   \                         |   /                         |
       |    \---- signed, authorized, typed EVENT MESSAGES ----/    |
       |                  (P2P: request/response/challenge)        |
       +----------------------+-----------------------+-----------+
                              |
               SPECIALIST PEERS — capability-scoped tools
     Design • Tolerance • Metrology • Quality • Process • Assembly
     Bayesian • Inspection • Security • Reliability • Kaizen • ...
      (21 registered roles; only incident-relevant roles activate)
                              |
               Evidence-linked proposals / protected dissent
                              |
         ASSEMBLY PEER: deterministic risk & allowed proposal
                              |
                  Human engineering approval

   V12 SORTER NODE: separate local DB + approved certificate gate;
   controls only bench diverter: PASS / HOLD / CONFIRMED REJECT.
   Neither a Chief nor a global quality-release authority.

   OBSERVABILITY ONLY: dashboard reads authorized peer views,
   aggregates them for display, and never controls/owns decisions.

  BASELINES (EXPERIMENTS ONLY): Hybrid Chief / Centralized Agent
```

**Critical distinction:** the Assembly node may be incident initiator and domain-specific *pairing owner*, but **not a global controller**. Any permitted node can request specialist review and challenge data. No permanent leader exists. Safety acceptance is rule-based and human-governed, not determined by agent votes.

**V12 extension:** treat the new Sorter as the fourth *independently deployed station peer*, not as a role inside the central web server. See ADR-012 and Section 16 for exact authority and physical-route tests.

### 3.2 What "fully decentralized" must mean in this project

| Property | Minimum demonstrable rule | Failure test |
|---|---|---|
| Local storage | Slot/Tab/Assembly/Sorter use separate persistent DB files or DB instances with separated credentials | Try cross-station raw read → denied |
| Independent runtimes | **Four** distinct server **processes/containers** in v12; not merely Python classes | Kill Sorter; Slot/Tab still measure and Assembly still abstains safely |
| Peer-only coordination | Tasks/evidence may flow without Chief, scheduler or global inference engine | Shut off all coordinator/comparator routes; complete allowed peer incident |
| Policy boundaries | Each node validates source identity, requested fields and role | Unauthorized requests denied and logged |
| No global raw lake | Dashboard/read model contains only approved summaries | Inspect storage/network payloads for unapproved raw rows |
| Fault containment | Failed peer marked unavailable; stale evidence expires | Risk decision becomes incomplete/abstains, not stale "green" |
| Durable delivery | Local outbox and idempotent receiver inbox | Deliver duplicate event → one logical application |
| No UI dependency | Peer decisions/proposals survive website outage | Disable UI gateway; API peer test still passes |
| Auditable provenance | Source refs, hashes, model config and origin labels present | Tamper/missing-ID test rejects unsupported claim |

**Transport ≠ authority:** a message broker may relay bytes, but it must not have privileged raw-data access, infer risk, become a required central controller, or rewrite content. For strongest demonstration use direct, mutually authenticated peer HTTP between containers with durable outboxes; a replaceable relay can be an optional queue transport, not a central brain.

### 3.3 Distributed tasks without a Chief Engineer

A peer incident follows a **bounded capability protocol**:

1. *Initiate:* Assembly creates `incident_id`, objective, safe action set, budget and allowed evidence graph.
2. *Discover:* capability registry (a cached, signed allowlist replicated with nodes) identifies eligible specialists. Registry *selection* is deterministic; no coordinator grants permissions.
3. *Request:* a requesting peer sends `EvidenceRequested` with reason, permitted fields, deadline and nonce to an owning station/specialist.
4. *Validate:* receiving peer checks identity, schema, time, signature/authentication, per-field policy and freshness. It may respond `Denied/Unknown` instead of leaking raw data.
5. *Compute:* each relevant specialist runs its own approved tool, returns a typed `SpecialistAssessment` with source IDs, uncertainty and disconfirming test. Only tools compute numeric truth.
6. *Challenge:* another peer may issue `EvidenceChallenge`; material, sourced, decision-relevant dissent invokes a **hold/inspect gate**, never silent majority override.
7. *Propose:* Assembly calculates allowed pairwise risk **from its current authorized evidence snapshot**; results tied to a hash and versions. Inspection policy chooses **from registered specimen IDs** only.
8. *Gate:* if evidence is insufficient, stale, uncalibrated or contradictory → `ABSTAIN_*` / `HOLD_REVIEW`, not "safe release".
9. *Approve:* a human engineer reviews the source-linked proposal. For the demo only safe actions `hold`, `inspect`, `request_more`, `propose_alternative` are offered.
10. *Observe:* resulting physical measurement or fit outcome is logged at the owning node; another evaluation occurs using a new snapshot.

**Concurrent proposals:** use immutable incident evidence snapshots, version fields and optimistic check-before-approval. Conflicting proposals remain separate and require human review. Do not invent a globally consistent consensus algorithm or imply that two of three votes make an unsafe pairing safe.

### 3.4 Temporary role ownership without a permanent boss

For optional work that needs a single short-lived *work-item handler*, use an idempotent `work_key=(incident_id, task_type, evidence_snapshot_hash)` and a deterministic capability-aware selection policy, with a short lease and retries. That peer has **no special access or right to approve**; if it fails, any authorized peer can execute the task after lease expiry. This optimization is optional and must be tested under duplicates/partitions. Never rely on a shared global lease service in the primary topology.

### 3.5 Network partitions and epistemic safety

- **Local monitoring continues** at Slot/Tab while links are absent.
- **Global pairing risk may be unavailable**; missing evidence is *not* an assumed zero deviation. Reject unsafe claims and show `coverage: 1/2` or explicit policy status.
- A stale approved summary must be invalidated if freshness expires or measurement version changes.
- Use monotonic per-node sequences, UTC timestamps and `(source_id, event_id)` idempotency keys; wall-clock ordering is not causal ordering.
- Reconnection: replay at-least-once delivery, deduplicate applications and resolve contradictory versions using station ownership plus immutable event IDs; do not promise exactly-once network transport.
- Peer/transport failures must be injected physically at process/container boundary, not just a toggle that changes a UI label.

---

## 4. Twenty-one genuine specialist agents: role, tools, acceptance test

Each specialist is a **bounded, replaceable service/tool executor**, not a fictional character. A valid agent implementation needs: `role_id`, allowed input schema, capability-based permission, versioned deterministic tool or real integrated sensor/CAD reader, JSON-schema output, provenance citations, fallback/abstention, reproducibility test, independent negative test and ablation switch. LLM is optional for language/task planning; it cannot manufacture a measurement, edit the mathematical risk score, override a policy or pretend a tool executed.

| # | Specialist | Authoritative inputs | Concrete output/tool | Fail-closed / test |
|---:|---|---|---|---|
| 01 | Design Geometry | CAD rev, datums, dimensional specification | rev-linked geometry constraint report | unknown revision → abstain |
| 02 | Tolerance Analyst | dimensions, accepted distributions, pairing policy | clearance sensitivity; conditional fit risk | missing distribution model → abstain |
| 03 | Materials Engineer | material batch, thermal state, certified model | expansion/warpage hypothesis | uncertified material model → unknown |
| 04 | Process Engineer | local process graph, trace time series | candidate stage fault paths | missing operation history → conditional only |
| 05 | CNC Machining Expert | cutter offset, tool wear, machining log | wear/offset explanation | absent CNC evidence → not applicable |
| 06 | Additive Manufacturing Expert | STL rev, slicer, material, print logs | print orientation/flow/warping explanation | no print metadata → abstain |
| 07 | Metrology Engineer | gauge ID, resolution, repeated readings | measurement noise/uncertainty assessment | unverified instrument → warning/hold |
| 08 | Statistical Process Control | calibrated baseline, local series | EWMA/CUSUM statistic and alarm event | absent baseline → no numeric alarm claim |
| 09 | Quality Inspector | local readings, part spec, source events | accept/review/inspect per local spec | unverifiable reading → abstain |
| 10 | Assembly Engineer | pair constraints and authorized summaries | pair fit-risk and physical test plan | one station unavailable → partial/hold |
| 11 | Causal Diagnosis | process DAG, interventions, event times | competing causal explanations + discriminator | observational equivalence → unidentifiable |
| 12 | Bayesian Statistician | frozen priors, validated likelihoods | posterior with sensitivity | unvalidated likelihood → exploratory |
| 13 | Inspection Planner | registered candidate IDs, cost + outcome model | IG / EVSI / V-DER ranking | no trustworthy outcome model → fixed fallback |
| 14 | Operations Research | approved inventory + constraints | feasible pair matching optimization | unknown stock/constraints → no allocation |
| 15 | Maintenance Engineer | machine maintenance/log sensors | preventive maintenance hypothesis | no relevant telemetry → unknown |
| 16 | Supplier Boundary Agent | supplier authorization, contract, payload | field-limited authorized evidence | prohibited fields → deny and audit |
| 17 | Safety and Governance | role policy, machine safety, plant limits | policy veto + human-approval gate | unsafe release request → deny |
| 18 | Privacy and Security | auth attempts, transport envelopes | leakage/authentication risk report | unverified peer → deny |
| 19 | Reliability and Network | link states, freshness, inbox/outbox | coverage, outage, replay audit | stale evidence → stale/partial |
| 20 | Scientific Auditor | run manifest, source hashes, seeds | reproducibility / validity report | origins mixed silently → fail |
| 21 | **Kaizen / PDCA Agent (NEW)** | verified defect history, process baseline, interventions | controlled Plan–Do–Check–Act proposal | insufficient causal evidence → hypothesis only |

**Status today (inherited 10.0):** 20 registry entries; eight narrow, deterministic reference handlers; twelve contracts without implementations. The Kaizen role (#21), genuinely independent peer runtime, and **new Sorter physical station** are **new requirements**, not already delivered code. A prototype may truthfully show role readiness badges: `contract`, `reference_tool`, `peer_service`, `validated`. The Sorter is a **station actor**, not an invented 22nd specialist.

### 4.1 Why many agents can be valuable—or harmful

- **Selective activation:** do not call 21 models for a 0.3-mm clearance arithmetic problem. The normal 100-part case activates Assembly + Metrology + SPC + Inspection Planner; optionally Process, Design, Kaizen when evidence justifies it.
- **Shared model correlation:** several LLM personas using the same model do not supply independent evidence. Count distinct measurements/tool outputs, not votes.
- **Hidden evidence:** specialist claims link to local IDs and must make critical evidence available through authorized requests.
- **Protected minority evidence:** a well-supported dissent cannot be overridden solely by a larger number of unsupported messages.
- **Human approval:** final production release remains outside agent authority.
- **Ablation:** compare `1 / 4 / 8 / 21 available roles` at fixed query, tool and compute budgets; account for extra latency and token cost.

### 4.2 Minimal specialist input/output schema (v2, additive)

```json
{
  "assessment_id": "UUID",
  "schema_version": "2.0.0-draft",
  "incident_id": "UUID",
  "peer_id": "metrology-peer-01",
  "role_id": "metrology_engineer",
  "data_authority": "caliper-source-owner",
  "evidence_snapshot_hash": "sha256:...",
  "source_event_ids": ["real-event-id"],
  "tool_id": "measurement_repeatability_v1",
  "tool_version": "1.0.0",
  "numeric_result_ref": "immutable-tool-result-id-or-null",
  "claim": "Gauge calibration status must be verified",
  "confidence_status": "unverified",
  "limitation": "No traceable calibration certificate",
  "disconfirming_test": "Recheck standard gauge block",
  "proposed_action": "inspect",
  "expires_at": "2026-10-30T22:00:00Z",
  "origin_partition": "physical"
}
```

**Example only:** IDs and timestamps above are illustrative; they are not actual measurements or executed agent outputs. Validate schema and role permissions before accepting any response.

---

## 5. Research hypothesis: evidence-governed collective decisions

### 5.1 What is known, what remains unproved

Inherited foundations include tolerance analysis, Bayesian diagnosis, Monte Carlo, EWMA, entropy/Information Gain, EVSI/decision theory, event sourcing, authenticated service messaging and multi-agent tool use. **None of these alone is claimed as newly invented.**

**Testable proposed contribution:** combine **(a)** owner-scoped manufacturing evidence, **(b)** agent disagreement protected by source-level justification, **(c)** decision-value-aware inspection routing, and **(d)** safe peer coordination under partitions, without a central decision agent.

Call the experimental policy **EVIDENCE-MESH / V-DER (Value-guided Decision-Evidence Routing)**. Its novelty and superiority are **hypotheses to investigate**, not established discoveries.

### 5.2 Five pre-registered primary research questions

- **RQ1 — collective capability:** under the same budget and same available authorized evidence, does the peer network improve diagnosis or safe decision coverage compared with isolated station monitoring?
- **RQ2 — decentralization cost:** how closely does peer coordination approach a fully-informed centralized upper-bound when data cannot be pooled, and at what message/privacy cost?
- **RQ3 — partitions:** when a station or coordinator fails, does peer architecture preserve more *legitimate* local capability without increasing unsafe confident conclusions?
- **RQ4 — inspection choice:** does V-DER reduce expected **decision loss net of inspection cost** relative to classical IG, classical EVSI, random and fixed policies, in which scenarios?
- **RQ5 — specialist collaboration:** do role specialization, evidence-grounded dissent and Kaizen evaluation add measurable value after controlling for additional tools, tokens, time, number of requests and information access?
- **RQ7 (v12 experimental extension) — physical containment:** with identical inspection accuracy, hardware, allowed evidence and operating budget, what added safety/throughput capability comes from decentralized peer disposition and sorting versus isolated/centralized alternatives? See S0–S3 in Section 16.7.

**Optional exploratory RQ6:** does Kaizen-directed, controlled process intervention reduce physically measured deviation in repeated prints compared with an appropriate control, without opportunistic cherry-picking? This requires replicated, controlled printing and cannot be inferred from two successful examples.

### 5.3 Inherited hard numerical core

For slot width `W`, tab thickness `T` and clearance `C`:

```text
C = W - T
mu_C = mu_W - mu_T
var(C) = var(W) + var(T) - 2 * cov(W,T)
Risk = P(C < c_min | slot locally accepted, tab locally accepted,
                   available authorized evidence, pairing policy)
```

For independent normal *untruncated* example distributions, standardize `C` and use the normal CDF. **Production risk must condition on parts passing local specifications**, with a deterministic Monte Carlo or validated integral; document correlation and random-vs-selective pairing. Do not turn one deterministic `W−T` into a falsely calibrated probabilistic model.

Local EWMA:

```text
z_t = λ * x_t + (1−λ) * z_(t−1)
ControlLimit_t = mu0 ± L * sigma0 * sqrt[λ/(2−λ) * (1−(1−λ)^(2t))]
```

`λ=0.2`, `L=3` are *starting configuration values* from 5.0; they are not optimized or industrially validated. Fit `mu0/sigma0` from a frozen calibration set, never from five current points.

Evidence-scoped posterior:

```text
P(H_k | E_authorized) ∝ P(H_k) × Π P(E_station | H_k)
H0 = stable with nonzero design baseline risk
H1 = slot mean shift downward
H2 = tab mean shift upward
H4 = both shift toward tighter clearance
```

Do not multiply conditionally dependent evidence as if independent; either model dependence or state the limitation. Omit missing/stale/unapproved likelihood terms and show coverage. Without a validated likelihood or discriminating sensor, report `ABSTAIN_UNIDENTIFIABLE` rather than fabricate a cause.

Classical information gain baseline:

```text
IG(a) = H[P(H|E)] - Σ_y P(y|a,E) H[P(H|E,y)]
IG_rate(a) = IG(a) / expected_seconds(a)
```

**Decision value baseline and proposed extension:**

```text
CurrentLoss(E) = min_{d in SAFE_ACTIONS} Σ_h P(h|E) L(d,h)
ExpectedLossAfter(a,E) = Σ_y P(y|a,E) min_{d in SAFE_ACTIONS} Σ_h P(h|E,y) L(d,h)
NetEVSI(a) = CurrentLoss(E) - ExpectedLossAfter(a,E) - InspectionCost(a)
V-DER(a) = NetEVSI(a) subject to authorization, freshness,
            provenance, safety constraints, deadline and evidence coverage
```

The decision-value formulation has classical precedents; the test concerns **end-to-end implementation across separately authorized peers**, not claiming to have invented EVSI. If no calibrated outcome likelihood or loss model exists, **do not print a precise EVSI figure**: use IG/fixed fallback and label exploratory.

### 5.4 New protocol ingredients and falsifiability

**Evidence Debt Ledger (EDL):** at each peer, keep an incident-scoped map `hypothesis → needed evidence → source owner → ID/freshness/permission → blocking status`. Missing is not false. This can be replicated as metadata without pooling raw measurements.

**Protected Expert Dissent (PED):** a dissenting specialist must submit an actual source ID, relevant numeric tool output and an expected safe-action difference. A material, testable contradiction creates `HOLD_REVIEW` until checked by another authorized measurement/tool or a human. Unsupported verbal dissent is logged but cannot endlessly block.

**Counterfactual Decision Certificate (CDC):** log which approved action is proposed *before* and *after* the recommended inspection, with evidence IDs, assumptions, calibrated expected loss or `null`, uncertainty and authority. If the candidate would never change a safe action under any plausible outcome, disclose it rather than presenting it as valuable.

**Bounded Autonomy Ledger (BAL):** immutable audit references, human authority and final outcome evidence. A local in-memory hash chain is not a substitute for durable, authenticated, tamper-evident audit infrastructure.

**Peer epistemic safety:** new evidence can legitimately make the final decision more conservative. The desired outcome is not "always release faster"; report abstention/hold as a positive safety behavior when warranted.

### 5.5 Scientific guardrails from prior 9.0 benchmark

The inherited **3,000-trial synthetic toy benchmark** yielded approximately:

| Policy | Previously reported toy mean cost |
|---|---:|
| V-DER-like decision-value policy | 0.6989 |
| Entropy information gain | 0.6991 |
| Random | 0.7419 |

These toy metrics are **not** factory outputs and do not establish an advantage of V-DER over IG (the difference is tiny). Reproduce the included code/seed before reusing them; mark them `PRIOR_TOY_SIMULATION`. Do not add physical data to this table. Pre-register realistic unequal inspection costs, action thresholds, heterogeneous hidden evidence and outage conditions to look for falsifiable, *not guaranteed*, distinctions.

### 5.6 Baseline matrix — change one factor at a time

| ID | Method | Coordinator | Information / tools | Purpose |
|---|---|---|---|---|
| B0 | Local QC only | none | only own station | isolated baseline |
| B1 | Fixed inspection policy | none | matched scoped evidence | action-policy baseline |
| B2 | Random allowed inspection | none | matched scoped evidence | simple baseline |
| B3 | Entropy IG peer policy | none | matched scoped evidence, same core | classical baseline |
| B4 | Classical EVSI peer policy | none | matched scoped evidence, same loss model | decision theory baseline |
| B5 | **Fully decentralized QualityRelay** | **none** | peer evidence + specialists + PED; baseline inspection policy | **main architecture** |
| B6 | Fully decentralized + V-DER | none | same as B5; proposed planner change | V-DER ablation |
| B7 | Fully decentralized, PED disabled | none | same as B5 minus sourced dissent | dissent effect |
| B8 | Single LLM agent | one agent | declared matched tool/data budget | multi-agent effect |
| B9 | Hybrid with bounded Chief | bounded Chief | matched peer authority + extra coordination cost | comparison only |
| B10 | Centralized pooled reference | one global inference role | maximal available raw info, explicitly marked upper bound | comparison only |
| B11 | Peer mode, link outage | none | local continuity, partial evidence | resilience test |
| B12 | Hybrid coordinator outage | Chief unavailable | same peer nodes; measure fallback | show Chief is unnecessary |

Not all B0–B12 are feasible in the live demo. **P0 minimum:** B0, B3, B5, B9/B10 as recorded comparison, and one real outage of B5. **Research extension:** full factorial and policy ablations. Every experiment reports where information access differs. Fully-informed centralized B10 is *not an equal-privacy comparator*.

### 5.7 Outcomes and preregistration

**Primary:** unsafe confident recommendation rate; valid-decision coverage; paired hypothesis accuracy on simulated truth; incremental inspection count and time; evidence exposure; message bytes; uptime/local continuity under partitions.

**Secondary:** Brier score for simulated probability predictions only; detection delay from injected change-point; calibration by risk bins with adequate n; net decision loss; per-query token/API cost; PED false-block rate; human review time; exact event replay deduplication.

**V12 physical routing metrics:** confirmed route accuracy, false-reject rate, defect escape rate, HOLD-WIP occupancy, good-part throughput and time from measurement to physically confirmed diversion. Keep denominators and machine/print origins separate.

**Design:** use matched generator seeds, fixed process distributions, frozen hypothesis priors, same statistical code and equal inspection budgets. Prefer multiple seeds with paired per-seed differences, confidence intervals and raw per-seed outputs. Do not select best seeds after seeing outcomes. Make negative results visible.

**Ablations:** remove P2P evidence, role specialization, PED, Kaizen, V-DER one at a time; compare `1/4/8/21` available specialists with identical *active* token/query/compute caps, not just nominal role counts. Disclose if a comparator has more raw data, stronger tools or compute.

**A real scientific contribution requires:** pre-specified metric, completed experiments, uncertainty, reproducible code/data/seed provenance, review of prior work, and an honest limitation section. No unvalidated "Nobel-level" or "first in the world" claim.

---

## 6. The 100-specimen physical experiment (mandatory user story)

### 6.1 Materials and batches

Print **50 slot specimens** and **50 tab specimens**, plus optional spare/repeatability coupons counted separately. Every specimen receives a machine-readable unique ID (`S001…S050`, `T001…T050`) with a fixed source lot and CAD revision. Divide the 100 target specimens into planned strata, e.g.:

| Slot design/lot | n | Tab design/lot | n | Planned contrast |
|---|---:|---|---:|---|
| S-NOM | 20 | T-NOM | 20 | normal pair baseline |
| S-TIGHT | 15 | T-THICK | 15 | combined reduced clearance |
| S-VAR | 15 | T-VAR | 15 | near-boundary/repeatability stress |
| **TOTAL** | **50** | **TOTAL** | **50** | **100 specimens** |

The names and allocations are **proposed experimental design**, not measured part properties. Set the actual CAD parameters to a discriminable physical margin based on pilot printer/gauge repeatability; keep source STL and slicer settings versioned. The 5.0 print kit supplies `slot_good_21p20`, `slot_nominal_21p00`, `slot_risk_20p70`, corresponding tab models and repeatability bar; extend with *declared* new variants, do not quietly overwrite the originals.

**Mechanical lead (HyorinmaruK):** own CAD/STL revision, print manifest (material, slicer profile, nozzle, orientation, temperature, location on plate, operator), labeling, caliper protocol, camera witness footage and final presentation.

### 6.2 Metrology before AI

1. Zero the caliper and record instrument ID, resolution and operator. Check a known reference when available.
2. Measure one stable repeatability coupon **10 times**, removing/reseating the jaws each time; preserve every raw reading. Compute mean, sample standard deviation and range.
3. Record **3 readings at one declared location** for each specimen (the raw protocol can be reduced only if documented as a limitation). Record surface anomalies and ID photos separately.
4. Do not assume 3D CAD dimensions are the measured truth; do not sand or force parts to make the result fit; record any post-processing and remeasure.
5. Prespecify physical pass/fail/indeterminate: at declared insertion depth and gentle finger pressure, no visible bending. Leave indeterminate genuine.
6. **Ground truth vs accessible evidence:** an independent validation ledger may hold all measured readings, but agents must start with a limited, predetermined exposed subset. Hidden measurements are revealed only through simulated permitted inspections / a genuine live inspection; the ground-truth ledger cannot leak through an API, model prompt, dashboard or common DB.
7. Distinguish **physical labor actually performed** from **counterfactual inspections requested** during replay. If the team pre-measures all 100 off-line, a reduced number of *algorithm-requested revelations* does **not** prove a reduction in the real labor already spent.

### 6.3 End-to-end physical demo (audience-readable)

**Example only (not claimed result), extended by v12 sorting step:**

1. Open website → select `QualityRelay / Fully Decentralized` (large green label `PRIMARY MODE`).
2. Choose target batch/pair `S-TIGHT` + `T-THICK`, click **Open Assembly Risk Case**.
3. Assembly peer displays `PENDING_EVIDENCE` and visible data coverage `0/2`.
4. Slot and Tab peers respond with source-limited summary + event IDs; each local UI shows its own measurements.
5. Relevant Specialist Agents (Quality, Metrology, Process/Assembly, Inspection) independently evaluate. A sourced contradiction remains visible rather than being voted away.
6. Assembly peer displays computed risk with **model and origin tags** or declines to assess if evidence is insufficient.
7. Inspection Planner proposes **one registered** `S###`/`T###` caliper reading based on a declared algorithm; the user performs it or reveals that prerecorded measurement with explicit retrospective label.
8. Update and compare the prediction; physically fit one measured high-clearance and one tight-clearance pair. Record `PASS/FAIL/INDETERMINATE` honestly.
9. Turn OFF the Tab node **process**; Slot still measures locally, Assembly shows `PARTIAL_EVIDENCE`, *no fabricated green decision*. Reconnect, replay queued events once.
10. Show three research-mode comparison panels **after** the primary live decentralized demo; conclude with reproducible run manifest and limitations.
11. **V12 optional physical close-the-loop:** scan a registered part and its local inspection evidence; local owner issues a disposition certificate; Sorter peer independently validates it and, only with bench operator enable, diverts to PASS/HOLD/REJECT with a sensor-confirmed `SortActuationConfirmed` event. Unknown/stale evidence must not route to PASS.

### 6.4 Matching 50 pairs without scientific leakage

A Smart Matching option can minimize predicted incompatible pairs under a one-to-one pairing constraint **only if** inventory IDs, the same evidence availability, allowed candidates and rejection rules are frozen. Algorithms: maximum weight bipartite matching or min-cost flow using validated pairwise probabilities; fixed/random matching baselines mandatory. **Do not simply reveal exact individual dimensions for every item, compute the optimal matching, then claim AI reduced inspections.** Run the matching and inspection experiments separately or explicitly model who knows what and when.

### 6.5 What physical observations can establish

A 100-specimen set can demonstrate process variation, measurement/fit mechanics, a complete agent/evidence loop and controlled comparisons **within that print batch**. It does not, by itself, validate probability calibration for future factories, causal discovery, or a global industrial defect rate. Keep physical outcomes as `PHYSICAL` and simulation as `SIMULATED`, with unpooled headline figures.

---

## 7. Kaizen integration (Toyota-inspired, testable)

**Kaizen Agent** is a peer, not another boss. It may access approved aggregate defect history and propose a **Plan–Do–Check–Act** cycle:

| Phase | Concrete action | Evidence and approval |
|---|---|---|
| PLAN | identify recurring defect class, enumerate 5-Whys hypotheses; specify measurable target and confounders | cites process events; admits unproven causality |
| DO | propose one controlled printer/process parameter change on designated new specimens | human/operator approval, declared intervention, stable other settings |
| CHECK | compare intervention and control with raw readings, repeatability and uncertainty | frozen metrics, role-specific Data Science validation |
| ACT | propose retaining, reverting or repeating an improvement | decision document and human approval; no unvalidated machine actuation |

**Kaizen is not an automatic self-improving black box.** Simply seeing lower deviations after a print does not establish causation. Predefine control/treatment, process conditions, sample sizes, randomization or counterbalancing, and a stopping rule. In the hackathon, showing a well-formed PDCA proposal is sufficient; claimed process gains require executed tests.

---

## 8. One website: exact screens and interaction sequence

**Design principle:** one web UI, many *independent services*. It is a view over authorized summaries; its shutdown cannot stop peer work.

| Route / screen | User sees | Responsible peer(s) | Must not imply |
|---|---|---|---|
| `/dashboard` | plant status, 100-part counts, freshness, mode, alerts | read-only peer adapters | one central global database |
| `/parts` | 50 Slot + 50 Tab IDs, lot, physical/sim origin, disclosed readings | Slot / Tab | hidden ground-truth leakage |
| `/stations` | each peer live/offline, local EWMA and measurement log | Slot / Tab / Assembly | online = evidence valid automatically |
| `/cases/new` | pair/lot selection, requirements, objective | Assembly | AI can approve any pair |
| `/cases/:id` | evidence timeline, queries, hypotheses, risk, next registered inspection | Assembly + relevant peers | invented tool outputs |
| `/ai-team` | 21 roles, 2–6 activated per case, tool/contract status, source-backed conclusions | specialist peers | all 21 are deployed LLMs |
| `/peer-network` | P2P messages, provenance, redacted payload, outage/queue | Reliability/Security | central orchestration |
| `/inspection` | caliper/photo witness; ID-scoped reading form, immutable origin | owning station + Metrology | camera auto-measures µm dimensions |
| `/matching` | feasible approved pair suggestions, constraints, uncertainty | Assembly + OR | exact optimization if dims withheld |
| `/sorting` | each part ID, local source certificate, requested/confirmed bin, occupancy, uncertainty and manual intervention | Sorter + owning quality peer | motion from dashboard inference or speculative AI |
| `/kaizen` | PDCA plan, human decision, before/after controlled evidence | Kaizen + Process | automatic plant parameter change |
| `/research` | **separate** B0/B5/B9/B10 charts, origin panels, seeds, assumptions | Scientific Auditor | real results from unrun trials |
| `/audit` | event/citation lineage, denial tests, run manifest export | each owner + read-only aggregator | tamper-proof ledger without keys |

### 8.1 Screen hierarchy for judges

The opening page says **FULLY DECENTRALIZED — PRIMARY MODE**, next to a limited **COMPARISON MODES** disclosure, never an unexplained global Chief panel. Network graph edges represent **actual authenticated evidence messages**, not an animation. The next-inspection card shows `request_id`, specimen ID, expected value **if actually calculated**, responsible agent and uncertainty. A missing evidence icon is more valuable than invented confidence.

### 8.2 Recommended user-facing statuses

`PENDING_EVIDENCE`, `EVIDENCE_PARTIAL`, `ASSESSMENT_READY`, `ABSTAIN_UNIDENTIFIABLE`, `ABSTAIN_UNVERIFIED_GAUGE`, `PED_CHALLENGE_OPEN`, `HUMAN_REVIEW_REQUIRED`, `PHYSICAL_TEST_RECORDED`, `NETWORK_PARTITION`, `REPLAY_RECONCILED`.

### 8.3 Camera behavior

An ordinary phone/webcam is **supporting photographic evidence** only; it can capture specimen ID, caliper display and visible surface defect. It is **not** accepted as sub-millimeter dimensional ground truth without calibrated optics, a scale/reference, validation and uncertainty analysis. Physical size comes from a documented gauge/metrology tool.

---

## 9. Software plan: migrating existing 10.0 code to genuine peer mode

### 9.1 Baseline source (do not mislabel)

Existing 10.0 ZIP includes a single FastAPI app (`qualityrelay10/api.py`), `core.py`, `state.py`, `agents.py`, `decision_value_prototype.py`, a web demo, 15 passing local demonstration tests (according to the inherited release report), 20 role registry entries/eight narrow tools, old Chief endpoints and peer-review fallback. These are **reference assets only**; they do not yet satisfy the independent services, durable databases, authenticated P2P or all 21 agent behaviors in this document.

### 9.2 Proposed new repository layout

```text
qualityrelay/
  README.md
  docs/QUALITYRELAY_12_DECENTRALIZED_SORTING_MASTER_BLUEPRINT.md
  legacy/QualityRelay_5_ORIGINAL.zip         # bytes unchanged
  legacy/QualityRelay_10_REFERENCE.zip       # bytes unchanged
  contracts/v1/*                             # exact original schema
  contracts/v2/{peer_event,assessment,incident,inspection,challenge}.schema.json
  services/
    slot/{app.py,db.py,policy.py,outbox.py}
    tab/{app.py,db.py,policy.py,outbox.py}
    assembly/{app.py,db.py,decision.py,outbox.py}
    sorter/{app.py,db.py,policy.py,hardware_adapter.py,outbox.py}
    specialists/{registry.py,capabilities.py,handlers/}
    shared/{core.py,event_validation.py,idempotency.py,auth.py}
  research/{simulator.py,baselines.py,vder.py,preregister.yaml,analysis.py}
  physical/{specimens.csv,measurement_protocol.md,measurements.csv,fit_tests.csv}
  hardware/sorter/{cad,stl,wiring.md,calibration.md,safety_checklist.md}
  web/{dashboard,parts,agents,incidents,network,kaizen,research}
  tests/{unit,contracts,security,topology,fault_injection,statistics,physical_data}
  infra/{docker-compose.yml,station_credentials,healthchecks}
  results/{manifests,plots,raw_runs,negative_results}
```

Use Python + FastAPI + per-station SQLite in the hackathon; Postgres or industrial data connectors are later options. Prefer **three independently running services** and peer HTTP first; do not expand to Kubernetes/complicated consensus under deadline pressure.

### 9.3 Version 1 compatibility, version 2 extension

Original `contracts/event-envelope.schema.json` has `schema_version=1.0.0`, allowlisted event types, `source_agent`, `station_id`, rich `origin`, `run_id`, `correlation_id`, `occurred_at`, `payload`, `evidence_refs`; the v1 schema deliberately rejects unknown agents/events. Preserve its bytes and write a **v1-to-v2 translation adapter** with explicit validation tests. Do **not** take a v2 specialist message and falsely declare it is v1-compliant.

**v2 event security requirements:** stable UUID, source peer identity, station ID, incident/correlation/causation IDs, `origin.kind`, timestamp and monotonic source sequence, permission scope, expiry, payload hash, actual message signature/authenticated channel, contract version, schema validation and traceable source IDs. A SHA-256 string alone does not authenticate identity.

### 9.4 Minimum P2P endpoints (design contract, not claimed implemented)

```text
POST /v2/incidents                             # create at owning peer
GET  /v2/incidents/{id}/state                  # authorized read model
POST /v2/evidence/requests                     # sender -> owning station
POST /v2/evidence/responses                    # station -> requester
POST /v2/specialists/assess                    # ask a peer to use allowed tools
POST /v2/challenges                            # sourced dissent
POST /v2/inspections/proposals                 # approved candidate IDs
POST /v2/measurements                          # submit at owning station
POST /v2/fit-outcomes                          # submit at assembly owner
POST /v2/human/reviews                         # authorized human gate
GET  /v2/outbox /v2/inbox                      # per-peer durable event replay
GET  /v2/status                                # health; not global leader
GET  /v2/replay-manifest                       # per-incident reproducibility
```

The integrated dashboard may call approved gateway/read-only APIs, but the **peer-to-peer decision path must not require the gateway**.

### 9.5 Example request/response sequence (conceptual)

```text
Assembly -> Slot: EvidenceRequested(incident=I, lot=A-07, fields=[count,mean_mm,...])
Slot -> Assembly: EvidenceResponded(incident=I, source_event_ids=[...], fresh_until=...)
Assembly -> Tab: EvidenceRequested(incident=I, lot=B-12, fields=[count,mean_mm,...])
Tab -> Assembly: EvidenceResponded(incident=I, source_event_ids=[...], fresh_until=...)
Assembly -> Metrology: Assess(gauge_status, source_refs=[...])
Metrology -> Assembly: VerifiedAssessment/ABSTAIN(citations=[...])
Assembly -> Inspector: Rank(whitelisted_specimen_ids=[...], model_version=...)
Inspector -> Assembly: ProposedInspection(ID=an actual registered candidate)
Assembly -> Human: HOLD or INSPECT proposal + CDC + source events
Human -> Owning station: Approved measurement task
Owning station -> Assembly: MeasurementRecorded(physical origin, gauge/operator IDs)
```

**All arrows here are protocol directions.** They are not a claim that physical microservices already exist. Any diagram showing a Chief Engineer managing these arrows is a **Hybrid comparator**, not the default product.

### 9.6 Readiness gates to leave in-process 10.0

**Gate G1 (v12):** **four** services start independently; four different DB credentials/paths; prove cross-read denial.  
**G2:** full `v1` contract tests preserved; `v2` schema validates and conversions lossless where applicable; unrecognized payloads rejected.  
**G3:** relevant specialists function as tool-grounded peers without Chief; dashboard not needed for peer decision.  
**G4:** one node truly offline, local measurement continues, evidence status invalidates, reconnect leads to one logical event application.  
**G5:** all numeric risk outputs deterministic for frozen inputs + seed; origin, assumptions, uncertainty and human gate visible.  
**G6:** scientific baseline and physical experiment do not consume hidden ground truth illicitly.

---

## 10. Security, safety and factory-readiness constraints

### 10.1 Threats to explicitly test

- Peer A requests Peer B raw measurement table without authorization.
- A malicious specialist sends fabricated `source_event_id`, specimen ID or unsupported confidence.
- Replay sends an identical event 2+ times; receiver must not double-count.
- Stale measurement is accepted after a link outage.
- A compromised model prompt asks to leak a supplier's raw records.
- One LLM hallucinates "safe" despite a deterministic `HOLD`.
- UI dashboard goes down, peer operations must continue.
- Under partition, two peers issue contradictory versions; no unauthorized automatic release.
- Operator uploads `SIMULATED` as if `PHYSICAL`, or mixes origins in one metric.
- A model invents camera-based precise dimensional measurements.

### 10.2 Hard controls

RBAC/ABAC scoped permissions, independently verified peer identities (e.g. mTLS in later pilot), encrypted authenticated connections, request allowlists, API input schema, per-station storage, durability and immutable IDs, expiry invalidation, audit log, human-approved safe actions, key revocation, no raw logs in dashboards, prompt-injection boundaries, rate limits, secret management, and factory IT/OT segmentation. **Current demo implementation does not satisfy all of these.**

### 10.3 Factory adoption ladder

| Stage | Allowed claim | Required evidence |
|---|---|---|
| Research demo | isolated 3D-printed parts + seeded simulation | raw runs, manifests, local tests |
| Independent metrology review | third party checked physical measurements | inspection report, traceable method |
| Factory shadow-mode pilot | software observes real data, human decides | written site permission, mapping, calibration, access control |
| Limited supervised recommendation | engineers review recommendations on real processes | prospective evaluation, monitoring, rollback, safety signoff |
| Operational release | site-specific certified process control | formal safety, cybersecurity, quality management validation |

**Never describe a hackathon prototype as "ready to deploy at any factory."** The code must first pass data-protection, site-IT, measurement system and operating-risk checks.

---

## 11. Team work allocation: 3 owners + optional 4th

### 11.1 Explicit accountability

| Owner / GitHub | Owns | Deliverable files | Acceptance proof |
|---|---|---|---|
| **Bakdaulet-omeraiuly** | research/DS, statistical core, conditional risk, simulations, IG/EVSI/V-DER, honest results | `services/shared/core.py`, `research/*`, `results/*`, scientific results copy | deterministic numerical tests; paired runs with uncertainty; no leaked holdout truth |
| **adilnurgg** | independent services, P2P transport, permissions, v1→v2 adapter, evidence/event integrity, failure injection | `services/{slot,tab,assembly}`, `services/shared/{auth,event_validation,idempotency}`, `contracts/v2`, `infra/*` | separate processes/DB; 403 deny; offline local continuity; replay idempotency; Chief-free run |
| **HyorinmaruK** | **mechanical engineering**, all CAD/printing/caliper/fit validation, physical evidence report, integrated visual demo UX, **final slides and pitch** | `physical/*`, `cad/*`, web demo/UX review, `slides/*` | 100 IDs + print manifest, repeated raw readings, assembly witness, physical report, rehearsed final demo |
| **Optional 4th** | frontend implementation, cross-service UI, independent QA, pilot interfaces | `web/*`, `tests/ui/*`, connectors after permission | read-only gateway does not control peers; E2E tests; accessibility; integration notes |

**Conflict rule:** HyorinmaruK always owns *physical/mechanical validation and the final presentation*, not Bakdaulet. Bakdaulet owns statistical results delivered to HyorinmaruK for the slides. adilnurgg must not become permanent "Chief Engineer" in product mode; the old Chief is an isolated comparison module only.

### 11.2 Minimum handoffs

- **H0 contract freeze:** all agree on station/specimen IDs, accepted unit `mm`, v1/v2 envelope, safe actions, origin taxonomy, output states and process/DB ports. No unapproved schema changes.
- **DS→Backend:** versioned `estimate_risk(snapshot, config)`, `update_hypotheses(snapshot, config)`, `rank_inspections(candidates, snapshot, cost_table)`. Return source IDs + digest + assumptions and explicit unknown cases.
- **Backend→Mechanical/UI:** stable incident flow and real event IDs; state transitions; measured-data ingestion; peer status, explicit offline/partial behavior.
- **Mechanical→DS:** print CSV with lot, CAD rev, specimen ID, raw reading index, dimension, unit, gauge ID, origin, operator, date; separate fit outcome sheet.
- **DS→Presentation:** charts with completed seeds, uncertainty and exact label `SIMULATED`; physical part charts labeled `PHYSICAL / descriptive`; competitor comparisons as constraints, not exaggerations.
- **Review:** each PR specifies schema version, local run commands, test output, source hashes, known limitations, reviewer approval and rollout/fallback.

### 11.3 Git branches / repository strategy

- `main` protected for release; `develop` integration if desired.
- `feature/science-core` — Bakdaulet.
- `feature/peer-services` — adilnurgg.
- `feature/physical-demo` — HyorinmaruK.
- `feature/web-qa` — optional 4th; until then HyorinmaruK coordinates visual UX and adilnurgg exposes minimal authenticated views.
- `experiment/hybrid-baseline`, `experiment/central-baseline` — isolated research branches, **never merged as the default runtime**.
- Release tag: `qualityrelay-v11-peer-hackathon` after acceptance tests, not just after completing slides.

---

## 12. Execution plan: deadline-driven, not feature theater

### 12.1 P0: one real, demonstrable decentralized loop

**Priority order:** (1) 3 original independent station services → (2) explicit evidence requests and authorization → (3) stable risk result and abstention → (4) one real caliper input → (5) outage/replay → (6) fair baseline result → (7) **small fourth Sorter peer and manual/bench verified bin route if time permits** → (8) final slides. The 21-agent registry, extra Kaizen screens, elaborate conveyor and attractive network animation must not take time away from the core.

| Active hour | Deliverable | Responsible | Cut if behind |
|---|---|---|---|
| 0–1 | freeze contracts, demo story and scientific claim | all | no new features |
| 1–6 | mathematical core + print/measurement characterization + station DB setup | DS / ME / backend | defer advanced V-DER |
| 6–12 | baseline P2P incident path, evidence, risk, minimal dashboard | backend + DS | run 3 specialist tools only |
| 12–18 | auth deny, independent process outage, local continuity, replay | backend | mock only as contingency, label honestly |
| 18–23 | main simulation, paired baselines, physical first test | DS + ME | fewer preregistered seeds, report n |
| 23–25 | integration freeze, complete real run twice | all | delete optional 3D camera/animations |
| 25–29 | results, limitations, slides, replay and rehearsal | ME presentation lead | no new code |
| before actual organizer deadline | export deck + repo + short demo video + manifests | all | submit early and confirm receipt |

**30-hour table is inherited planning context, not a claim of actual time remaining.** Confirm current event clock/deadline with organizers; do not rely on an old hardcoded submission timestamp.

### 12.2 Optional P1 after P0

1. 21 genuine specialist handlers; activated subset policy with cost/ablation.
2. PED and CDC production-grade adjudication and signing.
3. Kaizen controlled process intervention loop.
4. Smart matching and real inspection-cost model.
5. Authenticated durable peer networking across physical devices.
6. 100-specimen larger sample completed and audited, if not physically possible within hackathon time.
7. Independent industrial metrology and prospective factory shadow-mode pilot.
8. 10,000-paper candidate metadata retrieval with DOI deduplication, screening and real evidence synthesis (NOT 10,000 automatic paper conclusions).

### 12.3 Five-minute judge demo (adapt to official slot)

- **0:00–0:30:** problem: locally accepted Slot/Tab may not assemble; factory evidence lives at different owners.
- **0:30–1:10:** show three **independently running** station processes and one website without central decision agent.
- **1:10–2:05:** open pair case; peer evidence flows; one specialist challenges / requests inspection; risk comes from numeric service, not LLM prose.
- **2:05–2:55:** caliper specimen and real fit test; `PHYSICAL` badge; show source-linked decision, no fake probability result.
- **2:55–3:40:** kill a real peer process; other nodes keep local measurements; show partial evidence and safe abstention; reconcile on recovery.
- **3:40–4:35:** research baseline chart: isolated vs decentralized vs hybrid/centralized, matched assumptions, uncertainty and any negative results.
- **4:35–5:00:** scientific question, honest limitation, manufacturing impact, repo/manifests. HyorinmaruK leads the pitch.

---

## 13. Testing and release acceptance

### 13.1 P0 mandatory tests (binary pass/fail)

1. **Contract:** every sent event validated against its declared schema; v1 original contract unchanged; v2 explicitly names new events.
2. **Pending:** incident reports `PENDING_EVIDENCE` before receiving both required authorized fresh summaries.
3. **Isolation:** Slot cannot query Tab raw records; unauthorized HTTP returns 403 and audit event.
4. **Independent runtimes:** stopping the dashboard/Chief does not stop peer incident path.
5. **Peer-down:** stopping Tab process does not stop Slot local measurement or alarm.
5a. **Sorter-down (v12):** stopping the Sorter process does not stop Slot/Tab measurements; no unknown incoming material is routed to PASS, and a restart does not duplicate a physical actuation.
6. **Freshness:** stale or changed evidence cannot produce an unchanged "ready" decision.
7. **Idempotence:** duplicate replay events result in exactly one *logical application* and an auditable dedup count.
8. **Origin:** physical measurement requires instrument and operator; simulated requires seed and generator version; mixed derived claims labeled separately.
9. **Determinism:** identical frozen evidence + config + seed yields identical deterministic numeric output.
10. **Safe action:** LLM cannot release manufacturing lot, change process parameters or use unknown specimen IDs.
11. **Dissent:** actual sourced contradictory measurement can trigger `HOLD_REVIEW`; unsupported challenge does not forge event IDs.
12. **Mathematics:** physical clearance arithmetic and conditional Monte Carlo accepted-domain tests; original 5.0 scenario preserved.
13. **Science:** seed-by-seed baseline run; comparator assumptions, budgets and origins declared; no pooling physical and simulated denominator.
14. **Physical:** gauge repeatability ten raw readings; specimen labels; at least one good/risk physical fit attempt logged honestly.
15. **Website:** primary mode clearly `Fully Decentralized`; comparison modes are separate; no false central-Chief dependency.
16. **Security:** all peer IDs/auth scopes tested; mock credentials not exposed to public or plant networks.
17. **Audit:** report source evidence IDs, algorithm version, snapshot hash, run seed, operator authorization and outcome.
18. **Paper claim:** no novel-theorem/validated-factory claim without specific replicable evidence.
19. **V12 physical routing:** independently verify part ID, source disposition, guarded bench enable, actual bin arrival, hold/uncertain path and no unsafe replay; see Section 16.8.

### 13.2 Research quality rubric (internal, not judge score)

| Dimension | Points |
|---|---:|
| Decentralization implemented and failure-tested | 25 |
| Matched, falsifiable scientific experiments | 20 |
| Evidence integrity, safety and abstention | 20 |
| Physical loop measured and provenance-correct | 15 |
| Reproducibility and raw results | 10 |
| Audience clarity and credible presentation | 10 |
| **Total possible** | **100** |

**Do not auto-award 100/100.** Score only after tests and external review; a lengthy document does not by itself improve empirical performance.

---

## 14. Research integrity and citations discipline

**Source-derived inherited materials:** QualityRelay 5.0 original blueprint/ZIP, QualityRelay 8.0 Evidence-Mesh draft, 9.0 toy research program, 10.0 runnable reference source + test report. These are project materials and may contain unverified literature leads; their title/claims do not independently prove peer-reviewed novelty.

**Results categories:**

- `CODE_TESTED_LOCAL`: exact source commit, environment and observed test stdout.
- `SIMULATED_COMPLETE`: generated outputs, seeds, versions, pairing rules, confidence/uncertainty.
- `PHYSICAL_DESCRIPTIVE`: actual specimen IDs, raw caliper readings, witnessed fit, n, instrument information.
- `PILOT_FACTORY`: only with site agreement and prospective process data.
- `PROPOSED_NOT_RUN`: hypothesis, requirements and draft experiment.

**Previously reported evidence (source 9.0/10.0, not new in this document):** 3,000-trial toy V-DER/IG comparison near tie; 15 local tests in inherited 10.0 demo; 20-role registry / eight narrow handlers. Fresh V11 tests must be run and logged separately.

**10,000 papers:** the 9.0 archive describes a candidate metadata collector and research-screening workflow; it is **not evidence that 10,000 studies were retrieved, read, or analyzed**. Record DOI, publication type, full-text access, population/industrial relevance, study design, actual outcome and quality screen for every study used in a scientific claim. Distinguish preprints from peer-reviewed research.

**Prior-work research topics to cite carefully:** manufacturing digital thread interoperability; multistage fault diagnosis and sequential inspection; feedforward/feedback quality gates; Bayesian experimental design/VOI; SPC/EWMA; selective assembly and tolerance allocation; multi-agent collaboration with hidden/distributed evidence; industrial safety, authorization and event provenance; Toyota/PDCA improvement. Claims must use verified primary references, not merely a theme or unverified URL.

### 14.1 Claim ladder for final presentation

| Bad statement | Evidence-supported alternative |
|---|---|
| "20 LLM agents fully control a real factory" | "21 bounded specialist roles are designed; selected tools are implemented; humans approve actions" |
| "We discovered a new theorem" | "We propose and evaluate evidence-governed peer coordination in a manufacturing testbed" |
| "V-DER always beats IG" | "Prior toy results showed near parity; we test conditions under which policy choices differ" |
| "Our camera measures to 0.01 mm" | "We record caliper measurements and optionally capture photos" |
| "Our decentralization can never fail" | "We demonstrate tested local continuity and conservative evidence status under a specific node outage" |
| "100 specimens prove factory readiness" | "100 printed specimens are a controlled physical demonstration, not industrial validation" |
| "We reviewed 10,000 papers" | "We designed a 10,000-record metadata collection and study-screening program" |

---

## 15. Production decision that closes the architecture debate

**We are not promising a system that requires a central agent because decentralization fails.** Our *product* is independent, owner-authorized specialist peers. Every joint action is evidence-scoped, uncertainty-aware, reproducible and subject to human review. Hybrid and centralized variants are scientifically useful **comparators**, not mandatory rescue modes.

**Best project research question (final):**

> Under matched statistical tools, inspection budgets and explicit information-access rules, can a fully decentralized network of specialized manufacturing agents reach reliable, evidence-grounded quality decisions while minimizing inspection effort and raw-data exposure, and maintaining safe local operation during communication failures?

**Proof, not the number of agents, is the deliverable.** An honest negative result, a real physically verified loop and a credible failure test are scientifically stronger than an unsupported superiority claim.

---

## 16. V12 implemented-design extension: quality-aware decentralized physical sorting

**Precedence:** Section 16 and ADR-012 govern all **new** sorting behavior. Sections 0–15 describe the inherited v11 proposal and must be read with the v12 additions. Appendix A remains an unmodified historical v5 record. This section is a **design and test plan**, not evidence that hardware/services exist.

### 16.1 Why sorting improves the scientific problem

QualityRelay v11 answered: “Which evidence should independent peers share to estimate a slot-tab compatibility risk?” V12 also asks: **“When each peer has limited local information, can authenticated local disposition and a separate physical sorter prevent suspect material from reaching assembly without needlessly scrapping reusable components?”**

The **root-cause station** (e.g., drifting printer) is not necessarily the **capacity bottleneck** (e.g., inspection/rework). Early peer notification and physical quarantine can reduce contaminated work-in-process (WIP) and downstream reinspection, but may also create sorter congestion and false quarantines. All are **testable hypotheses**, not promised improvements. The sorter does not repair tool wear or claim new defect detection mathematics.

### 16.2 Target topology and authority (four independently deployed station actors)

```text
SLOT PEER (own measurements, conformance, local SPC)
    |  approved scoped conformance/disposition certificate  \
    |                                                       \
    +------ authenticated owner-to-owner event exchange ------> SORTER PEER
    |                                                         local durable DB
TAB PEER (own measurements, conformance, local SPC)       ->  local policy validation
    |  approved scoped conformance/disposition certificate  /   servo/fixture (bench only)
    |                                                       ->  PASS / HOLD / REJECT bins
    +-------------------------> ASSEMBLY PEER                 |
                                 pair-specific risk/HOLD <---+
                                 selective pairing suggestion

SPECIALISTS: scoped tools/services called by any authorized station peer.
READ-ONLY DASHBOARD: displays evidence and physical routing; no control authority.
OPTIONAL COMPARATORS: separate centralized/hybrid research modes, never default.
```

**Sorter authority:** accepts individual authorized route certificates and commands *its own* demonstrator hardware. It never orders Slot/Tab to rewrite measurements or approves assembly release on their behalf. Slot/Tab may each trigger independent local holds; Assembly may block a proposed **pair**. No Chief, centralized router-as-brain, shared global process memory, or global posterior is required for the primary peer mesh. Any central display or transport may fail without transferring decision ownership.

**Four-process proof:** run `slot`, `tab`, `assembly`, `sorter` as separately addressable OS processes/containers, with individually owned persistent SQLite files and independent API credentials; a dead Sorter process must not stop Slot/Tab measurement or Assembly's safe abstention. A software class named `SorterAgent` inside the inherited single FastAPI app **does not prove** decentralization.

### 16.3 Individual-conformance vs pairwise-compatibility logic

For each physical specimen `part_id`, evaluate its **own drawing specification** at the *source* peer. For example:

| Example | Source inspection | Pairing result | Routing recommendation |
|---|---|---|---|
| `S010 W=21.00`, verified | locally conforming | no assigned partner yet | PASS to **eligible** stock; not blanket assembly release |
| `S011 W=20.60`, `T011 T=20.40`, both verified | **both** locally conforming | `C=0.20` below `c_min=0.50` | HOLD the **pair** or seek alternate partner; neither part automatically scrap |
| `S012 W=20.40` | raw reading below `W_min=20.50` | not evaluated | HOLD for measurement uncertainty/repeat; REJECT only after confirmed nonconformance |
| measurement missing/stale, wrong ID, unknown CAD revision | evidence insufficient | unknown | HOLD/stop feed |

Measurements above are **illustrative invented examples**, not experimental observations. A source should classify PASS only if its declared guardband/measurement-uncertainty policy supports conformance; if the measured interval overlaps a tolerance boundary, put the part on HOLD. For a simplified validated guardband with expanded uncertainty `U`, a measurement `x` is safely inside `[LSL,USL]` only when `x-U >= LSL` and `x+U <= USL`; rejection requires an independently declared confirmation rule. If `U` is unknown, do not claim calibrated risk.

**Do not conflate** a process-level SPC alarm with a per-part reject verdict. SPC alarms start investigation/containment of an affected time-window/lot; only specimen-level evidence supports specimen-level disposition. A visible flaw from an ordinary camera is inspection evidence but cannot replace calibrated sub-mm dimensional measurements.

### 16.4 State machine, controls and event contract

```text
REGISTERED -> MEASURED -> CLASSIFIED_LOCALLY
                               | PASS_CANDIDATE ------> ROUTE_READY
                               | UNCERTAIN -----------> HOLD_READY
                               | CONFIRMED_NONCONFORM -> REJECT_READY
ROUTE_READY/HOLD_READY/REJECT_READY
    -> OPERATOR_ENABLED -> ROUTE_REQUESTED
    -> ACTUATING -> BIN_SENSOR_CONFIRMED -> ROUTED_VERIFIED
                 \-> SENSOR_TIMEOUT / DISAGREEMENT -> JAM_HOLD_MANUAL_REVIEW
```

At the Sorter, validation must require: known immutable `part_id` and type; source ID; origin (`SIMULATED` vs `PHYSICAL`); current drawing/spec rev; local measurement/inspection event IDs; evidence snapshot hash; disposition revision; authenticated issuing peer; certificate expiry; operator enable; unique actuation key; correct inlet/exit occupancy. `PASS` must be blocked by an outstanding source HOLD or pair-specific downstream HOLD relevant to the attempted operation. The safe fallback is a **stopped feed or tested HOLD diversion**; do not assume a failed servo will mechanically settle into the intended bin.

**Proposed v2 event types (new version; preserve v1 schema bytes):**

- `PartRegistered`, `MeasurementVerified`, `ProcessShiftAlert`
- `PartDispositionProposed`, `DispositionConfirmed`, `DispositionRevoked`
- `SortRequested`, `SortAccepted`, `SortDenied`
- `SortActuationStarted`, `SortActuationConfirmed`, `SortUncertain`
- `PairCompatibilityHold`, `ReinspectionRequested`, `OperatorInterventionRecorded`

An illustrative data envelope (not a completed event or certified signature):

```json
{
  "schema_version": "2.1.0-draft",
  "event_type": "DispositionConfirmed",
  "event_id": "EXAMPLE-UUID",
  "source_peer_id": "slot-peer-01",
  "target_peer_id": "sorter-peer-01",
  "part_id": "S012",
  "part_type": "slot",
  "cad_spec_revision": "EXAMPLE-REV-A",
  "disposition_revision": 2,
  "destination": "HOLD",
  "reason_code": "MEASUREMENT_CONFIRMATION_PENDING",
  "source_event_ids": ["EXAMPLE-MEASUREMENT-ID"],
  "evidence_snapshot_hash": "sha256:EXAMPLE-NOT-A-REAL-HASH",
  "origin": {"kind": "PHYSICAL", "verified": false},
  "expires_at": "2026-10-31T00:00:00Z",
  "authenticated_channel": "REQUIRED_AT_RUNTIME"
}
```

The `origin.verified=false` field is deliberate: a typed message by itself proves neither a physical measurement nor authentication. A production implementation must validate certificate signatures or authenticated channels and independent trusted identity. **Transport hashes are not authentication.**

**One part, one physical route:** messages may arrive *at least once*; only one route effect is allowed for a given `part_id + disposition_revision + physical presentation_id`. Persist a pre-actuation intent and a post-actuation bin sensor confirmation. On crash/restart between these steps, **do not blindly actuate again**; set `SORT_UNCERTAIN` until a physical sensor or operator establishes where the part is. Idempotent database insert alone does not make a physical actuator exactly-once.

**Changed diagnosis after routing:** emit `DispositionRevoked` and initiate a physical recall/reinspection workflow. Do not retroactively change a verified bin event or claim a part was moved when it was not.

### 16.5 Minimal bench-top demonstrator, no industrial machine connection

**Mechanical layout:** one shallow inlet guide for ID-tagged slot or tab, one manually or slowly fed singulator, a servo-actuated diverter/flap, three clearly labeled **PASS / HOLD / REJECT** removable trays, one inlet presence sensor and preferably a bin arrival sensor; a stable base and guarded pinch points. Each part should be loaded **one at a time** and its ID confirmed by scan or operator entry. An optional camera provides only visual/ID evidence.

**Suggested resources (check dimensions with actual printed specimens first):**

| Item | Purpose | Scope |
|---|---|---|
| 3D-printed chute, gate/flap, bracket, three trays | physical sorting | model clearance/sliding and print with available white filament; use contrasting labels |
| Bench microcontroller + suitably powered small servo | bounded diverter motion | separate servo supply with common reference ground as appropriate; no factory PLC attachment |
| Inlet photoelectric/IR switch and optional bin sensor(s) | presence and route confirmation | sensor timeout causes stop/hold, never assumed delivery |
| USB/low-voltage power, physical stop/enable, guards | controlled demonstration | prove no unattended motion; supervise all motion |
| QR/printed IDs, caliper and repeatability coupon | specimen identity and measured evidence | reuse 50 slot + 50 tab IDs; do not double-count specimens |
| Four peer services plus a local serial/USB bridge on Sorter peer | software | `sorter` controls bridge, other peers send authorized disposition events |

Mechanical design output: CAD assembly, STL for guide/diverter/trays, bolt/pin locations, clearances verified against **largest and smallest actual parts**, documented power/wiring layout, and an inspection checklist. **Do not invent dimensions** until the specimen geometry is measured; allow a transparent manual bin-movement fallback if the prototype cannot be actuated safely in time. The mock sorter is a live/bench research aid, **not an OSHA-compliant industrial conveyor or robot safety claim**. Moving parts require guarding and assessed emergency stops before any deployment (see OSHA's machine guarding guidance).

### 16.6 Two demo paths, both scientifically honest

**Path A: fast hackathon P0 (recommended).** Scan `S012` → enter/confirm a caliper result at Slot peer → Slot emits disposition → Sorter independently validates it → operator enables low-speed bench diversion → bin sensor verifies physical destination → dashboard shows two independently owned event IDs. Deliberately disconnect Slot; another unknown item may be held, never automatically passed. Restore link and replay; no duplicated physical sorting. This provides **one reproducible, safe end-to-end loop**.

**Path B: expanded P1.** Run 100 documented specimens through the three-way sorter, simulate misclassification, unknown IDs, queue saturation, correlated lot defects and failed exit detection. Measure true/specimen labels independently and audit each route. Use one physically confirmed defect and one *locally conforming but pairwise incompatible* example. Never pre-label an unmeasured printed part as physically defective just because its CAD file name says “risk.”

**Judge-facing sequence (~60–90 seconds inside the larger demo):** show four separate process/DB identities → scan part → local measurement → signed event across peer boundary → physical diversion to HOLD/REJECT → replay/peer outage test → show matched ablation result with caveats. Avoid a dramatic animation that is disconnected from actual events.

### 16.7 Scientifically fair sorting experiments and measurable outcomes

New **RQ7:** Under fixed inspection accuracy, specimen distribution, actuation capability and compute/message budget, does **peer-to-peer, source-authorized part disposition** reduce defective escape and downstream wasted work relative to isolated station decisions? What availability/privacy/latency tradeoff arises versus a centralized controller with equivalent allowed inputs?

**Four matched conditions:**

| Arm | Strategy | Why it matters |
|---|---|---|
| S0 | No physical routing (baseline), standard inspection/rework | quantify existing propagation |
| S1 | Local QC + simple deterministic sorter with **no cross-peer compatibility evidence** | isolate the value of adding hardware |
| S2 | Fully decentralized peers + exactly the same sorter/thresholds + scoped pair evidence | isolate collaborative information gain |
| S3 | Central coordinator + **same available evidence, sorter, limits, actions and budget** | isolate topology, not extra information |

Run identical seeded synthetic sequences and fixed physical specimens where feasible. Compare **good-part throughput**, escape rate, false rejection rate, HOLD occupancy/WIP, correct-route fraction, detection-to-divert time, inspection/actuation cost, line blocking, message bytes and continuity during one genuine process outage. Report numerators and denominators, paired seed differences and confidence intervals. Do not count the same premeasured physical specimen as a new independent trial. If physical sort runs are few, label as **demonstration**, not statistical proof.

**Critical ablations:** (1) sorter present/absent, (2) cross-peer compatibility enabled/disabled, (3) authentic vs stale or revoked certificate, (4) Sorter process disabled, (5) same architecture with process shift `slot -0.100 mm`, `tab +0.100 mm`, (6) duplicate/reordered `SortRequested` messages, (7) empty/full bin. Expected safety invariants are testable; **no throughput or accuracy benefit is assumed in advance**.

### 16.8 Minimum API, file layout and acceptance tests

**Add only to new v2.x contracts / v12 repository; never rewrite legacy v1 files:**

```text
services/sorter/{app.py,db.py,policy.py,hardware_adapter.py,outbox.py}
contracts/v2/{part_disposition,sort_request,sort_result}.schema.json
hardware/sorter/{cad,stl,wiring.md,calibration.md,safety_checklist.md}
physical/sort_events.csv
research/{sort_baselines.py,sort_fault_injection.py}
tests/{test_sort_disposition.py,test_sorter_peer_isolation.py,test_sort_replay.py}
web/sorting
```

```text
POST /v2/parts/{part_id}/dispositions       # SOURCE station only
POST /v2/sort/requests                       # SORTER validates certificate
GET  /v2/sort/parts/{part_id}                # authorized local route state
POST /v2/sort/confirm                        # physical sensor/operator confirmation
POST /v2/sort/operator-enable                # local bench safety gate only
GET  /v2/sort/health                         # own service health; no central authority
```

**P0 binary tests:**

1. Four independently running processes/DBs; dashboard/Chief down cannot prevent source measurement or legitimate local hold.
2. Wrong issuer, stale certificate, wrong part ID, wrong spec revision → PASS denied; event audited.
3. A valid local PASS cannot override a current Assembly pair HOLD.
4. A locally conforming but pair-incompatible part enters HOLD/re-match, **not scrap**.
5. Confirmed out-of-spec specimen routes to REJECT only under declared confirmation/authorization rules.
6. Missing calibration/uncertain guardband → HOLD, with concrete explanation.
7. Duplicate/reordered messages do not cause a second physical actuation.
8. Process crashes between intent and sensor confirmation → `SORT_UNCERTAIN` / manual check, not blind retry.
9. Sorter offline leaves Slot/Tab measurement intact; reconnection replays messages once logically.
10. Failed inlet/exit sensor or full destination bin stops feed or safely routes to HOLD under a **physically demonstrated** mechanism.
11. Synthetic vs physical labels remain separate; no invented measured benefit, all specimen IDs real/registered.
12. Matched S0–S3 runs archive seeds, manifest, raw outputs and negative findings.

### 16.9 Ownership and priority in a three-person hackathon team

| Owner | P0 task | Evidence handed off |
|---|---|---|
| HyorinmaruK — mechanical/manufacturing | design small gravity chute + diverter, use white filament, test movement and sensor, label three bins, collect caliper evidence, take lead on five-minute presentation | CAD/STL, parts IDs, video, calibration, measured route times |
| adilnurgg — distributed backend | fourth independent Sorter peer, validated disposition events, deduped physical command state, hardware serial adapter, peer outage tests | source code, separate process logs, real event trace, negative security tests |
| Bakdaulet-omeraiuly — data science | deterministic local classification/guardband, process drift simulation, S0–S3 ablations, metrics with uncertainty | simulator, seed manifest, raw results, honest comparison chart |

**Cut order if time is short:** P0 core v11 peer risk loop first; then three labeled trays with **operator-assisted deterministic routing**; then one actual safe servo move + confirmed sensor; then research comparisons. Do not sacrifice independent-process proof or validation to create a complicated conveyor. A manual sorter can validate the event/disposition contract, but must be clearly labeled *operator-assisted* rather than autonomous physical actuation.

### 16.10 Official ScienceClaw rubric and evidence-aware assessment (not an official judge score)

The event publishes weights: **Problem Significance & Complexity 20%; Scientific/Technical Impact 25%; Decentralized Agency 20%; Collective Capability 25%; Execution & Validation 10%**. It also offers a **separate +10-point collaboration bonus** for demonstrated capabilities reused by another team. Manufacturing & Materials is an eligible challenge area; the event has **one overall competition**, not a separate track prize (official source: https://scienceclawhack.ai/; checked 2026-10-30).

The following **subjective pre-demo estimates** are intentionally weighted by **evidence currently present in the uploaded archive**, not by how ambitious the written plan sounds. Scores /10 in each criterion, then multiplied by its fraction; they are **not predictions of actual judges**.

| Official criterion | Weight | V11 supplied package, evidence today | V12 with **design-only** sorter | If four peers + sorter + matched results are validated |
|---|---:|---:|---:|---:|
| Significance & complexity | 20% | 8.5 | 8.8 | 8.8 |
| Scientific/technical impact **achieved** | 25% | 5.0 | 5.3 | 8.0 |
| Decentralized agency **demonstrated** | 20% | 3.5 | 3.5 | 8.5 |
| Collective capability **demonstrated** | 25% | 3.5 | 3.7 | 8.0 |
| Execution & validation | 10% | 3.5 | 3.5 | 8.0 |
| **Weighted score out of 10** | **100%** | **4.9** | **5.1** | **8.3 (conditional target)** |

Why conservative? Uploaded v11 contains a **blueprint plus nested v10 local one-process FastAPI demo**, not running independent peer nodes, a v12 sorter, new physical measurements or matched empirical S0–S3 results. Its archived report lists **15 earlier tests**, not a v11/v12 peer validation run. Concept/presentation quality alone is stronger (subjective **8/10 blueprint**), but ScienceClaw explicitly rewards a *functioning system and scientifically meaningful validated result*. New sections do **not** by themselves raise demonstrated-impact scores meaningfully. The conditional 8.3/10 requires actual build/run evidence and may be higher or lower based on results. Collaboration bonus is **0/unearned** until another team really reuses the tool and provides a traceable acknowledgment.

**Highest-return work before judging:** four independently killed/restarted processes, one real part diverted with ID and confirmation, one network-failure safe-hold demonstration, and at least one matched seeded baseline chart. Prove the source of each observation. If sorter mechanics delay this, keep the physical sorter as a stretch feature and retain the original v11 incident loop.

### 16.11 Sources, boundary notes and intellectual honesty

Primary technical references for this extension (use the actual publications when creating final slides):

- ScienceClaw official purpose, challenge areas and weighted rubric: https://scienceclawhack.ai/
- NIST statistical process/product monitoring and SPC: https://www.nist.gov/publications/nistsematech-engineering-statistics-handbook-chapter-6-process-or-product-monitoring
- NIST measurement-process characterization, gauge stability and uncertainty: https://www.nist.gov/publications/nistsematech-engineering-statistics-handbook-chapter-2-measurement-process
- NIST manufacturing digital thread and product/manufacturing information: https://www.nist.gov/programs-projects/digital-thread-manufacturing
- OPC Foundation machine-tool monitoring/job management interoperability specification: https://reference.opcfoundation.org/specs/OPC-40501-1
- OSHA machine guarding introduction (industrial deployment design consideration; a low-energy mock is not certified): https://www.osha.gov/etools/machine-guarding/introduction/general-requirements

**Verdict:** The addition is worthwhile because it adds a falsifiable **physical action** and a new distributed-evidence problem. It is **not yet implemented**, and its value depends on completing a minimal credible demonstration and clean baseline experiments. Keep original archived reference implementations unchanged.

---

## APPENDIX A — Original QualityRelay 5.0 master blueprint (verbatim preservation)

The section that follows is copied verbatim from the supplied `01_MASTER_BLUEPRINT.markdown` for reference. **It remains the historical 5.0 specification.** If its references to a shared event router or older milestones differ from the new peer architecture, ADR-011 above controls the new 11.0 design; the original is preserved, not retroactively edited.


# QualityRelay 5.0 master blueprint

## 1. Executive definition

QualityRelay is a decentralized quality-coordination system for assemblies whose fit depends on measurements owned by different manufacturing stations. A slot can pass its local specification and a tab can pass its local specification while their pairing still has insufficient clearance. Each station continues to own its raw data and local decisions. Agents exchange scoped, provenance-linked evidence only when an assembly-risk query or anomaly makes collaboration useful.

The hackathon demonstration answers one narrow scientific question:

> With the same statistical core and inspection budget, what capability is gained or retained when quality evidence is coordinated across independently authorized station agents, especially when communication is intermittent?

It does **not** attempt to prove that multi-agent systems are universally better than centralized quality systems.

## 2. The manufacturing problem

Three logical stations are modeled:

1. **Slot station** produces a slot and measures slot width `W`.
2. **Tab station** produces a tab and measures tab thickness `T`.
3. **Assembly station** selects lots, observes fit outcomes, and evaluates clearance `C = W - T` against a functional minimum `c_min`.

Local part specifications are deliberately not equivalent to the assembly requirement. In the demonstration reference design:

- Slot specification: 20.5–21.5 mm.
- Tab specification: 19.5–20.5 mm.
- Functional minimum clearance: 0.5 mm.
- Nominal means: slot 21.0 mm, tab 20.0 mm.

Worst-case individually accepted parts can produce `20.5 - 20.5 = 0.0 mm`, below the functional requirement. The exact risk depends on the process distributions and the acceptance conditioning. These values are configuration assumptions for a teaching demonstration, not measured factory parameters.

## 3. User story

Before assembly, an operator selects slot lot A-07 and tab lot B-12. The assembly agent cannot calculate a current risk until it obtains sufficient, authorized summaries from both stations. It sends evidence requests. Each station returns a signed summary referencing local measurement event IDs, not its entire raw table. The assembly agent calls the deterministic compatibility engine, receives a provenance-linked risk estimate, and either:

- permits the planned pairing with its uncertainty and evidence coverage;
- recommends a server-provided alternative lot with lower estimated risk; or
- asks for the physical measurement with highest expected information gain per second.

If the slot link is taken offline, the slot station continues local measurements and queues outbound events. Peers stop receiving new slot evidence; the UI marks the current diagnosis as partial and omits the stale station likelihood from the live posterior. The audit history remains intact. On reconnection, event IDs make replay idempotent.

## 4. Why decentralized agents are justified

The system models real organizational and technical boundaries:

- Different equipment or suppliers own different raw records.
- A station has authority to measure and summarize its own process, not to read another station’s database.
- Assembly owns the relational decision: whether two lots should be paired.
- Communication can be intermittent while local production and monitoring continue.
- An append-only router moves messages but cannot fabricate a measurement, compute a diagnosis, or override a station.

If every actor reads one shared database and one global posterior, the project fails its own decentralization claim.

## 5. P0 end-to-end behavior

1. Record or seed at least five recent measurements per relevant lot and station.
2. Create a `BatchRiskQuery` for an upcoming slot–tab lot pairing.
3. Show `pending_insufficient_evidence` until authorized evidence responses arrive.
4. Calculate clearance risk with the shared deterministic engine.
5. Link every estimate to the exact evidence event IDs, code version, assumptions, and origin labels.
6. Rank server-provided physical inspection candidates by expected information gain divided by time cost.
7. Accept a real caliper entry and update the diagnosis.
8. Toggle one station link offline and show partial-evidence behavior.
9. Reconnect and reconcile queued events exactly once.
10. Export a replayable run manifest and result record.

## 6. Architecture at a glance

```text
Slot UI/tool -> Slot service + local DB ----\
                                         signed evidence events
Tab UI/tool  -> Tab service + local DB ----- event router/log ---> Assembly service + local DB -> Dashboard
                                             |                         |
                                             |                         +-> risk/diagnosis/inspection core
                                             +-> no diagnostic authority

Optional LLM adapters sit above each station's approved tools.
All numeric truth is rendered from deterministic service responses.
```

The statistical core is one versioned library reused in isolated, centralized, and decentralized conditions. This prevents a strawman baseline. Deployment and evidence access change; the mathematics does not.

## 7. Scientific core

### 7.1 Clearance risk

For independent normal slot and tab distributions before acceptance truncation:

`mu_C = mu_W - mu_T`

`sigma_C^2 = sigma_W^2 + sigma_T^2 - 2*rho*sigma_W*sigma_T`

`P(C < c_min) = Phi((c_min - mu_C) / sigma_C)`

The benchmark must condition on both parts passing their local specifications. Use deterministic Monte Carlo from truncated distributions or numerical integration. The random seed is derived from the run ID, lot pair, evidence snapshot hash, and algorithm version so identical inputs return identical outputs.

### 7.2 Local process monitoring

Each station maintains an EWMA:

`z_t = lambda*x_t + (1-lambda)*z_(t-1)`

Control limits use the standard time-varying EWMA form. `lambda = 0.2` and `L = 3` are starting configuration values, not optimized claims. Baseline process mean and sigma come from the calibration dataset; they are not estimated from only five live points.

### 7.3 Evidence-scoped diagnosis

The minimum hypothesis set is:

- `H0`: stable process; assembly failures occur at the nonzero design baseline.
- `H1`: slot mean shifted downward.
- `H2`: tab mean shifted upward.
- `H4`: both means shifted toward reduced clearance.

Optional `H3` fixture/misalignment is P3 because a credible physical mechanism and likelihood model are not available in the core sprint.

Posterior updates are performed only over evidence the calling actor has locally observed or received through authorized responses. When a station is unavailable or evidence is outside the freshness window, its likelihood term is omitted and the posterior is renormalized. The UI must show evidence coverage, such as “computed from 2 of 3 stations.”

### 7.4 Targeted inspection

For candidate action `a` and possible outcomes `y`:

`IG(a) = H[p(H|E)] - sum_y p(y|a,E) * H[p(H|E,y)]`

`score(a) = IG(a) / expected_seconds(a)`

Candidate specimen IDs come from the server. An LLM may choose among them or request no action, but cannot invent an ID. The method is an application of established Bayesian experimental design, not a new information-theory algorithm.

## 8. Requested combined demonstration scenario

`configs/scenario_combined_0p100mm.yaml` specifies:

- scenario: `combined`;
- slot mean shift: `-0.100 mm`;
- tab mean shift: `+0.100 mm`;
- slot communication: `online` at the start;
- data source: `simulated`;
- pairing policy: uniform random pairing among locally accepted parts;
- outcome status: `NOT_RUN`.

Expected qualitative observations, not claimed results:

- both local EWMAs should move toward reduced clearance, though the exact alarm timing is unknown until run;
- the joint clearance-risk estimate should tend upward relative to the frozen nominal baseline;
- evidence requests and responses should complete while the slot link is online;
- the combined hypothesis should gain support if the generated evidence matches the configured shifts;
- a targeted inspection may be proposed if expected information gain exceeds the configured threshold;
- all dashboard values must be labeled simulated and tied to the seed.

Do not promise that the collaborative system beats the isolated condition at this shift magnitude. Pilot candidate shifts first because 0.100 mm may be locally detectable depending on sigma, EWMA parameters, and run length.

## 9. Validation design

### Experiment A: collective capability under full connectivity

Compare:

- isolated station actors with peer requests disabled;
- centralized system with all raw evidence;
- QualityRelay peer evidence exchange.

Use the same core, scenario streams, inspection budget, and seeds. Primary interpretation: QualityRelay may recover much of centralized performance with less raw-data access and a traceable communication budget. Do not claim it should beat the centralized upper bound.

### Experiment B: resilience to information topology

A 2×2 design:

| Topology | Always on | Intermittent link |
|---|---|---|
| Centralized hub | upper-bound reference | hub/link degradation |
| Decentralized peer mesh | normal QualityRelay | local continuity + partial evidence + reconciliation |

The hub’s coordinator-failure test is deliberately asymmetric: a peer mesh has no single coordinator to fail. State this rather than pretending the cells are identical.

### Metrics

- fault-hypothesis accuracy on simulated ground truth;
- detection delay in units after injected change;
- assembly-risk Brier score on simulated runs only;
- number and time cost of physical/simulated inspections;
- raw records exposed across station boundaries;
- message count and bytes;
- evidence coverage at decision time;
- duplicate-event count after reconnect;
- unauthorized access attempts denied;
- physical loop completion reported descriptively, never as a calibrated percentage.

## 10. Physical evidence plan

Use a small U-slot coupon and flat tab coupon printed in white PLA. Print a safe pair, a nominal pair, and a tight-risk pair plus backups. Do not rely on CAD dimensions as ground truth. First measure one stable coupon ten times, compute repeatability standard deviation `s_r`, then choose a demonstrated clearance difference comfortably larger than measurement noise. A 3–5× `s_r` rule is a screening heuristic, not a full gauge R&R study.

Two or three physical pairings close the loop; they do not validate the predicted probability. Simulation supplies repeated, seeded ground truth. Physical and simulated metrics must be shown in separate panels.

Do not attempt a live print-redesign-reprint-refit loop. Show any corrected CAD as a next-step artifact.

## 11. Success criteria

P0 is complete only when all are true:

- one command resets the demo to a known state;
- a risk query remains pending before evidence arrives;
- unauthorized cross-station raw reads return 403 and are logged;
- the same input snapshot produces the same risk output;
- all numeric UI statements are server-rendered from structured results;
- candidate IDs are whitelisted;
- link loss changes evidence coverage visibly without deleting history;
- reconnect produces zero duplicate events;
- a physical caliper entry is stored with `origin.kind = physical`;
- a simulated benchmark record includes seed and generator version;
- no chart combines physical and simulated observations into one unlabeled metric;
- the deterministic fallback performs the complete demo without an LLM.

## 12. Milestones and cut lines

| Milestone | Active-hour deadline | Acceptance condition | Cut if missed |
|---|---:|---|---|
| M0 scope/interface freeze | H1 | schemas, role boundaries, scenario IDs fixed | remove alternative-lot and disagreement branches |
| M1 deterministic core | H6 | clearance, EWMA, diagnosis, inspection tests pass | remove Bayesian extras; keep risk + fixed inspection |
| M2 minimum viable demo | H12 | reset → query → evidence → risk → inspection → update | LLM removed from critical path |
| M3 decentralized proof | H18 | 403 test, scoped posterior, offline queue, idempotent replay | use recorded outage clip; keep live evidence exchange |
| M4 experiment freeze | H23 | pilot selects shift rule; matrix and seeds frozen | reduce to 3 seeds and label exploratory |
| M5 feature freeze | H25 | full run completes twice | no new features |
| M6 submission ready | H29 | slides, repository, manifest, backup clip, 2 rehearsals | polish only |

## 13. ScienceClaw rubric alignment

| Rubric | Evidence to show |
|---|---|
| Problem significance, 20% | relational tolerance-stack failure across data silos; preventable scrap/rework risk |
| Scientific/technical impact, 25% | prospective lot-pair risk, targeted inspection, traceable decision; results shown only after execution |
| Decentralized agency, 20% | station-local data/authority, explicit evidence requests, no decision-making router, offline local continuity |
| Collective capability, 25% | same-core comparison against isolated and centralized conditions; link-fault experiment |
| Execution/validation, 10% | functioning vertical loop, seeded experiments, physical caliper input, negative permission test, replay manifest |
| Optional collaboration bonus | another team actually reuses the event schema, replay dataset, or tool; usage is documented |

## 14. Honest closing claim template

Fill brackets only after measured runs:

> Using the same statistical core and inspection budget, QualityRelay’s independently authorized station agents evaluated an upcoming compatibility risk through selective evidence exchange, requested a targeted inspection, and retained local operation during a communication interruption. In seeded simulation, the collaborative condition [measured result with uncertainty]. In the physical demonstration, [descriptive observed loop outcome]. These results demonstrate a hackathon prototype, not industrial validation.



---

## APPENDIX B — Project artifacts and no-regression map

These concrete source artifacts were provided in the conversation and should be preserved alongside this single MD in the optional companion ZIP:

| Historical artifact | Content | 11.0 action |
|---|---|---|
| `QualityRelay_Hackathon_Package_2026-10-28(1).zip` | Original 5.0 schemas, configs, 3D CAD/STL, physical templates, science and demo runbooks, schedule, sources and manifest | Preserve bytes, import through versioned adapters |
| `QualityRelay_10_FINAL_COMPLETE_PACKAGE.zip` | Reference FastAPI, original science, 20-role registry, 8 narrow tools, original local tests, toy experiment and legacy 5.0/8.0/9.0 resources | Preserve bytes; implement peer split before new claims |
| `QUALITYRELAY_8_0_ULTIMATE_SCIENTIFIC_MASTER_BLUEPRINT.md` | 20 roles, Evidence-Mesh ideas, ablations | Preserve for history; remove Chief from primary topology |
| `QualityRelay_9_RESEARCH/QUALITYRELAY_9_RESEARCH_MASTER.md` | V-DER toy and metadata retrieval research plan | Carry forward with honest non-superiority result |

### Explicit v10 → v11 migration checklist

- [ ] Change default `/` site badge from hybrid/Chief to **Fully Decentralized (Main)**.
- [ ] Remove runtime Chief dependency from default incident workflow; route to P2P Assembly/Slot/Tab.
- [ ] Keep old `GET /api/incidents/{id}/chief` only in **comparison namespace** with strict separation.
- [ ] Ensure `/api/incidents/{id}/peer-review` calls actual station services or label it as in-process emulation.
- [ ] Introduce physically separate processes, databases and durable outbox/inbox.
- [ ] Add v2 assessment/challenge/PDCA schemas; retain and test original v1 event schema untouched.
- [ ] Expose 21 specialists with **explicit readiness/status**, not fake live avatars.
- [ ] Build network graph using actual source → destination event logs.
- [ ] Keep experimental hybrid/centralized modes isolated with clearly stated data access and budgets.
- [ ] Add exact 100-specimen print/measure/assembly manifest (not invented outcome numbers).
- [ ] Complete new P2P auth, station outage, replay, stale evidence and human-review tests.
- [ ] Use confirmed experimental results only in final slides, including negative findings.
- [ ] Preserve original 5.0 files and 10.0 code unchanged in legacy archive; link source revision.

### Release note

This is the **single canonical planning Markdown** reflecting the team's latest discussion. The optional companion ZIP can contain original CAD/STL and historical runnable prototype assets, but none of those older assets are silently upgraded simply by including this new specification.
