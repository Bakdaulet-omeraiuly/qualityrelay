# QUALITYRELAY 10.0 — FINAL INTEGRATED SCIENTIFIC & IMPLEMENTATION MASTER BLUEPRINT

**Subtitle:** Evidence-Governed Manufacturing Intelligence (EGMI): trustworthy, decision-aware coordination of independent manufacturing stations and specialist agents.

**Version:** `10.0.0-research-reference`  
**Cutoff:** October 30, 2026  
**Audience:** ScienceClaw / MIT Media Lab judges, hackathon team, manufacturing researchers, quality and mechanical engineers, prospective industrial pilot partners.  
**Lead team:** `Bakdaulet-omeraiuly` (statistics/research), `adilnurgg` (backend/distributed systems/Chief Engineer), `HyorinmaruK` (mechanical validation/presentation); optional fourth person (frontend/QA/integration).  
**Scope:** one integrated plan **plus executable reference code** included in the release ZIP. The original 5.0 ZIP is preserved unchanged.

> **TRUTH BOX — READ BEFORE USING ANY CLAIM:** We have a plausible **research hypothesis and executable demonstration**, not a verified original scientific discovery. Value of Information, Bayesian experimental design, targeted manufacturing inspection, selective assembly, multi-agent orchestration and audit trails have extensive prior art. Proposed originality lies in a *specific, testable integration* of authorized decision-relevant evidence routing, protected expert dissent, calibrated metrology, distributed failure handling and bounded human approval. Novelty, superiority, industrial readiness and certification **remain unproven**. The 10,000-literature-item program is a **collector target**, not 10,000 downloaded, read or analyzed papers.

---

## 0. Қысқаша қазақша қорытынды / Executive decision

**Не жасаймыз:** QualityRelay — станциялар өз деректерін өзінде сақтайтын, бірақ ортақ жинақтау сапасына байланысты сұрақтарды шешуге мүмкіндік беретін өндірістік веб-платформа. Slot және Tab станциялары өлшемдер туралы шектеулі дәлел береді; Assembly жүйесі сол деректерді салыстырады; маманданған агенттер геометрия, өлшеу сапасы, статистика, материал, процес, ақау, қауіпсіздік және өндірістік шығынды бөлек зерттейді; Chief Engineer оларды ұйымдастырады, бірақ барлық raw деректі өзіне жинай алмайды және адам мақұлдамай шешімді орындамайды.

**Біз неге керекпіз:** Бір бөлшек штангенциркульмен өлшеніп, нормаға сай болуы мүмкін, ал екі қабылданған бөлшек біріккенде жарамсыз болуы мүмкін. Құндылық — *қандай партияларды жұптау*, *қауіп қаншалықты*, *қай бір өлшеу маңызды*, *кімнің қандай дәлелі бар*, *қай шешім ақшаны аз жоғалтады* деген өндірістік шешімдерді деректері бөлек жүйелер арасында дәлелмен үйлестіру. Штангенциркульді алмастырмаймыз.

**Ғылыми басты сұрақ:** шектеулі және кейде қолжетімсіз ақпарат жағдайында, дәлелдерді шешімге әсері бойынша сұрататын, маманның қарсы дәлелін жоғалтпайтын және өндірістік әрекетті адам бекітетін децентрализованная команда **әділ baseline-дарға қарағанда қандай жағдайда** шешім шығынын және қажетсіз дерек алмасуды азайтады?

**Не нақты іске асқан:** осы пакетте FastAPI негізіндегі шағын іске қосылатын демонстрация бар: авторизацияланған station summaries, жергілікті measurement store, екі станцияның бірігу қаупін Monte Carlo арқылы бағалау, Chief және Chief-off peer mode, 20 маман реестрі, 8 callable deterministic specialist handlers, 403 raw-read denial, offline local queue, idempotent replay, hash-chain audit, human-review-only decision gate, self-reported caliper readings, бөлек toy V-DER endpoint және HTML интерфейс. **Бұл production жүйе емес.** 20 толық LLM агент іске қосылды деген сөз емес.

**Жаңалық:** алгоритм идеясы бар, ғылыми жаңалық **расталмаған**. Алдыңғы 3000 toy сынақта V-DER (0.698883) vs entropy IG (0.699082) — айырмашылық ≈0.000198 шартты loss; статистикалық дәлел жоқ. Келесі эксперименттер дәл соны тексеру үшін.

---

## 1. What is inherited, what is new, and what is *actually* coded

### 1.1 Never discard these ORIGINAL 5.0 invariants

1. **Three independent station actors:** `slot`, `tab`, `assembly`, local storage and data authority.
2. Slot width `W`; tab thickness `T`; assembly clearance `C=W-T`, requirement `C>=0.5 mm`.
3. Demonstration part specs: slot `[20.5,21.5] mm`, tab `[19.5,20.5] mm`, nominal means `21.0/20.0 mm`; design/demo assumptions, not real plant measurements.
4. Locally conforming parts can jointly fail: illustrative `W=20.6`, `T=20.3`, `C=0.3`.
5. Authorized, provenance-linked summaries; **no cross-station raw table reads**.
6. `pending_insufficient_evidence` before responses; never hallucinate missing station evidence.
7. A versioned deterministic physical/statistical engine; LLM narration is never numeric truth.
8. Accepted-part conditioning in probabilistic pairing model, rather than unqualified Gaussian arithmetic.
9. Local EWMA/SPC, hypothesis set `H0` stable; `H1` slot mean down; `H2` tab mean up; `H4` combined shifts; optional mechanically justified fixture hypothesis only later.
10. Targeted inspection using Information Gain (IG) as honest prior art and scientifically justified baseline.
11. Same mathematical core and inspection budget across isolated, centralized and decentralized arms.
12. Offline local monitoring; partial evidence; rejoin with idempotent event replay; test Chief being unavailable.
13. Real physical 3D coupons, gauge repeatability checks and explicit separation of simulated vs physically measured data.
14. Reproducible seeds/configs/run manifests; precise source IDs and algorithm versions.
15. The original P0 acceptance gates, prior `openapi.yaml`, event JSON schema, example events, STL/SCAD sources, 30-hour schedule, risk register and validation templates stay intact.

Original 5.0 files are archived **byte-for-byte**, not silently rewritten. An extract of its canonical master follows in Appendix A; full original tree is available in `legacy/QualityRelay_5_ORIGINAL.zip`.

### 1.2 QualityRelay lineage, with implementation maturity

| Layer | Scientific/engineering role | In this release | Status |
|---|---|---|---|
| 5.0 | Independent station evidence, conditional assembly risk, SPC, Bayesian diagnosis, physical validation | Preserved entirely as archive; selected risk path prototyped | **Partial coded reference**; SPC/Bayes+physical calibration not yet integrated |
| 6.0 | Specialists mirror real factory professions | 20 role specifications; 8 deterministic callables | **8 narrow reference handlers**, not 20 LLM workers |
| 7.0 | Chief Engineer B orchestrator; human approval | bounded Chief review and approval API | **Local reference**, untrusted role string is NOT production identity |
| 8.0 | EVIDENCE-MESH, Evidence Debt, minority evidence protection, topology tests | evidence coverage, protected challenge, Chief-off test | **Partial**; cryptographic and independent dissent adjudication pending |
| 9.0 | V-DER / CDC / PED / BAL; 10k-paper candidate collection | executable four-hypothesis toy + collector and prior metrics | **Toy**; not integrated with calibrated plant data |
| **10.0** | Interface between station numerical evidence and specialist/Chief workflow | FastAPI + HTML + end-to-end tests, typed API and test matrix | **Runnable uncalibrated demonstration**, not industrial validated |

### 1.3 The competition criterion is actual demonstrated collective capability

ScienceClaw official rubric: significance 20%, scientific/technical impact 25%, decentralized agency 20%, collective capability 25%, execution/validation 10%, potential +10 collaboration bonus. There is **one overall competition**, not a guaranteed separate manufacturing winner. Do not claim that 20 names are 20 scientific contributions. Prove at least one operational capability using working peers and fair comparisons. Official source: https://scienceclawhack.ai/ (checked Oct 30, 2026). Sunday November 1, **13:00 EDT** is final-slide deadline; build and presentation should be ready earlier.

---

## 2. Research evidence → requirements → exact feature → test

| ID | Prior research / what it *actually* supports | Gap / new hypothesis, NOT proven | Engineering feature | Falsifiable test |
|---|---|---|---|---|
| R1 | NIST Hedberg et al., 2021: linked design/manufacture/inspection data is difficult even in a small implementation | decision-relevant summaries may be enough for limited joint tasks | station-local data + scoped evidence + provenance | 403 raw read; reproduce risk from exact accepted summary event IDs |
| R2 | Magnanini et al., CIRP 2024: feedforward/feedback quality gates affect multi-stage performance | measure effect of decision-aware inspections on final scrap/rework | assembly pre-pair gate + action records | simulated and real fit outcomes vs predeclared costs |
| R3 | Sensors 2021 sequential inspection: selecting measurements via Bayesian Information Gain is established | distinguish entropy reduction from action-value reduction under asymmetric loss/privacy | V-DER planner vs strong IG + EVSI baselines | paired matched-budget benchmark; near tie must be reported |
| R4 | HiddenBench, ICML 2026: distributed facts can cause collective reasoning failure | agents should explicitly ask who may hold *missing decisive evidence* | evidence debt map + scoped requests | hidden decisive station evidence, missing sensor and network partition |
| R5 | Pappu et al., ICML 2026: multi-agent teams can average away correct experts | traceable expert challenge may outperform majority voting | Protected Expert Dissent (PED) with verification workflow | inject one correct metrology dissent versus multiple duplicated bad opinions |
| R6 | QA digital-twin assurance review, October 2026, 235 studies: authority/assurance gaps | measurement → recommendation → authorization → measured outcome | Bounded Autonomy Ledger (BAL), human gate | unauthorized commands blocked, approval and measured outcome linked |
| R7 | Selective assembly and tolerance studies already estimate/optimize fit | learn when sparse lots data suffices for pairing decisions | optional smart pairing, decision loss | compare to measured-all benchmark; calibration sensitivity |
| R8 | Manufacturing digital twin standards / NIST | interoperable and traceable interfaces matter | canonical units, versioned schemas and adapters | schema contract, event replay, import provenance |
| R9 | NIST measurement handbook / metrology | repeatability and uncertainty can dominate tiny tolerance effects | gauge metadata, repeated physical measurements | repeated same specimen; independent mechanical validation |
| R10 | Decision-focused active sensing / value of information has substantial prior art | constrained **composition** of VOI + access policy + expert challenge + authority may help specific regimes | protocol-level EVIDENCE-MESH/V-DER | component ablations incl. *strong* decision-aware centralized baseline |

**Primary works and verification status** appear in §17. The existing 9.0 Crossref collector does NOT establish that 10,000 papers were individually read, nor does metadata retrieval establish novelty.

### 2.1 What could be scientifically original, more narrowly

**Candidate contribution EGMI:** a constrained, auditable *distributed decision protocol* where (i) a decision-loss-aware request is legal only with authorization and source provenance, (ii) consequential tool-backed minority evidence receives mandatory independent verification, (iii) missing or stale evidence triggers calibrated abstention, and (iv) the peer group continues local work even without Chief. What is possibly novel is the **combined protocol with measured scientific performance and failure guarantees under declared assumptions**—not the constituent VOI/IG/Bayesian/agent algorithms.

**Explicit novelty-killer search:** investigate existing “risk-sensitive value of sample information”, “decision-focused information acquisition”, “active fault diagnosis”, “privacy-aware POMDP”, “bounded agency / intervention assurance”, “expert dissent verification”, “selective assembly under partial observation”. If existing work has equivalent semantics, acknowledge that and claim only engineering application/benchmark, not a theoretical first.

### 2.2 Scientific questions and disconfirming criteria

- **RQ1: Hidden information.** Does structured evidence debt reduce a *premature commit rate* vs unconstrained multi-agent discussion? Null: no difference or worse.
- **RQ2: Costly inspection.** Does constrained decision value reduce mean downstream decision loss **beyond a strong EVSI baseline**? Null: no difference; prior toy shows near tie with entropy IG.
- **RQ3: Expertise preservation.** Does verified dissent recover a true expert's counterexample without letting a malicious agent block the system? Null: increased disruption or no accuracy gain.
- **RQ4: Decentralization.** With Chief disconnected, how much local work, accurate evidence and correct decisions remain available relative to a fair centralized hub outage? Null: peer system is equally unavailable or substantially less reliable.
- **RQ5: Metrology calibration.** When gauge bias/drift exceeds signal, does policy abstain appropriately? Null: silently overconfident numerical release recommendation.
- **RQ6: Real factory cost.** Under realistic labor, scrap, data and latency costs, does any measurable advantage survive uncertainty? Null: overhead exceeds benefit.

**Pre-registration rule:** freeze scenarios, loss functions, budgets, train/test split, hypotheses and primary endpoints *before* looking at holdout outcomes. Add a dated exploratory analysis log for subsequent ideas.

---

## 3. Scientific model (version 10.0)

### 3.1 Observable physical assembly

`W` = measured slot width in mm; `T` = measured tab thickness in mm; `C = W − T` clearance; `c_min = 0.5 mm` reference functional design. A part passes locally if its own measured value is within its own specified limits. A locally accepted slot and tab can yield `C < c_min`.

**Demonstration-only constants**: slot width `[20.5,21.5]`, tab thickness `[19.5,20.5]`, means `21.0,20.0`; set from initial 5.0, not any factory's actual drawing. CAD dimensions are NOT ground truth, and print expansion/warping is unknown until measured.

**Conditional risk model:**

```text
Given parameters θ = (μW, σW, μT, σT, ρ, measurement-error model, pairing policy),
P_fail(θ) = P[ W-T < c_min | W in slot_spec AND T in tab_spec, θ ].
```

If independent and *before* acceptance truncation, clearance mean is `μW−μT`, variance `σW² + σT² − 2ρσWσT`; that simple normal tail is NOT the final conditional model. Estimate the conditional probability from accepted-part truncated draws, with stable seeds; vary uncertain θ and plausible correlation as robustness checks. If data are too scarce/uncalibrated, report **model scenario**, not calibrated factory probability.

**Important code caveat:** `implementation/qualityrelay10/core.py` currently uses independent fitted normals, a sigma floor, acceptance-conditioned Monte Carlo and 12,000 draws. Its reported 95% interval covers only Monte Carlo sampling error; it **does not** cover uncertainty in μ/σ, model mismatch, gauge error, lot heterogeneity, correlation or CAD tolerance chain. Do not display as a calibrated predictive interval.

### 3.2 Local monitoring and diagnostic hypotheses

```text
EWMA: z_t = λ x_t + (1−λ) z_(t−1)
Reference initial values: λ=0.2, L=3 (NOT calibrated optimal).

H0: stable processes, nonzero base assembly risk
H1: slot mean shifts downward
H2: tab mean shifts upward
H4: both shifts toward smaller clearance
H3: fixture misalignment [FUTURE, only after validated physical likelihood]
```

Each station may locally monitor own process measurements and propose SPC alarms. An alarm alone is not a causal diagnosis. The Bayesian engine must use likelihoods from fresh and authorized evidence only, account for sample sizes, prior sensitivity, source dependence and sensor uncertainty. The 9.0 toy posterior (`decision_value_prototype.py`) assumes made-up likelihoods and known costs; it is a separate learning/test harness, not calibrated to slot/tab records.

### 3.3 Candidate requests and actions

- Safe action set includes `hold`, `inspect`, `request_more_evidence`, `recommend_alternative_lot`; `release` is a downstream, gated human/plant-system decision and **cannot be executed in demo**.
- Query examples: `request_slot_summary`, `request_tab_summary`, `measure_allowed_slot_specimen`, `measure_allowed_tab_specimen`, `request_fixture_check`, `request_gauge_repeatability`, `request_assembly_fit_witness`.
- Query metadata: source station, permitted data class, candidate specimen ID **from server** (never LLM-invented), source freshness, estimated seconds, test cost, disclosure class, measurement reliability, likelihood model version, calibration status.
- Query results must cite actual event IDs. Missing station evidence must never be backfilled by LLM prose.

### 3.4 IG baseline versus Value of Sample Information

Let `H` be fault hypothesis; `E` available authorized evidence; `a` a safe downstream action; `q` candidate inspection; `Yq` unknown response; `L(a,H)` predeclared loss.

```text
IG(q | E)   = Entropy(H | E) − E_Y[ Entropy(H | E,Yq) ]
R(E)        = min_a∈A_safe(E) E[ L(a,H) | E ]
EVSI(q | E) = R(E) − E_Y[ R(E,Yq) ]
NET(q | E)  = EVSI(q | E) − cost_of_measurement(q) − latency_cost(q)
              − privacy_disclosure_cost(q) − communication_cost(q)
```

`q* = argmax NET` among **authorized, feasible, fresh, server-registered** queries, or `no additional inspection` if no candidate has positive marginal expected net value. *The EVSI objective is not a new invention*: decision-centric Value of Information is established in Bayesian decision theory and industrial inspection literature. The **research** is whether the enforceable coordination protocol brings incremental value over strong existing policies under realistic constraints.

Do not combine seconds, privacy scores and dollar costs arbitrarily: define and publish explicit monetary utility or a Pareto frontier (decision loss, privacy exposure, turnaround time) with hard access policies, then freeze the policy before experiment.

**Elementary reproducible consequence, not a novel theorem:** under a correct likelihood model, a finite action set, costless non-destructive optional information and the same feasible action set before/after measuring, `EVSI >= 0` because the decision-maker can always ignore the new evidence. This fails as an operational guarantee when measurement is disruptive, constraints change, model is wrong or data are stale. It also says nothing about whether net EVSI is positive.

**Identifiability boundary:** if two hypotheses imply exactly the same distribution for every currently authorized measurement, no inference algorithm can distinguish them using only those observations. The system must request new discriminating measurements or report `unidentifiable`; an LLM explanation does not repair lack of information.

### 3.5 EVIDENCE-MESH / V-DER protocol: precise steps

1. Chief, or any peer when Chief unavailable, receives an incident reference, decision objective, loss matrix and role-specific authorization.
2. Each independent station keeps full raw records; shares signed/identity-verified **allowed** event summaries with exact measurement IDs, timestamps, units, versions and uncertainty fields.
3. Evidence Debt Ledger (`EDL`) builds a matrix: hypothesis × station × needed evidence × evidence ID × freshness × access rights × reliability. Missing is not zero risk.
4. Specialist registry selects *relevant* agent handlers: normally 3–6 active, not 20 simultaneous identical model calls.
5. Each specialist returns a schema-checked **claim + cited data IDs + tool result hash + assumptions + candidate disconfirming test**. If a field has no evidence, return `unknown`.
6. PED challenge path: if a metrology/design specialist presents a material, testable contradiction, freeze any release recommendation and request an independent check. Unsubstantiated objections have bounded time and are logged.
7. Deterministic engine calculates current hypotheses, conditional assembly risk and all allowed `q` candidate outcomes. Chief cannot change numeric values by persuasion.
8. Scheduler compares fixed, random, IG, **classical EVSI**, and constrained V-DER candidates; chooses via configured policy and records rationale/counterfactual decision certificate (CDC).
9. If evidence coverage or calibration insufficient, propose `hold`/`inspect`, not unsupported `release`; human sees why.
10. Human operator records a reviewed, authorized decision. Independent physical assembly/measurement later records actual outcome and instrument details, closing Bounded Autonomy Ledger (`BAL`).
11. Any station outage expires its stale evidence for current decisions, but station continues local measurements and eventually replays queue exactly once.
12. An exported manifest includes input IDs, origin labels, hashes, random seeds, versions, costs, approval and limitations. A reviewer can reproduce the model result and audit the action chain.

### 3.6 CDC / PED / BAL schemas, production design

**Counterfactual Decision Certificate (`CDC`)**:

```json
{
  "schema_version":"v2-draft",
  "incident_id":"UUID",
  "decision_context":{"lot_pair":["A-07","B-12"],"loss_model_id":"plant-APPROVED-v1"},
  "observed_evidence_ids":["real-event-ids-only"],
  "evidence_coverage":{"received":2,"required":2,"is_fresh":true},
  "hypothesis_posterior":{"H0":0.7,"H1":0.1,"H2":0.1,"H4":0.1},
  "candidate_query_id":"registered-query-ID",
  "current_safe_action":"hold",
  "possible_action_changes":["inspect","recommend_alternative_lot"],
  "expected_loss_before":null,
  "expected_loss_after":null,
  "net_value":null,
  "calibration_status":"unverified",
  "data_origin":"SIMULATED",
  "proof_status":"proposed / not-industry-validated",
  "human_authorization_status":"pending"
}
```

Posterior figures above are **example schema values, not inferred from production measurements**. `null` means not calculated. All computed numbers in an actual certificate must be filled exclusively from deterministic service responses, with stable versions.

**Protected Expert Dissent (`PED`)**:

```json
{
  "challenge_id":"UUID",
  "specialist":"metrology",
  "hypothesis":"gauge bias explains slot discrepancy",
  "counterevidence_event_ids":["existing-event-id"],
  "numeric_tool_result_hash":"sha256-of-validated-result",
  "expected_action_change":"inspect rather than release",
  "status":"requires_independent_verification",
  "adjudicator_role":"different calibrated human or approved tool",
  "deadline_utc":"explicit",
  "resolution":"unresolved"
}
```

The current runnable API checks that event IDs exist and preserves the challenge; it does **not** yet implement independent scientific adjudication, calibration/signature verification, challenge deadlines or per-incident blocking. Those are required P1 features.

**Bounded Autonomy Ledger (`BAL`)**: every append-only event links parent source IDs + SHA-256 hash + context, `origin.kind`, unit, model version, role, policy decision, human approval ID and physical verification ID. An in-memory hash chain **detects edits within that running process** but does NOT provide tamper resistance, nonrepudiation or valid cryptographic signatures. Production design requires durable storage, authenticated identities, signing/verification, rotation/revocation and key custody.

### 3.7 Decision to abstain is a scientific output

Abstention must be measured, not hidden. A calibration/status gate should return `ABSTAIN_PENDING_EVIDENCE`, `ABSTAIN_UNVERIFIED_SENSOR`, `ABSTAIN_MODEL_SHIFT`, `ABSTAIN_UNAUTHORIZED`, or `ABSTAIN_UNIDENTIFIABLE` as appropriate. Track false abstention, unsafe non-abstention, safe decision coverage and accuracy *conditional on coverage*.

---

## 4. The entire multi-agent organization, with contracts rather than personas

### 4.1 Three truly independent station services

| Station | Data it owns | Local functions | Allowed cross-boundary messages | What it may NEVER do |
|---|---|---|---|---|
| `slot` | lot/specimen W readings, gauge, machine, provenance | measurement, SPC, local evidence summary, queue | timestamped summary + allowlisted source event IDs | read tab raw database; approve assembly release |
| `tab` | lot/specimen T readings, gauge, process data | measurement, SPC, local evidence summary, queue | timestamped summary + source IDs | read slot raw database; forge slot measurement |
| `assembly` | pairing choices, test outcomes, final assembly events | request evidence, compute authorized fit logic, log outcomes | batch-risk query, tool proposals, outcome witness | invent W/T measurements; force station override |

These are **separate owners**, not simply three prompts. Real deployment should use independently authenticated local services/storage (the included mini-demo uses separate in-memory objects to illustrate this, NOT physically isolated databases).

### 4.2 Twenty specialists: roles, required data and acceptance test

An agent is not counted *implemented* merely because its prompt exists. Every role must have a typed input schema, real tool and output validation, provenance citations, abstention condition, scope of authority, a negative test and a disable/ablation switch.

| # | Specialist | Required scoped inputs | Deterministic / tool-grounded output | Must abstain or fail when… | Current status |
|---:|---|---|---|---|---|
| 1 | Design Geometry Engineer | CAD revision, datums, specs | fit envelope, conflict report | CAD version absent for complex geometry | narrow demo handler |
| 2 | Tolerance Analyst | accepted distributions, correlation assumptions | conditional fit risk + sensitivity | joint evidence absent, calibration invalid | narrow demo handler |
| 3 | Materials Engineer | certified resin/metal batch, temperature | dimensional expansion hypothesis | material model missing | contract only |
| 4 | Process Engineer | station operation graph + time series | fault-path likelihood | unmodeled alternate process | contract only |
| 5 | CNC Machining Expert | tool offsets, temperature, machining log | wear/offset hypothesis | no machine trace | contract only |
| 6 | Additive Manufacturing Expert | STL, slicer profile, material/print logs | extrusion/warping hypothesis | no print metadata | contract only |
| 7 | Metrology Engineer | gauge serial, resolution, repeats | uncertainty and gauge check | unverified calibration | narrow demo handler: always flags unverified |
| 8 | SPC Engineer | baseline, live time series | EWMA/CUSUM alarm with calibration | <5 points, no baseline | contract only |
| 9 | Quality Inspector | station measurements, specs, event IDs | local conformance check | traceability absent | narrow demo handler |
| 10 | Assembly Engineer | joint lot fit and pair requirements | clearance risk / test protocol | missing partner evidence | narrow demo handler |
| 11 | Causal Diagnosis | process DAG, intervention history | competing fault explanations | observational equivalence | contract only |
| 12 | Bayesian Statistician | frozen priors/likelihoods | posterior and sensitivity | unverified likelihood | contract only (9.0 toy separate) |
| 13 | Inspection Planner | registered tests, outcome likelihoods, costs | IG/EVSI/V-DER comparison | no legal or useful query | contract only (9.0 toy separate) |
| 14 | Operations Research | inventory, batch-level risk, constraints | selective pairing optimization | feasibility constraints unknown | contract only |
| 15 | Maintenance Engineer | sensor wear, service history | maintenance inspection hypothesis | unobserved machine condition | contract only |
| 16 | Supplier Boundary Agent | share policy, supplier payload | released signed summaries | scope invalid/expired | contract only |
| 17 | Safety & Governance Agent | plant safety policy, role privileges | deny/unverified gate | unsafe action request | narrow demo handler: always deny release |
| 18 | Privacy & Security Agent | access and message traces | denial/leak audit | messages not auditable | contract only |
| 19 | Reliability & Network Agent | freshness, link health, queue | evidence coverage/replay status | stale data | narrow demo handler |
| 20 | Scientific Auditor | run manifest, seeds, event hashes | reproducibility status | missing version/physical truth | narrow demo handler |

**Status contract:** `narrow demo handler` means deterministic, runnable reference behavior for one or few fields; NOT a trained autonomous specialist or industrial-grade tool. Only these eight currently have callable `/api/incidents/{id}/specialists/{role}` functions. Other twelve return HTTP 501 rather than pretend to reason.

### 4.3 Chief Engineer — selected B mode, safe authority

Responsibilities: (i) open incident and classify physical risk, (ii) select necessary specialist subset based on observed evidence gaps, (iii) request authorized summaries, (iv) require citation-backed contradictory evaluations, (v) call deterministic model/inspection service, (vi) stage recommendation, (vii) ask human to approve, (viii) check outcome after physical test. **No raw DB access across stations; no fabricated evidence; no right to change spec/threshold; no machine actuation; no sole point of production safety.**

Chief failure behavior: with Chief offline, `peer-review` still computes a limited conservative joint assessment from available authorized summaries; stations remain autonomous. Chief can improve human organization, but **the ScienceClaw collective must show capability without a central planner**.

### 4.4 Activation / scientific ablation

Compare `1`, `4`, `8`, `20` available specialists under equal context budgets; activate only relevant roles. Three measured costs: evidence transfer, wall-clock time, and token/API cost. In high-stakes cases tool output confidence outranks counts of verbal opinions; common underlying model lineage or shared events create correlated evidence, so naive majority voting is prohibited.

- **A0**: numeric QC only, no LLM specialists.
- **A1**: one fully informed LLM with exactly equivalent tools and data permission.
- **A2**: 4 expert roles with explicit evidence requests.
- **A3**: 20 roles registered, select 2–6 per incident; PED off.
- **A4**: A3 + verified PED.
- **A5**: A4 + Chief B coordination.
- **A6**: A4 + Chief disconnected (pure peer mode).
- **A7**: A4 + V-DER / decision-aware request policy.

Change only one feature per ablation; include a *fully informed* centralized upper-bound reference where physical evidence access is legally possible, and explicitly disclose whenever the access scenarios differ.

---

## 5. Actual working vertical slice included with the MD

### 5.1 Repo layout — one codebase, one site

```text
QualityRelay_10_RELEASE/
├── QUALITYRELAY_10_FINAL_INTEGRATED_MASTER_BLUEPRINT.md     # THIS single master
├── implementation/
│   ├── requirements.txt
│   ├── qualityrelay10/
│   │   ├── __init__.py
│   │   ├── core.py                      # conditional fit & measurement checks
│   │   ├── state.py                     # scoped local station objects, queue, audit
│   │   ├── agents.py                    # 20 registry roles, 8 executable tools, Chief/peer
│   │   ├── decision_value_prototype.py # 9.0 separate TOY research planner
│   │   ├── benchmark_toy.py            # reproducible paired toy experiment
│   │   └── api.py                       # REST + human gate
│   ├── web/index.html                   # one integrated site; research labels
│   └── tests/test_vertical_slice.py    # 15 executable tests
├── research/
│   ├── collect_10000.py                # 10k candidate METADATA collector; not executed online
│   ├── verified_seed_references.csv    # curated starting leads, requires quality screening
│   └── benchmark_toy.py               # 3000 episode original toy benchmark
├── results/
│   ├── prior_toy_benchmark.json         # actual existing 9.0 model toy outputs
│   └── (new run manifests + test logs)
└── legacy/
    ├── QualityRelay_5_ORIGINAL.zip      # untouched original source
    ├── QualityRelay_9_ORIGINAL.zip      # untouched prior research package
    └── QualityRelay_8_BLUEPRINT.md
```

### 5.2 Start locally (Mac/Linux)

```bash
cd QualityRelay_10_RELEASE/implementation
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python -m qualityrelay10.benchmark_toy  # optional: reproduce 3k-episode toy benchmark
uvicorn qualityrelay10.api:app --host 127.0.0.1 --port 8000
# Open http://127.0.0.1:8000
# API docs http://127.0.0.1:8000/docs
```

`localhost` is intentionally used. **Do not expose this demo to the public internet or factory network**: prototype role strings are spoofable, state is in-memory, no real authentication, no encrypted durable audit, no production DB transactions, no industrial connectors or cybersecurity assurance.

### 5.3 What the current endpoints really do

| Method + endpoint | Demonstrated behavior | Production gap |
|---|---|---|
| `POST /api/reset` | reset known seeded scenario | operator privilege + persistence |
| `POST /api/incidents` | make incident with lot pair and pending state | true lot/revision registry |
| `POST /api/incidents/{id}/evidence/slot` and `/tab` | scoped summary + source event IDs | independent signed transport and authentication |
| `GET /api/incidents/{id}/chief` | bounded coordinator with conservative fit risk and tasks | decision protocol + certified policy engine |
| `GET /api/incidents/{id}/peer-review` | same numeric core without Chief | independently deployed peer computation |
| `POST /api/chief/link` | model Chief online/offline | real process/service fault injection |
| `GET /api/stations/{station}/raw` | mock-role denial 403 to cross-reader | actual session/JWT/mTLS RBAC and physical DB isolation |
| `POST /api/stations/{station}/link` | model station disconnect/reconnect, queued replay | network transport, durable idempotency |
| `POST /api/measurements` | self-reported physical caliper value, invalidates prior summary | operator identity, gauge certificate, calibration/measurement uncertainty |
| `GET /api/incidents/{id}/specialists/{role}` | eight callable tools; 501 for others | complete specialist capabilities |
| `POST /api/incidents/{id}/challenge` | register sourced challenge, refuse fabricated IDs | independent adjudication, timeouts, thresholds |
| `POST /api/incidents/{id}/approve` | accept only hold/inspect/request-more and mock human role | real identity, dual control, plant authority separation |
| `GET /api/research/one_step_vder` | stand-alone toy posterior and next-query recommendation | calibrated physical EVSI, model validation, costly constrained action selection |
| `GET /api/audit` | hash-chain check and recent records | durable signed audit, security, retention |
| `GET /` | one HTML dashboard showing all above | accessibility, authentication, deployment & reliability |

**Do not show the toy planner score as the physical assembly's decision certificate**. They are explicitly separate until a shared, validated hypothesis/likelihood schema exists.

### 5.4 Demo request path (API-level, deterministic)

```bash
# 1. Open incident; copy the returned id
curl -s -X POST http://127.0.0.1:8000/api/incidents \
  -H 'Content-Type: application/json' \
  -d '{"slot_lot":"A-07","tab_lot":"B-12"}'
# 2. GET /api/incidents/<id>/chief → ABSTAIN_PENDING_EVIDENCE
# 3. POST /api/incidents/<id>/evidence/slot → coverage 1/2
# 4. POST /api/incidents/<id>/evidence/tab → coverage 2/2
# 5. GET /api/incidents/<id>/chief → model-simulated fit risk, review-only
# 6. POST /api/chief/link {"online":false}; Chief gives 503, peer-review works
# 7. POST /api/stations/slot/link {"online":false}; old slot evidence invalidates
# 8. POST /api/measurements with a real caliper reading & self-reported provenance
# 9. POST /api/stations/slot/link {"online":true}; queued events replay once
# 10. GET /api/audit; review hash chain & all event IDs
```

**Reference only:** The UI currently illustrates these operations; it does not connect to a live CNC machine, Formlabs printer, CMM or enterprise database. Camera can be included later as supporting photo evidence only, not sub-mm dimensional truth without calibrated photogrammetry and validation.

### 5.5 Security/consistency warnings discovered during integration

1. The supplied 5.0 event schema expects a provenance-rich envelope. The current reference API returns smaller demo records and is **NOT** certified v1-event-schema compatible. Build a v1→v2 adapter; do not silently replace existing contract fields.
2. The reference server's `actor_role` string or body value **is not an authenticated identity**. A 403 exercise proves a conditional check, not system security. Production MUST use authenticated service principals + policy engine + mTLS/TLS and least privilege.
3. The reference event log is in RAM. Hash chaining is NOT cryptographic signing or durable immutability. Use durable append-only storage and key verification for real audits.
4. Station local data is separated by object, not independently hosted databases. The true decentralized claim needs independent processes/credential stores and fault-domain isolation.
5. Seeded Monte Carlo uses approximate fitted Gaussian variation. It is **uncalibrated** and does not carry a metrological risk guarantee.
6. Self-reported caliper values are labeled as such; software cannot certify that measurement was really taken.
7. The 9.0 toy EVSI endpoint is deliberately disconnected from the conditional physical risk engine; joining them requires validated model likelihoods and consistent loss units.
8. Eight role handlers are narrow deterministic methods, not eight independent generative AI models. The 12 planned roles must not be represented as already operational in a pitch.
9. Any claim of safe plant actuation, ISO compliance or factory readiness requires external governance/security/mechanical validation beyond this release.

---

## 6. Integration contracts: v1 preserved, v2 additive

### 6.1 Contract freeze strategy

- **Never overwrite** original `contracts/openapi.yaml` or `event-envelope.schema.json` from the 5.0 ZIP. Import as versioned schema.
- Add `contracts/v2/` with `incident.schema.json`, `authorized-summary.schema.json`, `specialist-result.schema.json`, `CDC.schema.json`, `challenge.schema.json`, `action-approval.schema.json`, `outcome.schema.json`.
- Every event includes `schema_version`, `incident_id`, `station_id`, `lot_id`, `measurement_event_ids`, `origin.kind`, unit `mm`, time UTC, algorithm version, policy revision, source scope, request ID and idempotency ID.
- No `origin.kind=physical_verified` unless independent instrument/operator evidence is present. Current UI only supports `simulated` and `physical_self_reported`.

### 6.2 Specialist result envelope

```json
{
  "schema_version":"2.0-draft",
  "specialist_id":"metrology",
  "incident_id":"UUID",
  "status":"requires_independent_measurement",
  "hypothesis":"gauge bias may explain apparent shift",
  "supporting_event_ids":["registered-evidence-id"],
  "tool_id":"measurement_uncertainty_v1",
  "tool_version":"git-sha",
  "tool_result_hash":"sha256-of-bytes",
  "measurement_units":"mm",
  "assumptions":["gauge has not been externally calibrated"],
  "uncertainty_status":"unverified",
  "proposed_countertest_id":"server_allowlisted_test_id",
  "authority":"recommendation_only"
}
```

On missing evidence, return a structured `unknown` status—never infer missing values. The server validates IDs and canonical units. Chief outputs a machine-readable *task graph*, not unstructured votes.

### 6.3 Provenance state machine

```text
SIMULATED_GENERATED
    | model-input-snapshot(version,seed)
    v
MODEL_RISK_ESTIMATE  -- never silently become --> PHYSICAL_VERIFIED

PHYSICAL_SELF_REPORTED
    | gauge ID + operator + repeatability + independent confirm
    v
PHYSICAL_CHECKED
    | metrology review + config / dataset registration
    v
CALIBRATED_FOR_DECLARED_SCOPE [requires real evidence; NOT achieved in v10 demo]
```

### 6.4 Threat model, must-pass before factory pilot

- Attack: station A asks for station B raw data. **Mitigation:** service principal and explicit scope; denial event and leak test.
- Attack: LLM prompt injection from operator notes. **Mitigation:** tool/permission boundary external to LLM, structured event parser and injection test.
- Attack: replay/duplicate/rollback of evidence. **Mitigation:** signed hash-chained immutable event IDs, timestamp freshness and idempotent consumer; current demo tests only local hash chain and replay.
- Attack: fabricated event IDs and fake measurement. **Mitigation:** registry validation, verified instrument/human identity and traceable physical witness.
- Attack: Chief compromise/outage. **Mitigation:** no safety-critical Chief authority, peer computation, station local continuity.
- Attack: 19 LLM agents repeat same wrong measurement. **Mitigation:** hash-unique independent evidence and mandatory counterexample adjudication, not plurality vote.
- Attack: sensitive supplier aggregate reveals process IP. **Mitigation:** disclosure categories, consent/scopes, threat modeling and where needed formally proved privacy mechanisms—not hand-waving about aggregates.
- Attack: overconfident risk under drift. **Mitigation:** calibration monitoring, shift tests and conservative abstention.

---

## 7. Full scientific validation program

### 7.1 Experimental arms (fair matched budgets)

| Arm | Evidence topology | Query policy | Specialist organization | What this isolates |
|---|---|---|---|---|
| B0 | local station only | fixed check | no LLM | present local QC baseline |
| B1 | local station only | IG | no LLM | isolated statistical monitoring |
| B2 | all allowed raw evidence in single secure hub | EVSI | best calibrated centralized | full-information upper reference, not handicapped |
| B3 | same legal accessible summaries | IG | peer agents | decentralized with established IG |
| B4 | same summaries | classical EVSI | peer agents | decision-value prior art baseline |
| B5 | same summaries | constrained V-DER | peer agents | query protocol value beyond EVSI |
| B6 | same summaries | constrained V-DER | bounded Chief | coordinator incremental effect |
| B7 | B5 summaries | V-DER, PED off | peer agents | dissent ablation |
| B8 | B5 summaries | V-DER, evidence debt off | peer agents | evidence-question ablation |
| B9 | B5 summaries | V-DER, hash/authority off **sandbox only** | peer agents | failure mode / security tradeoff; never real plant |
| B10 | B5 summaries, Chief offline | same math | peer agents | continued local capability |
| B11 | centralized reference, coordinator offline | same math and event budget where meaningful | hub | topology resilience comparison, disclose asymmetry |
| B12 | single general-purpose agent | same total tools, cost and permitted data | 1 agent | specialization vs one capable model |

A single model with *more data* is not a fair target for a multi-agent claim unless the greater data rights are explicitly part of the comparison. Show both capability and data-sharing cost. Compare one-step and sequential horizons separately; avoid an EVSI policy advantaged by knowing a distribution it would not actually know.

### 7.2 Factorial scenario matrix and physical challenge set

| Scenario | Injected condition | Expected test / key failure possibility |
|---|---|---|
| S01 nominal | stable independent lots | all methods near nominal risk; unjustified false alarm? |
| S02 slot drift | `μW` decreases | local SPC/hypothesis H1 may emerge |
| S03 tab drift | `μT` increases | H2 and pairing risk may rise |
| S04 combined | `−0.100 mm/+0.100 mm` mean shifts | H4 support if identifiable; not guaranteed |
| S05 accepted-parts trap | individually pass, joint C below threshold | system must not equate local pass with functional pass |
| S06 sensor error | caliper bias/nonrepeatability | metrology abstention vs wrong confident diagnosis |
| S07 missing station | one authorized evidence source absent | explicit uncertainty/abstention |
| S08 intermittent network | link toggles mid-inspection | local continuity, no stale fake confidence, dedup replay |
| S09 Chief failure | Chief unavailable, peers online | peer system useful without single commander |
| S10 hidden dissent | one expert has correct countermeasurement, 19 share wrong one | measured expert-weighting vs majority failure |
| S11 malicious agent | forged event IDs, toxic notes, tool injection | deny; do not execute |
| S12 privacy boundary | supplier disallows raw sharing | comparable decision quality vs raw exposure |
| S13 correlated dimensions | lots/sensors are not independent | calibration and misspecification checks |
| S14 high costs | expensive inspection, cheap holding | EVSI may stop measurement appropriately |
| S15 rare critical failure | high false-release penalty | calibrated abstention/coverage frontier |
| S16 distribution shift | process parameters change after calibration | detect out-of-distribution and downgrade confidence |

All seeds, physical datasets and generated scenario recipes remain separate. Simulate at least 30 seeds per scenario when feasible; for 2-day hackathon P0 use a labeled exploratory subset and do not disguise it as statistical power. For full paper, power simulation must be pre-registered based on the primary effect and variance.

### 7.3 Primary estimands, definitions

1. **Expected realized decision loss per lot pairing:** `actual_scrap_or_rework_cost + inspection_cost + holding_cost + approved_latency_cost`, predeclared units. This is preferred primary endpoint over raw anomaly accuracy.
2. **Unsafe release rate:** proportion of release proposals when physically bad; in the uncalibrated demo this should be **zero release proposals** by policy, not an accuracy boast.
3. **Targeted inspection burden:** measured count and cumulative technician seconds per correctly diagnosed fault.
4. **Uncertainty and abstention:** Brier score / calibration curves with independent test truth, safe coverage and error conditional on coverage.
5. **Physical fit outcome:** number of printed pairs that actually assemble under explicitly defined force/orientation conditions, not simulated probability.
6. **Security/privacy:** unauthorized reads denied, raw fields transferred, message bytes, cross-plant leakage probes.
7. **Network resilience:** useful local events produced during outage, data freshness, replay duplicates, uptime per failure domain.
8. **Computational cost:** wall time, LLM tokens and API dollars per decision.

### 7.4 Statistical analysis

- Primary: paired treatment-versus-control difference in per-incident realized loss under shared scenario seeds, with incident-level bootstrap or appropriately clustered confidence intervals.
- Secondary: bootstrap CIs for detection delay, inspections, Brier, coverage and communication; avoid asserting independent data points if they share simulated lot/seed.
- Use paired sign/permutation tests where distributional conditions suit; give point differences **and absolute results** with uncertainty. No “95% confidence” for five physical specimens.
- For many scenario tests, state exploratory status or control false discovery risk; pre-register two or three confirmatory hypotheses.
- Show worst-case and cost-sensitivity results; use a Pareto table rather than hiding tradeoffs in arbitrary weighted scores.
- **Negative/neutral results must be shown**. The prior toy run shows no credible V-DER superiority vs IG; this is a baseline diagnostic, not proof of failure or success in all environments.

### 7.5 What the 9.0 3000-trial toy actually found

From the user-provided prior archive `results/prior_toy_benchmark.json`:

| Method | Mean toy decision loss | Measurement cost | Episodes |
|---|---:|---:|---:|
| `vder_evsi` | `0.698883` | `0.07` | 3,000 |
| `entropy_ig` | `0.699082` | `0.07` | 3,000 |
| `random_inspection` | `0.741873` | `0.07` | 3,000 |
| `fixed_slot` | `0.757193` | `0.07` | 3,000 |
| `no_inspection` | `1.023513` | `0` | 3,000 |

Paired per-incident V-DER minus IG mean: approximately **−0.000198** cost units; rough normal 95% CI approximately **[−0.002177, +0.001780]**. Only **6 of 3000** episodes differed in the simulated realized loss. This is essentially a tie and not a verified statistical advantage. Assumptions: handcrafted hypothesis priors, likelihoods and loss values, one equal-cost summary query, no real metrology/permission costs, synthetic cases. It is entirely inadequate for claiming production accuracy, a new theorem or commercial ROI.

**What to change scientifically:** include cases where the most informative hypothesis distinction does not affect action, where privacy/measurement costs differ, where tool-backed dissent reverses an otherwise wrong decision, and where topologies disconnect. **Also include a strong constrained EVSI baseline with the SAME costs and legal query set** so new gains cannot be attributed merely to choosing a better baseline.

---

## 8. Real mechanical validation: HyorinmaruK is owner

### 8.1 Print kit inherited from 5.0 — unchanged files

- `slot_good_21p20.stl`, `slot_nominal_21p00.stl`, `slot_risk_20p70.stl`;
- `tab_good_19p80.stl`, `tab_nominal_20p00.stl`, `tab_risk_20p30.stl`;
- `repeatability_bar_20p00.stl`;
- CAD source script, OpenSCAD file and print manifest.

**Do not assume STL nominal dimensions equal manufactured dimensions.** Print at known orientation and settings. Record spool/resin ID, printer, layer height, date/time, slicer version, ambient temp and observed print quality. Make backups; choose a visibly resolvable clearance difference, not a false high-precision demo.

### 8.2 Real measurement procedure

1. Inspect/clean print artifacts without secretly sanding dimensions differently for different treatments; record changes.
2. Identify one calibration artifact or certified gauge if available; verify zero, jaw cleanliness and instrument resolution; use `instrument_id`.
3. Measure repeatability bar at least ten times, with re-seating and ideally a second operator. Report mean, standard deviation, resolution and within-operator spread. This is **screening**, not a complete MSA or certified gauge R&R.
4. Measure slot width and tab thickness at defined datum locations; repeated readings per piece. Record specimen IDs, operator, instrument, raw readings and environmental conditions.
5. Freeze measurement procedure **before** knowing which pair is supposed to fit.
6. Randomize/record pair ordering; physically assemble each planned pair; define fit criterion (clearance only vs manual force vs insertion orientation) and report exactly what was observed.
7. Keep physical and synthetic tables separate. CSV origin must distinguish `physical_self_reported`, `physical_checked`, `simulated`, `assumed`.
8. Present the system's recommendation before showing the physical outcome. Do not tune the model on the test result and then claim validation on the same specimen.
9. Optional outside company checks only dimensions/fit and maybe engineering review by agreement; do not claim “factory validated” because a paid machine shop produced a measurement report.

### 8.3 Physical acceptance and honest demo claims

A single good/nominal/tight-risk pair shows *one mechanism*. It does not establish a numerical failure probability, 90% fault accuracy or wide process generalization. Any overfit, broken part, ambiguous fit or sensor disagreement belongs in `limitations`, not deleted from the dataset.

**Deliverables:** `physical_measurements.csv`, `instrument_log.csv`, `physical_pair_tests.csv`, `mechanical_validation_report.md`, labeled images/video (optional), and signed/confirmed reviewer notes if obtained. The 5.0 original templates remain present in the preserved archive.

---

## 9. The one website — information architecture and exact screen behavior

**Purpose:** bring data ownership and actual engineering decision workflow into one interface, not to turn 20 agents into decorative avatars.

1. **Incident / Lot Pair** — choose slot lot, tab lot, design revision, acceptable gap; immediate `pending_insufficient_evidence` state until authorized responses arrive.
2. **Station Network** — separate Slot/Tab/Assembly with online/offline indicators, source coverage, last freshness and queued events; link fault simulator.
3. **Evidence Map** — which evidence each specialist has, which missing item could change production action, and where source restrictions apply.
4. **Chief Engineer Mission Board** — small subset of actual specialist tasks, each status `pending/computed/abstained/challenged/verified`; Chief-off peer mode switch.
5. **Risk & Fit Lab** — acceptance-conditioned Monte Carlo with clear `SIMULATED/UNCALIBRATED` banner and non-overstated uncertainty; show formula and references to versions.
6. **Inspection Planner** — side-by-side fixed, IG, classical EVSI, V-DER candidate list, expected decision effect and allowed query IDs; avoid a fake unexplained 100% confidence score.
7. **Protected Dissent** — real counterevidence ID, human/independent verification state, no majority-vote suppression.
8. **Physical Measurements** — instrument/operator entry; `physical_self_reported` until verified; compare printed part pairs.
9. **Decision & Human Approval** — proposed safe action, risk reason, nonempty operator note, immutable parent ID; no automatic release.
10. **Replay & Science** — export seed, event log, run manifest, hypothesis posteriors and benchmark outcomes, separate physical vs simulated charts, explicit `REVIEW_ONLY_MIXED_EVIDENCE` when combining sources.
11. **Agent Registry** — exactly 20 named specialists, transparent `implemented/reference/specification` status, data access and tools; not “all working AI.”
12. **Industrial Integration** — CSV import validation, lot mapping, API adapter metadata and calibration; marked roadmap until real services exist.

The included `web/index.html` implements a compact subset of these screens, **not** every planned production page. Site UI should label all numbers and claims by provenance and calibration state.

---

## 10. Three-person division of labor + optional fourth: concrete repo ownership

| Owner | Current primary scope | Must deliver | Cannot claim |
|---|---|---|---|
| `Bakdaulet-omeraiuly` | math/DS, baseline benchmark, literature evidence, experiment manifests | v1 exact physical math, IG/EVSI controls, seeded trials, calibration test, science results tables and caveats | validated factory probabilities with five uncalibrated samples |
| `adilnurgg` | station-local backend, message transport/security, Chief B and peers, REST | independent station services, versioned contracts, 403 and replay tests, role-safe Chief, signed evidence proposal and deployment runbook | security is proven by mock role params |
| `HyorinmaruK` | mechanical engineer; physical validation and **final presentation** owner | print kit, gauge repeatability, blinded assembly, mechanical report, final slides/pitch/video, physical UX acceptance | STL model dimensions = measured reality |
| Optional 4th | frontend UX + independent QA / factory integrations | API-driven dashboard, negative E2E tests, accessibility, CSV/CMM adapters, external engineer outreach | that the pilot or certifications already occurred |

### 10.1 File/branch ownership (avoid merge conflicts)

```text
repo: qualityrelay                     [create a NEW shared repository or use approved existing]
main                                  [protected; working integration only]
feature/research-core                 @Bakdaulet-omeraiuly
  implementation/qualityrelay10/core.py
  implementation/qualityrelay10/decision_value_prototype.py
  research/, results/, tests/test_science_*.py

feature/distributed-chief             @adilnurgg
  implementation/qualityrelay10/state.py
  implementation/qualityrelay10/agents.py
  implementation/qualityrelay10/api.py
  contracts/v2/, infrastructure/, tests/test_security_*.py

feature/mechanical-validation         @HyorinmaruK
  physical/, cad/, slides/, reports/mechanical_validation_report.md
  implementation/web/ (design/UX oversight, presentational content)

feature/frontend-factory-connectors   @fourth-if-available
  implementation/web/, connectors/, tests/test_end_to_end_*.py
```

When only three people are present: `HyorinmaruK` owns final UI acceptance and pitch, `adilnurgg` wires minimum UI endpoints, `Bakdaulet-omeraiuly` supplies charts/table data. Do NOT give one person both all mechanics and every frontend task while also requiring final presentation. Freeze interfaces early and merge short PRs to `main`.

### 10.2 Integration handshake

- Freeze API request/response schemas first. Each owner writes contract tests before implementing feature details.
- Station authors may only modify their local data/access layer. The statistical service receives **authorized evidence results** with event IDs and origin metadata, never direct peer DB pointer.
- Core numerical functions are library calls, not LLM prose. Never allow an agent to redefine mathematical results.
- `main` commit protected by: unit tests, synthetic end-to-end evidence query, raw-read 403, Chief-off, station-offline queue, seeded deterministic risk, human release denial and science result origin labels.
- Tests must run in CI on merge; keep frozen demo state, a 90-second backup recording and a read-only run manifest available for judges.

---

## 11. Execution plan: 30-hour hackathon vs real scientific maturity

### Hackathon Priority P0 — deliver a real scientific slice

**H0–H3 / Scope freeze**: settle lot pair, CAD references, roles, threat model, one problem statement and run manifest. Assign issue owners.

**H3–H8 / Physics + station evidence**: actual source event IDs and pending→two summaries→risk; contract tests; no fake station data.

**H8–H13 / Peer/Chief safety**: policy checks, restricted raw read, human hold/inspect approval, Chief-off peer mode, link-loss replay and basic specialist task graph.

**H13–H18 / Physical experiment**: printed/available parts, calibration screening, real caliper entries, fit outcomes, provenance; no fabricated success.

**H18–H23 / Scientific benchmark**: run matched baselines on frozen scenarios; compare decision loss and evidence transfer, show even null results.

**H23–H26 / Freeze and verify**: cold-start twice, security test twice, record demo, manual source/fact check.

**H26–H29 / Pitch**: HyorinmaruK finalizes slides, real measurements and abstract, 2 rehearsals; no new features. **Official slide deadline Sunday Nov 1 13:00 EDT**; if deadline is near, prioritize a functioning vertical slice and submit early.

### Post-hackathon P1 — credible research, 2–6 weeks (not guaranteed timeline)

- Independent actual station services and durable events.
- Versioned physical risk model with gauge measurement-error and correlation robustness.
- 10,000 metadata candidate collector run, quality-screened shortlist, negative prior art review, not 10k claimed full-text analyses.
- Full 20 specialist **tools** with quantitative tests; only use LLM where reasoning genuinely adds evidence value.
- Blinded physical test matrix, trained held-out baselines and preregistered run manifest.

### P2 — factory shadow trial, only after partner agreement

- Real CNC/precision assembly company supplies consented deidentified specs and measurement data.
- CSV/QIF/MTConnect/OPC UA adapters as permitted; ISO 23247 concepts as architecture reference where applicable.
- Security assessment, calibration + GR&R, pilot comparators, human workflows and permission review.
- “Shadow mode” recommendations only; factory engineer retains actual action. Independent evaluation before any production integration.

### P3 — production suitability, unknown duration

- Hazard analysis, data governance, real service identity, cybersecurity evaluation, legal/compliance reviews, calibration, alert performance and drift management.
- Role-based governance and traceable interventions, audit retention, disaster recovery, integration testing in staging, staged rollout.
- Do not claim “deploy directly to any factory” or “certified” without external validation.

---

## 12. P0 pass/fail acceptance gate (from 5.0 plus new science)

- [ ] `reset → incident → pending → authorized evidence → risk → inspection recommendation → new measurement → updated risk` works twice cold-start.
- [ ] Cross-station raw query returns 403; deny event logged; identity mechanism status explicitly noted.
- [ ] Physical measurements include real instrument, operator and origin; never conflated with simulation.
- [ ] No invalid invented specimen ID can be scheduled.
- [ ] Same frozen evidence snapshot+model+seed yields same numerical result.
- [ ] Chief-off scenario does NOT stop independent station monitoring or peer review.
- [ ] Station-offline scenario downgrades evidence coverage and never presents stale risk as current.
- [ ] Station reconnect yields zero duplicate processed event IDs.
- [ ] Human approval is required; no hazardous autonomous machine action; no automatic production release in prototype.
- [ ] A correct, source-backed dissent is separately displayed and cannot be discarded by unsupported majority vote.
- [ ] Unresolved dissent has bounded conservative outcome, not eternal unreviewed lockout.
- [ ] At least one fair baseline comparison executed, with fixed budget and result uncertainty.
- [ ] Physical vs simulated outcomes appear in different labeled tables/panels.
- [ ] All reported numerical results have real source IDs, algorithm version and seed or measurement ID.
- [ ] Baselines include **classical EVSI**, not IG only, where a V-DER improvement is claimed.
- [ ] All 20 specialist roles show accurate implementation maturity; no ghost agents.
- [ ] Actual test output saved to `results/`, not just template checkboxes.
- [ ] Claims audit passes: no invention of 10k analyzed studies, factory certification, first-in-world novelty or Nobel-level discovery.

**Operational P0 status of included reference:** it passes the narrow 15 Python tests run here; external signatures, industrial deployment, physical measurements and the full research benchmark remain to be completed. This checkbox list is a target, not a claim everything is done.

---

## 13. Real scientific milestones that would make the novelty claim defensible

1. **Prior art:** disclose search syntax, dates, databases, title/abstract screening, negative hits and exact paper comparisons. 10,000 downloaded metadata items alone prove nothing.
2. **Definition:** formal V-DER protocol, CDC, PED, BAL and compliance conditions under realistic factory information partitions.
3. **Strong baselines:** compare with a strong single-agent model, deterministic/statistical QC, IG, *classical EVSI with identical costs and access*, and centralized full-information upper reference.
4. **Real mechanism:** show a physical case where a locally accepted pair fails in fit; agent requests a measurement justified *before* seeing ground truth.
5. **Robustness:** confidence bounds, model misspecification, process correlations, sensor errors and outages.
6. **Reproducibility:** exact frozen input events and seeds, code, tests, scripts and blinded analysis.
7. **Independent review:** external manufacturing engineer evaluates a mechanical protocol and a separate statistician reviews the comparator and uncertainty.
8. **Potential publishable effect:** statistically credible and practically meaningful improvement in decision loss, privacy/latency or resilience under clearly defined conditions, with limitations and failure cases.

**If our method does not beat IG/EVSI:** the honest publishable question may instead be *which conditions defeat collective evidence gathering, and when abstention is necessary*. A scientifically credible negative result is stronger than fake innovation.

---

## 14. Revenue/adoption, customer, and pilot definition

**Initial user:** Quality Engineer / Manufacturing Engineer at a small or mid-sized precision assembly/CNC/additive manufacturing plant, or a supplier relationship where measurement data are owned by different parties.

**What buyer pays for:** fewer avoidable cross-lot assembly reworks, less time spent tracing defect source, better selective inspection under a constrained gauge budget, consistent provenance and data minimization. Buyer does **not** pay for decorative AI personas.

**Pilot decision protocol:** pick one recurring assembly interface, reconstruct its traceability, measure baseline QC and rework costs, run QualityRelay in read-only shadow mode, prospectively compare recommendations against blind held-out actual outcomes and independent human engineer judgment. Publish false-alarm cost, missing-evidence rate, operator time and model uncertainty. No automatic production control until a separate safety assurance process.

**Unit economics:** `estimated savings = avoidable rework reduction + inspection labor saved − deployment/maintenance/gauge/LLM/compute/false-stop costs`; do not invent dollar ROI. Every estimate must show a credible measured baseline and uncertainty range.

---

## 15. Evidence status: what is known, inferred and unproven

| Statement | Evidence source | Status as of cutoff |
|---|---|---|
| 5.0 original ZIP contains complete planning/cad/contracts source set | user-provided archive; embedded preservation | **Verified as included**, 33 files |
| A standalone V-DER toy prototype can choose a one-step synthetic inspection | executable 9.0 model + tests | **Working toy, not production** |
| V-DER > IG on currently supplied 3000 episodes | toy outputs and paired comparison | **Not demonstrated** |
| Original protocol's new combination is first-of-its-kind | needs systematic related-work audit | **Unproven novelty** |
| 10,000 papers individually analyzed | no bulk corpus or screening evidence | **False; NOT claimed** |
| Current reference site handles scoped summaries/Chief/peer/offline/human approval | included runnable FastAPI+HTML and tests | **Demo only** |
| All 20 roles execute actual independently validated tools | 8 narrow reference handlers; 12 unimplemented | **False; planned** |
| Physical caliper measurements and external engineering review complete | user/operator must supply | **Not yet provided in this release** |
| Plant-ready security and calibration | requires real engineering assurance | **Not achieved** |

---

## 16. Suggested 5-minute pitch (HyorinmaruK owns final copy)

**0:00–0:35 — Problem:** “Two parts can independently pass inspection and still fail at assembly. The crucial missing information lives with different stations, often different suppliers.” Show true physical example, not idealized animation only.

**0:35–1:15 — The system:** show Slot/Tab owning independent data; Assembly queries authorized evidence. When lacking evidence, dashboard says *pending*, not hallucinated risk.

**1:15–2:10 — Collective coordination:** trigger one metrology dissent, ask one new inspection; Chief organizes but does not override measurements. Toggle Chief offline; peer path remains operational. This must be real, not filmed simulation alone where possible.

**2:10–3:15 — Physical outcome:** caliper measurement, lot pair and actual fit test with clear origin labels; compare recommendation with observed result.

**3:15–4:15 — Science:** predeclared IG / EVSI / V-DER and single vs peer comparisons, actual measured numbers and uncertainty; show negative toy result honestly if nothing stronger exists.

**4:15–5:00 — Impact and limitation:** scale to supplier-controlled evidence and factory shadow trials. “We built a reproducible research prototype; the improvement hypothesis remains under test.” Share code or reusable event schema for potential collaboration bonus.

---

## 17. Verified primary scientific sources / prior-art guardrails

The following are **high-priority primary or relevant overview sources**, not 10,000 fully screened full texts. Source pages verified or located from publisher/NIST records on Oct 30, 2026; results summarized only at the level supported by the paper abstracts or accessible text.

1. Hedberg Jr. et al. (2021), *Defining requirements for integrating information between design, manufacturing, and inspection*, International Journal of Production Research. NIST: https://www.nist.gov/publications/defining-requirements-integrating-information-between-design-manufacturing-and — original integration experiment; not a proof our protocol wins.
2. Magnanini et al. (2024), *Performance evaluation of multi-stage manufacturing systems operating under feedback and feedforward quality control loops*, CIRP Annals. https://www.sciencedirect.com/science/article/pii/S0007850624000295 — industrial gate-level prior art.
3. *A Sequential Inspection Procedure for Fault Detection in Multistage Manufacturing Processes*, Sensors 21(22), 7524 (2021). https://pmc.ncbi.nlm.nih.gov/articles/PMC8618403/ — IG inspection prior art and baseline; not our invention.
4. Li, Naito & Shirado (ICML 2026), *Systematic Failures in Collective Reasoning under Distributed Information in Multi-Agent LLMs*. https://proceedings.mlr.press/v306/li26ej.html — specific HiddenBench results; not direct manufacturing validation.
5. Pappu et al. (ICML 2026), *Multi-Agent Teams Hold Experts Back*. https://proceedings.mlr.press/v306/pappu26a.html — correct expert can be undermined, with task-dependent tradeoffs.
6. Anindya (2026), *From digital shadows to assured intervention: a systematic review of embodiment, authority, and assurance in manufacturing quality digital twins*. https://link.springer.com/article/10.1186/s44147-026-01295-x — 235-study review and assurance framing; review, not direct V-DER test.
7. NIST, *Manufacturing Digital Twin Standards* (2024). https://www.nist.gov/publications/manufacturing-digital-twin-standards — standardization/industrial integration context.
8. NIST/SEMATECH, *Measurement Process Characterization* (2003). https://www.nist.gov/publications/nistsematech-engineering-statistics-handbook-chapter-2-measurement-process — repeatability/measurement-process baseline.
9. Maltauro et al. (published online Oct 30, 2025), *A numerical approach to compute statistical assembly shift for patterns of fits: application to tolerance stack-up*. https://link.springer.com/article/10.1007/s12008-025-02428-x — Monte Carlo and tolerance-analysis prior art.
10. *Assembly Sequencing using Sparse Batch Variation Data: A Process-Oriented Tolerancing Approach* (Procedia CIRP, 2026). https://www.sciencedirect.com/science/article/pii/S2212827126007468 — selective assembly with sparse batch-level evidence is already researched.
11. Leyendecker et al., *Bayesian experimental design in production engineering: a comprehensive performance and robustness study* (published Jan 8, 2026). https://www.frontiersin.org/journals/manufacturing-technology/articles/10.3389/fmtec.2025.1614335/full — 15,360 reported benchmark experiments; method choice matters.
12. Chadha et al., *A value-of-information-based optimal sensor placement design framework for cost-effective structural health monitoring* (published online 2024, journal issue 2025). https://journals.sagepub.com/doi/full/10.1177/14759217241275643 — value-of-information cost reasoning precedes V-DER.
13. *Bayesian optimal experimental design of risk-based inspection policy through deep reinforcement learning* (2026). https://www.sciencedirect.com/science/article/pii/S0029801826030970 — evidence that risk-centric VoI inspection is established in other domains.
14. ScienceClaw official description/rubric/schedule (Oct 2026). https://scienceclawhack.ai/

**Do not put source article PDFs in the release unless licensing explicitly permits their redistribution.** The existing collector (`research/collect_10000.py`) targets Crossref METADATA candidates with deduplication and date filters; as of this release its online bulk retrieval has not run here. Bibliography relevance, venue, metadata accuracy and originality must be screened manually before making sweeping claims.

---

## 18. Release status and required next steps

**Verified locally when this package was built:** `python -m unittest discover -s tests -v` tested the vertical slice with pending evidence, bounded Chief, Chief-off peer computation, raw read denial, local queue replay, human release denial, sourced challenge input, limited specialist registry, deterministic Monte Carlo, geometry and hash tamper detection. See `results/IMPLEMENTATION_TESTS.txt` for actual test names/results. Tests prove only the tested demonstration behavior, NOT real-world plant safety, causal identifiability or scientific novelty.

**No staged/production deployment was performed.** Original 5.0 materials remain untouched. Current deliverable is a complete research+implementation plan and a narrow, honest, running reference—not a comprehensive industrial installation.

**Immediate priorities:** (1) run site with teammates, (2) replace assumed sample records with separately labeled real caliper readings, (3) freeze comparable IG/EVSI/V-DER experiments, (4) keep a literal evidence ledger, (5) have HyorinmaruK verify mechanical claims, (6) have adilnurgg harden actual station isolation, (7) remove unsupported novelty claims from pitch, (8) present measured outcomes rather than speculative percentages.

---

# APPENDIX A — Original QualityRelay 5.0 master blueprint, verbatim from user-provided archive

The following text is preserved from the ORIGINAL `01_MASTER_BLUEPRINT.md` for immediate reference. The original ZIP also contains detailed contracts, 3D CAD/STLs, schedules, manifest and validation templates; this appendix does not pretend to embed those binary assets.

> SOURCE: `QualityRelay_Hackathon_Package/01_MASTER_BLUEPRINT.md` from user archive; the content below is unchanged.

# QualityRelay 5.0 master blueprint

## 1. Executive definition

QualityRelay is a decentralized quality-coordination system for assemblies whose fit depends on measurements owned by different manufacturing stations. A slot can pass its local specification and a tab can pass its local specification while their pairing still has insufficient clearance. Each station continues to own its raw data and local decisions. Agents exchange scoped, provenance-linked evidence only when an assembly-risk query or anomaly makes collaboration useful.

The hackathon demonstration answers one narrow scientific question:

> With the same statistical core and inspection budget, what capability is gained or retained when quality evidence is coordinated across independently authorized station agents, especially when communication is intermittent?

It does **not** attempt to prove that multi-agent systems are universally better than centralized quality systems.

## 2. The manufacturing problem

Three logical stations are modeled:

1. **Slot station** produces a slot and measures slot width `W`.
2. **Tab station** produces a tab and measures tab thickness `T`.
3. **Assembly station** selects lots, observes fit outcomes, and evaluates clearance `C = W - T` against a functional minimum `c_min`.

Local part specifications are deliberately not equivalent to the assembly requirement. In the demonstration reference design:

- Slot specification: 20.5–21.5 mm.
- Tab specification: 19.5–20.5 mm.
- Functional minimum clearance: 0.5 mm.
- Nominal means: slot 21.0 mm, tab 20.0 mm.

Worst-case individually accepted parts can produce `20.5 - 20.5 = 0.0 mm`, below the functional requirement. The exact risk depends on the process distributions and the acceptance conditioning. These values are configuration assumptions for a teaching demonstration, not measured factory parameters.

## 3. User story

Before assembly, an operator selects slot lot A-07 and tab lot B-12. The assembly agent cannot calculate a current risk until it obtains sufficient, authorized summaries from both stations. It sends evidence requests. Each station returns a signed summary referencing local measurement event IDs, not its entire raw table. The assembly agent calls the deterministic compatibility engine, receives a provenance-linked risk estimate, and either:

- permits the planned pairing with its uncertainty and evidence coverage;
- recommends a server-provided alternative lot with lower estimated risk; or
- asks for the physical measurement with highest expected information gain per second.

If the slot link is taken offline, the slot station continues local measurements and queues outbound events. Peers stop receiving new slot evidence; the UI marks the current diagnosis as partial and omits the stale station likelihood from the live posterior. The audit history remains intact. On reconnection, event IDs make replay idempotent.

## 4. Why decentralized agents are justified

The system models real organizational and technical boundaries:

- Different equipment or suppliers own different raw records.
- A station has authority to measure and summarize its own process, not to read another station’s database.
- Assembly owns the relational decision: whether two lots should be paired.
- Communication can be intermittent while local production and monitoring continue.
- An append-only router moves messages but cannot fabricate a measurement, compute a diagnosis, or override a station.

If every actor reads one shared database and one global posterior, the project fails its own decentralization claim.

## 5. P0 end-to-end behavior

1. Record or seed at least five recent measurements per relevant lot and station.
2. Create a `BatchRiskQuery` for an upcoming slot–tab lot pairing.
3. Show `pending_insufficient_evidence` until authorized evidence responses arrive.
4. Calculate clearance risk with the shared deterministic engine.
5. Link every estimate to the exact evidence event IDs, code version, assumptions, and origin labels.
6. Rank server-provided physical inspection candidates by expected information gain divided by time cost.
7. Accept a real caliper entry and update the diagnosis.
8. Toggle one station link offline and show partial-evidence behavior.
9. Reconnect and reconcile queued events exactly once.
10. Export a replayable run manifest and result record.

## 6. Architecture at a glance

```text
Slot UI/tool -> Slot service + local DB ----\
                                         signed evidence events
Tab UI/tool  -> Tab service + local DB ----- event router/log ---> Assembly service + local DB -> Dashboard
                                             |                         |
                                             |                         +-> risk/diagnosis/inspection core
                                             +-> no diagnostic authority

Optional LLM adapters sit above each station's approved tools.
All numeric truth is rendered from deterministic service responses.
```

The statistical core is one versioned library reused in isolated, centralized, and decentralized conditions. This prevents a strawman baseline. Deployment and evidence access change; the mathematics does not.

## 7. Scientific core

### 7.1 Clearance risk

For independent normal slot and tab distributions before acceptance truncation:

`mu_C = mu_W - mu_T`

`sigma_C^2 = sigma_W^2 + sigma_T^2 - 2*rho*sigma_W*sigma_T`

`P(C < c_min) = Phi((c_min - mu_C) / sigma_C)`

The benchmark must condition on both parts passing their local specifications. Use deterministic Monte Carlo from truncated distributions or numerical integration. The random seed is derived from the run ID, lot pair, evidence snapshot hash, and algorithm version so identical inputs return identical outputs.

### 7.2 Local process monitoring

Each station maintains an EWMA:

`z_t = lambda*x_t + (1-lambda)*z_(t-1)`

Control limits use the standard time-varying EWMA form. `lambda = 0.2` and `L = 3` are starting configuration values, not optimized claims. Baseline process mean and sigma come from the calibration dataset; they are not estimated from only five live points.

### 7.3 Evidence-scoped diagnosis

The minimum hypothesis set is:

- `H0`: stable process; assembly failures occur at the nonzero design baseline.
- `H1`: slot mean shifted downward.
- `H2`: tab mean shifted upward.
- `H4`: both means shifted toward reduced clearance.

Optional `H3` fixture/misalignment is P3 because a credible physical mechanism and likelihood model are not available in the core sprint.

Posterior updates are performed only over evidence the calling actor has locally observed or received through authorized responses. When a station is unavailable or evidence is outside the freshness window, its likelihood term is omitted and the posterior is renormalized. The UI must show evidence coverage, such as “computed from 2 of 3 stations.”

### 7.4 Targeted inspection

For candidate action `a` and possible outcomes `y`:

`IG(a) = H[p(H|E)] - sum_y p(y|a,E) * H[p(H|E,y)]`

`score(a) = IG(a) / expected_seconds(a)`

Candidate specimen IDs come from the server. An LLM may choose among them or request no action, but cannot invent an ID. The method is an application of established Bayesian experimental design, not a new information-theory algorithm.

## 8. Requested combined demonstration scenario

`configs/scenario_combined_0p100mm.yaml` specifies:

- scenario: `combined`;
- slot mean shift: `-0.100 mm`;
- tab mean shift: `+0.100 mm`;
- slot communication: `online` at the start;
- data source: `simulated`;
- pairing policy: uniform random pairing among locally accepted parts;
- outcome status: `NOT_RUN`.

Expected qualitative observations, not claimed results:

- both local EWMAs should move toward reduced clearance, though the exact alarm timing is unknown until run;
- the joint clearance-risk estimate should tend upward relative to the frozen nominal baseline;
- evidence requests and responses should complete while the slot link is online;
- the combined hypothesis should gain support if the generated evidence matches the configured shifts;
- a targeted inspection may be proposed if expected information gain exceeds the configured threshold;
- all dashboard values must be labeled simulated and tied to the seed.

Do not promise that the collaborative system beats the isolated condition at this shift magnitude. Pilot candidate shifts first because 0.100 mm may be locally detectable depending on sigma, EWMA parameters, and run length.

## 9. Validation design

### Experiment A: collective capability under full connectivity

Compare:

- isolated station actors with peer requests disabled;
- centralized system with all raw evidence;
- QualityRelay peer evidence exchange.

Use the same core, scenario streams, inspection budget, and seeds. Primary interpretation: QualityRelay may recover much of centralized performance with less raw-data access and a traceable communication budget. Do not claim it should beat the centralized upper bound.

### Experiment B: resilience to information topology

A 2×2 design:

| Topology | Always on | Intermittent link |
|---|---|---|
| Centralized hub | upper-bound reference | hub/link degradation |
| Decentralized peer mesh | normal QualityRelay | local continuity + partial evidence + reconciliation |

The hub’s coordinator-failure test is deliberately asymmetric: a peer mesh has no single coordinator to fail. State this rather than pretending the cells are identical.

### Metrics

- fault-hypothesis accuracy on simulated ground truth;
- detection delay in units after injected change;
- assembly-risk Brier score on simulated runs only;
- number and time cost of physical/simulated inspections;
- raw records exposed across station boundaries;
- message count and bytes;
- evidence coverage at decision time;
- duplicate-event count after reconnect;
- unauthorized access attempts denied;
- physical loop completion reported descriptively, never as a calibrated percentage.

## 10. Physical evidence plan

Use a small U-slot coupon and flat tab coupon printed in white PLA. Print a safe pair, a nominal pair, and a tight-risk pair plus backups. Do not rely on CAD dimensions as ground truth. First measure one stable coupon ten times, compute repeatability standard deviation `s_r`, then choose a demonstrated clearance difference comfortably larger than measurement noise. A 3–5× `s_r` rule is a screening heuristic, not a full gauge R&R study.

Two or three physical pairings close the loop; they do not validate the predicted probability. Simulation supplies repeated, seeded ground truth. Physical and simulated metrics must be shown in separate panels.

Do not attempt a live print-redesign-reprint-refit loop. Show any corrected CAD as a next-step artifact.

## 11. Success criteria

P0 is complete only when all are true:

- one command resets the demo to a known state;
- a risk query remains pending before evidence arrives;
- unauthorized cross-station raw reads return 403 and are logged;
- the same input snapshot produces the same risk output;
- all numeric UI statements are server-rendered from structured results;
- candidate IDs are whitelisted;
- link loss changes evidence coverage visibly without deleting history;
- reconnect produces zero duplicate events;
- a physical caliper entry is stored with `origin.kind = physical`;
- a simulated benchmark record includes seed and generator version;
- no chart combines physical and simulated observations into one unlabeled metric;
- the deterministic fallback performs the complete demo without an LLM.

## 12. Milestones and cut lines

| Milestone | Active-hour deadline | Acceptance condition | Cut if missed |
|---|---:|---|---|
| M0 scope/interface freeze | H1 | schemas, role boundaries, scenario IDs fixed | remove alternative-lot and disagreement branches |
| M1 deterministic core | H6 | clearance, EWMA, diagnosis, inspection tests pass | remove Bayesian extras; keep risk + fixed inspection |
| M2 minimum viable demo | H12 | reset → query → evidence → risk → inspection → update | LLM removed from critical path |
| M3 decentralized proof | H18 | 403 test, scoped posterior, offline queue, idempotent replay | use recorded outage clip; keep live evidence exchange |
| M4 experiment freeze | H23 | pilot selects shift rule; matrix and seeds frozen | reduce to 3 seeds and label exploratory |
| M5 feature freeze | H25 | full run completes twice | no new features |
| M6 submission ready | H29 | slides, repository, manifest, backup clip, 2 rehearsals | polish only |

## 13. ScienceClaw rubric alignment

| Rubric | Evidence to show |
|---|---|
| Problem significance, 20% | relational tolerance-stack failure across data silos; preventable scrap/rework risk |
| Scientific/technical impact, 25% | prospective lot-pair risk, targeted inspection, traceable decision; results shown only after execution |
| Decentralized agency, 20% | station-local data/authority, explicit evidence requests, no decision-making router, offline local continuity |
| Collective capability, 25% | same-core comparison against isolated and centralized conditions; link-fault experiment |
| Execution/validation, 10% | functioning vertical loop, seeded experiments, physical caliper input, negative permission test, replay manifest |
| Optional collaboration bonus | another team actually reuses the event schema, replay dataset, or tool; usage is documented |

## 14. Honest closing claim template

Fill brackets only after measured runs:

> Using the same statistical core and inspection budget, QualityRelay’s independently authorized station agents evaluated an upcoming compatibility risk through selective evidence exchange, requested a targeted inspection, and retained local operation during a communication interruption. In seeded simulation, the collaborative condition [measured result with uncertainty]. In the physical demonstration, [descriptive observed loop outcome]. These results demonstrate a hackathon prototype, not industrial validation.



---

---

# APPENDIX B — Executable reference source (same files shipped separately in ZIP)

## `implementation/qualityrelay10/core.py`

```python
"""Demonstration-only physical math. No industrial calibration or safety certificate."""
from __future__ import annotations
from dataclasses import dataclass
import hashlib, json, math, random, statistics

SLOT_LIMITS = (20.5, 21.5)
TAB_LIMITS = (19.5, 20.5)
MIN_CLEARANCE = 0.5


def stable_seed(*items: object) -> int:
    encoded = json.dumps(items, sort_keys=True, default=str).encode()
    return int.from_bytes(hashlib.sha256(encoded).digest()[:8], 'big')


def summary(values: list[float], measurement_ids: list[str], origin: str) -> dict:
    if len(values) < 5:
        raise ValueError('at least five observations required for the demo')
    if len(values) != len(measurement_ids):
        raise ValueError('measurement_ids do not match readings')
    return {'n': len(values), 'mean_mm': round(statistics.mean(values), 6),
            'std_mm': round(statistics.stdev(values), 6),
            'measurement_ids': measurement_ids[:], 'origin': origin,
            'calibration_status': 'not_verified'}


def fit_risk(slot: dict, tab: dict, seed: int, iterations: int = 12000) -> dict:
    """Seeded demonstration Monte Carlo, CONDITIONED on both parts passing local specs.

    This uses independent, uncalibrated fitted normals with a sigma floor. Real
    manufacturing requires uncertainty propagation, correlation and MSA.
    """
    if iterations < 1000:
        raise ValueError('iteration count too low')
    rng = random.Random(seed)
    mean_w, mean_t = slot['mean_mm'], tab['mean_mm']
    sd_w, sd_t = max(slot['std_mm'], 0.035), max(tab['std_mm'], 0.035)
    fails = 0
    accepted = 0
    rejection = 0
    for _ in range(iterations):
        # Draw-until-accepted from the UNTRUNCATED fitted Gaussian: truncated model.
        for tries in range(10000):
            w = rng.gauss(mean_w, sd_w)
            t = rng.gauss(mean_t, sd_t)
            if SLOT_LIMITS[0] <= w <= SLOT_LIMITS[1] and TAB_LIMITS[0] <= t <= TAB_LIMITS[1]:
                break
            rejection += 1
        else:
            raise ValueError('conditioning event too rare; abort instead of inventing result')
        accepted += 1
        if w - t < MIN_CLEARANCE:
            fails += 1
    p = fails / accepted
    se = math.sqrt(max(p * (1 - p), 0) / accepted)
    return {'risk_probability': round(p, 6), 'mc_95pct_interval_approx':
            [round(max(0, p - 1.96 * se), 6), round(min(1, p + 1.96 * se), 6)],
            'effective_simulations': accepted, 'rejected_draws': rejection,
            'independence_assumed': True, 'measurement_uncertainty_modeled': False,
            'calibration_status': 'not_verified',
            'interval_warning': 'MC sampling error only, NOT uncertainty in fitted process parameters',
            'scope': 'SIMULATED MODEL OUTPUT; not factory-calibrated risk'}


def inspect_clearance(slot_width: float, tab_thickness: float) -> dict:
    if not all(math.isfinite(x) for x in (slot_width, tab_thickness)):
        raise ValueError('finite numbers required')
    clearance = slot_width - tab_thickness
    return {'clearance_mm': round(clearance, 5),
            'slot_local_pass': SLOT_LIMITS[0] <= slot_width <= SLOT_LIMITS[1],
            'tab_local_pass': TAB_LIMITS[0] <= tab_thickness <= TAB_LIMITS[1],
            'functional_fit_pass_by_width_only': clearance >= MIN_CLEARANCE,
            'caveat': 'Other geometric, force and process effects are not assessed'}

```

## `implementation/qualityrelay10/state.py`

```python
"""Local autonomous station actors + hash-chained demo event log.
NOT a production database, signature PKI or secure deployment.
"""
from __future__ import annotations
import datetime, hashlib, json, random, uuid
from .core import summary, stable_seed


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


class Station:
    def __init__(self, name: str, mean: float, sd: float, seed: int):
        self.name = name
        rng = random.Random(seed)
        self.measurements = [
            {'id': f'{name}-seed-{i}', 'value_mm': round(rng.gauss(mean, sd), 4),
             'origin': 'simulated', 'at': now()} for i in range(7)
        ]
        self.online = True
        self.pending: list[dict] = []

    def local_add(self, value: float, origin: str, instrument_id: str) -> dict:
        m = {'id': str(uuid.uuid4()), 'value_mm': float(value), 'origin': origin,
             'instrument_id': instrument_id, 'at': now()}
        self.measurements.append(m)
        if not self.online:
            self.pending.append({'kind': 'measurement-added', 'measurement_id': m['id']})
        return m

    def allowed_summary(self) -> dict:
        data = self.measurements[-7:]
        origins = {m['origin'] for m in data}
        kind = origins.pop() if len(origins) == 1 else 'mixed'
        return summary([m['value_mm'] for m in data], [m['id'] for m in data], kind)


class Audit:
    def __init__(self):
        self.events: list[dict] = []
        self.ids: set[str] = set()

    def append(self, event_type: str, actor: str, payload: dict, event_id: str | None = None) -> dict:
        ident = event_id or str(uuid.uuid4())
        if ident in self.ids:
            return next(x for x in self.events if x['id'] == ident)
        previous = self.events[-1]['hash'] if self.events else 'GENESIS'
        event = {'id': ident, 'type': event_type, 'actor': actor,
                 'payload': payload, 'timestamp_utc': now(), 'previous_hash': previous}
        event['hash'] = hashlib.sha256(json.dumps(event, sort_keys=True).encode()).hexdigest()
        self.events.append(event)
        self.ids.add(ident)
        return event

    def validate(self) -> bool:
        prev = 'GENESIS'
        for event in self.events:
            x = {k: v for k, v in event.items() if k != 'hash'}
            if event['previous_hash'] != prev or hashlib.sha256(json.dumps(x, sort_keys=True).encode()).hexdigest() != event['hash']:
                return False
            prev = event['hash']
        return True


class DemoState:
    def __init__(self):
        self.stations = {
          'slot': Station('slot', 20.92, 0.09, stable_seed('slot', 26)),
          'tab': Station('tab', 20.08, 0.09, stable_seed('tab', 26)),
          'assembly': Station('assembly', 0.85, 0.05, stable_seed('assembly', 26)),
        }
        self.chief_online = True
        self.incidents: dict[str, dict] = {}
        self.audit = Audit()

    def reset(self):
        self.__init__()

    def new_incident(self, slot_lot: str, tab_lot: str) -> dict:
        if not slot_lot or not tab_lot:
            raise ValueError('both lot IDs required')
        ident = str(uuid.uuid4())
        inc = {'id': ident, 'lot_ids': {'slot': slot_lot, 'tab': tab_lot},
               'evidence': {}, 'status': 'pending_insufficient_evidence',
               'approval': 'pending', 'approved_action': None, 'created_at': now()}
        self.incidents[ident] = inc
        self.audit.append('incident-created', 'assembly', {'incident_id': ident})
        return inc

    def request_station_summary(self, ident: str, station: str) -> dict:
        inc = self.incidents[ident]
        target = self.stations[station]
        if station not in ('slot', 'tab'):
            raise ValueError('only slot and tab summaries allowed')
        if not target.online:
            self.audit.append('summary-deferred', station, {'incident_id': ident})
            return {'station': station, 'status': 'unavailable', 'coverage': len(inc['evidence'])}
        payload = target.allowed_summary()
        ev = self.audit.append('authorized-summary', station, {'incident_id': ident, 'station': station,
           'summary': {k: v for k, v in payload.items() if k != 'measurement_ids'},
           'source_measurement_ids': payload['measurement_ids']})
        inc['evidence'][station] = {**payload, 'event_id': ev['id'], 'timestamp_utc': ev['timestamp_utc']}
        inc['status'] = 'ready_for_model' if len(inc['evidence']) == 2 else 'partial_evidence'
        return {'station': station, 'status': 'received', 'evidence_event_id': ev['id'],
                'coverage': len(inc['evidence'])}

    def toggle_link(self, station: str, online: bool) -> dict:
        s = self.stations[station]
        was = s.online
        s.online = bool(online)
        # Any prior remote summary is no longer current across a link change.
        # Require a fresh authorized response after reconnect.
        for inc in self.incidents.values():
            if station in inc['evidence']:
                del inc['evidence'][station]
                inc['status'] = 'partial_evidence'
        count = len(s.pending) if online else 0
        if online:
            for pending in s.pending:
                self.audit.append('queued-local-event-replayed', station, pending,
                                  event_id='replay:' + pending['measurement_id'])
            s.pending.clear()
        self.audit.append('station-link-changed', station, {'was_online': was, 'online': online, 'replayed': count})
        return {'station': station, 'online': online, 'replayed': count}

```

## `implementation/qualityrelay10/agents.py`

```python
"""Registered AI-specialist responsibilities with an executable narrow deterministic subset.
Chief is NOT an autonomous factory actuator or omniscient raw-data reader.
"""
from __future__ import annotations
from .core import inspect_clearance, fit_risk, stable_seed, SLOT_LIMITS, TAB_LIMITS, MIN_CLEARANCE

ROLES = [
 ('design_geometry','Design Geometry'),('tolerance','Tolerance Analyst'),
 ('materials','Materials Engineer'),('process','Process Engineer'),
 ('cnc','CNC Machining Expert'),('additive','Additive Manufacturing Expert'),
 ('metrology','Metrology Expert'),('spc','SPC Expert'),
 ('quality','Quality Inspector'),('assembly','Assembly Engineer'),
 ('causal','Causal Diagnosis'),('bayesian','Bayesian Statistician'),
 ('inspection','Inspection Planner'),('operations','Operations Research'),
 ('maintenance','Maintenance Engineer'),('supplier','Supplier Boundary'),
 ('safety','Safety and Governance'),('privacy','Cybersecurity and Privacy'),
 ('reliability','Reliability and Network'),('audit','Scientific Auditor'),
]
EXECUTABLE = {'design_geometry','tolerance','metrology','quality','assembly','safety','reliability','audit'}


def registry():
    return [{'id': slug, 'name': name,
             'status': 'deterministic_reference_tool' if slug in EXECUTABLE else 'specification_only',
             'authority': 'recommendation_only'} for slug, name in ROLES]


def peer_assessment(incident: dict) -> dict:
    coverage = sorted(incident['evidence'])
    missing = sorted({'slot','tab'} - set(coverage))
    tasks = [
      {'specialist': 'design_geometry', 'task': 'Check clearance requirement and drawing revision', 'status':'rule_checked'},
      {'specialist': 'quality', 'task':'Verify local acceptance and provenance', 'status':'rule_checked'},
      {'specialist': 'metrology', 'task':'Flag missing instrument calibration evidence', 'status':'unverified'},
    ]
    if missing:
        return {'status': 'ABSTAIN_PENDING_EVIDENCE', 'evidence_coverage':len(coverage),
                'missing':missing, 'tasks':tasks,'proposal':'hold_or_request_evidence',
                'human_approval_required':True, 'reason':'Cannot compute joint risk with missing station evidence'}
    slot, tab = incident['evidence']['slot'], incident['evidence']['tab']
    seed = stable_seed(incident['id'], slot['event_id'], tab['event_id'],'v10-demo-v1')
    risk = fit_risk(slot,tab,seed)
    origin_summary = {'slot':slot['origin'], 'tab':tab['origin']}
    risk['input_evidence_origin'] = origin_summary
    risk['physical_validation_claimed'] = False
    indicative = inspect_clearance(slot['mean_mm'],tab['mean_mm'])
    # Prototype conservative gate: absence of calibration -> no production release.
    tasks.append({'specialist':'assembly', 'task':'Compute joint truncated-normal model fit risk', 'status':'computed'})
    tasks.append({'specialist':'tolerance', 'task':'Check mean compatibility', 'status':'computed'})
    return {'status':'REVIEW_ONLY_MIXED_EVIDENCE' if 'mixed' in origin_summary.values() else 'REVIEW_ONLY_UNCALIBRATED', 'evidence_coverage':2,
            'missing':[], 'tasks':tasks,'risk_model':risk,
            'illustrative_mean_fit': indicative,
            'proposal':'inspect_and_request_human_review',
            'human_approval_required':True,
            'reason':'Model is uncalibrated; no production release authorized'}


def chief_review(incident: dict) -> dict:
    """Delegation facade, not a separate numeric truth source."""
    d=peer_assessment(incident)
    return {**d, 'coordination_mode':'chief_bounded',
            'chief_authority':'advisory_only', 'chief_raw_db_access':False}


def run_reference_specialist(role: str, incident: dict, audit_valid: bool = True) -> dict:
    """Eight REAL deterministic reference handlers. Others remain specification-only.

    No handler controls machinery. Output uses only authorized incident summaries.
    """
    if role not in EXECUTABLE:
        raise ValueError('role has no executable reference handler')
    ev=incident['evidence'];slot=ev.get('slot');tab=ev.get('tab')
    base={'specialist':role,'status':'evaluated','scope':'demo_or_research_only'}
    if role=='design_geometry':
        return {**base, 'slot_spec_mm':SLOT_LIMITS,'tab_spec_mm':TAB_LIMITS,
                'min_clearance_mm':MIN_CLEARANCE,'cad_revision':'not_provided'}
    if role=='reliability':
        return {**base,'evidence_coverage':len(ev),'missing':sorted({'slot','tab'}-set(ev))}
    if role=='audit':
        return {**base,'hash_chain_valid':audit_valid,'requires_external_signature_validation':True}
    if role=='metrology':
        return {**base,'instrument_calibration_verified':False,
                'request':'gauge calibration and repeated measurement study'}
    if role=='safety':
        return {**base,'production_release_permitted':False,
                'reason':'no real-model calibration, no authenticated production approval'}
    if role=='quality':
        return {**base, 'slot_mean_local_pass':None if not slot else SLOT_LIMITS[0]<=slot['mean_mm']<=SLOT_LIMITS[1],
                'tab_mean_local_pass':None if not tab else TAB_LIMITS[0]<=tab['mean_mm']<=TAB_LIMITS[1],
                'caveat':'mean pass is not a per-specimen acceptance certificate'}
    if slot is None or tab is None:
        return {**base,'status':'abstain_missing_authorized_evidence'}
    if role=='assembly':
        return {**base,'fit':inspect_clearance(slot['mean_mm'],tab['mean_mm'])}
    if role=='tolerance':
        return {**base,'risk':fit_risk(slot,tab,stable_seed(incident['id'],slot['event_id'],tab['event_id'],'specialist-tolerance'))}
    raise AssertionError('unhandled role')

```

## `implementation/qualityrelay10/decision_value_prototype.py`

```python
#!/usr/bin/env python3
"""Small deterministic reference implementation of *proposed* decision-aware inspection.
Research-only toy model; NOT calibrated to factory data, NOT an industrial controller.
No LLM computations of probability; all evidence is explicit, scoped, and numeric.
"""
from dataclasses import dataclass
from typing import Dict, Sequence
import json

H=('stable','slot_shift','tab_shift','both_shift')
BAD_PROB={'stable':0.015,'slot_shift':0.22,'tab_shift':0.22,'both_shift':0.68}
# Pr(inspection reports an anomaly | hypothesis), demonstrator inputs only:
TESTS={
 'slot_summary':{'stable':0.08,'slot_shift':0.90,'tab_shift':0.08,'both_shift':0.90},
 'tab_summary': {'stable':0.08,'slot_shift':0.08,'tab_shift':0.90,'both_shift':0.90},
 'assembly_fit':{'stable':0.02,'slot_shift':0.24,'tab_shift':0.24,'both_shift':0.70},
 'uninformative':{h:0.5 for h in H},
}
COSTS={'slot_summary':0.07,'tab_summary':0.07,'assembly_fit':0.25,'uninformative':0.01}
FAIL_COST=10.0; HOLD_COST=1.5

@dataclass(frozen=True)
class Recommendation:
    action: str
    expected_loss: float
    evidence_ids: tuple=()

def normalize(prior:Dict[str,float]):
    assert set(prior)==set(H) and all(v>=0 for v in prior.values()) and sum(prior.values())>0
    z=sum(prior.values());return {h:prior[h]/z for h in H}

def posterior(prior,inspection,result_anomaly):
    prior=normalize(prior)
    probs=TESTS[inspection]
    weighted={h:p*(probs[h] if result_anomaly else 1-probs[h]) for h,p in prior.items()}
    return normalize(weighted)

def decision_loss(prior):
    p=normalize(prior);bad=sum(p[h]*BAD_PROB[h] for h in H)
    losses={'release':bad*FAIL_COST, 'hold':(1-bad)*HOLD_COST}
    a=min(losses,key=lambda x:(losses[x],x))
    return Recommendation(a,losses[a])

def inspect_value(prior,inspection):
    p=normalize(prior); probs=TESTS[inspection]
    p_anomaly=sum(p[h]*probs[h] for h in H)
    before=decision_loss(p).expected_loss
    after=(p_anomaly*decision_loss(posterior(p,inspection,True)).expected_loss+
      (1-p_anomaly)*decision_loss(posterior(p,inspection,False)).expected_loss)
    evsi=before-after
    net=evsi-COSTS[inspection]
    return {'inspection':inspection,'evsi':evsi,'inspection_cost':COSTS[inspection],
            'net_decision_value':net,'anomaly_probability':p_anomaly}

def choose_next(prior,available:Sequence[str]):
    vals=[inspect_value(prior,a) for a in available]
    vals.sort(key=lambda x:(-x['net_decision_value'],x['inspection']))
    current=decision_loss(prior)
    if not vals or vals[0]['net_decision_value']<=1e-12:
        return {'recommendation':'no_additional_measurement','action_if_no_more_evidence':current.action,
                'current_expected_loss':current.expected_loss,'candidates':vals,'basis':'toy model'}
    return {'recommendation':vals[0]['inspection'],'action_if_no_more_evidence':current.action,
            'current_expected_loss':current.expected_loss,'candidates':vals,'basis':'toy model'}

if __name__=='__main__':
    p={'stable':.68,'slot_shift':.15,'tab_shift':.12,'both_shift':.05}
    print(json.dumps({'prior':p,'decision':decision_loss(p).__dict__,
      'next':choose_next(p,['slot_summary','tab_summary','assembly_fit','uninformative'])},indent=2))

```

## `implementation/qualityrelay10/benchmark_toy.py`

```python
#!/usr/bin/env python3
"""Reproducible matched-budget toy benchmark; not evidence of factory improvement."""
import csv,random,math,json,pathlib
from .decision_value_prototype import H,TESTS,COSTS,BAD_PROB,FAIL_COST,HOLD_COST,posterior,decision_loss,inspect_value

def entropy(p):return -sum(x*math.log(x) for x in p.values() if x>0)
def expected_ig(p,a):
 pr=sum(p[h]*TESTS[a][h] for h in H)
 return entropy(p)-pr*entropy(posterior(p,a,True))-(1-pr)*entropy(posterior(p,a,False))
def sample(p,rng):
 u=rng.random(); z=0
 for h in H:
  z+=p[h]
  if u<=z:return h
 return H[-1]
def score_action(action,truth):
 return BAD_PROB[truth]*FAIL_COST if action=='release' else (1-BAD_PROB[truth])*HOLD_COST

def run(n=3000,seed=20261030):
 rng=random.Random(seed);results=[]
 candidates=['slot_summary','tab_summary'] # Identical inspection cost and same one-step budget
 for i in range(n):
  weights=[rng.gammavariate(v,1) for v in (8.0,1.5,1.5,1.0)];total=sum(weights)
  prior={h:weights[j]/total for j,h in enumerate(H)}
  true_h=sample(prior,rng)
  u_slot,u_tab=rng.random(),rng.random()  # common random numbers for policy comparisons
  obs={'slot_summary':u_slot<TESTS['slot_summary'][true_h],
       'tab_summary':u_tab<TESTS['tab_summary'][true_h]}
  methods={
   'vder_evsi':max(candidates,key=lambda a:(inspect_value(prior,a)['evsi'],-candidates.index(a))),
   'entropy_ig':max(candidates,key=lambda a:(expected_ig(prior,a),-candidates.index(a))),
   'random_inspection':rng.choice(candidates),
   'fixed_slot':candidates[0],
   'no_inspection':None,
  }
  for name,choice in methods.items():
   post=posterior(prior,choice,obs[choice]) if choice else prior
   action=decision_loss(post).action
   results.append(dict(episode=i,method=name,inspection=choice or '',decision=action,
                       expected_ground_truth_loss=score_action(action,true_h)+(COSTS[choice] if choice else 0),
                       inspection_cost=COSTS[choice] if choice else 0))
 import statistics
 result={}
 for method in methods:
  vals=[r for r in results if r['method']==method]
  result[method]={'episodes':len(vals),'mean_simulated_loss':round(statistics.mean(r['expected_ground_truth_loss'] for r in vals),6),
  'mean_inspection_cost':round(statistics.mean(r['inspection_cost'] for r in vals),6),
  'hold_rate':round(sum(r['decision']=='hold' for r in vals)/len(vals),6)}
 return result,results

if __name__=='__main__':
 out=pathlib.Path(__file__).resolve().parents[2]/'results';out.mkdir(exist_ok=True)
 stats,rows=run()
 (out/'reproduced_toy_benchmark_results.json').write_text(json.dumps({'strict_disclaimer':'TOY SIMULATION ONLY; not a manufacturing validation, not a novel discovery','seed':20261030,'methods':stats},indent=2))
 with (out/'reproduced_toy_benchmark_trials.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
 print(json.dumps(stats,indent=2))

```

## `implementation/qualityrelay10/api.py`

```python
"""Local demo HTTP API. Never connect to manufacturing actuators.
Run: uvicorn qualityrelay10.api:app --reload --port 8000
"""
from __future__ import annotations
import math
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field
from fastapi.middleware.cors import CORSMiddleware
from .agents import registry, chief_review, peer_assessment, run_reference_specialist
from .state import DemoState
from .decision_value_prototype import choose_next, decision_loss

app=FastAPI(title='QualityRelay 10 — UNCALIBRATED Research Prototype', version='0.1.0')
# Dev same-origin static frontend is mounted separately; no open cross-origin access.
state=DemoState()

class IncidentIn(BaseModel):
    slot_lot: str = Field(min_length=1)
    tab_lot: str = Field(min_length=1)

class MeasurementIn(BaseModel):
    station: str
    value_mm: float
    instrument_id: str = Field(min_length=1)
    origin: str = 'physical_self_reported'

class ApprovalIn(BaseModel):
    actor_role: str
    proposed_action: str
    note: str = Field(min_length=1)

class LinkIn(BaseModel):
    online: bool

class DissentIn(BaseModel):
    specialist: str
    counterevidence_event_ids: list[str]
    claim: str = Field(min_length=5)


def get_incident(ident):
    if ident not in state.incidents:
        raise HTTPException(404,'unknown incident')
    return state.incidents[ident]

@app.post('/api/reset')
def reset():
    state.reset()
    return {'status':'reset','disclaimer':'local simulated state only'}

@app.get('/api/agents')
def agents():
    return {'specialists':registry(),'station_actors':['slot','tab','assembly'],
            'chief':'recommendation_only', 'implemented_specialist_count':8}

@app.post('/api/incidents')
def new_incident(data:IncidentIn):
    return state.new_incident(data.slot_lot,data.tab_lot)

@app.get('/api/incidents/{ident}')
def incident(ident:str):
    inc=get_incident(ident)
    return {k:v for k,v in inc.items() if k != 'evidence'} | {
      'evidence_coverage':len(inc['evidence']), 'evidence_event_ids':
          [e['event_id'] for e in inc['evidence'].values()]}

@app.post('/api/incidents/{ident}/evidence/{station}')
def evidence(ident:str, station:str):
    get_incident(ident)
    if station not in ('slot','tab'):
        raise HTTPException(400,'unknown station')
    return state.request_station_summary(ident,station)

@app.get('/api/incidents/{ident}/chief')
def chief(ident:str):
    inc=get_incident(ident)
    if not state.chief_online:
        raise HTTPException(503,'chief unavailable; use peer-review')
    return chief_review(inc)

@app.post('/api/chief/link')
def chief_link(data:LinkIn):
    state.chief_online=bool(data.online)
    state.audit.append('chief-link-changed','system',{'online':state.chief_online})
    return {'chief_online':state.chief_online,'station_services_unchanged':True}

@app.get('/api/incidents/{ident}/peer-review')
def peer_review(ident:str):
    inc=get_incident(ident)
    d=peer_assessment(inc)
    return {**d, 'coordination_mode':'peer_only', 'works_without_chief':True}

@app.get('/api/incidents/{ident}/specialists/{role}')
def specialist(ident:str,role:str):
    inc=get_incident(ident)
    try:
        return run_reference_specialist(role,inc,state.audit.validate())
    except ValueError:
        raise HTTPException(501,'not implemented as an executable specialist')

@app.get('/api/stations/{station}/raw')
def raw(station:str, actor_role:str=Query(...)):
    if station not in state.stations:
        raise HTTPException(404,'unknown station')
    # NOTE: mock role header/parameter for a local, untrusted demo ONLY.
    if actor_role!=f'{station}_operator':
        state.audit.append('forbidden-raw-read','api',{'station':station, 'role':actor_role})
        raise HTTPException(403,'cross-station raw read forbidden')
    return {'station':station,'measurements':state.stations[station].measurements}

@app.post('/api/stations/{station}/link')
def link(station:str, data:LinkIn):
    if station not in state.stations:
        raise HTTPException(404,'unknown station')
    return state.toggle_link(station,data.online)

@app.post('/api/measurements')
def measurements(data:MeasurementIn):
    if data.station not in ('slot','tab'):
        raise HTTPException(400,'invalid measuring station')
    if not math.isfinite(data.value_mm):
        raise HTTPException(400,'measurement must be finite')
    if data.origin!='physical_self_reported':
        raise HTTPException(400,'only physical_self_reported allowed on this endpoint')
    reading=state.stations[data.station].local_add(data.value_mm, data.origin,data.instrument_id)
    # Existing evidence for this station has changed: invalidate cache.
    for inc in state.incidents.values():
        if data.station in inc['evidence']:
            del inc['evidence'][data.station]
            inc['status']='partial_evidence'
    state.audit.append('physical-self-report',data.station,{'id':reading['id'], 'origin':reading['origin']})
    return reading

@app.post('/api/incidents/{ident}/challenge')
def challenge(ident:str, data:DissentIn):
    get_incident(ident)
    known=set(state.audit.ids)
    if not data.counterevidence_event_ids or not set(data.counterevidence_event_ids).issubset(known):
        raise HTTPException(400,'challenge needs real evidence event IDs')
    record=state.audit.append('protected-expert-challenge',data.specialist,
                              {'incident_id':ident,'claim':data.claim,
                               'counterevidence_event_ids':data.counterevidence_event_ids})
    return {'status':'requires_independent_verification','challenge_event_id':record['id'],
            'not_voted_away':True}

@app.post('/api/incidents/{ident}/approve')
def approve(ident:str,data:ApprovalIn):
    inc=get_incident(ident)
    if data.actor_role!='human_engineer':
        raise HTTPException(403,'human engineering approval required')
    if data.proposed_action not in ('hold','inspect','request_more_evidence'):
        raise HTTPException(422,'uncalibrated demo prohibits automatic production release')
    ev=state.audit.append('human-approved-decision',data.actor_role,
                          {'incident_id':ident,'action':data.proposed_action,'note':data.note})
    inc['approval']='approved_by_human';inc['approved_action']=data.proposed_action
    return {'status':inc['approval'],'audit_event_id':ev['id'], 'no_machine_actuation':True}

@app.get('/api/research/one_step_vder')
def research():
    p={'stable':.68,'slot_shift':.15,'tab_shift':.12,'both_shift':.05}
    return {'model':'four-hypothesis TOY only','prior':p,'decision':decision_loss(p).__dict__,
            'plan':choose_next(p,['slot_summary','tab_summary','assembly_fit','uninformative']),
            'not_connected_to_physical_risk_engine':True}

@app.get('/api/audit')
def audit():
    return {'events':state.audit.events,'hash_chain_valid':state.audit.validate(),
            'note':'hash chain is NOT a cryptographic signature or tamper-proof database'}

# Static research demo is last: all /api endpoints above take priority.
from pathlib import Path
from fastapi.staticfiles import StaticFiles
app.mount('/', StaticFiles(directory=str(Path(__file__).resolve().parents[1] / 'web'), html=True), name='research-demo')

```

## `implementation/requirements.txt`

```text
fastapi>=0.115,<1
uvicorn>=0.30,<1
httpx>=0.27,<1

```

> The runnable HTML client and tests are shipped as separate files inside the ZIP; all API behavior, assumptions and implementation requirements are documented above.
