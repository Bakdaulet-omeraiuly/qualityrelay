# QualityRelay 10.0 — START HERE

**Open this first:** `QUALITYRELAY_10_FINAL_INTEGRATED_MASTER_BLUEPRINT.md`. This is one final combined research + architecture + implementation Markdown, including the original 5.0 master blueprint as Appendix A and the reference backend source as Appendix B.

## What is genuine in this package?

- 15 end-to-end, mathematical and security behavior tests ran successfully in the local **demonstration** context. See `results/IMPLEMENTATION_TESTS.txt`.
- One runnable FastAPI + HTML research demonstration for three station actors, 20 role registry entries, eight executable reference handlers, bounded Chief, Chief-off peer assessment, offline measurement queue, scoped evidence, mock 403 denial, mock human approval, audit hash chain, fit simulation and a **separate** toy EVSI planner.
- The prior 3,000-incident simulation was independently reproduced from the included code with matching summary outputs. It found **no persuasive advantage** of V-DER over entropy IG in that toy setting.
- Preserved original QualityRelay 5.0 archive and 9.0 program; a copy of the 8.0 blueprint.

## What is NOT included/NOT proven?

- Not 10,000 downloaded, read or peer-screened papers; only a 10,000-metadata-record *collection program* and curated starting leads.
- Not scientifically established first-in-world novelty or statistically demonstrated V-DER superiority.
- Not twenty deployed LLM specialist workers, secure industrial authentication, calibrated metrology, factory pilot or production safe operation.
- Do NOT deploy the demo publicly or use it for real production release decisions.

## Run demo locally

```bash
cd implementation
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
uvicorn qualityrelay10.api:app --host 127.0.0.1 --port 8000
```

Visit `http://127.0.0.1:8000`; API docs at `/docs`.

To reproduce prior toy benchmark:

```bash
# from implementation folder, with .venv active
python -m qualityrelay10.benchmark_toy
```

To retrieve metadata candidates on a networked laptop, from the release root:

```bash
python3 research/collect_10000.py --target 10000 --output research/corpus
```

This requires Internet access and may need API throttling, verification and manual screening. It does NOT automatically review 10,000 scientific studies.

## Work ownership

- `Bakdaulet-omeraiuly`: statistics, research literature, fair baselines, results.
- `adilnurgg`: backend, security/permissions, Chief/peer coordination and true station-service separation.
- `HyorinmaruK`: mechanical verification, 3D parts/caliper, physical report and final presentation.
- Fourth participant if joins: frontend production UX, independent QA and connectors.

**Source-of-truth requirement:** the master MD and actual code/tests outrank earlier broad or aspirational claims about readiness.
