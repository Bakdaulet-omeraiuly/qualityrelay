"""Registered AI-specialist responsibilities with an executable narrow deterministic subset.
Chief is NOT an autonomous factory actuator or omniscient raw-data reader.
"""
from __future__ import annotations
from .core import inspect_clearance, fit_risk, stable_seed, SLOT_LIMITS, TAB_LIMITS, MIN_CLEARANCE

ROLES = [
 ('design_geometry','Design Geometry'),('tolerance','Tolerance Analyst'),
 ('materials','Materials Engineer'),('process','Process Engineer'),
 ('cnc','CNC Machining Expert'),('additive','Additive Manufacturing Expert'),
 ('metrology','Metrology Expert'),('spc','SPC Expert'),
 ('quality','Quality Inspector'),('assembly','Assembly Engineer'),
 ('causal','Causal Diagnosis'),('bayesian','Bayesian Statistician'),
 ('inspection','Inspection Planner'),('operations','Operations Research'),
 ('maintenance','Maintenance Engineer'),('supplier','Supplier Boundary'),
 ('safety','Safety and Governance'),('privacy','Cybersecurity and Privacy'),
 ('reliability','Reliability and Network'),('audit','Scientific Auditor'),
]
EXECUTABLE = {'design_geometry','tolerance','metrology','quality','assembly','safety','reliability','audit'}


def registry():
    return [{'id': slug, 'name': name,
             'status': 'deterministic_reference_tool' if slug in EXECUTABLE else 'specification_only',
             'authority': 'recommendation_only'} for slug, name in ROLES]


def peer_assessment(incident: dict) -> dict:
    coverage = sorted(incident['evidence'])
    missing = sorted({'slot','tab'} - set(coverage))
    tasks = [
      {'specialist': 'design_geometry', 'task': 'Check clearance requirement and drawing revision', 'status':'rule_checked'},
      {'specialist': 'quality', 'task':'Verify local acceptance and provenance', 'status':'rule_checked'},
      {'specialist': 'metrology', 'task':'Flag missing instrument calibration evidence', 'status':'unverified'},
    ]
    if missing:
        return {'status': 'ABSTAIN_PENDING_EVIDENCE', 'evidence_coverage':len(coverage),
                'missing':missing, 'tasks':tasks,'proposal':'hold_or_request_evidence',
                'human_approval_required':True, 'reason':'Cannot compute joint risk with missing station evidence'}
    slot, tab = incident['evidence']['slot'], incident['evidence']['tab']
    seed = stable_seed(incident['id'], slot['event_id'], tab['event_id'],'v10-demo-v1')
    risk = fit_risk(slot,tab,seed)
    origin_summary = {'slot':slot['origin'], 'tab':tab['origin']}
    risk['input_evidence_origin'] = origin_summary
    risk['physical_validation_claimed'] = False
    indicative = inspect_clearance(slot['mean_mm'],tab['mean_mm'])
    # Prototype conservative gate: absence of calibration -> no production release.
    tasks.append({'specialist':'assembly', 'task':'Compute joint truncated-normal model fit risk', 'status':'computed'})
    tasks.append({'specialist':'tolerance', 'task':'Check mean compatibility', 'status':'computed'})
    return {'status':'REVIEW_ONLY_MIXED_EVIDENCE' if 'mixed' in origin_summary.values() else 'REVIEW_ONLY_UNCALIBRATED', 'evidence_coverage':2,
            'missing':[], 'tasks':tasks,'risk_model':risk,
            'illustrative_mean_fit': indicative,
            'proposal':'inspect_and_request_human_review',
            'human_approval_required':True,
            'reason':'Model is uncalibrated; no production release authorized'}


def chief_review(incident: dict) -> dict:
    """Delegation facade, not a separate numeric truth source."""
    d=peer_assessment(incident)
    return {**d, 'coordination_mode':'chief_bounded',
            'chief_authority':'advisory_only', 'chief_raw_db_access':False}


def run_reference_specialist(role: str, incident: dict, audit_valid: bool = True) -> dict:
    """Eight REAL deterministic reference handlers. Others remain specification-only.

    No handler controls machinery. Output uses only authorized incident summaries.
    """
    if role not in EXECUTABLE:
        raise ValueError('role has no executable reference handler')
    ev=incident['evidence'];slot=ev.get('slot');tab=ev.get('tab')
    base={'specialist':role,'status':'evaluated','scope':'demo_or_research_only'}
    if role=='design_geometry':
        return {**base, 'slot_spec_mm':SLOT_LIMITS,'tab_spec_mm':TAB_LIMITS,
                'min_clearance_mm':MIN_CLEARANCE,'cad_revision':'not_provided'}
    if role=='reliability':
        return {**base,'evidence_coverage':len(ev),'missing':sorted({'slot','tab'}-set(ev))}
    if role=='audit':
        return {**base,'hash_chain_valid':audit_valid,'requires_external_signature_validation':True}
    if role=='metrology':
        return {**base,'instrument_calibration_verified':False,
                'request':'gauge calibration and repeated measurement study'}
    if role=='safety':
        return {**base,'production_release_permitted':False,
                'reason':'no real-model calibration, no authenticated production approval'}
    if role=='quality':
        return {**base, 'slot_mean_local_pass':None if not slot else SLOT_LIMITS[0]<=slot['mean_mm']<=SLOT_LIMITS[1],
                'tab_mean_local_pass':None if not tab else TAB_LIMITS[0]<=tab['mean_mm']<=TAB_LIMITS[1],
                'caveat':'mean pass is not a per-specimen acceptance certificate'}
    if slot is None or tab is None:
        return {**base,'status':'abstain_missing_authorized_evidence'}
    if role=='assembly':
        return {**base,'fit':inspect_clearance(slot['mean_mm'],tab['mean_mm'])}
    if role=='tolerance':
        return {**base,'risk':fit_risk(slot,tab,stable_seed(incident['id'],slot['event_id'],tab['event_id'],'specialist-tolerance'))}
    raise AssertionError('unhandled role')
