"""Local autonomous station actors + hash-chained demo event log.
NOT a production database, signature PKI or secure deployment.
"""
from __future__ import annotations
import datetime, hashlib, json, random, uuid
from .core import summary, stable_seed


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


class Station:
    def __init__(self, name: str, mean: float, sd: float, seed: int):
        self.name = name
        rng = random.Random(seed)
        self.measurements = [
            {'id': f'{name}-seed-{i}', 'value_mm': round(rng.gauss(mean, sd), 4),
             'origin': 'simulated', 'at': now()} for i in range(7)
        ]
        self.online = True
        self.pending: list[dict] = []

    def local_add(self, value: float, origin: str, instrument_id: str) -> dict:
        m = {'id': str(uuid.uuid4()), 'value_mm': float(value), 'origin': origin,
             'instrument_id': instrument_id, 'at': now()}
        self.measurements.append(m)
        if not self.online:
            self.pending.append({'kind': 'measurement-added', 'measurement_id': m['id']})
        return m

    def allowed_summary(self) -> dict:
        data = self.measurements[-7:]
        origins = {m['origin'] for m in data}
        kind = origins.pop() if len(origins) == 1 else 'mixed'
        return summary([m['value_mm'] for m in data], [m['id'] for m in data], kind)


class Audit:
    def __init__(self):
        self.events: list[dict] = []
        self.ids: set[str] = set()

    def append(self, event_type: str, actor: str, payload: dict, event_id: str | None = None) -> dict:
        ident = event_id or str(uuid.uuid4())
        if ident in self.ids:
            return next(x for x in self.events if x['id'] == ident)
        previous = self.events[-1]['hash'] if self.events else 'GENESIS'
        event = {'id': ident, 'type': event_type, 'actor': actor,
                 'payload': payload, 'timestamp_utc': now(), 'previous_hash': previous}
        event['hash'] = hashlib.sha256(json.dumps(event, sort_keys=True).encode()).hexdigest()
        self.events.append(event)
        self.ids.add(ident)
        return event

    def validate(self) -> bool:
        prev = 'GENESIS'
        for event in self.events:
            x = {k: v for k, v in event.items() if k != 'hash'}
            if event['previous_hash'] != prev or hashlib.sha256(json.dumps(x, sort_keys=True).encode()).hexdigest() != event['hash']:
                return False
            prev = event['hash']
        return True


class DemoState:
    def __init__(self):
        self.stations = {
          'slot': Station('slot', 20.92, 0.09, stable_seed('slot', 26)),
          'tab': Station('tab', 20.08, 0.09, stable_seed('tab', 26)),
          'assembly': Station('assembly', 0.85, 0.05, stable_seed('assembly', 26)),
        }
        self.chief_online = True
        self.incidents: dict[str, dict] = {}
        self.audit = Audit()

    def reset(self):
        self.__init__()

    def new_incident(self, slot_lot: str, tab_lot: str) -> dict:
        if not slot_lot or not tab_lot:
            raise ValueError('both lot IDs required')
        ident = str(uuid.uuid4())
        inc = {'id': ident, 'lot_ids': {'slot': slot_lot, 'tab': tab_lot},
               'evidence': {}, 'status': 'pending_insufficient_evidence',
               'approval': 'pending', 'approved_action': None, 'created_at': now()}
        self.incidents[ident] = inc
        self.audit.append('incident-created', 'assembly', {'incident_id': ident})
        return inc

    def request_station_summary(self, ident: str, station: str) -> dict:
        inc = self.incidents[ident]
        target = self.stations[station]
        if station not in ('slot', 'tab'):
            raise ValueError('only slot and tab summaries allowed')
        if not target.online:
            self.audit.append('summary-deferred', station, {'incident_id': ident})
            return {'station': station, 'status': 'unavailable', 'coverage': len(inc['evidence'])}
        payload = target.allowed_summary()
        ev = self.audit.append('authorized-summary', station, {'incident_id': ident, 'station': station,
           'summary': {k: v for k, v in payload.items() if k != 'measurement_ids'},
           'source_measurement_ids': payload['measurement_ids']})
        inc['evidence'][station] = {**payload, 'event_id': ev['id'], 'timestamp_utc': ev['timestamp_utc']}
        inc['status'] = 'ready_for_model' if len(inc['evidence']) == 2 else 'partial_evidence'
        return {'station': station, 'status': 'received', 'evidence_event_id': ev['id'],
                'coverage': len(inc['evidence'])}

    def toggle_link(self, station: str, online: bool) -> dict:
        s = self.stations[station]
        was = s.online
        s.online = bool(online)
        # Any prior remote summary is no longer current across a link change.
        # Require a fresh authorized response after reconnect.
        for inc in self.incidents.values():
            if station in inc['evidence']:
                del inc['evidence'][station]
                inc['status'] = 'partial_evidence'
        count = len(s.pending) if online else 0
        if online:
            for pending in s.pending:
                self.audit.append('queued-local-event-replayed', station, pending,
                                  event_id='replay:' + pending['measurement_id'])
            s.pending.clear()
        self.audit.append('station-link-changed', station, {'was_online': was, 'online': online, 'replayed': count})
        return {'station': station, 'online': online, 'replayed': count}
