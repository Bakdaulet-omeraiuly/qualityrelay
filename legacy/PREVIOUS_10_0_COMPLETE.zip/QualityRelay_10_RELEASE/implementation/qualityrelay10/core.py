"""Demonstration-only physical math. No industrial calibration or safety certificate."""
from __future__ import annotations
from dataclasses import dataclass
import hashlib, json, math, random, statistics

SLOT_LIMITS = (20.5, 21.5)
TAB_LIMITS = (19.5, 20.5)
MIN_CLEARANCE = 0.5


def stable_seed(*items: object) -> int:
    encoded = json.dumps(items, sort_keys=True, default=str).encode()
    return int.from_bytes(hashlib.sha256(encoded).digest()[:8], 'big')


def summary(values: list[float], measurement_ids: list[str], origin: str) -> dict:
    if len(values) < 5:
        raise ValueError('at least five observations required for the demo')
    if len(values) != len(measurement_ids):
        raise ValueError('measurement_ids do not match readings')
    return {'n': len(values), 'mean_mm': round(statistics.mean(values), 6),
            'std_mm': round(statistics.stdev(values), 6),
            'measurement_ids': measurement_ids[:], 'origin': origin,
            'calibration_status': 'not_verified'}


def fit_risk(slot: dict, tab: dict, seed: int, iterations: int = 12000) -> dict:
    """Seeded demonstration Monte Carlo, CONDITIONED on both parts passing local specs.

    This uses independent, uncalibrated fitted normals with a sigma floor. Real
    manufacturing requires uncertainty propagation, correlation and MSA.
    """
    if iterations < 1000:
        raise ValueError('iteration count too low')
    rng = random.Random(seed)
    mean_w, mean_t = slot['mean_mm'], tab['mean_mm']
    sd_w, sd_t = max(slot['std_mm'], 0.035), max(tab['std_mm'], 0.035)
    fails = 0
    accepted = 0
    rejection = 0
    for _ in range(iterations):
        # Draw-until-accepted from the UNTRUNCATED fitted Gaussian: truncated model.
        for tries in range(10000):
            w = rng.gauss(mean_w, sd_w)
            t = rng.gauss(mean_t, sd_t)
            if SLOT_LIMITS[0] <= w <= SLOT_LIMITS[1] and TAB_LIMITS[0] <= t <= TAB_LIMITS[1]:
                break
            rejection += 1
        else:
            raise ValueError('conditioning event too rare; abort instead of inventing result')
        accepted += 1
        if w - t < MIN_CLEARANCE:
            fails += 1
    p = fails / accepted
    se = math.sqrt(max(p * (1 - p), 0) / accepted)
    return {'risk_probability': round(p, 6), 'mc_95pct_interval_approx':
            [round(max(0, p - 1.96 * se), 6), round(min(1, p + 1.96 * se), 6)],
            'effective_simulations': accepted, 'rejected_draws': rejection,
            'independence_assumed': True, 'measurement_uncertainty_modeled': False,
            'calibration_status': 'not_verified',
            'interval_warning': 'MC sampling error only, NOT uncertainty in fitted process parameters',
            'scope': 'SIMULATED MODEL OUTPUT; not factory-calibrated risk'}


def inspect_clearance(slot_width: float, tab_thickness: float) -> dict:
    if not all(math.isfinite(x) for x in (slot_width, tab_thickness)):
        raise ValueError('finite numbers required')
    clearance = slot_width - tab_thickness
    return {'clearance_mm': round(clearance, 5),
            'slot_local_pass': SLOT_LIMITS[0] <= slot_width <= SLOT_LIMITS[1],
            'tab_local_pass': TAB_LIMITS[0] <= tab_thickness <= TAB_LIMITS[1],
            'functional_fit_pass_by_width_only': clearance >= MIN_CLEARANCE,
            'caveat': 'Other geometric, force and process effects are not assessed'}
