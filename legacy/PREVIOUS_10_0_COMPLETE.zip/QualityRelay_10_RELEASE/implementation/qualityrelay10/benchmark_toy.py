#!/usr/bin/env python3
"""Reproducible matched-budget toy benchmark; not evidence of factory improvement."""
import csv,random,math,json,pathlib
from .decision_value_prototype import H,TESTS,COSTS,BAD_PROB,FAIL_COST,HOLD_COST,posterior,decision_loss,inspect_value

def entropy(p):return -sum(x*math.log(x) for x in p.values() if x>0)
def expected_ig(p,a):
 pr=sum(p[h]*TESTS[a][h] for h in H)
 return entropy(p)-pr*entropy(posterior(p,a,True))-(1-pr)*entropy(posterior(p,a,False))
def sample(p,rng):
 u=rng.random(); z=0
 for h in H:
  z+=p[h]
  if u<=z:return h
 return H[-1]
def score_action(action,truth):
 return BAD_PROB[truth]*FAIL_COST if action=='release' else (1-BAD_PROB[truth])*HOLD_COST

def run(n=3000,seed=20261030):
 rng=random.Random(seed);results=[]
 candidates=['slot_summary','tab_summary'] # Identical inspection cost and same one-step budget
 for i in range(n):
  weights=[rng.gammavariate(v,1) for v in (8.0,1.5,1.5,1.0)];total=sum(weights)
  prior={h:weights[j]/total for j,h in enumerate(H)}
  true_h=sample(prior,rng)
  u_slot,u_tab=rng.random(),rng.random()  # common random numbers for policy comparisons
  obs={'slot_summary':u_slot<TESTS['slot_summary'][true_h],
       'tab_summary':u_tab<TESTS['tab_summary'][true_h]}
  methods={
   'vder_evsi':max(candidates,key=lambda a:(inspect_value(prior,a)['evsi'],-candidates.index(a))),
   'entropy_ig':max(candidates,key=lambda a:(expected_ig(prior,a),-candidates.index(a))),
   'random_inspection':rng.choice(candidates),
   'fixed_slot':candidates[0],
   'no_inspection':None,
  }
  for name,choice in methods.items():
   post=posterior(prior,choice,obs[choice]) if choice else prior
   action=decision_loss(post).action
   results.append(dict(episode=i,method=name,inspection=choice or '',decision=action,
                       expected_ground_truth_loss=score_action(action,true_h)+(COSTS[choice] if choice else 0),
                       inspection_cost=COSTS[choice] if choice else 0))
 import statistics
 result={}
 for method in methods:
  vals=[r for r in results if r['method']==method]
  result[method]={'episodes':len(vals),'mean_simulated_loss':round(statistics.mean(r['expected_ground_truth_loss'] for r in vals),6),
  'mean_inspection_cost':round(statistics.mean(r['inspection_cost'] for r in vals),6),
  'hold_rate':round(sum(r['decision']=='hold' for r in vals)/len(vals),6)}
 return result,results

if __name__=='__main__':
 out=pathlib.Path(__file__).resolve().parents[2]/'results';out.mkdir(exist_ok=True)
 stats,rows=run()
 (out/'reproduced_toy_benchmark_results.json').write_text(json.dumps({'strict_disclaimer':'TOY SIMULATION ONLY; not a manufacturing validation, not a novel discovery','seed':20261030,'methods':stats},indent=2))
 with (out/'reproduced_toy_benchmark_trials.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
 print(json.dumps(stats,indent=2))
