"""Local demo HTTP API. Never connect to manufacturing actuators.
Run: uvicorn qualityrelay10.api:app --reload --port 8000
"""
from __future__ import annotations
import math
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field
from fastapi.middleware.cors import CORSMiddleware
from .agents import registry, chief_review, peer_assessment, run_reference_specialist
from .state import DemoState
from .decision_value_prototype import choose_next, decision_loss

app=FastAPI(title='QualityRelay 10 — UNCALIBRATED Research Prototype', version='0.1.0')
# Dev same-origin static frontend is mounted separately; no open cross-origin access.
state=DemoState()

class IncidentIn(BaseModel):
    slot_lot: str = Field(min_length=1)
    tab_lot: str = Field(min_length=1)

class MeasurementIn(BaseModel):
    station: str
    value_mm: float
    instrument_id: str = Field(min_length=1)
    origin: str = 'physical_self_reported'

class ApprovalIn(BaseModel):
    actor_role: str
    proposed_action: str
    note: str = Field(min_length=1)

class LinkIn(BaseModel):
    online: bool

class DissentIn(BaseModel):
    specialist: str
    counterevidence_event_ids: list[str]
    claim: str = Field(min_length=5)


def get_incident(ident):
    if ident not in state.incidents:
        raise HTTPException(404,'unknown incident')
    return state.incidents[ident]

@app.post('/api/reset')
def reset():
    state.reset()
    return {'status':'reset','disclaimer':'local simulated state only'}

@app.get('/api/agents')
def agents():
    return {'specialists':registry(),'station_actors':['slot','tab','assembly'],
            'chief':'recommendation_only', 'implemented_specialist_count':8}

@app.post('/api/incidents')
def new_incident(data:IncidentIn):
    return state.new_incident(data.slot_lot,data.tab_lot)

@app.get('/api/incidents/{ident}')
def incident(ident:str):
    inc=get_incident(ident)
    return {k:v for k,v in inc.items() if k != 'evidence'} | {
      'evidence_coverage':len(inc['evidence']), 'evidence_event_ids':
          [e['event_id'] for e in inc['evidence'].values()]}

@app.post('/api/incidents/{ident}/evidence/{station}')
def evidence(ident:str, station:str):
    get_incident(ident)
    if station not in ('slot','tab'):
        raise HTTPException(400,'unknown station')
    return state.request_station_summary(ident,station)

@app.get('/api/incidents/{ident}/chief')
def chief(ident:str):
    inc=get_incident(ident)
    if not state.chief_online:
        raise HTTPException(503,'chief unavailable; use peer-review')
    return chief_review(inc)

@app.post('/api/chief/link')
def chief_link(data:LinkIn):
    state.chief_online=bool(data.online)
    state.audit.append('chief-link-changed','system',{'online':state.chief_online})
    return {'chief_online':state.chief_online,'station_services_unchanged':True}

@app.get('/api/incidents/{ident}/peer-review')
def peer_review(ident:str):
    inc=get_incident(ident)
    d=peer_assessment(inc)
    return {**d, 'coordination_mode':'peer_only', 'works_without_chief':True}

@app.get('/api/incidents/{ident}/specialists/{role}')
def specialist(ident:str,role:str):
    inc=get_incident(ident)
    try:
        return run_reference_specialist(role,inc,state.audit.validate())
    except ValueError:
        raise HTTPException(501,'not implemented as an executable specialist')

@app.get('/api/stations/{station}/raw')
def raw(station:str, actor_role:str=Query(...)):
    if station not in state.stations:
        raise HTTPException(404,'unknown station')
    # NOTE: mock role header/parameter for a local, untrusted demo ONLY.
    if actor_role!=f'{station}_operator':
        state.audit.append('forbidden-raw-read','api',{'station':station, 'role':actor_role})
        raise HTTPException(403,'cross-station raw read forbidden')
    return {'station':station,'measurements':state.stations[station].measurements}

@app.post('/api/stations/{station}/link')
def link(station:str, data:LinkIn):
    if station not in state.stations:
        raise HTTPException(404,'unknown station')
    return state.toggle_link(station,data.online)

@app.post('/api/measurements')
def measurements(data:MeasurementIn):
    if data.station not in ('slot','tab'):
        raise HTTPException(400,'invalid measuring station')
    if not math.isfinite(data.value_mm):
        raise HTTPException(400,'measurement must be finite')
    if data.origin!='physical_self_reported':
        raise HTTPException(400,'only physical_self_reported allowed on this endpoint')
    reading=state.stations[data.station].local_add(data.value_mm, data.origin,data.instrument_id)
    # Existing evidence for this station has changed: invalidate cache.
    for inc in state.incidents.values():
        if data.station in inc['evidence']:
            del inc['evidence'][data.station]
            inc['status']='partial_evidence'
    state.audit.append('physical-self-report',data.station,{'id':reading['id'], 'origin':reading['origin']})
    return reading

@app.post('/api/incidents/{ident}/challenge')
def challenge(ident:str, data:DissentIn):
    get_incident(ident)
    known=set(state.audit.ids)
    if not data.counterevidence_event_ids or not set(data.counterevidence_event_ids).issubset(known):
        raise HTTPException(400,'challenge needs real evidence event IDs')
    record=state.audit.append('protected-expert-challenge',data.specialist,
                              {'incident_id':ident,'claim':data.claim,
                               'counterevidence_event_ids':data.counterevidence_event_ids})
    return {'status':'requires_independent_verification','challenge_event_id':record['id'],
            'not_voted_away':True}

@app.post('/api/incidents/{ident}/approve')
def approve(ident:str,data:ApprovalIn):
    inc=get_incident(ident)
    if data.actor_role!='human_engineer':
        raise HTTPException(403,'human engineering approval required')
    if data.proposed_action not in ('hold','inspect','request_more_evidence'):
        raise HTTPException(422,'uncalibrated demo prohibits automatic production release')
    ev=state.audit.append('human-approved-decision',data.actor_role,
                          {'incident_id':ident,'action':data.proposed_action,'note':data.note})
    inc['approval']='approved_by_human';inc['approved_action']=data.proposed_action
    return {'status':inc['approval'],'audit_event_id':ev['id'], 'no_machine_actuation':True}

@app.get('/api/research/one_step_vder')
def research():
    p={'stable':.68,'slot_shift':.15,'tab_shift':.12,'both_shift':.05}
    return {'model':'four-hypothesis TOY only','prior':p,'decision':decision_loss(p).__dict__,
            'plan':choose_next(p,['slot_summary','tab_summary','assembly_fit','uninformative']),
            'not_connected_to_physical_risk_engine':True}

@app.get('/api/audit')
def audit():
    return {'events':state.audit.events,'hash_chain_valid':state.audit.validate(),
            'note':'hash chain is NOT a cryptographic signature or tamper-proof database'}

# Static research demo is last: all /api endpoints above take priority.
from pathlib import Path
from fastapi.staticfiles import StaticFiles
app.mount('/', StaticFiles(directory=str(Path(__file__).resolve().parents[1] / 'web'), html=True), name='research-demo')
