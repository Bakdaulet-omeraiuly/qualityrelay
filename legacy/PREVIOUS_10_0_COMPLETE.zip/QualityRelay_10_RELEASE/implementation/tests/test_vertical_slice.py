import unittest
from fastapi.testclient import TestClient
from qualityrelay10.api import app
from qualityrelay10.core import fit_risk, inspect_clearance, stable_seed
from qualityrelay10.state import Audit

class VerticalSlice(unittest.TestCase):
    def setUp(self):
        self.c=TestClient(app)
        self.assertEqual(self.c.post('/api/reset').status_code,200)
        self.i=self.c.post('/api/incidents',json={'slot_lot':'A-07','tab_lot':'B-12'}).json()['id']

    def test_pending_then_full_evidence(self):
        p=self.c.get(f'/api/incidents/{self.i}/chief').json()
        self.assertEqual(p['status'],'ABSTAIN_PENDING_EVIDENCE')
        self.c.post(f'/api/incidents/{self.i}/evidence/slot')
        self.assertEqual(self.c.get(f'/api/incidents/{self.i}/chief').json()['evidence_coverage'],1)
        self.c.post(f'/api/incidents/{self.i}/evidence/tab')
        q=self.c.get(f'/api/incidents/{self.i}/chief').json()
        self.assertEqual(q['status'],'REVIEW_ONLY_UNCALIBRATED')
        self.assertIn('risk_probability',q['risk_model'])
        self.assertNotEqual(q['proposal'],'release')

    def test_raw_cross_read_forbidden(self):
        self.assertEqual(self.c.get('/api/stations/slot/raw', params={'actor_role':'assembly_operator'}).status_code,403)
        self.assertEqual(self.c.get('/api/stations/slot/raw', params={'actor_role':'slot_operator'}).status_code,200)

    def test_link_loss_invalidates_evidence(self):
        self.c.post(f'/api/incidents/{self.i}/evidence/slot')
        self.c.post(f'/api/incidents/{self.i}/evidence/tab')
        self.c.post('/api/stations/slot/link',json={'online':False})
        q=self.c.get(f'/api/incidents/{self.i}/chief').json()
        self.assertEqual(q['status'],'ABSTAIN_PENDING_EVIDENCE')
        self.assertEqual(q['evidence_coverage'],1)
        self.assertEqual(self.c.post(f'/api/incidents/{self.i}/evidence/slot').json()['status'],'unavailable')
        self.c.post('/api/stations/slot/link',json={'online':True})
        self.c.post(f'/api/incidents/{self.i}/evidence/slot')
        self.assertEqual(self.c.get(f'/api/incidents/{self.i}/chief').json()['evidence_coverage'],2)

    def test_local_offline_measurement_and_idempotent_replay(self):
        self.c.post('/api/stations/tab/link',json={'online':False})
        m=self.c.post('/api/measurements',json={'station':'tab','value_mm':20.1,'instrument_id':'caliper-1'}).json()
        self.assertEqual(m['origin'],'physical_self_reported')
        x=self.c.post('/api/stations/tab/link',json={'online':True}).json()
        self.assertEqual(x['replayed'],1)
        y=self.c.post('/api/stations/tab/link',json={'online':True}).json()
        self.assertEqual(y['replayed'],0)
        events=self.c.get('/api/audit').json()['events']
        self.assertEqual(len([e for e in events if e['id']=='replay:'+m['id']]),1)
        self.assertTrue(self.c.get('/api/audit').json()['hash_chain_valid'])

    def test_physical_entry_invalidates_and_marks_mixed_origin(self):
        self.c.post(f'/api/incidents/{self.i}/evidence/slot')
        self.c.post(f'/api/incidents/{self.i}/evidence/tab')
        self.c.post('/api/measurements',json={'station':'tab','value_mm':20.2,'instrument_id':'caliper-1','origin':'physical_self_reported'})
        self.assertEqual(self.c.get(f'/api/incidents/{self.i}/chief').json()['status'],'ABSTAIN_PENDING_EVIDENCE')
        self.c.post(f'/api/incidents/{self.i}/evidence/tab')
        d=self.c.get(f'/api/incidents/{self.i}/chief').json()
        self.assertEqual(d['status'],'REVIEW_ONLY_MIXED_EVIDENCE')
        self.assertFalse(d['risk_model']['physical_validation_claimed'])
        self.assertEqual(d['risk_model']['input_evidence_origin']['tab'],'mixed')

    def test_chief_failure_peer_continuity(self):
        self.c.post(f'/api/incidents/{self.i}/evidence/slot')
        self.c.post(f'/api/incidents/{self.i}/evidence/tab')
        self.c.post('/api/chief/link',json={'online':False})
        self.assertEqual(self.c.get(f'/api/incidents/{self.i}/chief').status_code,503)
        d=self.c.get(f'/api/incidents/{self.i}/peer-review').json()
        self.assertEqual(d['evidence_coverage'],2)
        self.assertTrue(d['works_without_chief'])

    def test_approval_gate(self):
        self.assertEqual(self.c.post(f'/api/incidents/{self.i}/approve',json={'actor_role':'chief','proposed_action':'inspect','note':'Check fixture'}).status_code,403)
        self.assertEqual(self.c.post(f'/api/incidents/{self.i}/approve',json={'actor_role':'human_engineer','proposed_action':'release','note':'Just release it'}).status_code,422)
        self.assertEqual(self.c.post(f'/api/incidents/{self.i}/approve',json={'actor_role':'human_engineer','proposed_action':'inspect','note':'Check fixture'}).status_code,200)

    def test_protected_dissent_needs_real_id(self):
        bad=self.c.post(f'/api/incidents/{self.i}/challenge',json={'specialist':'metrology','counterevidence_event_ids':['fake'],'claim':'Gauge is noisy'})
        self.assertEqual(bad.status_code,400)
        self.c.post(f'/api/incidents/{self.i}/evidence/slot')
        ids=[x['id'] for x in self.c.get('/api/audit').json()['events']]
        good=self.c.post(f'/api/incidents/{self.i}/challenge',json={'specialist':'metrology','counterevidence_event_ids':[ids[-1]],'claim':'Gauge is noisy'})
        self.assertEqual(good.status_code,200)
        self.assertEqual(good.json()['status'],'requires_independent_verification')

    def test_agent_registry_truthful(self):
        d=self.c.get('/api/agents').json()
        self.assertEqual(len(d['specialists']),20)
        self.assertEqual(sum(x['status']=='deterministic_reference_tool' for x in d['specialists']),8)

    def test_executable_specialist_handlers(self):
        roles=['design_geometry','tolerance','metrology','quality','assembly','safety','reliability','audit']
        for r in roles:
            response=self.c.get(f'/api/incidents/{self.i}/specialists/{r}')
            self.assertEqual(response.status_code,200,r)
        self.assertEqual(self.c.get(f'/api/incidents/{self.i}/specialists/cnc').status_code,501)
        self.c.post(f'/api/incidents/{self.i}/evidence/slot')
        self.c.post(f'/api/incidents/{self.i}/evidence/tab')
        r=self.c.get(f'/api/incidents/{self.i}/specialists/tolerance').json()
        self.assertIn('risk',r)

    def test_toy_label(self):
        d=self.c.get('/api/research/one_step_vder').json()
        self.assertTrue(d['not_connected_to_physical_risk_engine'])
        self.assertIn('TOY',d['model'])

    def test_empty_and_missing(self):
        self.assertEqual(self.c.post('/api/incidents',json={'slot_lot':'','tab_lot':'B'}).status_code,422)
        self.assertEqual(self.c.get('/api/incidents/bad/chief').status_code,404)

class MathChecks(unittest.TestCase):
    def test_geometry(self):
        d=inspect_clearance(20.6,20.3)
        self.assertAlmostEqual(d['clearance_mm'],0.3)
        self.assertTrue(d['slot_local_pass'] and d['tab_local_pass'])
        self.assertFalse(d['functional_fit_pass_by_width_only'])

    def test_mc_determinism(self):
        x={'mean_mm':20.7,'std_mm':0.10};y={'mean_mm':20.3,'std_mm':0.10}
        z=fit_risk(x,y,stable_seed('test'),iterations=1200)
        self.assertEqual(z,fit_risk(x,y,stable_seed('test'),iterations=1200))
        self.assertGreater(z['risk_probability'],0.3)

    def test_hash_audit_tamper(self):
        a=Audit();a.append('test','actor',{'count':1});self.assertTrue(a.validate())
        a.events[0]['payload']['count']=2
        self.assertFalse(a.validate())

if __name__=='__main__':unittest.main()
