# QualityRelay 8.0 package verification

The original QualityRelay 5.0 files are copied byte-for-byte. This package contains the original uploaded ZIP (unchanged), all extracted non-directory files (unchanged), the current 8.0 research master document, and archived previous 7.1 document. 

No factory validation or run result is implied by package creation.

