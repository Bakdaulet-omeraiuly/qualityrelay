#!/usr/bin/env python3
"""Generate the simple QualityRelay coupon STL files with no dependencies."""

from __future__ import annotations

import argparse
import math
from pathlib import Path


Triangle = tuple[tuple[float, float, float], tuple[float, float, float], tuple[float, float, float]]


def box_triangles(x0: float, y0: float, z0: float, x1: float, y1: float, z1: float) -> list[Triangle]:
    v = [
        (x0, y0, z0),
        (x1, y0, z0),
        (x1, y1, z0),
        (x0, y1, z0),
        (x0, y0, z1),
        (x1, y0, z1),
        (x1, y1, z1),
        (x0, y1, z1),
    ]
    faces = [
        (0, 2, 1), (0, 3, 2),
        (4, 5, 6), (4, 6, 7),
        (0, 1, 5), (0, 5, 4),
        (3, 7, 6), (3, 6, 2),
        (0, 4, 7), (0, 7, 3),
        (1, 2, 6), (1, 6, 5),
    ]
    return [(v[a], v[b], v[c]) for a, b, c in faces]


def normal(triangle: Triangle) -> tuple[float, float, float]:
    a, b, c = triangle
    ux, uy, uz = b[0] - a[0], b[1] - a[1], b[2] - a[2]
    vx, vy, vz = c[0] - a[0], c[1] - a[1], c[2] - a[2]
    nx = uy * vz - uz * vy
    ny = uz * vx - ux * vz
    nz = ux * vy - uy * vx
    length = math.sqrt(nx * nx + ny * ny + nz * nz)
    if length == 0:
        raise ValueError("Degenerate triangle")
    return nx / length, ny / length, nz / length


def write_ascii_stl(path: Path, solid_name: str, triangles: list[Triangle]) -> None:
    with path.open("w", encoding="ascii", newline="\n") as handle:
        handle.write(f"solid {solid_name}\n")
        for tri in triangles:
            nx, ny, nz = normal(tri)
            handle.write(f"  facet normal {nx:.9g} {ny:.9g} {nz:.9g}\n")
            handle.write("    outer loop\n")
            for x, y, z in tri:
                handle.write(f"      vertex {x:.9g} {y:.9g} {z:.9g}\n")
            handle.write("    endloop\n")
            handle.write("  endfacet\n")
        handle.write(f"endsolid {solid_name}\n")


def slot_coupon(inner_width: float) -> list[Triangle]:
    total_length = 60.0
    height = 6.0
    base_length = 12.0
    rail = 6.0
    outer_width = inner_width + 2.0 * rail
    triangles: list[Triangle] = []
    triangles += box_triangles(0.0, 0.0, 0.0, base_length, outer_width, height)
    triangles += box_triangles(base_length, 0.0, 0.0, total_length, rail, height)
    triangles += box_triangles(base_length, rail + inner_width, 0.0, total_length, outer_width, height)
    return triangles


def tab_coupon(width: float) -> list[Triangle]:
    return box_triangles(0.0, 0.0, 0.0, 60.0, width, 6.0)


def bounds(triangles: list[Triangle]) -> tuple[float, float, float]:
    vertices = [vertex for triangle in triangles for vertex in triangle]
    xs = [v[0] for v in vertices]
    ys = [v[1] for v in vertices]
    zs = [v[2] for v in vertices]
    return max(xs) - min(xs), max(ys) - min(ys), max(zs) - min(zs)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=Path("stl"))
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    parts = {
        "slot_good_21p20.stl": slot_coupon(21.20),
        "slot_nominal_21p00.stl": slot_coupon(21.00),
        "slot_risk_20p70.stl": slot_coupon(20.70),
        "tab_good_19p80.stl": tab_coupon(19.80),
        "tab_nominal_20p00.stl": tab_coupon(20.00),
        "tab_risk_20p30.stl": tab_coupon(20.30),
        "repeatability_bar_20p00.stl": tab_coupon(20.00),
    }

    for filename, triangles in parts.items():
        path = args.output_dir / filename
        write_ascii_stl(path, path.stem, triangles)
        dx, dy, dz = bounds(triangles)
        print(f"{filename}: triangles={len(triangles)} bounds_mm={dx:.2f}x{dy:.2f}x{dz:.2f}")


if __name__ == "__main__":
    main()
