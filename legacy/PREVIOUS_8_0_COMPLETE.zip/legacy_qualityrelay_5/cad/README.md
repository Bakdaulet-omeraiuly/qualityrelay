# QualityRelay rebuilt Bambu print kit

This is a replacement for the unavailable prior path `/mnt/data/QualityRelay_Bambu_PrintKit.zip`. It is a new, simplified kit prepared for the QualityRelay 5.0 demonstration and is not claimed to be the original file.

## Included geometry

- `qualityrelay_printkit.scad`: parametric OpenSCAD source.
- `generate_stl.py`: dependency-free ASCII STL generator.
- `stl/slot_good_21p20.stl`
- `stl/slot_nominal_21p00.stl`
- `stl/slot_risk_20p70.stl`
- `stl/tab_good_19p80.stl`
- `stl/tab_nominal_20p00.stl`
- `stl/tab_risk_20p30.stl`
- `stl/repeatability_bar_20p00.stl`

STL units are millimeters. Import at 100% scale.

## Print quantities

Follow `print_manifest.csv`. Print one extra `slot_risk_20p70.stl` and one extra `tab_risk_20p30.stl` as backups.

## Bambu Studio workflow

1. Create a new plate with the correct printer and a 0.4 mm nozzle profile.
2. Import all STL files; confirm millimeter dimensions and 100% scale.
3. Duplicate the risk slot and risk tab once.
4. Keep every part flat as imported.
5. Use one PLA profile, 0.16–0.20 mm layer height, 3 walls, at least 4 top/bottom layers, 15–25% infill, and no supports.
6. Add spacing between parts and slice.
7. After printing and cooling, label the parts with black tape away from measurement surfaces.
8. Measure actual dimensions; never use filenames as measured truth.

## Regeneration

From this directory:

`python3 generate_stl.py --output-dir stl`

The generator prints a summary of triangle counts and nominal bounding boxes. It uses only the Python standard library.

## Geometry note

The U-slot STL is made from three touching rectangular solids in one STL shell set. Bambu Studio should slice the touching volumes as one part. Inspect the layer preview before printing. If your slicer reports an unrepaired mesh, use the OpenSCAD source to export the part instead.

## Identification

The STL geometry has no raised text so labels cannot affect measured width. Apply these IDs manually:

- S-GOOD, S-NOM, S-RISK;
- T-GOOD, T-NOM, T-RISK;
- RPT-20.

