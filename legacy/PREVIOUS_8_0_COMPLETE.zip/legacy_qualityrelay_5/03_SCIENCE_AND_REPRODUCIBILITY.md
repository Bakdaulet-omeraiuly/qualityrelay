# Science, algorithms, and reproducibility

## 1. Scientific posture

QualityRelay is a controlled prototype study, not an industrial validation. The scientific value comes from isolating one variable—information topology—while keeping the statistical core, generated process streams, inspection budget, and evaluation metrics fixed.

The main hypotheses are directional and must be finalized before the main run:

- Under always-on connectivity, centralized full access is an upper-bound reference; QualityRelay is expected to trade some information for less raw-data exposure.
- Under intermittent connectivity or a hub failure, peer-local operation and idempotent reconciliation may retain capability unavailable to a hub-dependent workflow.
- Selective evidence exchange may improve diagnosis or inspection choice relative to isolated actors when the signal is relational and local shifts are individually marginal.

These are testable expectations, not results.

## 2. Units and reference configuration

All dimensional values are stored internally in millimeters as decimal numbers. Do not accept ambiguous strings such as `0.1` without a unit at an external boundary.

Reference teaching configuration:

| Parameter | Value | Status |
|---|---:|---|
| Slot nominal mean | 21.0 mm | scenario assumption |
| Tab nominal mean | 20.0 mm | scenario assumption |
| Slot baseline sigma | 0.2 mm | scenario assumption, replace if calibrated |
| Tab baseline sigma | 0.2 mm | scenario assumption, replace if calibrated |
| Slot specification | [20.5, 21.5] mm | scenario assumption |
| Tab specification | [19.5, 20.5] mm | scenario assumption |
| Functional minimum clearance | 0.5 mm | scenario assumption |
| Pairing policy | uniform among locally accepted parts | frozen benchmark rule |
| Minimum live evidence | 5 per required station/lot | demo sufficiency gate, not variance-estimation claim |
| EWMA lambda | 0.2 | initial configuration |
| EWMA L | 3.0 | initial configuration |

The variance parameters should be estimated from a separate calibration/history dataset if real data are available. Five recent points are enough only to demonstrate an evidence gate; they are not enough to establish process capability.

## 3. Clearance and acceptance conditioning

Let slot width `W`, tab thickness `T`, and clearance `C = W - T`.

For a bivariate normal approximation:

`mu_C = mu_W - mu_T`

`var_C = sigma_W^2 + sigma_T^2 - 2*rho*sigma_W*sigma_T`

`risk_unconditional = Phi((c_min - mu_C) / sigma_C)`

The relevant assembly population has already passed local part inspection. Therefore the principal simulation estimates:

`P(W - T < c_min | W in slot_spec, T in tab_spec, pairing_policy)`

Use deterministic Monte Carlo:

1. derive a seed from `SHA256(run_id | lot_pair | evidence_snapshot_hash | core_version)`;
2. sample from the configured joint distribution;
3. apply local acceptance limits;
4. apply the frozen pairing policy;
5. estimate the insufficient-clearance probability and Monte Carlo standard error;
6. return sample count, accepted count, seed key, and assumptions with the estimate.

If serial correlation or FIFO pairing is modeled, do not use the independent random-pair analytic reference as the null. The pairing policy is part of the estimand.

## 4. EWMA process monitoring

For measurement `x_t`:

`z_t = lambda*x_t + (1-lambda)*z_(t-1)`, with `z_0 = mu_0`.

At time `t`, the normal-theory limit is:

`mu_0 +/- L*sigma_0*sqrt(lambda/(2-lambda) * (1-(1-lambda)^(2t)))`.

Implementation requirements:

- baseline `mu_0` and `sigma_0` are immutable within a run;
- missing observations do not create fake time steps;
- station-local EWMA continues during peer link loss;
- alarms reference the measurement event and configuration version;
- a risk estimate can be elevated without a local EWMA alarm; the two signals answer different questions.

The project does not claim to have invented EWMA or optimized its average run length.

## 5. Hypothesis model

Minimum states:

| State | Meaning | Slot shift model | Tab shift model |
|---|---|---|---|
| H0 | stable reference with nonzero baseline assembly risk | 0 | 0 |
| H1 | slot drift reduces clearance | negative | 0 |
| H2 | tab drift reduces clearance | 0 | positive |
| H4 | combined drift reduces clearance | negative | positive |

Use a declared likelihood model over station summary statistics. A hackathon-sized implementation can use recent sample mean residuals relative to baseline, with variance derived from the fixed baseline sigma and evidence count. Priors must be declared in the config. If equal priors are used, say so; if H0 receives a larger prior, justify and freeze it.

Posterior calculation:

`p(H_k | E) proportional to p(H_k) * product_{s in available_stations} p(E_s | H_k)`.

Evidence constraints:

- `available_stations` includes only fresh, authorized evidence held by the caller;
- remote raw records are never fetched by the posterior function;
- omitted likelihood terms are not replaced with neutral-looking fake summaries;
- the result returns station coverage and exact evidence refs;
- a derived result is invalidated and recomputed when its evidence snapshot changes.

## 6. Expected information gain inspection policy

For current posterior `p(H|E)`, candidate inspection `a`, and discretized outcomes `y`:

`IG(a) = H(p(H|E)) - sum_y p(y|a,E) H(p(H|E,y))`.

Rank by `IG(a) / expected_seconds(a)`. The action cost table is frozen before the main experiment. If the outcome model is too weak to support honest IG, fall back to a declared fixed inspection policy and mark IG as not evaluated.

Guardrails:

- candidates are generated by deterministic code from real lot/specimen IDs;
- the selected ID must be a member of the current candidate set;
- identical evidence and candidate sets return the same ranking;
- if all scores are below `min_ig`, return `no_inspection_recommended`;
- do not describe expected information gain as a novel algorithm.

## 7. Physical measurement characterization

Before using printed differences as evidence:

1. choose one stable coupon and one caliper;
2. one operator measures it ten times, reseating between readings;
3. record all values, including awkward ones;
4. calculate sample standard deviation `s_r` and range;
5. note instrument resolution and any zero check;
6. ensure the selected pairwise contrast is visibly larger than repeatability noise;
7. if two operators will measure during the demo, either test both or keep one designated operator.

The heuristic `effect >= 3–5*s_r` screens obvious weak demonstrations. It is not a substitute for a full gauge repeatability and reproducibility study, bias study, or calibration certificate.

## 8. Pilot and fault-magnitude freeze

The combined 0.100 mm scenario is required as a walkthrough, but it may be too easy for isolated EWMA monitoring. Prevent post-hoc cherry-picking:

1. Before running, define a candidate grid such as 0.025, 0.050, 0.075, and 0.100 mm per affected station.
2. Define the selection rule before seeing outcomes: choose the smallest shift that changes joint clearance risk by a declared practical amount while the median local alarm delay remains above a declared threshold.
3. Run the same small pilot seeds for every method.
4. Save all candidate outcomes.
5. Freeze the chosen main shift and explain the rule.

If no candidate separates the conditions, report that honestly and focus the demonstration on access boundaries and outage recovery instead of claiming diagnostic superiority.

## 9. Main experiment matrix

The compact main design is:

- scenarios: normal, slot shift, combined shift;
- methods: isolated, centralized, QualityRelay;
- seeds: 10 paired seeds if completed; otherwise report the completed preregistered subset;
- units per run: 200;
- change point: frozen in configuration;
- inspection budget: identical across methods;
- statistical core version: identical across methods.

A second topology/connectivity experiment uses centralized hub and decentralized peer mesh under always-on and intermittent connectivity. The isolated method is a reference, not another 2×2 cell.

## 10. Metrics and definitions

| Metric | Definition | Applies to |
|---|---|---|
| Detection delay | first valid alarm/decision unit minus injected change-point unit; censored if absent | simulation |
| Hypothesis accuracy | selected highest-posterior state equals injected scenario | simulation |
| Assembly-risk Brier score | mean `(p_i - y_i)^2` over simulated assembly outcomes | simulation only |
| Inspection cost | sum of configured seconds for selected inspections | simulation and descriptive physical |
| Raw exposure | number of raw station measurement records crossing an authority boundary | all runs |
| Message cost | count and serialized bytes of inter-station events | all runs |
| Evidence coverage | fresh stations represented / required stations | all decisions |
| Duplicate count | repeated logical event IDs applied after reconciliation | outage tests; target 0 |
| Unauthorized denial | forbidden access attempts rejected and audited | security test; target 100% for test cases |
| Physical loop outcome | measured dimensions, pair attempted, declared fit criterion, observed fit | descriptive physical only |

Do not calculate a physical Brier score from two or three pairs. Do not combine physical outcomes with hundreds of simulated units to produce one denominator.

## 11. Summaries and uncertainty

For simulated metrics:

- show every per-seed value;
- report mean, median, and standard deviation across seeds;
- use paired differences because methods share seeds;
- optionally show a bootstrap interval over paired seed differences, labeled exploratory;
- avoid p-values or claims of general population performance from ten seeds;
- state the number of completed seeds on every figure.

For physical observations:

- show the raw readings and repetitions;
- report repeatability descriptively;
- state `n` prominently;
- call the result a loop-closure demonstration, not validation of the predicted probability.

## 12. Data-origin separation

Every event has `origin.kind`:

- `physical`: direct human/instrument observation; must not contain a simulation seed;
- `simulated`: generated observation; must contain seed and generator version;
- `derived`: calculated from referenced parents; must list parent origin kinds and evidence refs.

Rules:

1. A direct record cannot be both physical and simulated.
2. Derived records preserve complete lineage.
3. The main analysis rejects a derived record whose parents mix physical and simulated origins.
4. A deliberately mixed exploratory view must use `analysis_partition: mixed_exploratory`, display a warning, and remain outside headline metrics.
5. Figures have separate physical and simulation panels and denominators.
6. Seeded preloaded histories used for a live demo are labeled simulated even if displayed beside a physical reading.

## 13. Reproducibility manifest

Each run records:

- run ID and UTC timestamps;
- git commit or source archive hash;
- configuration file hash;
- event schema version and core algorithm version;
- Python/runtime and dependency lock hash;
- operating system and hardware summary;
- scenario, method, topology, connectivity, pairing policy;
- seed and seed-derivation rule;
- model/provider name and prompt/tool schema hash if an LLM is used;
- source dataset IDs and origin partitions;
- completed unit count and any early-stop reason;
- output artifact hashes;
- operator and instrument IDs for physical runs.

Use `templates/run_manifest.yaml`. A clean replay must regenerate the same deterministic derived values from the same event snapshot.

## 14. Test checklist

- analytic and Monte Carlo clearance risk agree within a declared tolerance;
- truncated acceptance filter is applied correctly;
- deterministic seed makes repeated estimates stable;
- H0 failure rate is nonzero under the reference design;
- EWMA limits match a hand-calculated small test vector;
- posterior normalizes to 1;
- an actor cannot include unseen evidence;
- stale evidence is omitted from the current likelihood;
- candidate IDs are whitelisted;
- Brier score is calculated only on simulated events;
- physical ingest rejects a seed;
- simulated ingest requires a seed;
- mixed-origin headline analysis fails closed;
- event replay is idempotent;
- unauthorized reads return 403;
- reset restores seed data, online links, and an empty visible audit filter.

## 15. Result-state vocabulary

Use only:

- `NOT_RUN`: configured but never executed;
- `RUNNING`: incomplete artifact, not reportable;
- `COMPLETE`: run finished and manifest validated;
- `INVALID`: contract, provenance, or scientific rule failed;
- `EXPLORATORY`: executed outside the frozen main design;
- `PHYSICAL_DESCRIPTIVE`: physical loop record, not inferential benchmark evidence.

