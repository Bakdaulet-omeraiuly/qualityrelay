# Demonstration runbook

## 1. Demonstration goal

Make the audience see a relational manufacturing problem, authorized evidence exchange, a targeted physical measurement, and graceful behavior during communication loss. Do not turn the demo into a tour of every screen.

Target full version: 3.5–4 minutes plus questions. Keep a 75–90 second floor version.

## 2. Roles during the demo

- Manufacturing engineer: narrator, handles printed parts and caliper, states physical limitations.
- Data scientist / vibecoder: drives dashboard and points to statistical changes.
- Computer scientist: link toggle, access-denial proof, failure recovery, questions on architecture.

If only one screen is visible, the data scientist controls it; the CS does not reach across during the physical measurement.

## 3. Table setup

- laptop with local app and charger;
- phone/document camera aimed at caliper display and white parts;
- diffused light; no strong overhead glare;
- black labels on white specimens;
- tray in sequence: good pair, risk pair, backup pair;
- digital caliper, zeroed, spare battery if available;
- static result slide already open;
- backup replay clip already open and clearly labeled “recorded replay”;
- printed one-page architecture/QR card if available.

## 4. Reset checklist — 15 minutes before judging

1. Run the one-command reset.
2. Confirm expected seed/config hash and `NOT_RUN` is absent from any completed result panel.
3. Confirm slot, tab, and assembly links are online.
4. Confirm the visible audit view is empty after the reset event.
5. Confirm A-07 and B-12 each have at least five recent evidence rows.
6. Confirm the alternative-lot branch is reachable if it will be shown.
7. Confirm good/risk physical specimens match the IDs in the UI.
8. Confirm camera focus and caliper digits.
9. Run one silent full sequence with a stopwatch.
10. Assign exact speaker handoffs.

## 5. Four-minute script

### Opening — 0:00–0:25

Physical action: hold or point to the slot and tab coupons.

Suggested wording:

> “This slot and this tab can each pass their own dimensional specification, yet the pairing can still miss the required clearance. The evidence lives at different manufacturing stations. QualityRelay asks whether independently authorized station agents can catch the relational risk without turning the plant into one shared database.”

Do not say the system has already proven scrap reduction.

### Beat 1: prospective query, honestly pending — 0:25–0:50

Screen: choose A-07 × B-12 and press Evaluate.

Expected state: `pending_insufficient_evidence` or `pending_evidence` before responses.

Say:

> “Before assembly, the operator asks about this lot pair. Assembly cannot answer from its own data, and it does not guess. It requests evidence from the two station owners.”

If a number appears before evidence responses, the demo is scientifically wrong; reset rather than narrating over it.

### Beat 2: selective evidence and risk — 0:50–1:25

Screen: `EvidenceRequested`, two `EvidenceResponded` events, then `RiskEstimateComputed` with refs and origin labels.

Say:

> “Each station returns a scoped summary tied to its local event IDs. Only after both responses arrive does the deterministic engine calculate the estimate. The number on screen came from the server, not from model prose.”

If agents agree, say they agree. If they disagree, say they disagree and show the distinguishing inspection. Never stage disagreement verbally when the evidence does not contain it.

### Beat 3: targeted physical inspection — 1:25–2:10

Screen: ranked server-generated candidates and cost/IG values.

Say:

> “Rather than measure everything, the system ranks the available checks by expected information gained per second. The specimen ID is chosen from a server list; an LLM cannot invent it.”

Physical action: measure the selected coupon on camera, read the caliper aloud, and enter exactly that value as `PHYSICAL`.

Say after update:

> “This reading is one physical observation. It updates the diagnosis, but it does not validate the probability shown across only one or two parts.”

If the reading differs from expectation, record it and continue. Do not substitute another hidden value.

### Beat 4: communication loss and recovery — 2:10–2:50

CS toggles the slot link offline.

Screen: slot local state remains active; assembly shows partial/stale status and 2/3 coverage.

Say:

> “We are cutting the slot link. Slot monitoring continues locally. Assembly keeps the audit history but stops treating old slot evidence as current, so its coverage is explicit.”

CS restores the link.

Say:

> “On reconnection, queued events keep their IDs. They apply exactly once, and a new estimate references the reconciled evidence.”

If live recovery fails, switch to the labeled recorded replay. Do not claim the replay is live.

### Beat 5: enforced boundary — 2:50–3:15

Trigger the deliberate cross-station raw-data request.

Screen: 403 and `AccessDenied` audit event.

Say:

> “Even the agent itself cannot bypass the station boundary. The service rejects the request and records the denial.”

### Beat 6: measured evidence and limits — 3:15–4:00

Show the static generated result slide.

Use only the version appropriate to actual status:

If main experiments are complete:

> “These are paired seeded simulations using the same statistical core and inspection budget in every condition. The physical panel is separate and descriptive. Under full connectivity, centralized access is our upper-bound reference; the resilience comparison is the intermittent-link panel.”

If incomplete:

> “The full benchmark is still exploratory, so we are showing raw completed seeds rather than a finished performance claim. What is complete is the functioning evidence, permission, inspection, and recovery loop you just watched.”

Close:

> “Our contribution is not a new EWMA or a new Bayes rule. It is a tested way to preserve station authority and provenance while coordinating a relational quality decision under partial connectivity.”

## 6. Ninety-second floor version

0–15 seconds: physical problem.

> “Both parts can pass locally and still be a bad pair. Their data live at different stations.”

15–40 seconds: query and evidence.

> “Assembly refuses to guess, requests scoped summaries, then calculates a provenance-linked risk with the shared deterministic engine.”

40–65 seconds: targeted inspection.

> “It chooses this real caliper check because it is the highest information per second, not because we told it to measure everything.”

65–80 seconds: boundary/resilience.

> “Cut a link and local monitoring continues; reconnect and events apply exactly once. A direct raw-data request is still denied.”

80–90 seconds: measured result or honest status.

> “The seeded comparison is here; physical and simulated evidence are separated. Ask us to show the outage or access-denial proof.”

## 7. Sample combined-scenario walkthrough

Configuration: `combined`, slot mean shift `-0.100 mm`, tab mean shift `+0.100 mm`, slot communication online, simulated origin.

Expected observations only:

1. The run header displays `SIMULATED`, seed, generator version, and scenario.
2. Slot and tab local EWMAs trend toward smaller clearance; exact alarms and delays are unknown until run.
3. The risk query begins pending and completes after both authorized summaries arrive.
4. The clearance-risk estimate tends to rise relative to nominal if the generated sample reflects the shifts.
5. `H4 combined` may gain posterior support; the actual posterior is not prewritten.
6. Slot events should arrive normally because the link is online.
7. Inspection ranking may prefer a slot or tab specimen depending on the realized evidence and costs.
8. Any numeric value shown is a result of that run, not a value copied from this runbook.

## 8. Failure and fallback table

| Failure | Immediate action | Honest narration |
|---|---|---|
| LLM timeout | switch visible mode to deterministic policy | “The deterministic policy is the verified fallback; the LLM is not required for numeric truth.” |
| Risk still pending | show evidence count and threshold | “It requires five recent records per station and refuses to guess.” |
| Caliper reading unexpected | enter it unchanged | “The physical observation disagrees with our expectation; the system records that rather than forcing the script.” |
| Link toggle fails | play labeled replay | “This is a recorded replay from the same build and seeded state.” |
| Access-denial button fails | show automated test output or audit screenshot | “The live trigger failed; the enforcement test is here.” |
| Alternative lot not lower risk | skip that branch | “No lower-risk candidate met the policy threshold.” |
| Benchmark incomplete | show raw completed seeds | “Exploratory, not a completed performance claim.” |
| Network absent | local mode; deterministic actors | “The full demo is local and reproducible without external model access.” |

## 9. Judge Q&A

**Couldn’t one central script compute `W - T`?**

Yes. The centralized condition uses the same core and is the full-access upper bound. The question is what capability and provenance remain when raw data cannot be pooled or links fail.

**Why agents instead of three functions?**

The meaningful distinction is independent authority and local action: each station owns raw evidence, can continue locally, and decides what summary to release. Functions implement the math; actors implement the distributed decision boundary.

**How do you prevent hallucinated numbers?**

Agents emit structured actions and evidence refs. Services calculate values and render numeric text. IDs must be in a server-provided candidate list.

**Is the 0.100 mm shift a measured defect?**

No. It is an injected simulation parameter. Physical measurements are separately labeled and shown raw.

**Does the physical trial validate the probability?**

No. It closes the sensor/measurement loop. Calibration is assessed only over repeated seeded simulation, and the prototype is not industrial validation.

**Did QualityRelay beat centralized?**

Do not answer until results exist. The expected honest framing is that centralized full access is difficult to beat under perfect connectivity; QualityRelay’s value should be evaluated in access cost, provenance, and intermittent-connectivity behavior.

**What is scientifically novel?**

Not EWMA, Bayes, information gain, event sourcing, or tolerance analysis. The hackathon contribution is their evidence-scoped integration and measured comparison across information topologies in a compact physical/simulated demonstration.

**Why white PLA?**

Color does not change the algorithm. White is usable and makes black labels clear; diffuse lighting avoids glare. Dimensional calibration matters much more.

## 10. Never say

- “This eliminates manufacturing defects.”
- “We proved decentralized is better.”
- “The agents discovered a new scientific law.”
- “The 28% physical failure rate,” unless a valid repeated dataset actually supports it.
- “Real manufacturing data,” when the history is seeded simulation.
- “Autonomous LLM agents,” when the deterministic fallback produced the action.
- “Manufacturing track winner,” because the event has one overall competition.

