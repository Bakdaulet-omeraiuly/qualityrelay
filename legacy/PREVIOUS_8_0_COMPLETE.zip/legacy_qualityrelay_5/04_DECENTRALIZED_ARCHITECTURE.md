# Decentralized agent architecture

## 1. Design principle

Decentralization is enforced through authority, storage, and evidence flow—not through agent names. A station actor may decide locally, hold private raw records, issue or deny evidence requests, and continue local monitoring without a global planner.

The architecture separates:

- **transport:** append, route, queue, replay;
- **authority:** who may read or disclose which record;
- **computation:** deterministic statistical functions;
- **policy:** when an actor chooses an approved action;
- **presentation:** server-rendered explanations and dashboard state.

## 2. Actors and authority

### Slot agent

Owns:

- raw slot width readings;
- slot lot metadata;
- local EWMA and local alarms;
- authorization to release declared slot summaries.

Cannot:

- read tab raw records;
- decide final assembly pairing;
- invent an assembly outcome.

### Tab agent

Owns the symmetric tab responsibilities and restrictions.

### Assembly agent

Owns:

- upcoming lot-pair requests;
- physical fit outcomes;
- evidence requests for a pairing;
- compatibility-risk and diagnosis calls over evidence it has received;
- selection among server-provided inspections or alternative lots.

Cannot:

- query station raw databases directly;
- treat missing evidence as current evidence;
- override a station’s disclosure denial.

### Event router/log

May:

- validate envelopes;
- append events;
- route to authorized recipients;
- hold per-recipient queues;
- deduplicate by event ID;
- expose audit metadata.

May not:

- calculate risk or posterior;
- choose an inspection;
- alter payload meaning;
- silently drop or merge events;
- act as a central planner.

## 3. Trust boundaries

```text
Boundary A: slot token -> slot service -> slot store
Boundary B: tab token -> tab service -> tab store
Boundary C: assembly token -> assembly service -> assembly store
Boundary D: router token -> envelope metadata and routed payloads only
Boundary E: demo-admin token -> reset/link controls; never used by station agents
```

Use separate service identities even if all services run in one local process. The service layer, not the agent framework, is the enforcement point. A permissive or compromised LLM tool layer must still receive 403 from a forbidden endpoint.

## 4. Core interaction sequence

1. Operator creates `BatchRiskQuery` at assembly for lot A-07 × B-12.
2. Assembly checks local evidence state and emits `EvidenceRequest` to slot and tab.
3. Router validates and routes requests.
4. Each station independently decides whether to respond under the configured demo policy.
5. Responding station emits `EvidenceResponse` containing summary statistics, evidence refs, assumptions, and freshness—not raw rows.
6. Assembly waits until the evidence gate passes or returns a pending/partial status.
7. Assembly calls `POST /v1/risk-queries/{id}/evaluate` with the evidence refs it actually holds.
8. Core returns a structured `RiskEstimate` with probability, Monte Carlo error, coverage, source origins, and algorithm version.
9. Assembly requests candidate inspections and receives a deterministic ranked list.
10. A selected physical reading becomes `MeasurementRecorded(origin=physical)`.
11. A new derived diagnosis references the new measurement and prior evidence; nothing is overwritten.

## 5. State machines

### Risk query

`created -> pending_evidence -> evaluable -> complete`

Alternative terminal states:

- `pending_insufficient_evidence`;
- `partial_evidence`;
- `invalid_origin_mix`;
- `rejected_unauthorized`;
- `failed_contract`.

No numeric risk may be attached before `evaluable`.

### Evidence item

`requested -> supplied -> fresh -> stale`

Staleness does not delete the event. It controls whether the item may enter the current likelihood. A later response creates a new event rather than mutating the old one.

### Link

`online -> offline -> reconnecting -> online`

During `offline`, local station ingestion remains available. Outbound events enter a station queue. During `reconnecting`, queued events replay in original sequence with original IDs. The receiver acknowledges applied or duplicate-no-op.

## 6. Outage semantics

For the P0/P1 implementation:

- no invented interpolation of a disconnected station;
- history remains visible and traceable;
- evidence beyond the freshness TTL is omitted from the current posterior;
- the UI displays the last-observed timestamp and coverage;
- local SPC continues using local measurements;
- reconnect creates a new risk/diagnosis result; previous results remain immutable;
- deduplication key is the globally unique `event_id`;
- ordering uses `(occurred_at, station_sequence, event_id)` and the audit log records late arrival.

A random-walk uncertainty expansion for stale evidence is scientifically plausible but P3. Do not describe it as implemented unless it is tested and shown.

## 7. Structured action boundary

An optional LLM emits only a schema-valid action such as:

```json
{
  "action": "select_inspection",
  "candidate_id": "inspect-slot-S018",
  "evidence_refs": ["evt-..."],
  "reason_codes": ["max_information_per_second"]
}
```

The server verifies:

- caller authorization;
- action is legal in the current state;
- candidate exists in the server-generated list;
- evidence refs are visible to the caller;
- schema version is supported;
- no numeric claim is supplied by the LLM.

The server then renders human-readable text from deterministic outputs. Rejecting the action is an expected safety behavior, not an agent crash.

## 8. Data stores

Minimal tables:

### Station measurement

- `measurement_id`
- `station_id`
- `lot_id`
- `specimen_id`
- `value_mm`
- `measured_at`
- `origin_kind`
- `operator_or_generator`
- `instrument_id` or `seed`
- `event_id`

### Evidence summary

- `summary_id`
- `owner_station`
- `lot_id`
- `count`
- `mean_mm`
- `baseline_sigma_mm`
- `ewma_value_mm`
- `window_start`, `window_end`
- `evidence_refs`
- `fresh_until`
- `origin_parent_kinds`
- `algorithm_version`

### Event log

- canonical envelope from the JSON Schema;
- `station_sequence`;
- `received_at`;
- `delivery_status` per recipient;
- `payload_hash`;
- `duplicate_of` if applicable.

## 9. Authorization matrix

| Operation | Slot | Tab | Assembly | Router | Demo admin |
|---|---:|---:|---:|---:|---:|
| Write own measurement | yes | yes | fit only | no | seed/reset only |
| Read own raw measurement | yes | yes | fit only | no payload query | yes for reset/debug |
| Read another station raw data | no | no | no | no | not in live demo |
| Create own evidence summary | yes | yes | yes | no | no |
| Request peer evidence | yes | yes | yes | route only | no |
| Evaluate over held evidence | yes | yes | yes | no | no |
| Toggle link | no | no | no | no | yes |
| Reset demo | no | no | no | no | yes |

## 10. API/event contract relationship

`contracts/openapi.yaml` defines command/query endpoints. Every accepted state-changing request appends an event conforming to `contracts/event-envelope.schema.json`. API responses may include projections, but the event log is the replay source.

Important event types:

- `MeasurementRecorded`
- `BatchRiskQueryCreated`
- `EvidenceRequested`
- `EvidenceResponded`
- `RiskEstimateComputed`
- `InspectionCandidatesRanked`
- `InspectionSelected`
- `LinkStatusChanged`
- `ReconciliationCompleted`
- `AccessDenied`
- `RunReset`

## 11. Deployment modes

### Minimum viable local mode

- one Python process;
- four SQLite files;
- in-process router with durable queue;
- local dashboard;
- deterministic actors.

This is acceptable if service-layer boundaries and tests are real.

### Optional container mode

- slot, tab, assembly, router, dashboard processes;
- one store per service;
- local network with service tokens.

Do not spend core hours on orchestration unless local mode passes.

### Optional LLM mode

- one adapter per station with station-specific tool list;
- temperature 0 or the lowest available deterministic setting;
- tool schemas hashed in the run manifest;
- strict timeout and deterministic fallback;
- no agent-to-database connection.

## 12. Failure cases and responses

| Failure | System response | Demo wording |
|---|---|---|
| fewer than five recent records | pending, no numeric risk | “It refuses to guess.” |
| one station offline | partial coverage; missing likelihood omitted | “The estimate is explicitly based on 2/3 stations.” |
| duplicate replay | acknowledge no-op and audit duplicate | “Reconnect does not double-count.” |
| unauthorized raw read | 403 + `AccessDenied` event | “Boundaries are enforced below the agent layer.” |
| LLM invents candidate ID | schema/domain rejection | “Only server-provided specimens can be selected.” |
| mixed physical/sim parents | headline analysis rejection | “Origins cannot be silently pooled.” |
| Monte Carlo timeout | keep query pending/failed, show reason; never reuse unrelated result | “No estimate is better than an untraceable one.” |
| router unavailable | station-local measurement/SPC continue; outbound queue persists | “Local capability survives transport loss.” |

## 13. Required architecture tests

1. Slot agent’s direct tab-raw-data request receives 403.
2. A global evidence ref not held by assembly cannot enter assembly’s posterior.
3. Router process contains no imports from `core/diagnosis.py` or `core/inspection.py`.
4. Offline slot writes a local measurement and EWMA event successfully.
5. Assembly does not see that event until reconnection.
6. Replaying the same queued event twice changes no projection twice.
7. A stale summary remains in the audit view but is absent from current evidence coverage.
8. A physical record with `seed` is rejected.
9. A simulated record without `seed` is rejected.
10. An LLM action carrying a probability field is rejected by schema.

