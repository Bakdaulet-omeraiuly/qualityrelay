# Path and rule verification

Verified on October 28, 2026 in the current Codex workspace.

## File and path check

The previously referenced exact path is:

`/mnt/data/QualityRelay_Bambu_PrintKit.zip`

Result: **not present**. The parent path `/mnt` does not exist on this machine. A filename search under the current Codex Documents workspace and the active temporary attachment area also found no QualityRelay, Bambu PrintKit, STL, 3MF, STEP, SCAD, or matching ZIP file.

Four cached critique attachments from the referenced ChatGPT conversation were found at these exact paths and were used as design-history input:

- `/var/folders/_1/246650tn5gb7tnhjf__vx31m0000gn/T/codex-file-preview-Ambse0/Pasted text(3).txt`
- `/var/folders/_1/246650tn5gb7tnhjf__vx31m0000gn/T/codex-file-preview-iNhxIW/Pasted text(2).txt`
- `/var/folders/_1/246650tn5gb7tnhjf__vx31m0000gn/T/codex-file-preview-9S9ArM/Pasted text(1).txt`
- `/var/folders/_1/246650tn5gb7tnhjf__vx31m0000gn/T/codex-file-preview-X04uMB/Pasted text.txt`

Because the original print kit is unavailable, this package contains a replacement under `cad/`. It is explicitly named as a rebuilt kit and is not represented as the missing original.

## Official ScienceClaw facts

Primary source: [ScienceClaw Hackathon official site](https://scienceclawhack.ai/), checked October 28, 2026.

| Item | Verified rule | Consequence for QualityRelay |
|---|---|---|
| Dates and place | October 30–November 1, 2026, MIT Media Lab, in person | Plan for a physical table demo and local fallback |
| Team size | 2–5 people; every member should attend in person | A three-person team is valid |
| Hacking start | Friday 9:00 PM | Hour 0 in the schedule begins then |
| Team registration | Friday 11:00 PM deadline | Register the three members before deep integration work |
| Final deadline | Sunday 2:30 PM, hacking ends and final slides are due | Freeze features well before Sunday afternoon |
| Challenge area | Manufacturing & Materials: candidate discovery to fabrication, closing the loop between simulation and matter | QualityRelay is a natural A·03 positioning |
| Related area | Physical Agency: agents reaching into sensors, instruments, and cloud labs | Caliper-assisted measurement supports A·02, but the project need not claim two separate tracks |
| Competition structure | One overall competition, not separate tracks | Say “challenge area,” not “Manufacturing track prize” |
| Framework rule | Model- and framework-agnostic | OpenAI, Anthropic, OpenClaw, another framework, or a deterministic adapter are allowed |
| Required output | A functioning agentic system, demonstrated result, and convincing validation | Architecture slides alone are insufficient |
| Decentralization | Distinct knowledge/capabilities, coordination and adaptation without one central planner prescribing the trajectory | Enforce station-local evidence and show authorized peer exchange |
| Judging | Problem 20%, impact 25%, decentralized agency 20%, collective capability 25%, execution/validation 10% | Benchmark collective capability; do not over-invest in UI polish |
| Collaboration bonus | Up to +10 for a capability materially reused by another team | A shared event schema or replay dataset only counts if another team actually uses it |

## Important interpretation

ScienceClaw does not require OpenClaw. The system must be decentralized in capability and decision-making; merely running three prompts or naming three processes “agents” is not enough. QualityRelay therefore uses separate station data stores, station-specific service credentials, explicit evidence requests, and a router that transports events but does not decide the diagnosis.

## Items not found in the public brief

The official public page does not state a mandatory repository host, mandatory programming language, mandatory agent framework, minimum number of agents, required slide template, or detailed intellectual-property rule. Do not invent those constraints. Check any participant-only Discord or on-site briefing when access is available, and record changes in the run manifest.

