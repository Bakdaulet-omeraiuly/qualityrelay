# Claims and novelty guardrails

## 1. Defensible project statement

QualityRelay is a functioning prototype that coordinates a relational manufacturing-quality decision across independently authorized station agents. It applies established statistical methods to evidence-scoped, provenance-linked messages and evaluates the system against isolated and centralized information topologies.

## 2. What is not scientifically new

- tolerance stack-up and clearance arithmetic;
- EWMA process monitoring;
- Bayes’ rule and likelihood-based diagnosis;
- expected information gain / entropy reduction;
- Monte Carlo estimation from truncated distributions;
- API schemas, event sourcing, authorization, and idempotency;
- multi-agent tool calling in general;
- 3D printed go/no-go coupons.

The team should cite these foundations and avoid “novel algorithm” language.

## 3. Plausible hackathon contribution

The integration and evaluation may be new enough for a hackathon demonstration:

- station-local authority enforced beneath the agent framework;
- a risk estimate that cannot exist until authorized evidence actually arrives;
- identical mathematical core across isolated, centralized, and peer conditions;
- inspection selection over evidence held by the caller rather than a hidden global state;
- physical and simulated provenance carried through one event contract without being pooled;
- live link-loss and exactly-once reconciliation proof;
- measurement of collective capability, evidence exposure, and resilience in one compact manufacturing scenario.

Phrase this as “our contribution” or “we demonstrate,” not “the first system ever,” unless a real literature review supports priority.

## 4. Claims ladder

### Safe before experiments

- The prototype implements three station authorities and explicit evidence exchange.
- The mathematical core is shared across comparison conditions.
- The event contract distinguishes physical and simulated origins.
- The demo includes a real caliper measurement and a simulated benchmark plan.

### Safe only after automated tests pass

- Unauthorized cross-station raw reads are rejected in the tested cases.
- Replayed events are idempotent in the tested outage sequence.
- Identical evidence snapshots return stable risk estimates.
- An LLM cannot submit an unrecognized specimen ID through the guarded endpoint.

### Safe only after main runs complete

- QualityRelay changed detection delay, accuracy, Brier score, inspection cost, or access cost by a stated measured amount.
- QualityRelay recovered a stated fraction of centralized performance.
- Peer topology retained more capability under a stated communication fault.

Every such claim must state seeds/runs, scenario scope, uncertainty, and whether the run was preregistered or exploratory.

### Not supported by this hackathon

- industrial reliability or safety certification;
- generalization to arbitrary factories or oil refineries;
- proven scrap, cost, energy, or emissions reduction;
- superior performance to all centralized systems;
- fully autonomous manufacturing control;
- validated probability calibration from the physical coupons;
- new scientific discovery.

## 5. Wording substitutions

| Avoid | Use |
|---|---|
| “predicts defects” | “estimates insufficient-clearance risk under declared assumptions” |
| “proves decentralization is better” | “compares information topologies under matched algorithms and budgets” |
| “real-world validated” | “physical loop-closure demonstration plus seeded simulation” |
| “agents reason over the factory” | “station actors select approved actions over authorized evidence” |
| “zero hallucinations” | “numeric values and IDs are server-derived in the tested path” |
| “fault tolerant” | “continued local monitoring and idempotent replay in the tested link-outage sequence” |
| “track” | “Manufacturing & Materials challenge area; one overall competition” |
| “novel Bayesian algorithm” | “established Bayesian update applied to evidence-scoped manufacturing coordination” |

## 6. Results slide template

Title: `QualityRelay evaluation — [COMPLETE / EXPLORATORY]`

Left panel, simulation:

- scenarios, methods, seeds, units, change point;
- raw per-seed dots;
- metric definition;
- paired summary and uncertainty;
- origin label `SIMULATED`.

Right panel, physical:

- specimen IDs;
- raw repeated readings;
- `n` and caliper resolution;
- descriptive fit outcome;
- origin label `PHYSICAL_DESCRIPTIVE`;
- statement: “not used for probability calibration.”

Footer:

- shared core version and config hash;
- limitations;
- link to reproducibility artifact.

## 7. Collaboration bonus wording

Only claim the optional collaboration bonus when another team actually used a QualityRelay capability. Save evidence such as their project name, artifact version, timestamp, and what result it enabled. Publishing an API without adoption is useful but is not the same as demonstrated reuse.

