# QualityRelay 5.0 — ScienceClaw 2026 hackathon package

Prepared October 28, 2026 for a three-person team:

- Manufacturing engineer: physical system, measurement validity, specimen preparation, demo narration.
- Data scientist / vibecoder: statistical core, simulator, benchmarks, dashboard.
- Experienced computer scientist: decentralized services, event contracts, authorization, reliability, integration.

## The short answer on filament

White PLA is fine. Dimensional behavior and measurement consistency matter more than color. Use one dry spool, one printer profile, one orientation, and no supports. Matte or ordinary opaque white is preferable to glossy white under a camera. Add black specimen labels or tape and diffuse the lighting so the caliper and part edges remain visible.

## What this package is

QualityRelay is a hackathon-scale scientific demonstration of decentralized quality coordination. Separate slot, tab, and assembly agents hold different evidence and authority. They exchange evidence selectively to estimate the risk of an upcoming slot–tab pairing, request a high-value physical inspection, continue local work during a link outage, and reconcile events exactly once after reconnection.

The deterministic statistical engine is the authority. An LLM layer may decide which approved tool to call or explain a structured action, but it never invents measurements, probabilities, specimen IDs, or computed results.

No benchmark or physical result in this package is presented as already measured. Templates use `NOT_RUN` or blank fields until the team executes the experiment.

## Start here

1. Read `00_PATH_AND_RULE_VERIFICATION.md` for verified event rules and the missing original print-kit path.
2. Read `01_MASTER_BLUEPRINT.md` once as a team and freeze the P0 scope.
3. Follow `02_IMPLEMENTATION_AND_TEAM_OWNERSHIP.md` and `08_30_HOUR_SCHEDULE.csv`.
4. Implement the contracts in `contracts/` before wiring an agent framework.
5. Run the measurement-system check in `06_3D_PRINTED_SPECIMENS.md` before choosing the physical fault pair.
6. Run the preregistered experiments in `03_SCIENCE_AND_REPRODUCIBILITY.md`.
7. Rehearse `05_DEMONSTRATION_RUNBOOK.md` with the deterministic fallback enabled.

## Package map

| File | Purpose |
|---|---|
| `00_PATH_AND_RULE_VERIFICATION.md` | Exact path check and official ScienceClaw rule verification |
| `01_MASTER_BLUEPRINT.md` | Product, science, architecture, scope, milestones, rubric alignment |
| `02_IMPLEMENTATION_AND_TEAM_OWNERSHIP.md` | Step-by-step build order, interfaces, responsibilities, acceptance checks |
| `03_SCIENCE_AND_REPRODUCIBILITY.md` | Algorithms, assumptions, experiment design, metrics, manifests, analysis rules |
| `04_DECENTRALIZED_ARCHITECTURE.md` | Agent boundaries, event flow, outage behavior, authorization, failure handling |
| `05_DEMONSTRATION_RUNBOOK.md` | Reset checklist, 4-minute and 90-second demos, fallbacks, Q&A |
| `06_3D_PRINTED_SPECIMENS.md` | White PLA guidance, print plan, measurement protocol, specimen use |
| `07_RISK_REGISTER.csv` | Operational, scientific, demo, and schedule risks with owners and cutoffs |
| `08_30_HOUR_SCHEDULE.csv` | Active-hour plan and three-person ownership |
| `09_CLAIMS_AND_NOVELTY.md` | Defensible claims, non-claims, novelty guardrails, judge wording |
| `10_SOURCES.md` | Primary event and scientific references |
| `contracts/openapi.yaml` | Minimal service API contract |
| `contracts/event-envelope.schema.json` | Event and provenance JSON Schema |
| `contracts/example-events.jsonl` | Clearly labeled illustrative event sequence |
| `configs/scenario_combined_0p100mm.yaml` | Requested combined scenario with a 0.100 mm mean shift per affected station |
| `configs/experiment_matrix.yaml` | Reproducible benchmark plan |
| `templates/` | Blank manifests and measurement/result tables |
| `cad/` | Rebuilt parametric print kit and generated STL files |

## Scope tiers

- **P0 / must work:** deterministic math core, event log, three station actors, selective evidence request/response, dashboard, one physical measurement loop, origin labels, reset script, tests.
- **P1 / should work:** prospective batch-risk query, online/offline station link, exactly-once reconciliation, evidence-scoped posterior, targeted inspection ranking.
- **P2 / only after P0 rehearsal:** LLM tool-calling adapter, genuine disagreement narration, alternative-lot recommendation.
- **P3 / cut first:** live reprint loop, complex fixture hypothesis, cross-team service, elaborate UI, additional scenarios.

## Go/no-go rule

By active hour 12, the deterministic vertical loop must run end to end without an LLM. If it does not, remove the LLM layer from the critical path. A scripted deterministic actor may be demonstrated honestly as a deterministic agent policy; it must not be described as autonomous LLM reasoning.

