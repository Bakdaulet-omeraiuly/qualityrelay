# 3D printed specimens and white PLA guide

## 1. White PLA is fine

Use the white filament. Part color does not affect caliper measurement or the QualityRelay algorithms. White can work especially well with black specimen IDs and a dark mat beneath the parts.

Practical cautions:

- prefer matte or ordinary opaque white over very glossy/silk PLA;
- use diffuse side lighting to avoid losing edges on camera;
- mark each part with black tape or a fine permanent label after cooling;
- use the same spool and printer profile for the entire set;
- dry the filament if it pops, strings, or has been exposed to humidity;
- do not mix different PLA brands in one calibration set.

## 2. Missing original kit and replacement

The referenced `/mnt/data/QualityRelay_Bambu_PrintKit.zip` is not available in this environment. This package therefore includes a rebuilt, simple kit:

- `cad/qualityrelay_printkit.scad`: parametric source;
- `cad/generate_stl.py`: dependency-free STL generator;
- `cad/stl/`: generated, flat-print STL files;
- `cad/print_manifest.csv`: intended CAD dimensions and quantities.

This is not claimed to be the original prior kit.

## 3. Specimen concept

The slot coupon is a flat U-shaped part. The tab coupon is a flat rectangular strip that slides between the U arms. The functional clearance is:

`measured slot inner width - measured tab width`.

The printed set spans individually in-spec dimensions that produce clearly different pairwise clearances.

Reference CAD set:

| ID | Part | CAD dimension | Intended use |
|---|---|---:|---|
| S-GOOD | slot | 21.20 mm inner width | visibly comfortable pair |
| S-NOM | slot | 21.00 mm inner width | nominal reference |
| S-RISK | slot | 20.70 mm inner width | small-clearance pair |
| T-GOOD | tab | 19.80 mm width | visibly comfortable pair |
| T-NOM | tab | 20.00 mm width | nominal reference |
| T-RISK | tab | 20.30 mm width | small-clearance pair |
| RPT-20 | bar | 20.00 mm width | ten-reading repeatability coupon |

Print one backup each of S-RISK and T-RISK. CAD labels are design targets, not measurements.

Reference CAD pair clearances:

- S-GOOD + T-GOOD: 1.40 mm;
- S-NOM + T-NOM: 1.00 mm;
- S-RISK + T-RISK: 0.40 mm, below the 0.50 mm teaching requirement.

Actual printed dimensions may differ materially. Never select the live pair from these nominal numbers alone.

## 4. Bambu-oriented print settings

Starting settings for a 0.4 mm nozzle:

- material: PLA;
- layer height: 0.16 or 0.20 mm;
- first layer: standard profile, no extra elephant-foot compensation changes mid-set;
- wall loops: 3;
- top/bottom shell layers: at least 4;
- infill: 15–25%;
- supports: off;
- brim: normally off; use the same brim rule for every part if adhesion requires it;
- orientation: all parts flat on the same build plate orientation;
- scaling: 100%; verify millimeter import;
- seam: any consistent setting;
- cooling: standard PLA profile;
- print order: by layer or by object, but do not change process parameters mid-set.

Arrange slots and tabs with space between them. If printing risky backups, place them in different plate locations to reveal obvious location-dependent variation.

## 5. Print quantity

Minimum robust set:

- 3 slot designs × 1;
- 3 tab designs × 1;
- S-RISK backup × 1;
- T-RISK backup × 1;
- repeatability bar × 1.

Total: 9 pieces. If time is very limited, print S-GOOD, T-GOOD, S-RISK, T-RISK, both risky backups, and one repeatability bar: 7 pieces.

## 6. Post-print handling

1. Let all parts cool to room temperature on a flat surface.
2. Remove only obvious stringing; do not sand a mating edge unless the post-processing is recorded.
3. If an edge is sanded, assign a new specimen ID and remeasure it.
4. Label specimens after cooling; keep labels away from measured surfaces.
5. Store the good pair, risk pair, and backups in separate tray positions.

## 7. Measurement protocol

### Instrument check

1. Wipe caliper jaws.
2. Close gently and zero.
3. Check a known reference if available.
4. Record caliper resolution and instrument ID.

### Repeatability screen

1. Measure RPT-20 ten times.
2. Fully release and reseat the part between readings.
3. Use consistent gentle force.
4. Do not delete an outlying reading without documenting the cause.
5. Calculate mean, sample standard deviation, and range.

### Specimen characterization

For each slot and tab:

1. take three readings at the defined central measurement location;
2. record each raw reading;
3. calculate the specimen mean only after recording all readings;
4. take a photo showing specimen ID and measurement location if practical;
5. store as `origin.kind = physical` with no seed.

### Pair selection

Choose:

- one measured pair comfortably above the functional minimum;
- one measured pair near or below the functional minimum but composed of individually accepted parts;
- one backup for each.

Prefer a contrast at least 3–5 times larger than repeatability standard deviation. If this criterion cannot be met, describe the physical segment as a qualitative fit demonstration and keep all quantitative validation in simulation.

## 8. Fit criterion

Define before the demo. A simple teaching criterion:

- `pass`: tab enters the gauge depth under finger pressure without force or visible bending;
- `fail`: tab does not reach the gauge depth under the same procedure;
- `indeterminate`: inconsistent or operator-dependent result.

Record the outcome exactly. “Indeterminate” is allowed. Do not repeatedly force a part until it produces the scripted answer.

## 9. How the specimens are used in the live system

1. Preloaded station history remains labeled simulated.
2. Operator selects the upcoming lot pair.
3. Agents exchange simulated evidence summaries and calculate a simulated prospective risk.
4. The inspection policy chooses a real specimen from a server-provided list.
5. Operator measures that specimen with the caliper.
6. The measurement is ingested as physical and shown in a separate physical panel.
7. A derived physical diagnosis may use only physical parents for the headline physical view.
8. The team performs one good and one risk pairing and records descriptive outcomes.

Do not claim the physical observation came from the simulated lot unless it is explicitly a “physical analog of simulated lot B-12.” Keep identifiers clear.

## 10. Camera presentation

- dark nonslip mat under white parts;
- black ID labels visible but outside the jaws;
- phone camera locked on the caliper display;
- avoid auto-exposure pumping by using steady light;
- mirror the camera feed beside the dashboard if possible;
- rehearse hand placement so fingers do not hide the digits.

## 11. What not to do

- do not compare CAD dimensions to caliper readings as if CAD were ground truth;
- do not change slicer flow or scale for only the “faulty” parts without disclosing it;
- do not sand until a part fits and call that a process correction;
- do not compute probability calibration from two pairings;
- do not start a live redesign/reprint cycle during judging;
- do not pool physical and simulated rows into one performance metric.

