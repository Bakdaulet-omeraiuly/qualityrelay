# Implementation and team ownership

## 1. Operating model

The team works in three parallel lanes with explicit interface checkpoints. Nobody waits for a “finished backend” or “finished model.” The first shared objective is a thin deterministic vertical loop by active hour 12.

| Role | Primary ownership | Secondary ownership | Must not become the only person who can… |
|---|---|---|---|
| Manufacturing engineer (ME) | system requirements, physical print/measurement protocol, process assumptions, specimen mapping, demo narrator | risk review, acceptance tests, physical data audit | reset the physical demo or explain the problem |
| Data scientist / vibecoder (DS) | clearance risk, EWMA, diagnosis, inspection ranking, simulator, experiments, result plots, dashboard views | structured-action rendering, benchmark tests | run the benchmark or interpret each metric |
| Experienced computer scientist (CS) | services, event log, schemas, authorization, offline queue/replay, integration, deployment, test harness | dashboard wiring, agent adapter, backup recording | reset/deploy the app or diagnose the event flow |

## 2. Team rules

1. The deterministic core is merged before agent-framework integration.
2. Shared functions are used by every experimental condition; no baseline-specific math.
3. Raw station data can only be read by that station’s service identity.
4. Every merge that changes an event or API payload updates the schema and example.
5. Results are written by scripts from run artifacts, not typed into slides.
6. Physical and simulated sources remain separate at ingestion, analysis, and display.
7. A working P0 path is never replaced with an untested “cleaner” rewrite after H20.
8. Any fallback is labeled honestly: recorded replay, deterministic policy, or live LLM.

## 3. Repository shape to create

```text
qualityrelay/
  app/
    dashboard.py
    reset_demo.py
  core/
    clearance.py
    spc.py
    diagnosis.py
    inspection.py
    provenance.py
  services/
    slot.py
    tab.py
    assembly.py
    router.py
    auth.py
  agents/
    deterministic_policy.py
    llm_adapter.py              # optional P2
    structured_actions.py
  simulator/
    generator.py
    scenarios.py
    run_matrix.py
  storage/
    event_store.py
    models.py
  contracts/
    openapi.yaml
    event-envelope.schema.json
  tests/
    test_clearance.py
    test_spc.py
    test_evidence_scope.py
    test_access_control.py
    test_idempotency.py
    test_origin_separation.py
    test_prediction_determinism.py
    test_agent_grounding.py
  configs/
  results/
  runs/
```

SQLite files may live in one process for a hackathon, but use separate files or tables guarded by service-layer authorization: `slot.db`, `tab.db`, `assembly.db`, and `events.db`. Direct global queries are forbidden outside the centralized baseline runner.

## 4. Interface freeze — active hour 0 to 1

All three members do this together.

Decide and record:

- the exact P0 behavior from the master blueprint;
- the three station IDs: `slot`, `tab`, `assembly`;
- measurement units: millimeters only at service boundaries;
- minimum evidence count: five recent measurements per required station;
- freshness rule and TTL used in the demo;
- reference specifications and functional clearance threshold;
- experiment scenario IDs and pairing policy;
- deterministic seed derivation rule;
- whether the live LLM adapter is P2 or cut immediately;
- who has the final authority to freeze a feature: CS for reliability, DS for statistical validity, ME for physical credibility.

Acceptance: validate `contracts/event-envelope.schema.json` and agree not to rename event fields after H1 without all three present.

## 5. Step-by-step build

### Step 1 — physical metrology check (ME lead, H1–H3)

1. Inventory printer, white PLA, caliper, phone/document camera, labels, and printed parts.
2. If no part exists, start the rebuilt print kit immediately; printing is pre-event preparation, not a live feature.
3. Cool parts fully before measurement.
4. Measure one stable coupon ten times without looking at prior readings while reseating the caliper each time.
5. Compute mean, sample standard deviation `s_r`, range, and caliper resolution.
6. Do not lock the “risky” physical pair until its measured clearance difference is comfortably distinguishable from repeatability noise.
7. Enter physical readings only in `templates/physical_measurements.csv` or the live physical-ingest endpoint.

Acceptance: one documented repeatability series, one good pair, one risk pair, and backups identified by actual measured values.

### Step 2 — deterministic statistical core (DS lead, H1–H6)

Implement pure functions with no database or LLM imports:

- `ewma_update(previous, x, lambda_)`;
- `ewma_limits(mu0, sigma0, lambda_, L, t)`;
- `compatibility_risk(slot_model, tab_model, c_min, acceptance_specs, seed_key)`;
- `hypothesis_posterior(prior, scoped_evidence, likelihood_config)`;
- `rank_inspections(posterior, candidates, outcome_model, costs)`.

Required tests:

- analytic untruncated normal risk agrees with deterministic Monte Carlo within tolerance;
- accepted-part conditional risk differs from the unconditional calculation in the expected direction for the reference configuration;
- identical inputs give byte-stable or numerically identical output;
- removing tab evidence changes only the tab-dependent likelihood terms and evidence coverage;
- candidate ranking never returns an ID outside the supplied candidate list;
- `H0` includes the nonzero baseline failure probability.

Acceptance: tests pass from a clean environment; functions return values plus assumption/provenance metadata.

### Step 3 — event store and station services (CS lead, H1–H6)

1. Implement append-only event insertion with unique `event_id`.
2. Reject duplicate IDs without creating a second logical event.
3. Create service credentials scoped to one station.
4. Implement station-local measurement ingestion.
5. Implement evidence summary generation that references raw local event IDs.
6. Implement the router as transport only; it cannot call diagnostic functions.
7. Log allowed and denied actions.

Acceptance: slot credentials receive 403 when reading tab raw measurements; the denial appears in the audit log.

### Step 4 — deterministic station policy (CS + DS, H4–H8)

Expose the same function signatures that an optional LLM will later receive as tools:

- `get_local_recent_measurements(lot_id, window)`;
- `create_evidence_summary(lot_id, statistic_set)`;
- `request_evidence(target_station, lot_id, requested_fields)`;
- `evaluate_hypotheses(evidence_refs)`;
- `get_inspection_candidates(run_id)`;
- `select_inspection(candidate_id)`;
- `submit_measurement(specimen_id, value_mm, origin)`.

The deterministic policy calls these functions based on state transitions. It is a legitimate fallback and must complete the full flow.

Acceptance: no natural-language parser is required for any numeric decision.

### Step 5 — thin dashboard (DS lead, CS supports, H6–H10)

Build only these panels:

1. station status and link toggles;
2. upcoming lot-pair selector and risk-query button;
3. risk status/value with evidence IDs and coverage;
4. event timeline with origin badges;
5. hypothesis bars and assumption disclosure;
6. ranked inspection candidates;
7. physical measurement entry;
8. one-click access-denial demonstration;
9. reset button restricted to demo/admin mode.

Color is never the only encoding. Every badge also contains text: `PHYSICAL`, `SIMULATED`, `DERIVED`, `FRESH`, `STALE`, `PARTIAL`.

Acceptance: the query shows pending before evidence arrives and cannot render a risk value without a valid structured result.

### Step 6 — P0 vertical integration (all, H8–H12)

Run this exact acceptance sequence:

1. reset to a known database snapshot;
2. ingest or load five slot and five tab measurements;
3. select A-07 × B-12;
4. issue risk query;
5. observe pending state;
6. receive two evidence responses;
7. compute risk and evidence coverage;
8. obtain ranked inspection candidates;
9. enter one physical measurement;
10. update the posterior;
11. export the run manifest.

Do this twice from reset. If either run fails, stop work on the LLM adapter.

### Step 7 — decentralized proof (CS lead, H12–H18)

Implement and test:

- cross-station raw read denial;
- evidence-set scoping for posterior computation;
- outbound per-station queue;
- link online/offline state;
- stale/fresh gating;
- exactly-once replay using event IDs;
- “computed from N of 3 stations” display;
- router survival independent of station-local SPC.

Outage behavior:

- slot local ingestion and EWMA continue;
- no new slot evidence reaches peers;
- old events remain in audit history but are not treated as fresh;
- current posterior omits the missing likelihood term;
- reconnect flushes queued events once, then triggers a new derived estimate with new evidence refs.

Acceptance: duplicate-event count remains zero after two disconnect/reconnect cycles.

### Step 8 — optional LLM adapter (CS lead, DS guards, H15–H19)

Only start after the deterministic flow passes twice.

The adapter may:

- choose among approved tools;
- request evidence;
- select a candidate from a server-provided list;
- return a structured action with reason codes and evidence refs.

The adapter may not:

- write a measurement value;
- calculate or state a probability itself;
- invent a lot/specimen/event ID;
- access another station’s raw store;
- override a failed schema or authorization check.

Server-render all prose containing numbers. If the LLM fails or is slow, switch to deterministic policy and label the mode visibly.

Acceptance: `test_agent_grounding.py` confirms every displayed number and ID came from a service response.

### Step 9 — simulator and preregistration (DS lead, ME reviews, H18–H23)

1. Implement one generator shared by all methods.
2. Freeze pairing policy; do not switch between random and FIFO silently.
3. Run a small fault-magnitude pilot over a prespecified grid.
4. Apply the prespecified selection rule; record all pilot values.
5. Freeze the main seeds and configuration hash.
6. Run normal, slot-shift, and combined-shift scenarios.
7. Keep tab-only as a symmetry smoke test unless time allows inclusion.

Acceptance: one manifest can reproduce a run, including seed, code commit, config hash, core version, and scenario.

### Step 10 — physical loop (ME lead, all observe, H22–H24)

1. Record actual specimen IDs and three repeated readings per dimension.
2. Select the good and risk pair from measured values, not CAD labels.
3. Run the same dashboard ingestion path used in the demo.
4. Record fit outcome descriptively and, if used, define the fit criterion before testing.
5. Never add the physical outcomes to the simulation Brier-score table.

Acceptance: every physical row has operator, instrument ID, timestamp, units, origin, and no seed.

### Step 11 — results and freeze (DS lead, H23–H27)

Generate result tables and plots from run artifacts. Show:

- raw per-seed points;
- summary across seeds;
- paired method differences using identical seeds;
- communication/access cost;
- simulation and physical panels separated;
- limitations adjacent to the result they qualify.

If fewer than the preregistered seeds finish, report the number completed and label the run exploratory. Do not silently change the denominator.

### Step 12 — submission and demonstration (ME narrates, all, H27–H30)

1. Freeze the app at H25 and the results at H27.
2. Record the high-risk offline/reconnect beat as a backup replay.
3. Create slides from generated results.
4. Rehearse the 4-minute version twice and the 90-second version twice.
5. Rehearse an interruption and a no-network fallback.
6. Submit slides before the official Sunday 2:30 PM deadline.

## 6. Daily handoff checklist

At every checkpoint, each owner states:

- what passes now;
- what remains unverified;
- exact file/API changed;
- any schema/config hash change;
- whether a demo branch is reachable;
- the next feature to cut if the checkpoint slips.

## 7. Definition of done by role

### Manufacturing engineer

- physical assumptions reviewed and units consistent;
- repeatability data recorded;
- good/risk pairs selected from measured dimensions;
- physical vs simulated labels checked on screen;
- claims and demo wording technically accurate;
- demo tray, labels, caliper, lighting, and backups ready.

### Data scientist / vibecoder

- shared core passes tests;
- deterministic Monte Carlo is stable;
- H0 baseline and evidence scoping are correct;
- pilot and main experiment manifests exist;
- plots are generated, not hand-edited;
- no physical calibration metric is computed from n=2–3 trials.

### Experienced computer scientist

- services enforce station ownership;
- access denial is live and logged;
- reset is reliable;
- offline queue and exactly-once reconciliation pass;
- optional LLM cannot bypass schemas or authorization;
- local/no-network mode and backup replay are ready.

