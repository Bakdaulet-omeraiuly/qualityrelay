# Primary sources and scientific foundations

Checked October 28, 2026.

## ScienceClaw official source

- [ScienceClaw Hackathon official brief](https://scienceclawhack.ai/): dates, MIT Media Lab location, 2–5 person in-person teams, model/framework agnosticism, challenge areas, one overall competition, judging weights, collaboration bonus, and schedule.

The package relies on the organizer’s page rather than third-party event listings. Participant-only announcements may supersede public details; record any change in the run manifest.

## Statistical process monitoring

- Roberts, S. W. (1959). [Control Chart Tests Based on Geometric Moving Averages](https://doi.org/10.1080/00401706.1959.10489860). *Technometrics*, 1(3), 239–250.
- Lucas, J. M., & Saccucci, M. S. (1990). [Exponentially Weighted Moving Average Control Schemes: Properties and Enhancements](https://doi.org/10.1080/00401706.1990.10484583). *Technometrics*, 32(1), 1–12.

QualityRelay uses EWMA as an established small-shift monitoring method. It does not claim a new control chart or optimized average run length.

## Expected information gain

- Lindley, D. V. (1956). [On a Measure of the Information Provided by an Experiment](https://doi.org/10.1214/aoms/1177728069). *The Annals of Mathematical Statistics*, 27(4), 986–1005.

QualityRelay uses expected entropy reduction per inspection-time cost as a practical acquisition score. The information-gain principle is established work.

## Probability scoring

- Brier, G. W. (1950). [Verification of Forecasts Expressed in Terms of Probability](https://doi.org/10.1175/1520-0493%281950%29078%3C0001%3AVOFEIT%3E2.0.CO%3B2). *Monthly Weather Review*, 78(1), 1–3.

Brier score is used only for repeated simulated probability forecasts with known outcomes, not for the two or three physical demo pairings.

## Measurement-process characterization

- Croarkin, C. M. (2003). [NIST/SEMATECH Engineering Statistics Handbook, Chapter 2: Measurement Process Characterization](https://www.nist.gov/publications/nistsematech-engineering-statistics-handbook-chapter-2-measurement-process). National Institute of Standards and Technology.
- NIST/SEMATECH. [Quantifying uncertainties from a gauge study](https://www.itl.nist.gov/div898/handbook/mpc/section4/mpc46.htm).

The ten-repeat check in this package is a small demo screen for repeatability. It is not presented as a complete gauge R&R or uncertainty budget.

## Provenance

- W3C (2013). [PROV-O: The PROV Ontology](https://www.w3.org/TR/prov-o/), W3C Recommendation.

QualityRelay’s lightweight event fields are inspired by provenance concepts such as entities, activities, agents, derivation, and association. The JSON event schema is not claimed to implement full PROV-O conformance.

## Engineering formulas

The normal clearance formula follows standard propagation for a difference of jointly normal variables. The conditional accepted-part risk is estimated by deterministic Monte Carlo because specification truncation and pairing policy are part of the target population.

