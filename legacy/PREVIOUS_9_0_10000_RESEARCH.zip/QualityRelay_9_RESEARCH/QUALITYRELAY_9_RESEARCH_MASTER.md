# QUALITYRELAY 9.0 — VERIFIED DECISION INTELLIGENCE
## Scientific research program, 10,000-paper **candidate** literature infrastructure, falsifiable algorithm, and factory pilot blueprint

**Date and cutoff:** October 30, 2026 (US Eastern).  
**Competition:** ScienceClaw, MIT Media Lab, October 30–November 1, 2026.  
**Team:** `Bakdaulet-omeraiuly` — research and mathematical core; `adilnurgg` — distributed/backend/security; `HyorinmaruK` — mechanical validation and presentation; fourth contributor — independent QA / manufacturing integrations.  
**Inherited artifacts:** QualityRelay 8.0 EVIDENCE-MESH (complete previous blueprint) and **unchanged QualityRelay 5.0** archive are included. This version **extends**, not replaces, their contracts.

> **Evidence honesty statement (essential):** The deliverable includes a tested collector designed to retrieve **10,000 unique bibliographic candidate records** on a computer with Internet access, a topical collection protocol, a small curated seed list with primary source links, a novel *proposal*, and running reference tests. **10,000 papers have NOT been fetched or individually read in this environment** because the scholarly bulk APIs are unreachable from the local execution environment. A candidate metadata corpus is not equivalent to 10,000 scientifically reviewed studies. No new scientific finding or superiority claim is established until pre-registered experiments are run and independently reproduced. This distinction must remain visible on the website and pitch.

---

## 0. Executive research claim — what could actually be original?

**Manufacturing problem:** Local dimensional acceptance does not guarantee acceptable downstream assembly. Each station sees only its own measurements, while assembly requires joint tolerance information. Real factories face additional problems: mixed lots, costly inspections, restricted supplier data, drifting machines, missing evidence, intermittent connectivity, inconsistent sensor reliability, and humans who must authorize interventions.

**Known prior art:** Sequential inspection by information gain (2021); manufacturing digital threads and quality gates; digital twins; specialist-agent orchestration; conformal risk-control tools; Bayesian diagnosis and expected value of information; privacy-aware distributed systems. We DO NOT invent these components.

**Candidate scientific contribution:** **V-DER: Verifiable Decision-Effect Routing** — a policy for *which restricted manufacturing evidence to request next* that explicitly optimizes the **expected improvement in a downstream physical decision** under time, privacy, communication, metrology, calibration, and approval constraints. It adds three auditable controls:

1. **Counterfactual Decision Certificate (CDC):** each request states *which current decision it might change*, the hypothesized failure modes, uncertainty bounds, provenance, and expected cost of requesting it.
2. **Protected Expert Dissent (PED):** a minority expert's tool-backed counterexample may not be buried by 19 agreeing language agents; all material counterevidence gets an independently checkable challenge path.
3. **Bounded Autonomy Ledger (BAL):** a cryptographically traceable chain from raw observation to authorized summary to decision suggestion to human approval to independently measured outcome, with explicit abstention and offline operation.

The **testable conjecture**, not a proven discovery: under selected information partitions and cost regimes, this integrated protocol lowers expected *decision loss* and/or evidence exposure versus (i) information-gain-only inspection, (ii) fixed inspection, (iii) unstructured agent discussion, and (iv) a fair single-agent baseline. It is **not** expected to dominate an ideal centralized agent with full reliable information under all settings. Negative results are scientifically valuable.

**One-sentence pitch:** *QualityRelay helps separated manufacturing specialists discover the smallest authorized measurement that can change a costly assembly decision, while preserving the dissent, physical evidence, and human approval needed to trust that decision.*

---

## 1. What the research actually says: decisive sources

### Research synthesis, with source-type and honest scope

| Evidence | Established result | Scientific gap left open for our experiments | Primary source |
|---|---|---|---|
| NIST digital-thread experiment (2021) | Full integration of design/manufacturing/inspection information was challenging in a small implementation | Share minimal authorized *decision-relevant* evidence without creating one global raw-data copy | https://www.nist.gov/publications/defining-requirements-integrating-information-between-design-manufacturing-and |
| Sequential inspection (Sensors, 2021) | Bayesian / expected information gain can select fault-diagnostic measurements in multistage manufacturing | Choose evidence based on *action loss and information restrictions*, rather than inventing IG | https://pmc.ncbi.nlm.nih.gov/articles/PMC8618403/ |
| CIRP Annals (2024) | Quality gates, feedback and feedforward loops affect total multistage performance | Test whether interventions requested through distributed evidence change production-level outcomes | https://doi.org/10.1016/j.cirp.2024.04.015 |
| Manufacturing AI agents survey (JIII, 2026) | Survey of 96 publications; decision, reasoning and orchestration agents already appear in process optimization | Define falsifiable agent-specialization benefits, not mere role names | https://doi.org/10.1016/j.jii.2026.101129 |
| QA digital-twin assurance review (Oct 28, 2026) | Review of 235 QA studies identifies gaps between monitoring, authority and assured intervention | Join provenance, authority, abstention and measurable outcome into one chain | https://doi.org/10.1186/s44147-026-01295-x |
| HiddenBench (ICML, 2026) | Under distributed evidence, multi-agent LLM groups attained 30.1% on specific tasks versus 80.7% for fully informed single agents; limited generalizability | Detect inaccessible decisive facts and force targeted questioning | https://proceedings.mlr.press/v306/li26ej.html |
| Multi-Agent Teams Hold Experts Back (ICML, 2026) | Self-organizing teams may down-weight correct experts, with losses reported up to 41.1% in evaluated benchmarks | Ensure verified minority dissent triggers a test rather than a majority vote | https://proceedings.mlr.press/v306/pappu26a.html |
| Conformal Risk Control (ICLR 2024) | Controls expected monotone loss under conditions described by method | Risk estimation must state calibration/shift assumptions; not magic factory safety guarantee | https://proceedings.iclr.cc/paper_files/paper/2024/hash/f3549ef9b5ff520a7e41ff3cc306ab2b-Abstract-Conference.html |
| PeopleJoin (ACL 2025) | Information gathering from multiple distinct people can be evaluated as a coordination problem | Test requests over restricted industrial information owners | https://aclanthology.org/2025.findings-acl.916/ |
| AgentLeak (IEEE Access, 2026) | Inter-agent communications can expose sensitive information not present in final outputs | Audit *all* internal channels, not just UI visibility | https://doi.org/10.1109/ACCESS.2026.3704541 |

**Reading warning:** These sources do not jointly prove V-DER's novelty. A proper novelty review must compare algorithms and source code and seek disconfirming prior art. The claim can fail if an existing paper already combines the same mechanisms. The dates, paper statuses and linked abstracts must be re-checked before public citation.

### Ten research frontiers to test rather than proclaim solved

1. **Hidden decisive evidence:** agent does not know which peer holds critical information.
2. **Information-to-decision mismatch:** high entropy reduction can leave final assembly choice unchanged.
3. **Unequal specialist reliability:** best-calibrated specialist can be overridden by eloquent but wrong majority.
4. **Privacy/informativeness Pareto frontier:** which minimal sufficient summaries should leave station boundaries?
5. **Joint quality risk:** acceptance-truncated part distributions and cross-lot dependence invalidate naive normal assumptions.
6. **Calibration under drift:** predictions degrade when sensors, materials or supplier lots change.
7. **Active metrology:** how does noisy, time-expensive inspection alter the best next experiment?
8. **Partition resilience:** evidence may be stale or delayed, and delayed events must not be replayed twice.
9. **Assured intervention:** diagnostic confidence is not the same as authority to stop a line or modify settings.
10. **Scale versus quality:** 20 specialists can create more disagreement, cost, latency and leakage; activate by need and ablate by expertise.

---

## 2. Literature program: 10,000 metadata candidates, NOT 10,000 read studies

### 2.1 Reproducible electronic retrieval

- **Target**: up to exactly **10,000 distinct metadata records** (DOI-primary deduplication, normalized title fallback), publication date no later than **2026-10-30**.
- **Source**: Crossref works endpoint; 32 topic search queries spanning manufacturing, Bayesian inspection, agent coordination, information economics, safety, causal inference and standards. OpenAlex could later corroborate DOI/metadata; do not merge without identity validation.
- **Included metadata**: title, DOI, publication date/year, authors, venue, type, URL, citations (provider-reported), search categories, retrieval time. **No copyrighted article texts included**.
- **Where**: `research/collect_10000.py` (Python 3.10+ stdlib, online-capable). Data files write into `research/corpus/` and include `AUDIT.json`, `SHA256SUMS.txt` and `retrieval_log.jsonl`.
- **Run on Internet-connected Mac:**

```bash
cd QualityRelay_9_RESEARCH
python3 research/collect_10000.py --target 10000 --output research/corpus --email you@university.edu
```

- **Resumability**: `resume_state.json` persists cursor/page state; data are rewritten after each page with provenance. If API rejects cursor/query combination, adjust the documented collector and record change rather than silently switching sources.
- **Honesty**: output rows are `CANDIDATE_UNSCREENED`, `full_text_reviewed=false`, `claim_verified=false`. A row may be only weakly related to the query. Citation counts are not quality or novelty guarantees.

### 2.2 Practical screening funnel

| Stage | Task | Required evidence |
|---|---|---|
| Identification | Retrieve up to 10,000 unique Crossref candidates | Raw metadata CSV, timestamp, API source and errors |
| Title screening | Human/assisted topical inclusion against prewritten rule | Included/excluded flag + explicit reason + rater |
| Abstract screening | Obtain lawful abstracts where available and independently code | Extraction fields, disagreement reconciliation |
| Full text | Read **permitted** primary texts for priority papers | PDF/URL evidence, methods, baselines, dataset, reproduction status |
| Core synthesis | Build curated high-confidence evidence matrix | Verified claims linked to section/table/figure |
| Novelty test | Try hard to find publications that already propose each V-DER mechanism | Adversarial prior-art memo, direct comparisons |
| Pilot validation | Run declared benchmarks and physical tests | Run manifests, seeds, metrics, failures, limitations |

**Screening fields**: `retrieval_id`, `doi`, `topic`, `title_decision`, `abstract_decision`, `full_text_available`, `methods`, `datasets`, `competing_method`, `strength`, `limitations`, `status`, `reviewer`, `date`, `evidence_quote_location`. No hallucinated abstracts. Review at least a focused set deeply; number alone is not a scientific contribution.

### 2.3 Relevance rules

Include work addressing industrial quality diagnosis, uncertainty, active experiment design, decentralization, causal fault attribution, agent coordination/reliability, metrology, audited intervention or industrial integration. Exclude irrelevant terms matching only by keyword, retracted works (track separately), duplicates, editorial pieces without method, sources without verifiable bibliographic record. Review/preprint/report categories are distinct. A review that includes 235 studies does **not** mean we read its 235 studies.

### 2.4 Present status and literature audit

- 10,000 candidate retrieval goal defined: **yes**.
- Source collector implemented and syntax/unit tested offline: **yes**.
- Live bulk metadata retrieval in this environment: **no — blocked by network/DNS restrictions**.
- 10,000 records reviewed or full texts read: **no**.
- Curated primary-source research seed: `research/verified_seed_references.csv`; use that as research leads, not as a 10k corpus.
- Real factory or validated industrial pilot: **no**.

---

## 3. Formal scientific model and V-DER decision protocol

### 3.1 Physical target preserved from original 5.0

Three independent station agents keep local ownership:

- **Slot station** observes slot width `W`, accepted nominal interval **20.5–21.5 mm**.
- **Tab station** observes tab thickness `T`, accepted nominal interval **19.5–20.5 mm**.
- **Assembly station** observes fit outcome and clearance `C=W−T`, requiring `C>=0.5 mm`.
- `W=20.6 mm` and `T=20.3 mm` yield clearance `0.3 mm` (illustrative, **not observed**): both pass local limits but fail joint clearance.

Full calibration must account for **truncation after local acceptance**, possible correlation across lots and measurement uncertainty. A simple normal approximation before truncation is not the final model:

```
mu_C = mu_W - mu_T
var_C = sigma_W^2 + sigma_T^2 - 2*rho*sigma_W*sigma_T
P(C < c_min) = Phi((c_min-mu_C)/sqrt(var_C))    # only unconditional normal approximation
```

The operational estimate conditions on both parts passing their individual gates, pairing policy, process dependence, and sensor noise, with deterministic seeded simulation or validated integration.

### 3.2 Notation

- `H`: mutually exclusive process hypotheses (H0 stable; H1 slot drift; H2 tab drift; H4 combined drift). Extensions to fixture fault require physically grounded likelihoods and a clear new hypothesis identifier.
- `E`: currently authorized timestamped observations; `E_i` stored locally under station ownership.
- `M(E)`: set/distribution of causal models still compatible with evidence, including uncertainty caused by omitted nodes and stale sensors.
- `a`: candidate physical/product decision (pair/reject/hold/inspect/alternate lot); `a` is NOT executed until authorized.
- `q`: candidate scoped information request (station summary, inspection of specimen, additional fit test); includes expected latency, calibration status, privacy cost, data provenance and permission.
- `y`: possible response to request q.
- `L(a,H)`: task-specific economic/physical loss with safety and false-negative penalties fixed before experiment.
- `R(E)`: best achievable expected decision loss given current evidence, and only actions that satisfy safety bounds.

### 3.3 Information gain is not decision gain

Classical Bayesian information gain:

```
IG(q|E) = H[p(H|E)] - E_y H[p(H|E,y,q)]
```

This can prefer a query that reduces uncertainty about an irrelevant hypothesis without changing the production action. **Existing research already uses this:** do not present IG as original.

**Proposed V-DER value-of-decision request ranking:**

```
R(E) = min_{a in A_safe(E)} E[L(a,H)|E]
EVSI(q|E) = R(E) - E_y[R(E union response(q,y))]
NET(q|E) = EVSI(q|E) - lambda_t*T(q) - lambda_p*P(q)
           - lambda_b*Bandwidth(q) - lambda_c*CalibrationRisk(q)
q_star = argmax_{q authorized, fresh, feasible} NET(q|E)
```

`A_safe(E)` is an engineer- and policy-defined action set. If model uncertainty makes every release action unsafe, choose `hold / inspect / request human review`. The relative units of time, privacy, and money must be converted into an **explicit, frozen cost model**, not arbitrary score blending. If all NET values are non-positive, stop gathering and recommend best current permitted decision or abstain.

**Privacy protection:** `P(q)` must be grounded in an enforceable disclosure classification and a policy budget; NOT a claim that every aggregate is privacy-preserving. Some sufficient statistics can reveal sensitive information. For strict privacy protection, require implemented cryptographic, access-control or formal privacy mechanism and audit it.

**Missing evidence:** do not treat unobserved station as safe or infer a likelihood from stale data. Model uncertainty and evidence coverage must expand appropriately.

### 3.4 CDC: counterfactual decision certificate schema

```json
{
  "certificate_type":"proposed_scientific_protocol",
  "incident_id":"SIM-001",
  "decision_current":"hold",
  "decision_alternatives":["release","hold","inspect"],
  "hypotheses":["H0","H1","H2","H4"],
  "evidence_used":["event-id-from-local-station"],
  "missing_evidence":["fresh-tab-lot-summary"],
  "candidate_query":"request_authorized_tab_summary",
  "expected_decision_loss_before":"computed-by-versioned-backend",
  "evsi":"computed-by-versioned-backend",
  "privacy_disclosure_class":"summary-only",
  "model_version":"frozen-git-commit",
  "calibration_status":"unvalidated",
  "unsafe_action_guard":"no-automatic-physical-execution",
  "human_approval":"pending"
}
```

Values above are intentionally placeholders, not fake measurements. Numeric fields must be typed numbers in production and never filled by an LLM without calculation tools.

### 3.5 PED: protected expert dissent

Every specialist can register a structured `challenge` with `hypothesis`, `counterevidence_event_ids`, `quantitative_claim`, `tool_result_hash` and `expected_action_change`. Dissent is *not automatically true*. It triggers **independent verification** by a designated calibration/causal/measurement role. Rejection requires a logged reason and a counter-test. An unsupported claim cannot stall the system forever; timeout leads to explicit `unresolved` state and conservative decision policy.

**Reasoning hazard:** 20 agents repeating the same mistaken assumption are not 20 independent votes. The system must track common training/model lineage and correlated evidence. A single calibrated metrology tool can outweigh many natural-language opinions.

### 3.6 BAL: human-governed audit and authority

`observation -> authorized summary -> request -> tool result -> hypothesis update -> proposed action -> engineer approval -> physical outcome -> feedback`. Every link carries UTC time, exact source IDs, hash, permission result, algorithm version, calibration status and simulated/physical origin. The Chief Engineer may issue a **recommendation**, never directly override station truth or operate dangerous machinery.

**Minimal logical claim (conditional):** If the decision gate always rejects release whenever its declared conservative upper risk exceeds the configured bound, it enforces that *software decision rule on its inputs*. It does NOT establish that the unknown true physical risk is bounded absent a calibrated and valid model. In no circumstances translate this into a certified factory safety guarantee.

### 3.7 Actual executable miniature reference

`src/decision_value_prototype.py` implements a four-hypothesis Bayesian toy model, deterministic measurement likelihood updates, expected decision loss and EVSI-based next inspection. It intentionally uses illustrative probabilities and costs, not learned factory parameters. Tests verify normalization, nonnegative EVSI (up to roundoff), uninformative evidence, high-risk hold and response structure.

Run:

```bash
python3 src/decision_value_prototype.py
python3 -m unittest discover -s tests -v
```

**Important:** This is a *calculation prototype*, not the original 5.0 full statistical library, not multi-station deployment, and not scientific validation of V-DER's claimed advantage.

---

## 4. Agent architecture: 20 real specialists, three independent station nodes and bounded Chief Engineer

### 4.1 Principle

Specialists are **permissioned tools and testable hypotheses**, not personality prompts. Each role has distinct inputs, capabilities, prohibited actions, calibration checks, and an ablation. Define stable typed endpoints and state-specific activation triggers. Deploy distinct LLM calls where reasoning genuinely helps; use deterministic physics, statistics and policy checks where arithmetic matters.

### 4.2 Twenty specialist roles (activation is selective)

| # | Specialist | Scoped input | Approved tool / mathematical role | Material output |
|---:|---|---|---|---|
| 01 | Design Geometry | CAD revision & tolerances | CAD parser, geometric constraints | Fit envelope / datum conflict |
| 02 | Tolerance Analyst | Design limits, part distributions | Acceptance-conditioned Monte Carlo | Compatible lot risk |
| 03 | Materials Engineer | Material/process lot data | Material property rules and drift test | Material-linked hypotheses |
| 04 | Process Engineer | Station process time series | Process graph, Bayesian likelihoods | Fault source probabilities |
| 05 | CNC Machining Expert | Machining log, tool offsets | Structured machine-state diagnostics | Wear/offset candidates |
| 06 | Additive Manufacturing Expert | Print recipe, nozzle/layer parameters | Build process anomaly diagnostics | 3D print deviation explanation |
| 07 | Metrology Expert | Measurement repeats, caliper details | Repeatability and measurement noise tests | Validated measurement uncertainty |
| 08 | SPC Expert | Authorized local sensor series | EWMA/CUSUM and control limits | Drift evidence, not verdict |
| 09 | Quality Inspector | Dimensional QA results | Acceptance gate, traceability audit | Local pass/fail certificate |
| 10 | Assembly Engineer | Joint lot IDs and fit records | Clearance and fit-model verification | Assembly risk and test design |
| 11 | Causal Diagnosis | Versioned process causal graph | Model comparisons and sensitivity | Competing causal explanations |
| 12 | Bayesian Statistician | Authorized evidence likelihoods | Posterior update and calibration | Grounded uncertainty estimates |
| 13 | Inspection Planner | Candidate measurements + costs | Decision-value / IG baselines | Next allowed inspection |
| 14 | Operations Research | Lot availability and constraints | Selective matching optimizer | Proposed pairings and feasibility |
| 15 | Maintenance Engineer | Machine maintenance history | Condition trend and change point | Maintenance inspection request |
| 16 | Supplier Boundary | Supplier-authorized summaries | Disclosure policy & signature check | Shareable aggregate evidence |
| 17 | Safety and Governance | Risk policy, operator rights | Hard authorization and abstention gate | Denied/approved-action proposal |
| 18 | Cybersecurity and Privacy | Access events, message metadata | Policy validation, leakage test | Evidence boundary audit |
| 19 | Reliability and Network | Node health, queue snapshots | Partition and replay verification | Freshness/coverage report |
| 20 | Scientific Auditor | Frozen config, run manifests | Reproducibility and benchmark review | Discrepancies and limitations |

**Original 5.0 independent *station actors* remain separate and are NOT counted among the 20:** Slot, Tab, Assembly services, each with local DB, own measurement events, and authorized cross-boundary messages. Their data ownership cannot be replaced by departmental personas. The **Chief Engineer** is a 24th logical actor that orchestrates recommendations but cannot become the sole planner or data oracle. Physical operators remain human.

### 4.3 Chief Engineer Agent, selected B mode

- Accept incident with authorized lot IDs and observable evidence coverage.
- Form evidence-debt map: what each specialist knows, what is missing, how freshness affects conclusions.
- Delegate to **small relevant subsets** (2–6 active roles per incident); no blind 20-agent debate.
- Ask other experts to test conflicting explanations; require tool evidence and causal alternative.
- Call risk/EVSI computation through versioned deterministic service.
- Produce a **reviewable** recommendation and CDC; request human approval.
- Chief offline -> local station processes and peer evidence exchange still run; show degradation honestly.
- Cannot: browse arbitrary local DB, approve its own unsafe action, falsify an event, bypass 403 permissions, change CAD baseline without authority, or issue live actuator commands.

### 4.4 Agent budget and anti-theater metrics

- **Cost budget:** token spend, tool calls, messages, latency, bytes, and privacy disclosure per incident.
- **Routing:** at most 6 concurrently active specialists at demo; 20 registry slots shown as capabilities, not claims all were independently implemented.
- **Evidence precedence:** validated measurement > versioned calculation > expert qualitative hypothesis > unverified narrative.
- **Failure transparency:** unsupported tools must be unavailable, not silently mocked; simulations visibly labeled.
- **Agent ablation:** removal of one specialist reveals which class of hypotheses/risk/inspections degrades. If a role provides no measurable benefit, merge or remove it from production.

---

## 5. Scientific hypotheses, controls and disconfirming experiments

### 5.1 Pre-registration (before final test seed generation)

`H1 (decision-value)`: At equal physical inspection budgets, V-DER reduces mean realized decision loss vs entropy-based IG in a multi-hypothesis setting where uncertainty and decision relevance diverge. **Can fail** where IG is sufficient or costs are uniform.

`H2 (hidden evidence)`: Under unequal information ownership, policy-guided targeted requests increase correct source attribution or decrease misses vs unstructured multiagent chat, at comparable request budget. **Can fail** when summaries lose decisive information.

`H3 (expert minority)`: PED reduces accuracy losses caused by suppressing a correct minority specialist vs vote/consensus, without excessive false veto and delay. **Can fail** under unreliable experts/adversarial evidence.

`H4 (privacy)`: Scoped summary exchange reduces raw record disclosure relative to raw-data centralization at a pre-declared risk/accuracy tolerance. **Can fail** when sufficient summary itself leaks or proves inadequate.

`H5 (resilience)`: Locally independent nodes retain *limited safe local operation* and reconcile idempotently under selected partition types vs a single hub. **Can fail** when global approval is required (should abstain), or queues overflow.

`H6 (human governance)`: Approval-gated CDCs improve traceability and reduce unauthorized action recommendations compared with a free-form Chief Engineer. **Can fail** if reviewers cannot understand certificates or false confidence increases.

### 5.2 Baselines and fairness

| ID | Experimental condition | Honest purpose |
|---|---|---|
| B0 | Traditional fixed inspection | Established factory baseline |
| B1 | Random inspection at matched budget | Null control |
| B2 | Entropy-based information gain (2021-style) | Strong established active inspection baseline |
| B3 | Cost-normalized IG | Avoid unfairly handicapping IG |
| B4 | Centralized statistical oracle with **all raw information** | Upper bound / access advantage, not a fair same-access model |
| B5 | Centralized single AI, only authorized equivalent evidence | Same-access orchestration test |
| B6 | 5.0 decentralized station protocol, no specialists | Inherited architecture baseline |
| B7 | Multiagent free discussion, same evidence | Tests whether roles alone help |
| B8 | 8.0 EVIDENCE-MESH with expert tools | Previous proposed method |
| B9 | V-DER without PED | Ablation: dissent control |
| B10 | V-DER without decision effect, entropy only | Ablation: action-aware value |
| B11 | V-DER without privacy gate | Ablation: disclosure constraint |
| B12 | Full V-DER + 20 registry + selective routing | New candidate system |
| B13 | B12 with Chief Engineer offline / node partition | Decentralization proof |

**Crucial:** compare B4 under full access only as an upper bound; same-access B5 for fair agent organization. In a topology experiment, keep statistical model, random seeds, decision costs, precision, candidate actions, human approval constraints and availability of authorized evidence fixed unless topology is the manipulated factor.

### 5.3 Scenario generation: minimum credible matrix

- S01 nominal stable, all conforming.
- S02 slot mean drift down; S03 tab mean drift up; S04 simultaneous drifts; S05 variance inflation, unchanged means.
- S06 locally passing yet jointly incompatible lots; S07 measurement bias; S08 correlated lots and non-normal tails.
- S09 design tolerance error; S10 supplier data withheld; S11 stale station; S12 network partition/reconnect.
- S13 deliberately misleading majority agents, one correct specialist; S14 expert is mistaken; S15 accidental data leakage attempt; S16 unauthorized tool call.
- S17 pairing policy changes; S18 model drift; S19 incomplete causal graph; S20 two competing failure modes with identical observations.
- S21 asymmetric inspection costs; S22 high false-negative loss; S23 sensor repeatability below effect size; S24 previously unseen anomaly -> abstain.

The original 5.0 YAML scenarios, including combined shift `-0.100/+0.100 mm`, are preserved untouched. New scenarios augment the original suite; do not rewrite the benchmark after seeing final results.

### 5.4 Required metrics

Primary (preselect one): **mean realized decision loss** at fixed inspection budget, calibrated to declared cost matrix and **ground-truth simulated process**.

Secondary: fault source classification accuracy and confusion matrix; assembly-risk Brier score and calibration plots; 95% coverage of declared uncertainty intervals where valid; time to identify source, inspection count, accumulated cost, raw record exposure, message bytes/count, evidence coverage and freshness, abstention rate, false release rate, false hold rate, unauthorized access attempted/blocked, duplicate-event count after reconnect, and expert dissent preservation rate.

Physical: separately report **count of printed parts**, **caliper repeatability**, **observed fit outcomes**, **measured clearances**, and signed/dated technician notes. Never turn 3 physical pairs into a 95% model-accuracy claim.

### 5.5 Stats and reproducibility

- Freeze seeds/configs and a holdout generator before final runs; pilot seeds may be used for tuning, not reported as holdout.
- Pair comparisons by identical simulation seed and scenario. Report paired mean differences and bootstrap 95% CIs; pre-specify a primary comparison and multiplicity treatment for many secondary tests.
- Report absolute baselines, not only percentages. Include failure examples and run-time budget.
- Do not treat simulated observations from the same generator as independent external validation.
- Negative outcomes must be recorded. A single fabricated high-scoring demo is a failed science outcome.

**Research validity gate:** a positive result is merely *preliminary evidence in a toy/simulated setting* until independent data, independent author replication and serious prior-art search are completed.

---

## 6. Deployment and mechanical validation (HyorinmaruK owner)

**Scope of initial paid external service:** team prints PLA parts. External dimensional inspection/CMM provider may measure supplied parts and write a report; that is NOT validation of AI coordination unless they additionally evaluate algorithmic outputs.

### Physical test sequence

1. Freeze original 5.0 slot/tab CAD dimensions and acceptance rules. Save STL hashes and print/material settings.
2. Print nominal, safe and intentionally borderline slot/tab variants + repeatability coupon + backups.
3. Independently measure one reference coupon at least ten times to estimate measurement repeatability, recording instrument, resolution, temperature and operator.
4. Measure slot interior width and tab thickness at repeatable designated locations; capture uncertainty and original observation IDs.
5. Perform fit/not-fit tests under a documented non-forced procedure. Record mismatch, direction and photos.
6. Route **the same physical measurements** through QualityRelay and strong baselines, then compare **recommendation traceability**. Do not fabricate unseen ground truth.
7. Record any independent engineer notes verbatim with consent and their limitations.

**Camera:** optional evidence capture, not metrology unless calibrated with known scale, optical distortion model and uncertainty; no claim of millimeter accuracy from an ordinary phone photo.

### Industrial readiness ladder

- L0: synthetic reproducible simulation and meaningful baselines.
- L1: physical bench demo with logged measurement uncertainties.
- L2: independent dimensional report and engineering review.
- L3: historical real-factory data under NDA with permissions.
- L4: human-approved shadow deployment on a real line (read-only, no actuator access).
- L5: audited production integration after process safety, IT security, change management, reliability and site-specific validation.

**As of this version, actual status is specification + miniature toy inference, not L1-L5 factory validation.** ISO/NIST alignment is a design objective, not certification.

---

## 7. One unified website: screens, backends and acceptance gates

### Functional architecture

```text
                  One QualityRelay Web Application
     [Home/Incident] [Factory Twin] [Risk] [Inspect] [Research]
     [Evidence Graph] [Expert Challenges] [Chief Review] [Audit]
                             |
                 API Gateway + Role/Policy Gate
                             |
         Chief Engineer (bounded recommendation authority)
              |            |                 |
      20 typed specialist services / optional LLM adapters
              |            |                 |
         read-only authorized evidence request broker
              |            |                 |
  Slot Station DB     Tab Station DB      Assembly Station DB
       [LOCAL]            [LOCAL]             [LOCAL]
              \           |                 /
                Event Router (no inference authority)
                             |
    Deterministic physics, Bayesian risk, inspection value engine
                             |
    Immutable replay/audit + human engineer approval and feedback
```

### Required live demo path

1. User selects upcoming slot lot + tab lot.
2. Assembly shows `pending_insufficient_evidence` before cross-station replies.
3. Slot/tab agents answer **authorized summaries only**, with event IDs and time stamps; a raw cross-read gets 403.
4. Versioned numeric engine calculates joint fit risk and uncertainty.
5. PED challenge from Metrology or Design agent either alters the next inspection or gets a documented rejection.
6. V-DER offers an allowed measurement with **expected decision effect**, time cost and evidence coverage.
7. Operator enters real caliper readings labeled `origin.kind=physical`; derived risk updates and prior result remains in audit.
8. Chief Engineer explains proposed decision but requests human approval before sensitive action.
9. Turn Chief offline and disconnect one station; station-local work persists; risk confidence degrades honestly.
10. Reconnect and replay queued event IDs exactly once; export run manifest and results.

### Security and failure handling

- Deny-by-default cross-station authorization; scoped, expiring access grants; secrets server-side.
- Event payload schema, signature/identity, deduplication key, ordered append-only audit.
- Stale evidence excluded from a current posterior, not quietly reused as if current.
- LLM text is never the only source of authoritative numeric or production decision.
- Injection and fabricated source-ID tests; strict candidate specimen ID allowlist; no arbitrary tool invocation.
- Human approval separated from model operator, with rejected-action logging.
- Dashboard labels computed/simulated/physical/proposed/unsupported rather than making them look equal.

---

## 8. Division of labor, three people + optional fourth

### `Bakdaulet-omeraiuly`: Research Lead / Statistical Engineering

- Owns 5.0 conditional clearance-risk library, Bayesian diagnosis, SPC/EWMA, V-DER EVSI score, baselines, experiment scenarios/seeds, calibrated measurement-uncertainty assumptions, research source synthesis.
- Implements reproducible CLI experiment runs and scientific tables, with statistically fair comparisons; cannot claim improvements before execution.
- Owns literature collector protocol; 10,000 candidate records only after verified network retrieval.
- Supplies datasets, figures, result caveats, and conference-style methods/limitations to presentation owner.

### `adilnurgg`: Distributed Systems / Chief Engineer / Security

- Owns station-local storage, event router, API contracts, 403 tests, isolated/central topology toggles, queue/reconnect, audit signatures, permission scopes, security threat model.
- Builds Chief Engineer B-mode task graph and bounded approvals; PED challenged claim and CDC payload, deterministic numeric service integration.
- Publishes deployment/rollback and tests. Never lets the Chief become a hidden omniscient global DB reader.

### `HyorinmaruK`: Mechanical Engineering / Validation / Final Presentation

- Owns CAD/STL inspection, part manufacturing, PLA/print tolerances, caliper repeatability, physical assembly and dimensional evidence, mechanical validation report.
- Owns final slides, pitch narrative, recorded demo, mechanical interpretation and the visual explanation of counterexamples.
- Collaborates on website UX for diagrams and fit/inspection result clarity, not all frontend implementation alone.

### Fourth person (if joins): Frontend / QA / Industrial Integration

- Owns frontend production UI, evidence graph, interactive demo controls, accessibility, test automation, schema-driven API client.
- Runs independent E2E and adverse-case acceptance tests, CMM/CSV connector prototype, manufacturing user interviews, privacy red-team.
- Without fourth person: `HyorinmaruK` owns minimum demo UI design; `adilnurgg` integrates core frontend screens; `Bakdaulet-omeraiuly` provides chart/benchmark data. Freeze advanced features after P0 works.

### Integration contract and PR sequence

```text
main (protected)
  feature/statistical-core-and-baselines            @Bakdaulet-omeraiuly
  feature/station-services-and-chief                @adilnurgg
  feature/mechanical-evidence-and-pitch             @HyorinmaruK
  feature/web-ui-qa-and-integrations                @fourth-if-available
```

P0 contract freeze -> deterministic math -> station evidence loop -> website -> physical reading -> live benchmark -> offline/reconnect -> independent rehearsal. All numeric demos reference server result IDs. CI gates: unit tests, schema validation, 403 negative test, deterministic replay, no placeholder metrics marked real.

---

## 9. Prioritized actual deliverables for ScienceClaw, not vanity features

**P0 (~hackathon):** working 5.0 vertical slice; one visible CDC; 3–4 real active specialist tools; Chief delegation with human approval; one physical caliper update; 2 matched baseline runs; role-based 403; one offline/replay test; export evidence manifest. A functioning small proof outperforms 20 fake personas.

**P1 (~next weeks):** V-DER with deeper causal models and calibration, 20 specialist registry roles with independent unit tests, 10k candidate metadata collection + serious screening, real-factory candidate data, randomized double-blind mechanical validation.

**P2 (~months):** robust privacy and differential access, active learning from labeled production anomalies, true metrology connectors, real production shadow pilot, joint calibration and drift monitoring, feasibility analysis with plant engineers.

### Hard disqualifiers

- Inventing 10,000 citations or claiming 10,000 full papers were read.
- Replacing missing measurements with AI-invented numbers.
- Comparing 20-agent system to a purposely handicapped centralized or single-agent baseline.
- Claiming a mathematical guarantee without its assumptions, or a safety guarantee from a toy simulator.
- Claiming ISO certification, real-factory readiness, first-in-world novelty, or a Nobel-level breakthrough without independent proof.
- Calling simulated physical outcomes a real measurement.
- Failing to show what remains operational when Chief Engineer disconnects.

---

## 10. Research outputs that would justify a future scientific paper

A strong, publishable **future** paper could be structured as:

1. **Question:** When does decision-focused evidence routing improve industrial assembly decisions under distributed authority and measurement constraints?
2. **Prior art:** Sequential manufacturing IG, active sensing, digital threads, hidden profile collective failures, decision-focused acquisition, privacy/federated coordination, assured digital twins.
3. **Method:** V-DER + CDC + PED + BAL; precise formal objective and access semantics.
4. **Mathematical boundaries:** finite action models, calibrated likelihood assumptions, explicitly scoped risk sets, failure under model misspecification.
5. **Experiments:** multiple fault graphs, observation-model sensitivity, costs, partitions, privacy, 1/4/8/20 agents and matched baselines.
6. **Ablation:** turn off decision value, dissent, summary gating, authorization, Chief, and network resilience one at a time.
7. **Artifacts:** generator, run manifest, code, policy checks, human-readable certificates and at least one independent physical measurement report.
8. **Results:** absolute metrics, uncertainty intervals, failures, adverse cases and real experimental observations, not imagined percentages.
9. **Limits:** synthetic-to-industrial transfer, noisy/biased metrology, source provenance, access barriers, unmodeled mechanism, human factors.
10. **Claim:** restrict conclusion to actual demonstrated domain and uncertainty.

**Novelty honesty:** Until competing algorithms have been identified and results reproduced, V-DER is a **research contribution candidate**. No one can truthfully manufacture a new scientific discovery purely by producing a longer bibliography or manuscript.

---

## 11. Where to find the inherited full materials

- `legacy/QUALITYRELAY_8_0_ULTIMATE_SCIENTIFIC_MASTER_BLUEPRINT.md` contains the entire earlier 8.0 agent architecture, detailed experiments, demo plans and existing study maps, unedited.
- `legacy/QualityRelay_8_0_EVIDENCE_MESH_COMPLETE.zip` preserves the original package itself and its internal original 5.0 33-file source set.
- `legacy/QualityRelay_Hackathon_Package_2026-10-28.zip` preserves the direct 5.0 source input byte-for-byte.
- `research/verified_seed_references.csv` contains prioritized original-paper leads with identifiers; many are review, technical reports or preprints, **not identical-quality peer-reviewed experiments**.
- `research/collect_10000.py` implements target collection and emits auditable metadata when run online.
- `src/decision_value_prototype.py` and `tests/` contain executable demonstration science, not a claimed field result.

**Research cut line:** A scientific product is made credible by bounded claims, decisive baselines, traceable physical observations, and admitting when an idea fails. Target 10,000 research records to support the search; do not let that ambition replace a measurable working demonstration.

---

## 12. Real output from the initial miniature simulation (added after running code)

The included **illustrative**, non-industrial one-query experiment samples 3,000 hypothetical incidents using a deliberately simplified four-hypothesis world, known likelihoods, identical inspection costs and fixed random seed. Each method receives **exactly one available station-summary query**, except the disclosed no-inspection baseline. The code reuses common random draws across policies where applicable.

| Method | Mean simulated loss | Mean inspection cost | Honest interpretation |
|---|---:|---:|---|
| V-DER decision-value query | 0.698883 | 0.07 | Proposed rule |
| Entropy information gain | 0.699082 | 0.07 | **Essentially tied** with V-DER in this setting |
| Random query | 0.741873 | 0.07 | Weaker here, a toy outcome |
| Fixed slot query | 0.757193 | 0.07 | Weaker here, a toy outcome |
| No inspection | 1.023513 | 0 | Different inspection budget |

**Scientific honesty:** V-DER's measured apparent advantage over entropy IG here is **0.000199 loss units**, practically negligible and not tested for statistical significance. We do **not** claim superior scientific performance. This result is itself useful: decision-aware acquisition may only matter in scenarios with a real decision/entropy mismatch, distinct query costs or asymmetric risk constraints; those scenarios must be specified *before* final holdout runs to avoid gaming. It also shows why a dramatic pre-declared 20–40% improvement figure would be dishonest. Run `python3 src/benchmark_toy.py` to regenerate `artifacts/toy_benchmark_results.json` and `artifacts/toy_benchmark_trials.csv`.
