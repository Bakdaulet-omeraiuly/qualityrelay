# 10,000-candidate bibliographic evidence program

## Status
Target = 10,000 unique candidate metadata records; actual bulk fetched in this environment = 0. The program has been compiled and tested offline only. Target refers to metadata indexing, not 10,000 articles read, screened or validated.

## Sources
Crossref Works API for retrieval. Authoritative original article pages/DOI landing pages for curated claims. Optional OpenAlex enrichment after independent source-validation. Publication cutoff 2026-10-30. Do not import works that were first published after this date into a contemporary prior-art novelty audit.

## Query design
32 exact category searches stored as QUERIES in `collect_10000.py`: manufacturing fault diagnosis, quality gates, metrology, statistical tolerances, selective assembly, decentralized agents, causal diagnosis, active sensing, privacy, robust risk, and human authorization. Query results are broad and must be screened for relevance. A keyword match is not proof of relevance.

## Screening
Stage 1 automatic type/date/dedup; Stage 2 independent title/abstract screen using declared inclusion/exclusion rules; Stage 3 prioritize full text for original methods and conflicting findings; Stage 4 code baselines, task, statistical assumptions, evaluation, dataset, limitations, reproducibility; Stage 5 high-confidence synthesis linked to paper sections. Record disagreements and adjudication. Do not report a PRISMA systematic review unless it actually was conducted and recorded end-to-end.

## Bias and quality
Metadata APIs favor well-indexed published works; preprints, industry reports, non-English and non-DOI works may be missed. Citation counts are not correctness or novelty. Many returned rows will be irrelevant. Dynamic APIs may reorder results during retrieval; preserve time, query and duplicates. Full-text access is permissioned; do not scrape unauthorized PDFs.

## Negative novelty search keywords
Find evidence against novelty: decision-focused active sensing, Bayesian value of information, risk-sensitive POMDP, constrained experimental design, Blackwell ordering, causal active learning, privacy-preserving federated inference, provenance-aware agent systems, industrial agentic quality control, digital twin authority and assurance, dissent-aware collective decision making. Any nearly identical method requires changing novelty claims accordingly.

## What counts as finished
- Verified `retrieval_audit.json` or `AUDIT.json` showing 10,000 distinct retrieved metadata rows.
- Curated paper decisions with evidence locations and reproducible search criteria.
- Negative prior-art crosswalk and direct method comparisons.
- Executed holdout benchmark with uncertainty reporting.
- Independently collected physical evidence and engineering review.

Nothing in this archive claims these final milestones have occurred.
