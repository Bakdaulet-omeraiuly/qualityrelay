#!/usr/bin/env python3
"""Transparent candidate-bibliography collection from Crossref.

Downloads metadata, NEVER full articles. Default target 10,000 UNIQUE candidate records,
NOT 10,000 individually screened/reviewed studies. Needs internet on your computer.

Usage:
  python3 research/collect_10000.py --target 10000 --output research/corpus
  python3 research/collect_10000.py --target 10000 --email researcher@example.org
  python3 research/collect_10000.py --dry-run

Libraries: Python 3.10+ standard library. Resume after interruption supported.
"""
from __future__ import annotations
import argparse, csv, datetime, hashlib, json, pathlib, random, re, sys, time
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

CUTOFF = '2026-10-30'
QUERIES = {
 'Q01 manufacturing fault diagnosis':'multistage manufacturing fault diagnosis fault localization',
 'Q02 process control':'statistical process control manufacturing EWMA change detection',
 'Q03 dimensional metrology':'measurement uncertainty dimensional metrology gauge repeatability reproducibility',
 'Q04 tolerance stackup':'assembly tolerance stack up statistical tolerancing',
 'Q05 selective assembly':'selective assembly matching tolerance optimization',
 'Q06 coordinate measuring':'coordinate measuring machine metrology measurement planning',
 'Q07 sequential inspection':'sequential inspection manufacturing information gain Bayesian',
 'Q08 quality gates':'manufacturing quality gate feedforward feedback control',
 'Q09 digital thread':'manufacturing digital thread interoperability traceability',
 'Q10 digital twins':'manufacturing digital twin quality assurance verification',
 'Q11 production planning':'manufacturing planning scheduling uncertainty optimization',
 'Q12 factory multiagent':'multi agent systems smart manufacturing distributed quality',
 'Q13 LLM multiagent':'language model multi agent collaboration distributed information',
 'Q14 hidden profiles':'hidden profile group decision information sharing consensus',
 'Q15 decentralized POMDP':'decentralized POMDP decision making multi agent',
 'Q16 active sensing':'active sensing optimal experimental design value information',
 'Q17 causal diagnosis':'causal root cause analysis manufacturing defects',
 'Q18 conformal prediction':'conformal prediction uncertainty risk control distribution shift',
 'Q19 robust decision':'distributionally robust optimization partial identification decisions',
 'Q20 Bayesian experimental design':'Bayesian experimental design expected value of sample information',
 'Q21 machine learning anomalies':'industrial anomaly detection manufacturing inspection',
 'Q22 sensor fusion':'industrial sensor fusion multimodal defect detection',
 'Q23 data provenance':'data provenance lineage distributed manufacturing audit',
 'Q24 verification safety':'safety assurance human in loop AI manufacturing governance',
 'Q25 distributed consistency':'event sourcing idempotency network partitions distributed systems',
 'Q26 privacy federation':'federated learning privacy industrial manufacturing data sharing',
 'Q27 assembly robotics':'robotic assembly tolerance misalignment industrial quality',
 'Q28 maintenance diagnostics':'predictive maintenance anomaly fault attribution industrial',
 'Q29 human factors':'human AI teaming decision support manufacturing quality',
 'Q30 calibration':'model calibration uncertainty reliability manufacturing predictions',
 'Q31 active learning':'cost sensitive active learning acquisition optimization',
 'Q32 adversarial agents':'multi agent debate reliability dissent minority evidence',
}
FIELDS=['key','title','doi','published','year','authors','venue','type','url','citation_count','search_topics','source','screening_status','full_text_reviewed','claim_verified','retrieved_at_utc']
VALID={'journal-article','proceedings-article','posted-content','article','review','book-chapter'}

def canonical_doi(v):
    return re.sub(r'^https?://(?:dx\.)?doi\.org/','',(v or '').strip().lower()).strip()

def key_for(doi,title):
    d=canonical_doi(doi)
    return 'doi:'+d if d else 'title:'+re.sub('[^a-z0-9]','',title.lower())[:120]

def network_json(url, retries=5, delay=1.5):
    for i in range(retries):
        try:
            req=Request(url,headers={'Accept':'application/json','User-Agent':'QualityRelay-Research-Metadata-Collector/2.0 (noncommercial, contact via Crossref mailto) '})
            with urlopen(req,timeout=50) as res: return json.load(res)
        except (URLError,HTTPError,TimeoutError,ValueError) as exc:
            if isinstance(exc,HTTPError) and exc.code in (400,401,403,404): raise
            if i==retries-1: raise RuntimeError(f'Metadata service unavailable: {exc}') from exc
            time.sleep(delay*2**i + 0.2)

def parse_crossref(rec,topic,now):
    title=(rec.get('title') or [''])[0].strip()
    typ=rec.get('type') or ''
    if not title or typ not in VALID:return None
    dateparts=(rec.get('published',{}).get('date-parts') or rec.get('issued',{}).get('date-parts') or [[None]])[0]
    date='-'.join(str(x).zfill(2 if i else 4) for i,x in enumerate(dateparts)) if dateparts and dateparts[0] else ''
    if date and date[:10]>CUTOFF:return None
    authors='; '.join(' '.join([a.get('given',''),a.get('family','')]).strip() for a in rec.get('author',[])[:15])
    doi=canonical_doi(rec.get('DOI'))
    return dict(key=key_for(doi,title),title=title,doi=doi,published=date,year=date[:4],authors=authors,
      venue='; '.join(rec.get('container-title',[])[:2]),type=typ,url=rec.get('URL') or ('https://doi.org/'+doi if doi else ''),
      citation_count=rec.get('is-referenced-by-count') or 0,search_topics=topic,source='Crossref',
      screening_status='CANDIDATE_UNSCREENED',full_text_reviewed='false',claim_verified='false',retrieved_at_utc=now)

def fetch_page(topic,search,cursor,rows,email):
    params={'query.bibliographic':search,'filter':f'until-pub-date:{CUTOFF}',
            'rows':rows,'cursor':cursor,'select':'DOI,title,author,published,issued,container-title,type,URL,is-referenced-by-count'}
    if email:params['mailto']=email
    u='https://api.crossref.org/works?'+urlencode(params)
    message=network_json(u).get('message',{})
    return message.get('items') or [], message.get('next-cursor')

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def run(args):
    out=pathlib.Path(args.output);out.mkdir(parents=True,exist_ok=True)
    if args.dry_run:
        print(json.dumps({'goal':args.target,'source':'Crossref','queries':QUERIES,'state':'NO WORKS DOWNLOADED','note':'Full texts are not obtained and relevance is not individually screened'},indent=2));return 0
    corpus=out/'candidate_bibliography.csv';state_path=out/'resume_state.json';log=out/'retrieval_log.jsonl'
    records={}
    if corpus.exists() and args.resume:
        with corpus.open(encoding='utf-8',newline='') as f:
            for r in csv.DictReader(f):records[r['key']]=r
    if state_path.exists() and args.resume:
        state=json.loads(state_path.read_text())
        if state.get('target')!=args.target:raise SystemExit('Cannot resume with different --target; use a new output directory')
    else:state={'target':args.target,'cursors':{q:'*' for q in QUERIES},'pages':{q:0 for q in QUERIES},'completed':[], 'errors':[]}
    names=list(QUERIES.keys());random.Random(20261030).shuffle(names)
    now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
    max_passes=args.max_pages_per_topic
    for pass_no in range(max_passes):
        for topic in names:
            if len(records)>=args.target:break
            if topic in state['completed']:continue
            if state['pages'].get(topic,0)!=pass_no:continue
            cursor=state['cursors'].get(topic,'*')
            if not cursor:
                state['completed'].append(topic);continue
            try:
                items,next_cursor=fetch_page(topic,QUERIES[topic],cursor,args.rows,args.email)
                added=0
                for raw in items:
                    r=parse_crossref(raw,topic,now)
                    if r is None:continue
                    k=r['key']
                    if k in records:
                        current=set(records[k]['search_topics'].split(' | '))
                        current.add(topic);records[k]['search_topics']=' | '.join(sorted(current))
                    else:records[k]=r;added+=1
                    if len(records)>=args.target:break
                state['pages'][topic]=pass_no+1
                state['cursors'][topic]=next_cursor
                if not items or not next_cursor:state['completed'].append(topic)
                with log.open('a',encoding='utf-8') as f:f.write(json.dumps({'topic':topic,'page':pass_no+1,'returned':len(items),'added':added,'total':len(records),'timestamp':now})+'\n')
                print(f'{topic}: page {pass_no+1}, +{added}, unique={len(records)}',flush=True)
                with corpus.open('w',newline='',encoding='utf-8') as f:
                    w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(records.values())
                state_path.write_text(json.dumps(state,indent=2))
                time.sleep(args.delay)
            except Exception as exc:
                state['errors'].append({'topic':topic,'page':pass_no+1,'error':str(exc)[:400]})
                state_path.write_text(json.dumps(state,indent=2))
                print('ERROR',topic,str(exc)[:220],file=sys.stderr)
                if args.fail_fast:raise
        if len(records)>=args.target or len(state['completed'])==len(QUERIES):break
    audit={'retrieval_cutoff':CUTOFF,'target':args.target,'unique_candidate_metadata_rows':len(records),
      'target_reached':len(records)>=args.target,'full_text_reviewed':0,'individual_relevance_screened':0,
      'source':'Crossref','search_categories':len(QUERIES),'retrieved_at_utc':now,
      'not_an_SLR':True,'warnings':['10,000 bibliographic records are NOT 10,000 studies read or screened',
      'Crossref search ranking and source coverage introduce bias','The collector retrieves metadata, never copyrighted full-text',
      'Deduplication uses DOI or normalized title and can miss version duplicates',
      'Novelty claims require targeted prior-art searches and independent scientific validation'],
      'failures':state['errors'][-40:]}
    (out/'AUDIT.json').write_text(json.dumps(audit,indent=2,ensure_ascii=False))
    (out/'SHA256SUMS.txt').write_text('\n'.join(sha(out/p)+'  '+p for p in ['candidate_bibliography.csv','AUDIT.json'])+'\n')
    print(json.dumps(audit,indent=2))
    return 0 if audit['target_reached'] else 2

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--target',type=int,default=10000);p.add_argument('--output',default='research/corpus')
    p.add_argument('--email',default='');p.add_argument('--rows',type=int,default=200)
    p.add_argument('--max-pages-per-topic',type=int,default=30);p.add_argument('--delay',type=float,default=1.0)
    p.add_argument('--resume',action=argparse.BooleanOptionalAction,default=True)
    p.add_argument('--fail-fast',action='store_true');p.add_argument('--dry-run',action='store_true')
    a=p.parse_args()
    if not 1<=a.target<=10000:p.error('--target must be 1..10000')
    if not 1<=a.rows<=1000:p.error('--rows must be 1..1000')
    sys.exit(run(a))
