#!/usr/bin/env python3
"""Online, auditable bibliographic metadata collection. NEVER fabricate sources.
Requires internet on user's machine. No full-text downloading. Python 3.10+ stdlib.
Example: python3 research/collect_1000_verified.py --target 1000 --source crossref
         python3 research/collect_1000_verified.py --target 1000 --source openalex --openalex-key YOUR_FREE_KEY
Output is CANDIDATE citations to be screened, not 1000 papers read or validated.
"""
import argparse, csv, datetime as dt, hashlib, json, os, pathlib, random, re, sys, time
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

SEARCHES = {
    'multistage_manufacturing': 'multistage manufacturing fault diagnosis sequential inspection',
    'assembly_tolerance': 'tolerance stack up assembly process variation',
    'selective_assembly': 'selective assembly matching dimensional quality',
    'metrology': 'coordinate measuring machine measurement uncertainty gauge repeatability',
    'digital_thread': 'manufacturing digital thread design inspection interoperability',
    'digital_twin': 'manufacturing quality assurance digital twin',
    'multi_agent_manufacturing': 'multi agent manufacturing quality control',
    'decentralized_decision': 'decentralized decision making partially observable agents',
    'bayesian_inspection': 'Bayesian sequential inspection value information',
    'information_gain': 'active learning expected information gain experimental design',
    'uncertainty_calibration': 'conformal prediction risk control distribution shift',
    'evidence_provenance': 'data provenance evidence traceability industrial systems',
    'causal_diagnosis': 'causal inference root cause analysis manufacturing',
    'multi_agent_reliability': 'multi agent language models hidden profile consensus failure',
    'network_partitions': 'distributed systems network partition event consistency idempotence',
    'safety_governance': 'AI safety assurance human in the loop manufacturing control',
}
CUTOFF = '2026-10-30'
TYPES_OK = {'journal-article','proceedings-article','posted-content','article','preprint','proceedings','review','book-chapter'}

def get_json(url, attempts=5, pause=0.6):
    last = None
    for i in range(attempts):
        try:
            req = Request(url, headers={'User-Agent':'QualityRelay-literature-protocol/1.0 (non-commercial research; transparent metadata collection)', 'Accept':'application/json'})
            with urlopen(req, timeout=45) as res:
                return json.load(res)
        except (HTTPError, URLError, TimeoutError, ValueError) as e:
            last=e
            if isinstance(e, HTTPError) and 400 <= e.code < 500 and e.code != 429: raise
            time.sleep(min(15, pause * 2**i))
    raise RuntimeError(f'Bibliographic API unavailable: {last}')

def normalized_key(doi, title):
    doi = re.sub('^https?://(?:dx\\.)?doi\\.org/', '', (doi or '').strip().lower())
    if doi: return 'doi:'+doi
    return 'title:'+re.sub('[^a-z0-9]+','', title.lower())[:120]

def crossref_records(query, rows, offset, mailto):
    params={'query':query,'rows':rows,'offset':offset,'filter':f'until-pub-date:{CUTOFF}', 'select':'DOI,title,author,published,container-title,type,URL,abstract,is-referenced-by-count'}
    if mailto: params['mailto']=mailto
    url='https://api.crossref.org/works?'+urlencode(params)
    payload=get_json(url)['message']
    for rec in payload.get('items',[]):
        dates=rec.get('published',{}).get('date-parts',[[None]])[0]
        date='-'.join(str(int(x)).zfill(2 if ix else 4) for ix,x in enumerate(dates)) if dates and dates[0] else ''
        authors='; '.join((' '.join([a.get('given',''),a.get('family','')]).strip()) for a in rec.get('author',[])[:10])
        yield dict(title=(rec.get('title') or [''])[0],doi=rec.get('DOI') or '',year=int(dates[0]) if dates and dates[0] else None,published=date,
                   authors=authors,venue='; '.join(rec.get('container-title',[])[:2]),work_type=rec.get('type',''),
                   url=rec.get('URL',''),source='Crossref',citation_count=rec.get('is-referenced-by-count',0))

def openalex_records(query, rows, page, api_key):
    params={'search':query,'per_page':rows,'page':page,'filter':f'to_publication_date:{CUTOFF}', 'select':'id,doi,title,publication_year,publication_date,type,authorships,primary_location,cited_by_count'}
    if api_key: params['api_key']=api_key
    url='https://api.openalex.org/works?'+urlencode(params)
    payload=get_json(url)
    for rec in payload.get('results',[]):
        authors='; '.join(x.get('author',{}).get('display_name','') for x in rec.get('authorships',[])[:10])
        loc=rec.get('primary_location') or {}; src=loc.get('source') or {}
        yield dict(title=rec.get('title') or '',doi=(rec.get('doi') or '').replace('https://doi.org/',''),year=rec.get('publication_year'),
                   published=rec.get('publication_date') or '',authors=authors,venue=src.get('display_name') or '',work_type=rec.get('type',''),
                   url=rec.get('doi') or rec.get('id',''),source='OpenAlex',citation_count=rec.get('cited_by_count',0))

def collect(args):
    dest=pathlib.Path(args.output); dest.mkdir(parents=True,exist_ok=True)
    if args.dry_run:
        print(json.dumps({'queries':SEARCHES,'target':args.target,'source':args.source,'cutoff':CUTOFF,'status':'dry-run, zero works fetched'},indent=2)); return 0
    records={}; audit=[]; seed=int(args.seed)
    cats=list(SEARCHES.items()); random.Random(seed).shuffle(cats)
    # Three passes to preserve field coverage, not just most-cited papers.
    for pass_id in range(1,4):
        for topic, query in cats:
            if len(records)>=args.target: break
            try:
                if args.source=='crossref':
                    offset=(pass_id-1)*100
                    result=list(crossref_records(query,100,offset,args.email))
                else:
                    result=list(openalex_records(query,100,pass_id,args.openalex_key or os.getenv('OPENALEX_API_KEY')))
                accepted=0
                for r in result:
                    if not r['title'] or r.get('work_type','') not in TYPES_OK: continue
                    pub = r.get('published') or ''
                    if len(pub)>=10 and pub[:10]>CUTOFF: continue
                    k=normalized_key(r.get('doi'),r['title'])
                    if k in records:
                        if topic not in records[k]['matched_search_topics']: records[k]['matched_search_topics'].append(topic)
                        continue
                    r['matched_search_topics']=[topic]
                    r['screening_status']='metadata_retrieved_not_screened'
                    r['full_text_read']=False
                    r['claim_verified']=False
                    records[k]=r; accepted+=1
                    if len(records)>=args.target: break
                audit.append({'topic':topic,'pass':pass_id,'returned':len(result),'new_unique':accepted,'total_unique':len(records),'status':'ok'})
                print(f'{topic:28s} pass {pass_id}: +{accepted:3d} = {len(records)}',flush=True)
                time.sleep(args.delay)
            except Exception as e:
                audit.append({'topic':topic,'pass':pass_id,'status':'error','error':str(e)[:500]})
                print(f'WARNING {topic}: {e}',file=sys.stderr)
        if len(records)>=args.target: break
    data=list(records.values())[:args.target]
    fields=['title','doi','year','published','authors','venue','work_type','url','source','citation_count','matched_search_topics','screening_status','full_text_read','claim_verified']
    with (dest/'candidate_bibliography.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows([dict(r,matched_search_topics='; '.join(r['matched_search_topics'])) for r in data])
    (dest/'candidate_bibliography.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
    audit_json={'retrieval_date_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'cutoff':CUTOFF,'target':args.target,
        'retrieved_unique':len(data),'target_reached':len(data)>=args.target,'read_full_text_count':0,
        'validated_study_claims_count':0,'source':args.source,'search_queries':SEARCHES,'log':audit,
        'critical_disclaimer':'Bibliographic metadata only. Candidate matches are NOT 1000 studies individually reviewed or verified for relevance.'}
    (dest/'retrieval_audit.json').write_text(json.dumps(audit_json,ensure_ascii=False,indent=2))
    for name in ['candidate_bibliography.csv','candidate_bibliography.json','retrieval_audit.json']:
        (dest/(name+'.sha256')).write_text(hashlib.sha256((dest/name).read_bytes()).hexdigest()+'  '+name+'\n')
    print('RESULT',len(data),'unique indexed candidates;', 'target reached' if len(data)>=args.target else 'target NOT reached')
    return 0 if len(data)>=args.target else 2

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--target',type=int,default=1000);p.add_argument('--source',choices=['crossref','openalex'],default='crossref');p.add_argument('--output',default='research/output');p.add_argument('--email',default='');p.add_argument('--openalex-key',default='');p.add_argument('--delay',type=float,default=0.55);p.add_argument('--seed',type=int,default=42);p.add_argument('--dry-run',action='store_true')
    args=p.parse_args()
    if args.target<1 or args.target>10000:p.error('target must be 1..10000')
    sys.exit(collect(args))
