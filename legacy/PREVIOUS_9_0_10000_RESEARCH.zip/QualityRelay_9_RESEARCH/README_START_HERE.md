# QualityRelay 9.0 — START HERE

**What you have:** One research-ready ZIP containing a 514+ line extension blueprint, the **entire 8.0 blueprint and original ZIP**, an **unchanged original 5.0 ZIP**, a curated literature seed, a **10,000-record Crossref metadata candidate collector**, an executable decision-value toy prototype, a matched-budget toy simulation, and automatic tests.

**What you do NOT have:** 10,000 downloaded or read scientific articles; a demonstrated novel discovery; real-factory test results; complete factory-ready web software. This archive deliberately does not fabricate them.

## 1. Open the main document
`QUALITYRELAY_9_RESEARCH_MASTER.md`

## 2. Test the algorithm now (works offline)
```bash
python3 -m unittest discover -s tests -v
python3 src/decision_value_prototype.py
python3 src/benchmark_toy.py
```

## 3. Fetch 10,000 bibliographic candidates on an Internet-connected machine
```bash
python3 research/collect_10000.py --target 10000 --output research/corpus --email you@university.edu
```
Use your own contact email or omit `--email`. The collector uses Crossref metadata; source service may throttle/deny requests. It retries, saves progress, and outputs `AUDIT.json`, `candidate_bibliography.csv`, and integrity checks. **Do not treat these metadata rows as 10,000 papers individually reviewed.** Filter and review top relevant papers manually before making a novelty claim.

## 4. Research priorities
1. Demonstrate a real working slot/tab/assembly evidence exchange before adding many LLM calls.
2. Compare V-DER to information gain fairly; the current toy test is **a near tie**, not a win.
3. Obtain measured physical caliper data and instrument noise; show the true number of specimens.
4. Preserve station-local authority, robust safety abstention, human approval and traceability.
5. Pre-register holdout experiments and collect data that could **disprove** the proposed contribution.

## 5. Team
- `Bakdaulet-omeraiuly`: statistics, literature retrieval, experimental design and benchmark results.
- `adilnurgg`: backend, station autonomy, agent orchestration and security.
- `HyorinmaruK`: mechanical/physical validation and final slide deck/pitch, plus UX support.
- Fourth person (if joins): frontend, independent QA and integrations.

## Archive
Files under `legacy/` are unmodified originals. Source article PDFs are not mirrored: permissions differ among publishers. All source citations are linked in the master document and `research/verified_seed_references.csv`.
