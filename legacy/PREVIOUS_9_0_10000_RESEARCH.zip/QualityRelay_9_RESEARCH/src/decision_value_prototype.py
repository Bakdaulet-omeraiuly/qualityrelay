#!/usr/bin/env python3
"""Small deterministic reference implementation of *proposed* decision-aware inspection.
Research-only toy model; NOT calibrated to factory data, NOT an industrial controller.
No LLM computations of probability; all evidence is explicit, scoped, and numeric.
"""
from dataclasses import dataclass
from typing import Dict, Sequence
import json

H=('stable','slot_shift','tab_shift','both_shift')
BAD_PROB={'stable':0.015,'slot_shift':0.22,'tab_shift':0.22,'both_shift':0.68}
# Pr(inspection reports an anomaly | hypothesis), demonstrator inputs only:
TESTS={
 'slot_summary':{'stable':0.08,'slot_shift':0.90,'tab_shift':0.08,'both_shift':0.90},
 'tab_summary': {'stable':0.08,'slot_shift':0.08,'tab_shift':0.90,'both_shift':0.90},
 'assembly_fit':{'stable':0.02,'slot_shift':0.24,'tab_shift':0.24,'both_shift':0.70},
 'uninformative':{h:0.5 for h in H},
}
COSTS={'slot_summary':0.07,'tab_summary':0.07,'assembly_fit':0.25,'uninformative':0.01}
FAIL_COST=10.0; HOLD_COST=1.5

@dataclass(frozen=True)
class Recommendation:
    action: str
    expected_loss: float
    evidence_ids: tuple=()

def normalize(prior:Dict[str,float]):
    assert set(prior)==set(H) and all(v>=0 for v in prior.values()) and sum(prior.values())>0
    z=sum(prior.values());return {h:prior[h]/z for h in H}

def posterior(prior,inspection,result_anomaly):
    prior=normalize(prior)
    probs=TESTS[inspection]
    weighted={h:p*(probs[h] if result_anomaly else 1-probs[h]) for h,p in prior.items()}
    return normalize(weighted)

def decision_loss(prior):
    p=normalize(prior);bad=sum(p[h]*BAD_PROB[h] for h in H)
    losses={'release':bad*FAIL_COST, 'hold':(1-bad)*HOLD_COST}
    a=min(losses,key=lambda x:(losses[x],x))
    return Recommendation(a,losses[a])

def inspect_value(prior,inspection):
    p=normalize(prior); probs=TESTS[inspection]
    p_anomaly=sum(p[h]*probs[h] for h in H)
    before=decision_loss(p).expected_loss
    after=(p_anomaly*decision_loss(posterior(p,inspection,True)).expected_loss+
      (1-p_anomaly)*decision_loss(posterior(p,inspection,False)).expected_loss)
    evsi=before-after
    net=evsi-COSTS[inspection]
    return {'inspection':inspection,'evsi':evsi,'inspection_cost':COSTS[inspection],
            'net_decision_value':net,'anomaly_probability':p_anomaly}

def choose_next(prior,available:Sequence[str]):
    vals=[inspect_value(prior,a) for a in available]
    vals.sort(key=lambda x:(-x['net_decision_value'],x['inspection']))
    current=decision_loss(prior)
    if not vals or vals[0]['net_decision_value']<=1e-12:
        return {'recommendation':'no_additional_measurement','action_if_no_more_evidence':current.action,
                'current_expected_loss':current.expected_loss,'candidates':vals,'basis':'toy model'}
    return {'recommendation':vals[0]['inspection'],'action_if_no_more_evidence':current.action,
            'current_expected_loss':current.expected_loss,'candidates':vals,'basis':'toy model'}

if __name__=='__main__':
    p={'stable':.68,'slot_shift':.15,'tab_shift':.12,'both_shift':.05}
    print(json.dumps({'prior':p,'decision':decision_loss(p).__dict__,
      'next':choose_next(p,['slot_summary','tab_summary','assembly_fit','uninformative'])},indent=2))
