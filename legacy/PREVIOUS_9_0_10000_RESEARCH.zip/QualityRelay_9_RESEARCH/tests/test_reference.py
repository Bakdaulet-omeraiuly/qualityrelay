import os,sys,unittest
sys.path.insert(0,os.path.join(os.path.dirname(__file__),'..','src'))
from decision_value_prototype import *
class Tests(unittest.TestCase):
 def setUp(self):self.p={'stable':.68,'slot_shift':.15,'tab_shift':.12,'both_shift':.05}
 def test_normalization(self):self.assertAlmostEqual(sum(normalize(self.p).values()),1)
 def test_posterior(self):
  for a in TESTS:
   for b in (True,False):self.assertAlmostEqual(sum(posterior(self.p,a,b).values()),1)
 def test_zero_information(self):self.assertAlmostEqual(inspect_value(self.p,'uninformative')['evsi'],0,places=10)
 def test_evsi_nonnegative(self):
  for a in TESTS:self.assertGreaterEqual(inspect_value(self.p,a)['evsi'],-1e-9)
 def test_response(self):
  d=choose_next(self.p,list(TESTS));self.assertIn('recommendation',d)
 def test_bad_scenario(self):
  high={'stable':0,'slot_shift':0,'tab_shift':0,'both_shift':1}
  self.assertEqual(decision_loss(high).action,'hold')
if __name__=='__main__':unittest.main()
