import os,sys,unittest
sys.path.insert(0,os.path.join(os.path.dirname(__file__),'..','research'))
from collect_10000 import canonical_doi,key_for,parse_crossref,CUTOFF,QUERIES
class CollectorTests(unittest.TestCase):
 def test_doi_normalization(self):self.assertEqual(canonical_doi('https://doi.org/10.1234/ABC'),'10.1234/abc')
 def test_doi_dedup_key(self):self.assertEqual(key_for('https://doi.org/10.123/a','X'),key_for('10.123/a','Z'))
 def test_reject_future(self):
  rec={'title':['Futuristic'], 'type':'journal-article','DOI':'10.1/z','published':{'date-parts':[[2027,1,1]]}}
  self.assertIsNone(parse_crossref(rec,'Q01','2026-10-30'))
 def test_metadata_not_screened(self):
  rec={'title':['Manufacturing Quality Study'],'type':'journal-article','DOI':'10.1/x','published':{'date-parts':[[2024,1,4]]}}
  o=parse_crossref(rec,'Q01','2026-10-30');self.assertEqual(o['screening_status'],'CANDIDATE_UNSCREENED');self.assertEqual(o['full_text_reviewed'],'false')
 def test_at_least_30_queries(self):self.assertGreaterEqual(len(QUERIES),30)
if __name__=='__main__':unittest.main()
