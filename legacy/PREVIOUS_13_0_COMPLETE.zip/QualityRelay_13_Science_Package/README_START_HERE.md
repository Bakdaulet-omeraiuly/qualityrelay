# QualityRelay 13.0 — ғылыми зерттеу пакеті

## Неден бастау керек?

1. `QUALITYRELAY_13_SCIENTIFIC_MASTER_BLUEPRINT.md` — толық ғылыми архитектура, зерттеу гипотезалары, шынайы 3D-құрастыру жоспары және 3+1 адамға міндеттер.
2. `research/verified_sources.csv` — ғылыми дереккөздерге нақты URL/DOI, жарияланым мәртебесі және қаншалықты оқылғаны туралы журнал (**18 дереккөз**, 10 000 емес).
3. `research/RESEARCH_INTEGRITY.md` — жасалған жұмыстың шекарасы; не іске қосылды, не әлі гипотеза.
4. `prototype/` — Python стандарт кітапханасымен іске қосылатын шағын Bayesian/EVSI/IG/reference модель.
5. `results/` — 21 unit test, 5000-нан төрт сценарий бойынша synthetic benchmark, шешім мен энтропия айырмашылығын көрсететін нақты математикалық қарсы мысал.
6. `legacy/QualityRelay_12_ORIGINAL_UNMODIFIED.zip` — сен жіберген алдыңғы **12.0 пакет өзгеріссіз**, ішінде бұрынғы 11.0 және одан бұрынғы материалдар да бар.

## Қандай ғылыми жаңалық бар?

**Ғылымда алғаш рет ашылған заң немесе басқалардан артық алгоритм расталған жоқ.** Тексеруге болатын ғылыми ұсыныс бар: *рұқсат етілген, дереккөзге байланыстырылған дәлелдермен жұмыс істейтін decentralized агенттер шешімге маңызды келесі өлшеуді таңдап, қайшы/жоғалған мәлімет кезінде қауіпсіз HOLD жасай ала ма?*

Синтетикалық reference экспериментте EVSI мен Information Gain тең шықты; бөлек құрылған нақты математикалық мысал EVSI-дің шешім мақсатында неліктен тиімді болуы **мүмкін** екенін көрсетеді. Бұл белгілі теорияның қолданылуы, өндірістік дәлел емес.

## Терминалдан тексеру

```bash
cd QualityRelay_13_Science_Package
python -m unittest discover -s tests -v
PYTHONPATH=prototype python prototype/decision_trap.py
PYTHONPATH=prototype python prototype/paired_benchmark.py --n 5000 --out results/benchmark.json
```

## Топ бөлінісі

- **Bakdaulet:** Data Science, hypothesis tests, baseline science, uncertainty and benchmark.
- **adilnurgg:** independent services, security, peer messages, replay, safe command contract.
- **HyorinmaruK:** mechanical design, **physical validation and final presentation**.
- **4th teammate (optional):** frontend integration, blind QA and independent testing.

**Маңызды:** 12.0 төрт peer-іне арналған жұмыс істейтін distributed runtime бұл пакетте әлі жоқ; 13.0 Python мысалы бір процессте ғана жұмыс істейді.
