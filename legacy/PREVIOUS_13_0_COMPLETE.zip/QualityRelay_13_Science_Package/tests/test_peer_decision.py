import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]/'prototype'))
from peer_decision import *

class PeerDecisionTests(unittest.TestCase):
    def test_sum(self): self.assertAlmostEqual(sum(PRIOR),1)
    def test_risk(self): self.assertTrue(0<failure_risk(PRIOR)<1)
    def test_bayes_positive(self):self.assertGreater(update(PRIOR,'slot',True)[1],PRIOR[1])
    def test_evsi_nonnegative(self):
        for t in LIKELIHOOD:self.assertGreaterEqual(evsi(PRIOR,t),-1e-10)
    def test_ig_nonnegative(self):
        for t in LIKELIHOOD:self.assertGreaterEqual(information_gain(PRIOR,t),-1e-10)
    def test_duplicate_event_id(self):
        l=Ledger();e=EvidenceEvent('1','origin1','slot','slot',True)
        self.assertTrue(l.ingest(e));p=l.posterior
        self.assertFalse(l.ingest(e));self.assertEqual(p,l.posterior)
    def test_correlated_origin_forwarded(self):
        l=Ledger();l.ingest(EvidenceEvent('1','origin1','slot','slot',True))
        self.assertFalse(l.ingest(EvidenceEvent('2','origin1','slot','slot',True)))
    def test_no_unauthorized(self):
        l=Ledger();self.assertFalse(l.ingest(EvidenceEvent('1','origin1','slot','slot',True,authorized=False)))
        self.assertEqual(l.posterior,PRIOR)
    def test_stale(self):
        l=Ledger();self.assertFalse(l.ingest(EvidenceEvent('1','origin1','slot','slot',True,fresh=False)))
    def test_wrong_owner(self):
        l=Ledger();self.assertFalse(l.ingest(EvidenceEvent('1','origin1','tab','slot',True)))
    def test_covered_unapproved_hold(self):
        c=decision_certificate(Ledger(),evidence_coverage={'slot':True,'tab':True},human_approved=False)
        self.assertEqual(c['status'],'HOLD')
    def test_unavailable_hold_even_if_human(self):
        l=Ledger();l.ingest(EvidenceEvent('1','origin1','slot','slot',False))
        c=decision_certificate(l,evidence_coverage={'slot':True,'tab':False},human_approved=True)
        self.assertEqual(c['status'],'HOLD')
    def test_conflict_hold(self):
        l=Ledger();c=decision_certificate(l,evidence_coverage={'slot':True,'tab':True},conflict=True,human_approved=True)
        self.assertEqual(c['status'],'HOLD')
    def test_no_actuation(self):
        l=Ledger();c=decision_certificate(l,evidence_coverage={'slot':True,'tab':True},human_approved=True)
        self.assertFalse(c['physical_actuation_authorized'])
    def test_unvalidated_source(self):
        l=Ledger();self.assertFalse(l.ingest(EvidenceEvent('1','origin1','slot','slot',True,source_kind='unknown')))
    def test_deterministic(self):
        a=choose_inspection(PRIOR,method='decision');b=choose_inspection(PRIOR,method='decision');self.assertEqual(a,b)

if __name__=='__main__':unittest.main()

class DecisionTrapTests(unittest.TestCase):
    def test_evsi_versus_ig_rank_disagreement(self):
        from decision_trap import TESTS,score
        v={t:score(t) for t in TESTS}
        self.assertGreater(v['fault_type_marker']['information_gain_bits'],v['release_risk_signal']['information_gain_bits'])
        self.assertLess(v['fault_type_marker']['net_decision_value'],v['release_risk_signal']['net_decision_value'])
    def test_marker_zero_decision_value(self):
        from decision_trap import score
        self.assertAlmostEqual(score('fault_type_marker')['evsi_before_test_cost'],0,places=6)

class CounterfactualTests(unittest.TestCase):
    def test_counterfactual_bounded(self):
        r=counterfactual_decision_stability(PRIOR,['slot','tab'])
        self.assertEqual(r['enumerated_scenarios'],4)
        self.assertIn('HOLD',r['possible_decisions'])
    def test_counterfactual_not_certification(self):
        r=counterfactual_decision_stability(PRIOR,['slot'])
        self.assertEqual(r['assurance_scope'],'FINITE_SYNTHETIC_MODEL_ONLY')
    def test_counterfactual_unknown(self):
        with self.assertRaises(ValueError):counterfactual_decision_stability(PRIOR,['some_test'])
