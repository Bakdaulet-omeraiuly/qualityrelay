# Scientific claims register — 2026-10-30

| ID | Claim | Evidence class | Allowed to say at hackathon? | Next evidence needed |
|---|---|---|---|---|
| C01 | Two locally conforming parts can fail assembly clearance | Algebra in original 5.0 demo constraints | Yes: teaching example | Real measure and physically confirmed pair |
| C02 | Multi-agent information exchange can fail on hidden facts | Peer-reviewed external study [R05] | Yes, with citation and scope | Our own comparable experiment |
| C03 | Expert evidence can be diluted by group conversation | Peer-reviewed external study [R06] | Yes, with citation and scope | Our own dissent ablation |
| C04 | EVSI optimizes decision utility, unlike Shannon entropy | Established Bayesian decision theory [R12]; toy counterexample | Yes, not as new discovery | Independent/physical cost study |
| C05 | V-DER outperforms IG on QualityRelay reference | No: they tie in v13 synthetic benchmark | **NO** | Held-out real evidence and properly matched replicates |
| C06 | Four independent peers are deployed | Not in supplied v12 or v13 | **NO** | Four-process live test |
| C07 | 21 AI specialist models are trained/deployed | v12 contains role specifications; no such demonstrated proof | **NO** | Per-role tool tests and measured value |
| C08 | 3D printed fit tests validate AI/industrial accuracy | Not performed here | **NO** | Mechanically witnessed report, multiple specimens |
| C09 | A sorter actually routed a part automatically | Not performed here | **NO** | Physical command + sensor/operator confirmation |
| C10 | 10,000 papers analyzed | Earlier collector exists; review not performed | **NO** | Verifiable systematic corpus, screening and extraction logs |
| C11 | Proposed PACE guard is scientifically novel globally | Unproven novelty | **NO** | Exhaustive novelty search and external peer review |
| C12 | v13 provenance duplicate-ingestion toy code and tests run | 21 local unit tests | Yes, explicitly **toy**, not distributed | Multi-host signed-message tests |
