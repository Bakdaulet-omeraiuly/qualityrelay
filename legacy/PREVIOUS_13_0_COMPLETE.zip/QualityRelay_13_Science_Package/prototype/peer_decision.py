"""QualityRelay 13: auditable one-step Bayesian inspection decision reference.

RESEARCH PROTOTYPE ONLY. All likelihoods and costs are synthetic teaching values.
No real industrial prediction/calibration, LLM, agent network or actuation here.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from math import log2
from typing import Mapping

HYPOTHESES = ('stable', 'slot_shift', 'tab_shift', 'both_shift')
PRIOR = (0.85, 0.06, 0.06, 0.03)
FAIL_RATE = (0.01, 0.42, 0.42, 0.88)
# Binary inspection 'anomaly observed' probabilities given latent process state.
LIKELIHOOD = {
    'slot': (0.05, 0.84, 0.05, 0.84),
    'tab': (0.05, 0.05, 0.84, 0.84),
    'assembly': (0.10, 0.75, 0.75, 0.95),
}
TEST_COST = {'slot': 0.22, 'tab': 0.22, 'assembly': 0.65}
FALSE_RELEASE_COST = 20.0
HOLD_COST = 1.5


def normalize(v):
    if len(v) != 4 or any(x < 0 for x in v) or sum(v) <= 0:
        raise ValueError('Invalid hypothesis probabilities')
    s = sum(v)
    return tuple(x/s for x in v)


def failure_risk(p):
    return sum(pi * fi for pi, fi in zip(p, FAIL_RATE))


def best_decision(p):
    """Return (decision, expected-loss). HOLD resolves equal cost conservatively."""
    r = FALSE_RELEASE_COST * failure_risk(p)
    if r < HOLD_COST:
        return 'PROPOSE_RELEASE', r
    return 'HOLD', HOLD_COST


def update(p, test, positive):
    like = LIKELIHOOD[test]
    return normalize(tuple(x*(l if positive else (1-l)) for x,l in zip(p, like)))


def predictive_positive(p, test):
    return sum(x*l for x,l in zip(p, LIKELIHOOD[test]))


def entropy(p):
    return -sum(x*log2(x) for x in p if x)


def information_gain(p, test):
    py = predictive_positive(p, test)
    return entropy(p) - py*entropy(update(p,test,True)) - (1-py)*entropy(update(p,test,False))


def evsi(p, test):
    """Expected reduction in Bayes risk BEFORE testing cost."""
    py = predictive_positive(p, test)
    loss_now = best_decision(p)[1]
    loss_after = py*best_decision(update(p,test,True))[1] + (1-py)*best_decision(update(p,test,False))[1]
    return loss_now - loss_after


def choose_inspection(p, tests=('slot','tab','assembly'), method='decision'):
    tests = tuple(t for t in tests if t in LIKELIHOOD)
    if not tests or method == 'none':
        return None
    if method == 'decision':
        ranked = sorted(tests, key=lambda t: (evsi(p,t)-TEST_COST[t],t), reverse=True)
        best = ranked[0]
        return best if evsi(p,best) > TEST_COST[best] + 1e-12 else None
    if method == 'ig':
        # Production-grade alternative would also add an explicit stopping rule.
        return max(tests, key=lambda t:(information_gain(p,t)/TEST_COST[t],t))
    raise ValueError('Unknown method')


@dataclass(frozen=True)
class EvidenceEvent:
    event_id: str
    measurement_origin_id: str
    station: str
    test: str
    positive: bool
    authorized: bool = True
    fresh: bool = True
    source_kind: str = 'simulated'
    # Same physical measurement forwarded through peers MUST NOT be counted twice.


@dataclass
class Ledger:
    posterior: tuple = PRIOR
    event_ids: set = field(default_factory=set)
    origins: set = field(default_factory=set)
    accepted: list = field(default_factory=list)
    rejected: list = field(default_factory=list)

    def ingest(self, event: EvidenceEvent):
        if not event.authorized:
            self.rejected.append((event.event_id,'UNAUTHORIZED'))
            return False
        if not event.fresh:
            self.rejected.append((event.event_id,'STALE'))
            return False
        if event.source_kind not in ('physical','simulated'):
            self.rejected.append((event.event_id,'UNSUPPORTED_ORIGIN'))
            return False
        if event.event_id in self.event_ids or event.measurement_origin_id in self.origins:
            self.rejected.append((event.event_id,'DUPLICATE_OR_CORRELATED_ORIGIN'))
            return False
        if event.test not in LIKELIHOOD:
            self.rejected.append((event.event_id,'UNKNOWN_INSPECTION'))
            return False
        if event.station not in ('slot','tab','assembly'):
            self.rejected.append((event.event_id,'OWNER_MISMATCH'))
            return False
        if event.test != event.station:
            self.rejected.append((event.event_id,'TEST_OWNER_MISMATCH'))
            return False
        self.posterior = update(self.posterior,event.test,event.positive)
        self.event_ids.add(event.event_id)
        self.origins.add(event.measurement_origin_id)
        self.accepted.append(event)
        return True


def decision_certificate(ledger:Ledger, *, evidence_coverage:Mapping[str,bool],
                         conflict:bool=False, human_approved:bool=False):
    """Defensive research policy: no automatic physical actuation."""
    reasons = []
    for station in ('slot','tab'):
        if not evidence_coverage.get(station,False): reasons.append('MISSING_FRESH_'+station.upper())
    if conflict:reasons.append('UNRESOLVED_EVIDENCE_CONFLICT')
    proposal, expected_loss = best_decision(ledger.posterior)
    if proposal=='HOLD': reasons.append('UNACCEPTABLE_EXPECTED_RISK')
    if not human_approved: reasons.append('HUMAN_APPROVAL_REQUIRED')
    status='HOLD' if reasons else 'RELEASE_APPROVED_FOR_BENCH_ONLY'
    return {'status':status,'decision_proposal':proposal,
            'failure_probability_model':round(failure_risk(ledger.posterior),6),
            'expected_loss_model':round(expected_loss,6),
            'source_event_ids':sorted(ledger.event_ids),
            'coverage':dict(evidence_coverage), 'reasons':reasons,
            'physical_actuation_authorized':False}


def counterfactual_decision_stability(p, missing_tests):
    """Finite-model sensitivity check, NOT a safety certificate.

    Enumerates all possible *binary* outcomes of remaining tests and checks
    whether the Bayes-optimal terminal action changes. This is conditional
    on the likelihood model, conditional independence, fixed losses and the
    supplied finite test set; it cannot certify industrial safety.
    """
    tests=tuple(missing_tests)
    if any(t not in LIKELIHOOD for t in tests):
        raise ValueError('Unknown test in counterfactual set')
    if len(tests)>16: raise ValueError('Exponential enumeration budget exceeded')
    from itertools import product
    possible=set()
    for outcomes in product((False,True),repeat=len(tests)):
        q=p
        for test,y in zip(tests,outcomes):q=update(q,test,y)
        possible.add(best_decision(q)[0])
    return {'stable':len(possible)==1,'possible_decisions':sorted(possible),
            'enumerated_scenarios':2**len(tests),
            'assurance_scope':'FINITE_SYNTHETIC_MODEL_ONLY'}
