"""Exact synthetic decision trap: diagnostic entropy is not economic decision value.

This is a constructed counterexample illustrating established Bayesian decision theory,
NOT a discovered theorem or evidence of industrial improvement.
"""
from math import log2

H=('safe','fault_A','fault_B')
PRIOR=(0.50,0.25,0.25)
LOSS_RELEASE=(0,16,16) # models failure risk 0.8 * cost 20 for fault types
LOSS_HOLD=(5,5,5)
TESTS={'fault_type_marker':(0.5,1.0,0.0),'release_risk_signal':(0.2,0.8,0.8)}
TEST_COST=0.1

def entropy(p):return -sum(q*log2(q) for q in p if q)
def risk(p):return min(sum(a*b for a,b in zip(p,LOSS_RELEASE)),sum(a*b for a,b in zip(p,LOSS_HOLD)))
def upd(p, probs, yes):
 q=[a*(b if yes else 1-b) for a,b in zip(p,probs)];d=sum(q);return [x/d for x in q]
def score(test):
 l=TESTS[test];py=sum(a*b for a,b in zip(PRIOR,l)); p1=upd(PRIOR,l,True);p0=upd(PRIOR,l,False)
 ig=entropy(PRIOR)-py*entropy(p1)-(1-py)*entropy(p0)
 evsi=risk(PRIOR)-py*risk(p1)-(1-py)*risk(p0)
 return {'information_gain_bits':round(ig,8),'evsi_before_test_cost':round(evsi,8),
         'net_decision_value':round(evsi-TEST_COST,8),
         'risk_without_test':risk(PRIOR), 'risk_after_test_expected':round(risk(PRIOR)-evsi,8)}
if __name__=='__main__':
 import json
 scores={t:score(t) for t in TESTS}
 print(json.dumps({'source':'synthetic exact counterexample, not field study',
 'diagnostic_entropy_policy':max(TESTS,key=lambda t:scores[t]['information_gain_bits']),
 'decision_value_policy':max(TESTS,key=lambda t:scores[t]['net_decision_value']),
 'scores':scores},indent=2))
