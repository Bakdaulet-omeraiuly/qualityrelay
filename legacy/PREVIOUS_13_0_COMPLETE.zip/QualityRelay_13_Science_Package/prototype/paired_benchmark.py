"""Synthetic benchmark for peer_decision.py: reports results; not evidence of factory efficacy."""
import csv, json, math, random, statistics
from pathlib import Path
from peer_decision import *

SCENARIOS = {
 'reference': {'prior': PRIOR, 'available': ('slot','tab','assembly')},
 'rare_fault': {'prior': (0.94,0.025,0.025,0.01), 'available': ('slot','tab','assembly')},
 'missing_assembly': {'prior': PRIOR, 'available': ('slot','tab')},
 'only_slot': {'prior': PRIOR, 'available': ('slot',)},
}


def one(seed, config, method):
    rnd=random.Random(seed)
    p=config['prior']
    u=rnd.random(); total=0; h=0
    for i,pr in enumerate(p):
        total+=pr
        if u <= total:
            h=i; break
    # Common random numbers across policies even if inspection choice differs.
    signals={t:rnd.random() < LIKELIHOOD[t][h] for t in LIKELIHOOD}
    physical_failure=(rnd.random() < FAIL_RATE[h])
    if method=='random':
        action=random.Random(seed+500_000).choice(config['available']) if config['available'] else None
    else: action=choose_inspection(p,config['available'],method=method)
    posterior=update(p,action,signals[action]) if action else p
    decision,_=best_decision(posterior)
    cost=TEST_COST[action] if action else 0.0
    if decision=='HOLD': cost += HOLD_COST
    elif physical_failure: cost += FALSE_RELEASE_COST
    return {'seed':seed,'hypothesis':HYPOTHESES[h], 'test':action or 'no_test',
            'decision':decision,'cost':cost,'physical_failure_simulated':physical_failure,
            'predicted_failure_probability':failure_risk(posterior)}


def ci_paired(a,b):
    x=[ra-rb for ra,rb in zip(a,b)]
    n=len(x); mu=statistics.mean(x)
    se=statistics.stdev(x)/math.sqrt(n)
    return [round(mu-1.96*se,5),round(mu+1.96*se,5)]


def run(n=5000, outfile=None):
    report={'description':'INTERNAL SYNTHETIC ONE-STEP MONTE CARLO: not an industrial validation',
            'seed_schedule':'seed=901000 + trial_index; common simulation across policies',
            'n_per_scenario':n, 'scenarios':{}}
    for name,config in SCENARIOS.items():
        variants=['none','random','ig','decision']
        trials={m:[one(901000+i,config,m) for i in range(n)] for m in variants}
        losses={m:[r['cost'] for r in trials[m]] for m in variants}
        rr={}
        for m in variants:
            arr=trials[m]
            rr[m]={'mean_cost':round(statistics.mean(losses[m]),5),
                  'hold_rate':round(sum(r['decision']=='HOLD' for r in arr)/n,5),
                  'inspection_rate':round(sum(r['test']!='no_test' for r in arr)/n,5),
                  'false_release_rate':round(sum(r['decision']!='HOLD' and r['physical_failure_simulated'] for r in arr)/n,5),
                  'mean_predicted_failure_risk':round(statistics.mean(r['predicted_failure_probability'] for r in arr),5)}
        rr['comparisons']={'decision_minus_ig_ci95':ci_paired(losses['decision'],losses['ig']),
                            'decision_minus_none_ci95':ci_paired(losses['decision'],losses['none'])}
        report['scenarios'][name]=rr
    if outfile: Path(outfile).write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
    return report

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--n',type=int,default=5000);ap.add_argument('--out',default='results/benchmark.json')
    args=ap.parse_args();print(json.dumps(run(args.n,args.out),indent=2))
