# Research integrity: exactly what has and has not been done

Date: 2026-10-30. This is an evidence-based **research synthesis and runnable synthetic reference**. It is not a literature-wide proof of novelty, a patentability opinion, or validated industrial science.

- The bibliography lists **18 selectively verified references**, based on publisher/official pages and primary abstracts or identified sections. The number does **not** equal 10,000 or even a systematic literature review.
- The previously packaged 10,000-record collector is a **collection plan/script**, not a corpus already collected, read, deduplicated, screened, or independently assessed. It remains inside the preserved legacy packages; verify its behavior before production use.
- Already known: entropy/IG-driven inspection, EVSI, decentralized fusion, proof/provenance, specialist agents, and evidence arbitration. **Do not claim first-in-world novelty for these alone.**
- Proposed applied research: **safe decision-sensitive evidence selection under partial authorization and network partitions**, combined with physical assembly/sorting. Novelty is **candidate integration plus empirical evaluation**, not a validated new scientific law.
- `prototype/` contains a toy discrete Bayesian model and proof-of-concept safety checks. It does not contain a real distributed runtime, real AI models, secure network stack, or hardware controllers.
- Numerical values are synthetic and explicitly specified by source code; no result indicates manufacturing savings or industrial readiness.
- Report both supportive and negative/null comparisons. In our 5,000-trial **reference** simulation, IG and EVSI choose the same test with the same cost; this is informative. In the constructed exact counterexample, decision utility and diagnostic entropy diverge, which **illustrates established theory** rather than discovering a new law.
- Numerical approximate 95% CIs in benchmark rely on paired independent seeds and normal approximation; report full seeds, scenarios, model parameters, and the complete benchmark JSON.
- Release claims must pass: code tests, actual separate-process peer test, no raw access leakage, physical measurement, measured classifier performance, repeated seeded experiments, and human safety review.
